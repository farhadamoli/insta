<?php

/**
 * فایل اصلی برنامه
 *
 * تمام درخواست‌ها از طریق این فایل هدایت می‌شوند
 */

// تعریف مسیر اصلی برنامه
define('ROOT_PATH', __DIR__);

// تنظیم autoloader دستی
spl_autoload_register(function ($class) {
    // تبدیل namespace به مسیر فایل
    $prefix = '';
    $baseDir = __DIR__ . '/';

    // اگر کلاس با App شروع می‌شود
    if (strpos($class, 'App\\') === 0) {
        $prefix = 'App\\';
        $baseDir = __DIR__ . '/app/';
    }

    // حذف پیشوند از نام کلاس
    $relativeClass = substr($class, strlen($prefix));

    // تبدیل \ به / برای مسیر فایل
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    // بررسی وجود فایل
    if (file_exists($file)) {
        require $file;
        return true;
    }

    return false;
});

// بارگذاری تنظیمات
$config = require_once 'app/config/config.php';

// تنظیم timezone
date_default_timezone_set($config['app']['timezone'] ?? 'Asia/Tehran');

// شروع جلسه (session)
session_name($config['security']['session_name'] ?? 'edameye_session');
session_start();

// تنظیم error reporting بر اساس محیط برنامه
if (($config['app']['environment'] ?? 'production') === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// تنظیم error handler
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (error_reporting() === 0) {
        return false;
    }

    $error = "Error [$errno] $errstr in $errfile on line $errline";
    error_log($error);

    if (in_array($errno, [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
        throw new ErrorException($error, $errno, 0, $errfile, $errline);
    }

    return true;
});

// تنظیم exception handler
set_exception_handler(function ($exception) use ($config) {
    $error = "Uncaught Exception: " . $exception->getMessage() . " in " . $exception->getFile() . " on line " . $exception->getLine();
    error_log($error);

    http_response_code(500);

    if (($config['app']['debug'] ?? false) === true) {
        echo "<h1>خطای سیستم</h1>";
        echo "<p>$error</p>";
        echo "<pre>" . $exception->getTraceAsString() . "</pre>";
    } else {
        // نمایش صفحه خطای عمومی
        echo "<h1>خطای سیستم</h1>";
        echo "<p>متأسفانه خطایی رخ داده است. لطفاً بعداً مجدداً تلاش کنید.</p>";
    }

    exit;
});

try {
    // بارگذاری مسیرها و اجرای مسیریاب
    $router = require_once 'app/config/routes.php';
    $router->dispatch();
} catch (Exception $e) {
    // ثبت و نمایش خطا
    error_log("Fatal error: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());

    http_response_code(500);

    if (($config['app']['debug'] ?? false) === true) {
        echo "<h1>خطای سیستم</h1>";
        echo "<p>" . $e->getMessage() . "</p>";
        echo "<pre>" . $e->getTraceAsString() . "</pre>";
    } else {
        // نمایش صفحه خطای عمومی
        echo "<h1>خطای سیستم</h1>";
        echo "<p>متأسفانه خطایی رخ داده است. لطفاً بعداً مجدداً تلاش کنید.</p>";
    }

    exit;
}