<?php
/**
 * config/config.php
 *
 * تنظیمات اصلی سیستم SOCIALKOCH.CO
 * این فایل شامل تمام متغیرهای محیطی و تنظیمات عمومی سیستم است
 */

// تنظیمات اصلی برنامه
define('APP_NAME', 'SOCIALKOCH.CO');
define('APP_URL', 'http://localhost/socialkoch'); // در محیط تولید تغییر داده شود
define('APP_VERSION', '1.0.0');
define('APP_LANGUAGE', 'fa'); // زبان پیش‌فرض (فارسی)
define('DEFAULT_TIMEZONE', 'Asia/Tehran');

// تنظیم منطقه زمانی
date_default_timezone_set(DEFAULT_TIMEZONE);

// مسیرهای ثابت
define('ROOT_PATH', dirname(__DIR__));
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('VIEWS_PATH', ROOT_PATH . '/views');
define('LANG_PATH', ROOT_PATH . '/lang');
define('LIBRARIES_PATH', ROOT_PATH . '/libraries');
define('LOGS_PATH', ROOT_PATH . '/logs');
define('CACHE_PATH', ROOT_PATH . '/cache');

// تنظیمات امنیتی
define('HASH_COST', 12); // هزینه هش کردن رمز عبور
define('SESSION_LIFETIME', 86400); // طول عمر جلسه به ثانیه (۲۴ ساعت)
define('CSRF_TOKEN_LIFETIME', 3600); // طول عمر توکن CSRF به ثانیه (۱ ساعت)
define('MIN_PASSWORD_LENGTH', 8); // حداقل طول رمز عبور
define('PASSWORD_RESET_TOKEN_LIFETIME', 3600); // طول عمر توکن بازنشانی رمز عبور (۱ ساعت)

// کلیدهای API
define('OPENAI_API_KEY', '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');
define('RAPIDAPI_HOST', 'social-api4.p.rapidapi.com');
define('RAPIDAPI_KEY', '8bd55d1178mshf90fd8b82a016e2p1d058fjsn1ddef23ef86e');

// تنظیمات OpenAI
define('OPENAI_DEFAULT_MODEL', 'gpt-4'); // مدل پیش‌فرض
define('OPENAI_DEFAULT_TEMPERATURE', 0.7); // دمای پیش‌فرض
define('OPENAI_DEFAULT_TIMEOUT', 60); // زمان انتظار به ثانیه
define('OPENAI_DEFAULT_MAX_TOKENS', 2000); // حداکثر تعداد توکن‌های خروجی

// تنظیمات اشتراک
define('SUBSCRIPTION_MONTHLY', 100000);  // ۳۰ روزه - ۱۰۰,۰۰۰ تومان
define('SUBSCRIPTION_QUARTERLY', 500000); // ۹۰ روزه - ۵۰۰,۰۰۰ تومان
define('SUBSCRIPTION_YEARLY', 2000000);  // ۳۶۵ روزه - ۲,۰۰۰,۰۰۰ تومان

// تنظیمات محدودیت استفاده از API
define('API_DAILY_LIMIT', 100); // حداکثر تعداد درخواست روزانه
define('API_HOURLY_LIMIT', 20); // حداکثر تعداد درخواست در ساعت
define('API_IMAGE_GENERATION_LIMIT', 50); // حداکثر تعداد تصویر تولید شده روزانه

// تنظیمات آپلود فایل
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // حداکثر اندازه فایل آپلودی (۱۰ مگابایت)
define('ALLOWED_IMAGE_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']); // پسوندهای مجاز تصویر
define('ALLOWED_DOCUMENT_EXTENSIONS', ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt']); // پسوندهای مجاز اسناد

// تنظیمات درگاه پرداخت
define('DEFAULT_PAYMENT_GATEWAY', 'zarinpal'); // درگاه پرداخت پیش‌فرض
define('ZARINPAL_MERCHANT_ID', ''); // شناسه پذیرنده زرین‌پال (در محیط تولید تکمیل شود)
define('ZARINPAL_SANDBOX', true); // استفاده از محیط تست
define('ZARINPAL_CALLBACK_URL', APP_URL . '/payment/verify'); // آدرس بازگشت از درگاه

// تنظیمات ایمیل
define('MAIL_HOST', 'smtp.gmail.com'); // سرور SMTP
define('MAIL_PORT', 587); // پورت SMTP
define('MAIL_USERNAME', ''); // نام کاربری SMTP (در محیط تولید تکمیل شود)
define('MAIL_PASSWORD', ''); // رمز عبور SMTP (در محیط تولید تکمیل شود)
define('MAIL_ENCRYPTION', 'tls'); // رمزنگاری SMTP
define('MAIL_FROM_ADDRESS', 'info@socialkoch.co'); // آدرس ایمیل فرستنده
define('MAIL_FROM_NAME', 'SOCIALKOCH.CO'); // نام فرستنده

// تنظیمات کش
define('CACHE_ENABLED', true); // فعال‌سازی کش
define('CACHE_LIFETIME', 3600); // طول عمر کش به ثانیه (۱ ساعت)

// تنظیمات لاگ
define('LOG_ENABLED', true); // فعال‌سازی لاگ
define('LOG_LEVEL', 'error'); // سطح لاگ (debug, info, notice, warning, error, critical, alert, emergency)

// تنظیمات مربوط به چندزبانگی
define('ENABLE_MULTILINGUAL', true); // فعال‌سازی پشتیبانی چندزبانه
define('AVAILABLE_LANGUAGES', ['fa', 'en', 'ar']); // زبان‌های موجود

// تنظیمات نمایش خطا
define('DISPLAY_ERRORS', true); // نمایش خطا (در محیط تولید false شود)
define('LOG_ERRORS', true); // ثبت خطاها در لاگ

// تنظیمات تحلیل اینستاگرام
define('INSTAGRAM_DAILY_ANALYSIS_LIMIT', 5); // حداکثر تعداد تحلیل روزانه
define('INSTAGRAM_POST_FETCH_LIMIT', 50); // حداکثر تعداد پست‌های قابل دریافت

// تنظیمات امنیتی سشن
define('SESSION_SECURE', false); // استفاده از کوکی امن (در محیط تولید true شود)
define('SESSION_HTTP_ONLY', true); // استفاده از ویژگی HttpOnly برای کوکی‌ها
define('SESSION_REGENERATE_ID', true); // بازسازی ID جلسه در هر بار ورود

// تنظیمات رابط کاربری
define('UI_DEFAULT_THEME', 'light'); // تم پیش‌فرض رابط کاربری
define('UI_ENABLE_RTL', true); // فعال‌سازی پشتیبانی از RTL
define('UI_ITEMS_PER_PAGE', 20); // تعداد آیتم‌ها در هر صفحه
define('UI_MAX_PAGINATION_LINKS', 5); // حداکثر تعداد لینک‌های صفحه‌بندی

// تنظیمات مدیریت محتوا
define('CONTENT_MAX_TITLE_LENGTH', 100); // حداکثر طول عنوان محتوا
define('CONTENT_MAX_DESCRIPTION_LENGTH', 500); // حداکثر طول توضیحات محتوا
define('CONTENT_MIN_CONTENT_LENGTH', 100); // حداقل طول محتوا

// تنظیمات سیستم
define('MAINTENANCE_MODE', false); // حالت تعمیر و نگهداری
define('MAINTENANCE_MESSAGE', 'سیستم در حال بروزرسانی است. لطفاً بعداً مراجعه کنید.'); // پیام تعمیر و نگهداری

// تنظیم بازنویسی خطا برای محیط توسعه
if (DISPLAY_ERRORS) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
}

// تنظیمات جلسه
session_start([
    'cookie_lifetime' => SESSION_LIFETIME,
    'cookie_httponly' => SESSION_HTTP_ONLY,
    'cookie_secure' => SESSION_SECURE,
    'use_strict_mode' => true,
    'use_cookies' => true,
    'use_only_cookies' => true,
    'name' => 'SOCIALKOCH_SESSION',
]);

// بازسازی ID جلسه برای جلوگیری از session fixation
if (SESSION_REGENERATE_ID && !empty($_SESSION['user_id'])) {
    session_regenerate_id();
}

// تنظیم سربرگ‌های امنیتی
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

// تنظیم کش‌کنترل برای جلوگیری از کش شدن صفحات حساس
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// بستن درگاه‌های امنیتی
ini_set('allow_url_fopen', 0);
ini_set('allow_url_include', 0);