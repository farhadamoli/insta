<?php
/**
 * config/database.php
 *
 * تنظیمات پایگاه داده سیستم SOCIALKOCH.CO
 * این فایل شامل تنظیمات اتصال به پایگاه داده MySQL است
 */

// تنظیمات اتصال به پایگاه داده
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // در محیط تولید تغییر داده شود
define('DB_PASS', ''); // در محیط تولید تغییر داده شود
define('DB_NAME', 'socialkoch2');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATION', 'utf8mb4_persian_ci'); // برای پشتیبانی از زبان فارسی
define('DB_PORT', 3306); // پورت پیش‌فرض MySQL

// تنظیمات PDO
define('PDO_ATTR_ERRMODE', PDO::ERRMODE_EXCEPTION); // نحوه مدیریت خطاها
define('PDO_ATTR_DEFAULT_FETCH_MODE', PDO::FETCH_ASSOC); // حالت پیش‌فرض دریافت نتایج
define('PDO_ATTR_EMULATE_PREPARES', false); // غیرفعال کردن شبیه‌سازی prepared statements

// تنظیمات کانکشن پول
define('DB_PERSISTENT', false); // استفاده از اتصال دائمی
define('DB_TIMEOUT', 30); // زمان انتظار اتصال به ثانیه

// تنظیمات بکاپ‌گیری
define('DB_BACKUP_PATH', ROOT_PATH . '/backups/database'); // مسیر ذخیره فایل‌های بکاپ
define('DB_BACKUP_COMPRESS', true); // فشرده‌سازی فایل‌های بکاپ
define('DB_BACKUP_WITH_DROP', true); // اضافه کردن دستور DROP TABLE به بکاپ

/**
 * تابع اتصال به پایگاه داده
 *
 * این تابع یک اتصال PDO به پایگاه داده ایجاد می‌کند
 *
 * @return PDO|false شیء PDO یا false در صورت بروز خطا
 */
function db_connect() {
    try {
        // ساخت DSN
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

        // اضافه کردن پورت به DSN اگر مقدار پیش‌فرض نباشد
        if (DB_PORT !== 3306) {
            $dsn .= ";port=" . DB_PORT;
        }

        // تنظیمات اتصال
        $options = [
            PDO::ATTR_ERRMODE => PDO_ATTR_ERRMODE,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO_ATTR_DEFAULT_FETCH_MODE,
            PDO::ATTR_EMULATE_PREPARES => PDO_ATTR_EMULATE_PREPARES,
        ];

        // اضافه کردن پرچم اتصال دائمی اگر فعال باشد
        if (DB_PERSISTENT) {
            $options[PDO::ATTR_PERSISTENT] = true;
        }

        // ایجاد شیء PDO
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);

        // تنظیم timeout برای اتصال
        $pdo->setAttribute(PDO::ATTR_TIMEOUT, DB_TIMEOUT);

        // تنظیم collation فارسی
        $pdo->exec("SET NAMES " . DB_CHARSET . " COLLATE " . DB_COLLATION);

        return $pdo;
    } catch (PDOException $e) {
        // ثبت خطا در لاگ
        if (defined('LOG_ERRORS') && LOG_ERRORS) {
            error_log('Database Connection Error: ' . $e->getMessage());
        }

        // نمایش خطا در صورت فعال بودن
        if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
            echo 'خطا در اتصال به پایگاه داده: ' . $e->getMessage();
        }

        return false;
    }
}

/**
 * بررسی اتصال به پایگاه داده
 *
 * این تابع بررسی می‌کند که آیا اتصال به پایگاه داده برقرار است یا خیر
 *
 * @return bool وضعیت اتصال
 */
function db_check_connection() {
    $pdo = db_connect();
    return ($pdo !== false);
}

/**
 * بررسی وجود جدول در پایگاه داده
 *
 * @param string $table نام جدول
 * @return bool وضعیت وجود جدول
 */
function db_table_exists($table) {
    $pdo = db_connect();

    if ($pdo === false) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("SHOW TABLES LIKE :table");
        $stmt->execute(['table' => $table]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * گرفتن اطلاعات جدول
 *
 * @param string $table نام جدول
 * @return array|false اطلاعات جدول یا false در صورت بروز خطا
 */
function db_get_table_info($table) {
    $pdo = db_connect();

    if ($pdo === false) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("DESCRIBE :table");
        $stmt->execute(['table' => $table]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * ایجاد بکاپ از پایگاه داده
 *
 * @return string|false مسیر فایل بکاپ یا false در صورت بروز خطا
 */
function db_create_backup() {
    // بررسی وجود مسیر بکاپ
    if (!file_exists(DB_BACKUP_PATH)) {
        if (!mkdir(DB_BACKUP_PATH, 0755, true)) {
            return false;
        }
    }

    // نام فایل بکاپ
    $filename = DB_BACKUP_PATH . '/' . DB_NAME . '_' . date('Y-m-d_H-i-s') . '.sql';

    // ساخت دستور mysqldump
    $command = sprintf(
        'mysqldump --host=%s --user=%s --password=%s --port=%s %s',
        escapeshellarg(DB_HOST),
        escapeshellarg(DB_USER),
        escapeshellarg(DB_PASS),
        escapeshellarg(DB_PORT),
        escapeshellarg(DB_NAME)
    );

    // اضافه کردن پرچم‌های اضافی
    if (DB_BACKUP_WITH_DROP) {
        $command .= ' --add-drop-table';
    }

    // هدایت خروجی به فایل
    $command .= ' > ' . escapeshellarg($filename);

    // اجرای دستور
    system($command, $return_var);

    // بررسی موفقیت عملیات
    if ($return_var !== 0) {
        return false;
    }

    // فشرده‌سازی فایل در صورت نیاز
    if (DB_BACKUP_COMPRESS && extension_loaded('zip')) {
        $zip = new ZipArchive();
        $zipFile = $filename . '.zip';

        if ($zip->open($zipFile, ZipArchive::CREATE) === true) {
            $zip->addFile($filename, basename($filename));
            $zip->close();

            // حذف فایل اصلی
            unlink($filename);

            return $zipFile;
        }
    }

    return $filename;
}

// اتصال اولیه به پایگاه داده برای بررسی
$db_connection_check = db_check_connection();

// نمایش وضعیت اتصال در حالت دیباگ
if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS && !$db_connection_check) {
    echo '<div style="padding: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;">خطا در اتصال به پایگاه داده. لطفاً تنظیمات را بررسی کنید.</div>';
}