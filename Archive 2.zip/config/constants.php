<?php
/**
 * config/constants.php
 *
 * تعریف ثابت‌های سیستم SOCIALKOCH.CO
 * این فایل شامل ثابت‌هایی است که در بخش‌های مختلف سیستم استفاده می‌شوند
 */

// نقش‌های کاربری
define('ROLE_SUPERADMIN', 1);
define('ROLE_ADMIN', 2);
define('ROLE_USER', 3);

// وضعیت‌های کاربر
define('USER_STATUS_ACTIVE', 1);
define('USER_STATUS_INACTIVE', 2);
define('USER_STATUS_BANNED', 3);
define('USER_STATUS_PENDING', 4);

// وضعیت‌های اشتراک
define('SUBSCRIPTION_ACTIVE', 1);
define('SUBSCRIPTION_EXPIRED', 2);
define('SUBSCRIPTION_PENDING', 3);
define('SUBSCRIPTION_CANCELLED', 4);

// وضعیت‌های پرداخت
define('PAYMENT_PENDING', 1);
define('PAYMENT_COMPLETED', 2);
define('PAYMENT_FAILED', 3);
define('PAYMENT_REFUNDED', 4);

// وضعیت‌های تیکت پشتیبانی
define('TICKET_OPEN', 1);
define('TICKET_ANSWERED', 2);
define('TICKET_CLOSED', 3);
define('TICKET_PENDING', 4);

// انواع محتوا
define('CONTENT_TYPE_POST', 1);
define('CONTENT_TYPE_STORY', 2);
define('CONTENT_TYPE_CAROUSEL', 3);
define('CONTENT_TYPE_VIDEO', 4);
define('CONTENT_TYPE_REELS', 5);

// وضعیت‌های محتوا
define('CONTENT_STATUS_PLANNED', 1);
define('CONTENT_STATUS_PUBLISHED', 2);
define('CONTENT_STATUS_SKIPPED', 3);
define('CONTENT_STATUS_DRAFT', 4);

// انواع پست
define('POST_TYPE_IMAGE', 1);
define('POST_TYPE_VIDEO', 2);
define('POST_TYPE_CAROUSEL', 3);
define('POST_TYPE_REELS', 4);

// انواع استوری
define('STORY_TYPE_IMAGE', 1);
define('STORY_TYPE_VIDEO', 2);
define('STORY_TYPE_POLL', 3);
define('STORY_TYPE_QUESTION', 4);
define('STORY_TYPE_QUIZ', 5);
define('STORY_TYPE_SLIDER', 6);
define('STORY_TYPE_COUNTDOWN', 7);
define('STORY_TYPE_PRODUCT', 8);

// وضعیت‌های تحلیل اینستاگرام
define('ANALYSIS_STATUS_PENDING', 1);
define('ANALYSIS_STATUS_PROCESSING', 2);
define('ANALYSIS_STATUS_COMPLETED', 3);
define('ANALYSIS_STATUS_FAILED', 4);

// انواع تصاویر تولیدی
define('IMAGE_TYPE_PROFILE', 1);
define('IMAGE_TYPE_POST', 2);
define('IMAGE_TYPE_STORY', 3);
define('IMAGE_TYPE_COVER', 4);
define('IMAGE_TYPE_PRODUCT', 5);
define('IMAGE_TYPE_GENERAL', 6);

// وضعیت‌های تولید تصویر
define('IMAGE_STATUS_PENDING', 1);
define('IMAGE_STATUS_COMPLETED', 2);
define('IMAGE_STATUS_FAILED', 3);

// انواع اعلان‌ها
define('NOTIFICATION_TYPE_INFO', 1);
define('NOTIFICATION_TYPE_SUCCESS', 2);
define('NOTIFICATION_TYPE_WARNING', 3);
define('NOTIFICATION_TYPE_ERROR', 4);

// وضعیت‌های اعلان
define('NOTIFICATION_STATUS_UNREAD', 1);
define('NOTIFICATION_STATUS_READ', 2);

// وضعیت‌های پیام
define('MESSAGE_STATUS_SENT', 1);
define('MESSAGE_STATUS_DELIVERED', 2);
define('MESSAGE_STATUS_READ', 3);
define('MESSAGE_STATUS_FAILED', 4);

// انواع فایل‌های آپلودی
define('FILE_TYPE_IMAGE', 1);
define('FILE_TYPE_VIDEO', 2);
define('FILE_TYPE_DOCUMENT', 3);
define('FILE_TYPE_AUDIO', 4);
define('FILE_TYPE_OTHER', 5);

// انواع گزارش‌ها
define('REPORT_TYPE_DAILY', 1);
define('REPORT_TYPE_WEEKLY', 2);
define('REPORT_TYPE_MONTHLY', 3);
define('REPORT_TYPE_CUSTOM', 4);

// وضعیت‌های وبلاگ
define('BLOG_STATUS_PUBLISHED', 1);
define('BLOG_STATUS_DRAFT', 2);
define('BLOG_STATUS_PENDING', 3);
define('BLOG_STATUS_REJECTED', 4);

// انواع پروژه وب‌سایت
define('WEBSITE_TYPE_NORMAL', 1);
define('WEBSITE_TYPE_SHOP', 2);
define('WEBSITE_TYPE_LANDING', 3);
define('WEBSITE_TYPE_BLOG', 4);

// وضعیت‌های پروژه وب‌سایت
define('WEBSITE_STATUS_DRAFT', 1);
define('WEBSITE_STATUS_PUBLISHED', 2);
define('WEBSITE_STATUS_ARCHIVED', 3);

// انواع سبک محتوا
define('CONTENT_STYLE_INFORMATIVE', 1);
define('CONTENT_STYLE_ENTERTAINING', 2);
define('CONTENT_STYLE_INSPIRING', 3);
define('CONTENT_STYLE_PROMOTIONAL', 4);
define('CONTENT_STYLE_STORYTELLING', 5);
define('CONTENT_STYLE_BEHIND_THE_SCENES', 6);
define('CONTENT_STYLE_USER_GENERATED', 7);
define('CONTENT_STYLE_Q_AND_A', 8);
define('CONTENT_STYLE_HOW_TO', 9);
define('CONTENT_STYLE_TIPS_AND_TRICKS', 10);

// انواع لحن کپشن
define('CAPTION_TONE_PROFESSIONAL', 1);
define('CAPTION_TONE_CASUAL', 2);
define('CAPTION_TONE_HUMOROUS', 3);
define('CAPTION_TONE_INSPIRATIONAL', 4);
define('CAPTION_TONE_EDUCATIONAL', 5);
define('CAPTION_TONE_PROMOTIONAL', 6);
define('CAPTION_TONE_FORMAL', 7);
define('CAPTION_TONE_STORYTELLING', 8);
define('CAPTION_TONE_PERSONAL', 9);
define('CAPTION_TONE_POETIC', 10);

// مسیرهای آپلود
define('UPLOAD_PATH_PROFILE_IMAGES', UPLOADS_PATH . '/profiles');
define('UPLOAD_PATH_INSTAGRAM_PROFILES', UPLOADS_PATH . '/instagram/profiles');
define('UPLOAD_PATH_INSTAGRAM_POSTS', UPLOADS_PATH . '/instagram/posts');
define('UPLOAD_PATH_GENERATED_IMAGES', UPLOADS_PATH . '/generated/images');
define('UPLOAD_PATH_TEMP', UPLOADS_PATH . '/temp');
define('UPLOAD_PATH_BLOG', UPLOADS_PATH . '/blog');
define('UPLOAD_PATH_DOCUMENTS', UPLOADS_PATH . '/documents');

// محدودیت‌های اشتراک پایه
define('BASE_SUBSCRIPTION_INSTAGRAM_PAGES', 3); // تعداد پیج‌های قابل ثبت در اشتراک پایه
define('BASE_SUBSCRIPTION_CONTENT_DAILY', 10); // تعداد محتوای قابل تولید روزانه در اشتراک پایه
define('BASE_SUBSCRIPTION_IMAGES_DAILY', 5); // تعداد تصویر قابل تولید روزانه در اشتراک پایه

// زمان‌های سیستم
define('SYSTEM_CLEANUP_INTERVAL', 86400); // فاصله زمانی پاکسازی فایل‌های موقت (۱ روز)
define('SYSTEM_SESSION_CLEANUP_INTERVAL', 604800); // فاصله زمانی پاکسازی جلسه‌های منقضی شده (۷ روز)
define('SYSTEM_LOG_ROTATION_INTERVAL', 2592000); // فاصله زمانی چرخش لاگ‌ها (۳۰ روز)

// کدهای خطا
define('ERROR_DATABASE_CONNECTION', 1001);
define('ERROR_INVALID_CREDENTIALS', 1002);
define('ERROR_ACCESS_DENIED', 1003);
define('ERROR_RESOURCE_NOT_FOUND', 1004);
define('ERROR_FILE_UPLOAD', 1005);
define('ERROR_API_REQUEST', 1006);
define('ERROR_OPENAI_REQUEST', 1007);
define('ERROR_RAPIDAPI_REQUEST', 1008);
define('ERROR_PAYMENT_PROCESS', 1009);
define('ERROR_GENERAL', 9999);

// ترجمه وضعیت‌ها به فارسی
$GLOBALS['status_translations'] = [
    // وضعیت‌های اشتراک
    SUBSCRIPTION_ACTIVE => 'فعال',
    SUBSCRIPTION_EXPIRED => 'منقضی شده',
    SUBSCRIPTION_PENDING => 'در انتظار تایید',
    SUBSCRIPTION_CANCELLED => 'لغو شده',

    // وضعیت‌های پرداخت
    PAYMENT_PENDING => 'در انتظار پرداخت',
    PAYMENT_COMPLETED => 'پرداخت شده',
    PAYMENT_FAILED => 'ناموفق',
    PAYMENT_REFUNDED => 'بازگشت وجه',

    // وضعیت‌های تیکت
    TICKET_OPEN => 'باز',
    TICKET_ANSWERED => 'پاسخ داده شده',
    TICKET_CLOSED => 'بسته شده',
    TICKET_PENDING => 'در انتظار بررسی',

    // وضعیت‌های محتوا
    CONTENT_STATUS_PLANNED => 'برنامه‌ریزی شده',
    CONTENT_STATUS_PUBLISHED => 'منتشر شده',
    CONTENT_STATUS_SKIPPED => 'رد شده',
    CONTENT_STATUS_DRAFT => 'پیش‌نویس',

    // وضعیت‌های کاربر
    USER_STATUS_ACTIVE => 'فعال',
    USER_STATUS_INACTIVE => 'غیرفعال',
    USER_STATUS_BANNED => 'مسدود شده',
    USER_STATUS_PENDING => 'در انتظار تأیید'
];

/**
 * تبدیل کد وضعیت به متن فارسی
 *
 * @param int $status_code کد وضعیت
 * @return string متن فارسی وضعیت یا کد وضعیت اگر ترجمه‌ای نداشت
 */
function get_status_text($status_code) {
    global $status_translations;

    if (isset($status_translations[$status_code])) {
        return $status_translations[$status_code];
    }

    return "کد {$status_code}";
}

/**
 * تبدیل رشته به slugified string
 *
 * @param string $string رشته ورودی
 * @return string رشته slug شده
 */
function create_slug($string) {
    // حذف کاراکترهای خاص و جایگزینی با -
    $string = preg_replace('/[^\p{L}\p{N}]+/u', '-', $string);
    // حذف - از ابتدا و انتهای رشته
    $string = trim($string, '-');
    // تبدیل به حروف کوچک
    $string = mb_strtolower($string, 'UTF-8');

    return $string;
}