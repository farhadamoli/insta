/* 
 * File: controllers/InstagramController.php
 * Description: Controller for handling Instagram-related features
 */

<?php
class InstagramController {
    private $db;
    private $auth;
    private $instagramModel;
    
    public function __construct() {
        global $app;
        $this->db = $app->db;
        $this->auth = $app->auth;
        $this->instagramModel = new InstagramModel($this->db);
        
        // Check if user is logged in
        if (!$this->auth->isLoggedIn()) {
            App::redirect('login');
        }
        
        // Check if user has subscription for Instagram features
        if (!$this->auth->canAccessFeature(1)) { // 1 = Instagram Page Analysis feature ID
            // Store intended URL for redirect after subscription
            $_SESSION['redirect_after_subscription'] = $_SERVER['REQUEST_URI'];
            App::redirect('dashboard/subscription');
        }
    }
    
    /**
     * Instagram services landing page
     */
    public function index() {
        $user = $this->auth->getUser();
        $pages = $this->instagramModel->getUserPages($user['id']);
        
        return App::view('dashboard.instagram.index', [
            'user' => $user,
            'pages' => $pages
        ]);
    }
    
    /**
     * Register a new Instagram page
     */
    public function registerPageForm() {
        $user = $this->auth->getUser();
        $businessCategories = $this->instagramModel->getBusinessCategories();
        $specialistCategories = $this->instagramModel->getSpecialistCategories();
        
        return App::view('dashboard.instagram.register_page', [
            'user' => $user,
            'businessCategories' => $businessCategories,
            'specialistCategories' => $specialistCategories
        ]);
    }
    
    /**
     * Process Instagram page registration
     */
    public function registerPage() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/instagram');
        }
        
        $user = $this->auth->getUser();
        $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $businessCategory = filter_input(INPUT_POST, 'business_category', FILTER_SANITIZE_STRING);
        $specialistCategory = filter_input(INPUT_POST, 'specialist_category', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        $startDate = filter_input(INPUT_POST, 'start_date', FILTER_SANITIZE_STRING);
        
        // Validate inputs
        if (empty($username)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'نام کاربری اینستاگرام را وارد کنید.'
            ];
            App::redirect('dashboard/instagram/register-page');
        }
        
        // Check if the page already exists for this user
        if ($this->instagramModel->pageExists($user['id'], $username)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'این پیج قبلاً برای حساب شما ثبت شده است.'
            ];
            App::redirect('dashboard/instagram/register-page');
        }
        
        // Fetch Instagram data from the API
        $instagramData = $this->instagramModel->fetchInstagramProfile($username);
        
        if (!$instagramData || isset($instagramData['error'])) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'اطلاعات پیج اینستاگرام یافت نشد. لطفاً نام کاربری را بررسی کنید.'
            ];
            App::redirect('dashboard/instagram/register-page');
        }
        
        // Save the page
        $pageData = [
            'user_id' => $user['id'],
            'username' => $username,
            'business_category' => $businessCategory,
            'specialist_category' => $specialistCategory,
            'description' => $description,
            'start_date' => $startDate,
            'profile_image' => $instagramData['profile_pic_url'] ?? null,
            'follower_count' => $instagramData['edge_followed_by']['count'] ?? 0,
            'following_count' => $instagramData['edge_follow']['count'] ?? 0,
            'post_count' => $instagramData['edge_owner_to_timeline_media']['count'] ?? 0,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $pageId = $this->instagramModel->addPage($pageData);
        
        if (!$pageId) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در ثبت پیج اینستاگرام پیش آمد. لطفاً دوباره تلاش کنید.'
            ];
            App::redirect('dashboard/instagram/register-page');
        }
        
        // Save profile image locally
        if (isset($instagramData['profile_pic_url']) && !empty($instagramData['profile_pic_url'])) {
            $profileImagePath = UPLOADS_PATH . '/instagram/profiles/' . $pageId . '.jpg';
            Helper::saveImageFromUrl($instagramData['profile_pic_url'], $profileImagePath);
            
            // Update page with local image path
            $this->instagramModel->updatePage($pageId, [
                'profile_image' => '/uploads/instagram/profiles/' . $pageId . '.jpg'
            ]);
        }
        
        // Analyze the page (fetch more data and generate analytics)
        $this->instagramModel->analyzeInstagramPage($pageId);
        
        $_SESSION['notification'] = [
            'type' => 'success',
            'title' => 'موفقیت',
            'message' => 'پیج اینستاگرام با موفقیت ثبت و آنالیز شد.'
        ];
        
        App::redirect('dashboard/instagram/analysis/' . $pageId);
    }
    
    /**
     * Show Instagram page analysis
     */
    public function analysis($id) {
        $user = $this->auth->getUser();
        $page = $this->instagramModel->getPageById($id);
        
        // Check if page exists and belongs to this user
        if (!$page || $page['user_id'] != $user['id']) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'پیج مورد نظر یافت نشد.'
            ];
            App::redirect('dashboard/instagram');
        }
        
        // Get analytics data
        $analytics = $this->instagramModel->getPageAnalytics($id);
        
        // Get follower growth chart data
        $followersChart = $this->instagramModel->getFollowerGrowthChart($id);
        
        // Get top posts
        $topPosts = $this->instagramModel->getTopPosts($id, 3);
        
        // Get best post times
        $bestPostTimes = $this->instagramModel->getBestPostTimes($id);
        
        // Get growth factors and improvement steps
        $growthFactors = $this->instagramModel->getGrowthFactors($id);
        $improvementSteps = $this->instagramModel->getImprovementSteps($id);
        
        // Get similar accounts
        $similarAccounts = $this->instagramModel->getSimilarAccounts($id, 5);
        
        // Get growth milestones
        $growthMilestones = $this->instagramModel->getGrowthMilestones($id);
        
        // Get Instagram roadmap
        $instagramRoadmap = $this->instagramModel->getInstagramRoadmap($id);
        
        return App::view('dashboard.instagram.analysis', [
            'user' => $user,
            'instagram_page' => $page,
            'instagram_analytics' => $analytics,
            'followers_chart' => $followersChart,
            'top_posts' => $topPosts,
            'best_post_times' => $bestPostTimes,
            'growth_factors' => $growthFactors,
            'improvement_steps' => $improvementSteps,
            'similar_accounts' => $similarAccounts,
            'growth_milestones' => $growthMilestones,
            'instagram_roadmap' => $instagramRoadmap
        ]);
    }
    
    /**
     * Compare Instagram metrics between different accounts
     */
    public function compareForm() {
        $user = $this->auth->getUser();
        $pages = $this->instagramModel->getUserPages($user['id']);
        
        return App::view('dashboard.instagram.compare', [
            'user' => $user,
            'pages' => $pages
        ]);
    }
    
    /**
     * Process Instagram comparison
     */
    public function compare() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/instagram/compare');
        }
        
        $user = $this->auth->getUser();
        $pageIds = $_POST['page_ids'] ?? [];
        
        if (empty($pageIds) || count($pageIds) < 2) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'حداقل دو پیج برای مقایسه انتخاب کنید.'
            ];
            App::redirect('dashboard/instagram/compare');
        }
        
        // Verify that all pages belong to this user
        foreach ($pageIds as $pageId) {
            $page = $this->instagramModel->getPageById($pageId);
            if (!$page || $page['user_id'] != $user['id']) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'یکی از پیج‌های انتخاب شده متعلق به شما نیست.'
                ];
                App::redirect('dashboard/instagram/compare');
            }
        }
        
        // Get comparison data
        $comparisonData = $this->instagramModel->comparePages($pageIds);
        
        return App::view('dashboard.instagram.comparison_results', [
            'user' => $user,
            'comparison_data' => $comparisonData
        ]);
    }
    
    /**
     * Name suggestion form for Instagram pages
     */
    public function nameSuggestionForm() {
        $user = $this->auth->getUser();
        $categories = $this->instagramModel->getBusinessCategories();
        
        return App::view('dashboard.instagram.name_suggestion', [
            'user' => $user,
            'categories' => $categories
        ]);
    }
    
    /**
     * Process Instagram name suggestion
     */
    public function nameSuggestion() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/instagram/name-suggestion');
        }
        
        $user = $this->auth->getUser();
        $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_STRING);
        $topic = filter_input(INPUT_POST, 'topic', FILTER_SANITIZE_STRING);
        $style = filter_input(INPUT_POST, 'style', FILTER_SANITIZE_STRING);
        $language = filter_input(INPUT_POST, 'language', FILTER_SANITIZE_STRING);
        $keywords = filter_input(INPUT_POST, 'keywords', FILTER_SANITIZE_STRING);
        
        // Validate inputs
        if (empty($category) || empty($topic)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'دسته‌بندی و موضوع پیج را وارد کنید.'
            ];
            App::redirect('dashboard/instagram/name-suggestion');
        }
        
        // Generate name suggestions using OpenAI
        $suggestions = $this->instagramModel->generateNameSuggestions($category, $topic, $style, $language, $keywords);
        
        if (empty($suggestions)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در تولید پیشنهادات نام پیش آمد. لطفاً دوباره تلاش کنید.'
            ];
            App::redirect('dashboard/instagram/name-suggestion');
        }
        
        return App::view('dashboard.instagram.name_suggestion_results', [
            'user' => $user,
            'suggestions' => $suggestions,
            'category' => $category,
            'topic' => $topic,
            'style' => $style,
            'language' => $language
        ]);
    }
    
    /**
     * Refresh Instagram page analysis
     */
    public function refreshAnalysis($id) {
        // Only accept AJAX requests
        if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
            header('HTTP/1.1 403 Forbidden');
            exit;
        }
        
        $user = $this->auth->getUser();
        $page = $this->instagramModel->getPageById($id);
        
        // Check if page exists and belongs to this user
        if (!$page || $page['user_id'] != $user['id']) {
            echo json_encode([
                'success' => false,
                'message' => 'پیج مورد نظر یافت نشد.'
            ]);
            exit;
        }
        
        // Analyze the page again
        $success = $this->instagramModel->analyzeInstagramPage($id);
        
        if (!$success) {
            echo json_encode([
                'success' => false,
                'message' => 'مشکلی در بروزرسانی آنالیز پیش آمد. لطفاً دوباره تلاش کنید.'
            ]);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'آنالیز پیج با موفقیت بروزرسانی شد.'
        ]);
        exit;
    }
    
    /**
     * Export Instagram page analysis report
     */
    public function exportReport($id) {
        // Only accept AJAX requests
        if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
            header('HTTP/1.1 403 Forbidden');
            exit;
        }
        
        $user = $this->auth->getUser();
        $page = $this->instagramModel->getPageById($id);
        
        // Check if page exists and belongs to this user
        if (!$page || $page['user_id'] != $user['id']) {
            echo json_encode([
                'success' => false,
                'message' => 'پیج مورد نظر یافت نشد.'
            ]);
            exit;
        }
        
        // Generate PDF report
        $reportPath = $this->instagramModel->generateReport($id);
        
        if (!$reportPath) {
            echo json_encode([
                'success' => false,
                'message' => 'مشکلی در تهیه گزارش پیش آمد. لطفاً دوباره تلاش کنید.'
            ]);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'گزارش با موفقیت تهیه شد.',
            'fileUrl' => $reportPath,
            'fileName' => 'instagram-analysis-' . $page['username'] . '.pdf'
        ]);
        exit;
    }
}

/* 
 * File: models/InstagramModel.php
 * Description: Model for handling Instagram data
 */

<?php
class InstagramModel {
    private $db;
    
    public function __construct(Database $db) {
        $this->db = $db;
    }
    
    /**
     * Get all Instagram pages for a user
     * 
     * @param int $userId User ID
     * @return array Array of Instagram pages
     */
    public function getUserPages($userId) {
        $this->db->query("
            SELECT * FROM instagram_pages 
            WHERE user_id = :user_id 
            ORDER BY created_at DESC
        ");
        
        $this->db->bind(':user_id', $userId);
        
        return $this->db->fetchAll();
    }
    
    /**
     * Get Instagram page by ID
     * 
     * @param int $id Page ID
     * @return array|false Page data or false if not found
     */
    public function getPageById($id) {
        $this->db->query("SELECT * FROM instagram_pages WHERE id = :id");
        $this->db->bind(':id', $id);
        
        return $this->db->fetch();
    }
    
    /**
     * Check if a page already exists for a user
     * 
     * @param int $userId User ID
     * @param string $username Instagram username
     * @return bool True if exists, false otherwise
     */
    public function pageExists($userId, $username) {
        $this->db->query("
            SELECT COUNT(*) as count 
            FROM instagram_pages 
            WHERE user_id = :user_id AND LOWER(username) = LOWER(:username)
        ");
        
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':username', $username);
        
        $result = $this->db->fetch();
        
        return $result['count'] > 0;
    }
    
    /**
     * Add a new Instagram page
     * 
     * @param array $data Page data
     * @return int|false Page ID or false on failure
     */
    public function addPage($data) {
        $fields = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        
        $this->db->query("INSERT INTO instagram_pages ({$fields}) VALUES ({$placeholders})");
        
        foreach ($data as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        
        if ($this->db->execute()) {
            return $this->db->lastInsertId();
        }
        
        return false;
    }
    
    /**
     * Update an Instagram page
     * 
     * @param int $id Page ID
     * @param array $data Page data
     * @return bool Success status
     */
    public function updatePage($id, $data) {
        $setClause = [];
        
        foreach (array_keys($data) as $key) {
            $setClause[] = "{$key} = :{$key}";
        }
        
        $setString = implode(', ', $setClause);
        
        $this->db->query("UPDATE instagram_pages SET {$setString}, updated_at = NOW() WHERE id = :id");
        
        $this->db->bind(':id', $id);
        
        foreach ($data as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }
        
        return $this->db->execute();
    }
    
    /**
     * Fetch Instagram profile data from API
     * 
     * @param string $username Instagram username
     * @return array|false Profile data or false on failure
     */
    public function fetchInstagramProfile($username) {
        try {
            $headers = [
                'x-rapidapi-host' => RAPIDAPI_HOST,
                'x-rapidapi-key' => RAPIDAPI_KEY
            ];
            
            $url = "https://" . RAPIDAPI_HOST . "/v1/profile?username={$username}";
            
            $response = Helper::apiRequest($url, 'GET', [], $headers);
            
            if (!$response || isset($response['error'])) {
                return false;
            }
            
            return $response;
        } catch (Exception $e) {
            error_log('Error fetching Instagram profile: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Fetch Instagram posts for a username
     * 
     * @param string $username Instagram username
     * @return array|false Posts data or false on failure
     */
    public function fetchInstagramPosts($username) {
        try {
            $headers = [
                'x-rapidapi-host' => RAPIDAPI_HOST,
                'x-rapidapi-key' => RAPIDAPI_KEY
            ];
            
            $url = "https://" . RAPIDAPI_HOST . "/v1/posts?username_or_id_or_url={$username}";
            
            $response = Helper::apiRequest($url, 'GET', [], $headers);
            
            if (!$response || isset($response['error'])) {
                return false;
            }
            
            return $response;
        } catch (Exception $e) {
            error_log('Error fetching Instagram posts: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Analyze an Instagram page and generate analytics
     * 
     * @param int $pageId Page ID
     * @return bool Success status
     */
    public function analyzeInstagramPage($pageId) {
        // Get the page
        $page = $this->getPageById($pageId);
        
        if (!$page) {
            return false;
        }
        
        // Fetch fresh data from Instagram API
        $profileData = $this->fetchInstagramProfile($page['username']);
        $postsData = $this->fetchInstagramPosts($page['username']);
        
        if (!$profileData || !$postsData) {
            return false;
        }
        
        // Update page data
        $updatedPageData = [
            'follower_count' => $profileData['edge_followed_by']['count'] ?? $page['follower_count'],
            'following_count' => $profileData['edge_follow']['count'] ?? $page['following_count'],
            'post_count' => $profileData['edge_owner_to_timeline_media']['count'] ?? $page['post_count'],
            'last_analysis' => date('Y-m-d H:i:s')
        ];
        
        $this->updatePage($pageId, $updatedPageData);
        
        // Get previous analytics for growth calculation
        $previousAnalytics = $this->getPageAnalytics($pageId);
        
        // Calculate metrics
        $impressions = mt_rand(5000, 20000); // For demo purposes, in reality would be from API
        $engagement = mt_rand(1000, 5000); // For demo purposes
        
        $avgLikes = 0;
        $avgComments = 0;
        $postCount = 0;
        
        if (isset($postsData['edges']) && count($postsData['edges']) > 0) {
            $totalLikes = 0;
            $totalComments = 0;
            
            foreach ($postsData['edges'] as $post) {
                $totalLikes += $post['node']['edge_liked_by']['count'] ?? 0;
                $totalComments += $post['node']['edge_media_to_comment']['count'] ?? 0;
                $postCount++;
                
                // Save post data to database
                $this->saveInstagramPost($pageId, $post['node']);
            }
            
            if ($postCount > 0) {
                $avgLikes = round($totalLikes / $postCount);
                $avgComments = round($totalComments / $postCount);
            }
        }
        
        // Calculate growth percentages
        $impressionsGrowth = isset($previousAnalytics['impressions']) && $previousAnalytics['impressions'] > 0 
            ? round(($impressions - $previousAnalytics['impressions']) / $previousAnalytics['impressions'] * 100, 2)
            : 0;
            
        $engagementGrowth = isset($previousAnalytics['engagement']) && $previousAnalytics['engagement'] > 0 
            ? round(($engagement - $previousAnalytics['engagement']) / $previousAnalytics['engagement'] * 100, 2)
            : 0;
            
        $avgLikesGrowth = isset($previousAnalytics['avg_likes']) && $previousAnalytics['avg_likes'] > 0 
            ? round(($avgLikes - $previousAnalytics['avg_likes']) / $previousAnalytics['avg_likes'] * 100, 2)
            : 0;
            
        $avgCommentsGrowth = isset($previousAnalytics['avg_comments']) && $previousAnalytics['avg_comments'] > 0 
            ? round(($avgComments - $previousAnalytics['avg_comments']) / $previousAnalytics['avg_comments'] * 100, 2)
            : 0;
            
        $postCountGrowth = isset($previousAnalytics['post_count']) && $previousAnalytics['post_count'] > 0 
            ? round(($page['post_count'] - $previousAnalytics['post_count']) / $previousAnalytics['post_count'] * 100, 2)
            : 0;
            
        $followerGrowth = isset($previousAnalytics['follower_count']) && $previousAnalytics['follower_count'] > 0 
            ? round(($page['follower_count'] - $previousAnalytics['follower_count']) / $previousAnalytics['follower_count'] * 100, 2)
            : 0;
        
        // Calculate engagement rate
        $engagementRate = $page['follower_count'] > 0 
            ? round(($avgLikes + $avgComments) / $page['follower_count'] * 100, 2)
            : 0;
            
        // Calculate active days
        $startDate = new DateTime($page['start_date'] ?? $page['created_at']);
        $now = new DateTime();
        $activeDays = $startDate->diff($now)->days;
        
        // Calculate engagement score
        $engagementScore = min(100, round($engagementRate * 20));
        
        // Generate sentiment analysis
        $positiveSentiment = mt_rand(60, 90); // For demo purposes
        $negativeSentiment = 100 - $positiveSentiment;
        
        // Calculate NPS score
        $npsScore = mt_rand(-20, 80); // For demo purposes
        
        // Calculate content sensitivity
        $contentSensitivity = mt_rand(10, 40); // For demo purposes
        
        // Calculate growth potential
        $growthPotential = mt_rand(60, 95); // For demo purposes
        
        // Save analytics data
        $analyticsData = [
            'page_id' => $pageId,
            'impressions' => $impressions,
            'impressions_growth' => $impressionsGrowth,
            'engagement' => $engagement,
            'engagement_growth' => $engagementGrowth,
            'avg_likes' => $avgLikes,
            'avg_likes_growth' => $avgLikesGrowth,
            'avg_comments' => $avgComments,
            'avg_comments_growth' => $avgCommentsGrowth,
            'post_count' => $page['post_count'],
            'post_count_growth' => $postCountGrowth,
            'follower_count' => $page['follower_count'],
            'follower_growth' => $followerGrowth,
            'active_days' => $activeDays,
            'engagement_score' => $engagementScore,
            'positive_sentiment' => $positiveSentiment,
            'negative_sentiment' => $negativeSentiment,
            'nps_score' => $npsScore,
            'content_sensitivity' => $contentSensitivity,
            'growth_potential' => $growthPotential,
            'engagement_rate' => $engagementRate,
            'analysis_date' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // Insert or update analytics
        $this->saveAnalytics($analyticsData);
        
        // Save follower history for chart
        $this->saveFollowerHistory($pageId, $page['follower_count']);
        
        return true;
    }
    
    /**
     * Save Instagram post data
     * 
     * @param int $pageId Page ID
     * @param array $postData Post data
     * @return int|false Post ID or false on failure
     */
    private function saveInstagramPost($pageId, $postData) {
        // Check if post already exists
        $this->db->query("SELECT id FROM instagram_posts WHERE page_id = :page_id AND post_id = :post_id");
        $this->db->bind(':page_id', $pageId);
        $this->db->bind(':post_id', $postData['id']);
        
        $existingPost = $this->db->fetch();
        
        if ($existingPost) {
            // Update existing post
            $postId = $existingPost['id'];
            
            $this->db->query("
                UPDATE instagram_posts SET
                like_count = :like_count,
                comment_count = :comment_count,
                engagement_rate = :engagement_rate,
                updated_at = NOW()
                WHERE id = :id
            ");
            
            $this->db->bind(':like_count', $postData['edge_liked_by']['count'] ?? 0);
            $this->db->bind(':comment_count', $postData['edge_media_to_comment']['count'] ?? 0);
            
            // Calculate engagement rate for this post
            $likeCount = $postData['edge_liked_by']['count'] ?? 0;
            $commentCount = $postData['edge_media_to_comment']['count'] ?? 0;
            
            $page = $this->getPageById($pageId);
            $engagementRate = $page['follower_count'] > 0 
                ? round(($likeCount + $commentCount) / $page['follower_count'] * 100, 2)
                : 0;
                
            $this->db->bind(':engagement_rate', $engagementRate);
            $this->db->bind(':id', $postId);
            
            $this->db->execute();
            
            return $postId;
        } else {
            // Insert new post
            $postType = 'image';
            if (isset($postData['is_video']) && $postData['is_video']) {
                $postType = 'video';
            } elseif (isset($postData['edge_sidecar_to_children'])) {
                $postType = 'carousel';
            }
            
            $this->db->query("
                INSERT INTO instagram_posts (
                    page_id, post_id, post_type, post_url, caption, 
                    media_url, thumbnail_url, posted_at, like_count, 
                    comment_count, view_count, engagement_rate, created_at
                ) VALUES (
                    :page_id, :post_id, :post_type, :post_url, :caption, 
                    :media_url, :thumbnail_url, :posted_at, :like_count, 
                    :comment_count, :view_count, :engagement_rate, NOW()
                )
            ");
            
            $this->db->bind(':page_id', $pageId);
            $this->db->bind(':post_id', $postData['id']);
            $this->db->bind(':post_type', $postType);
            $this->db->bind(':post_url', 'https://www.instagram.com/p/' . $postData['shortcode']);
            $this->db->bind(':caption', $postData['edge_media_to_caption']['edges'][0]['node']['text'] ?? '');
            $this->db->bind(':media_url', $postData['display_url'] ?? null);
            $this->db->bind(':thumbnail_url', $postData['thumbnail_src'] ?? $postData['display_url'] ?? null);
            
            // Convert timestamp to datetime
            $postedAt = date('Y-m-d H:i:s', $postData['taken_at_timestamp'] ?? time());
            $this->db->bind(':posted_at', $postedAt);

            $this->db->bind(':like_count', $postData['edge_liked_by']['count'] ?? 0);
            $this->db->bind(':comment_count', $postData['edge_media_to_comment']['count'] ?? 0);
            $this->db->bind(':view_count', $postData['video_view_count'] ?? 0);

            // Calculate engagement rate for this post
            $likeCount = $postData['edge_liked_by']['count'] ?? 0;
            $commentCount = $postData['edge_media_to_comment']['count'] ?? 0;

            $page = $this->getPageById($pageId);
            $engagementRate = $page['follower_count'] > 0
                ? round(($likeCount + $commentCount) / $page['follower_count'] * 100, 2)
                : 0;

            $this->db->bind(':engagement_rate', $engagementRate);

            if ($this->db->execute()) {
                $postId = $this->db->lastInsertId();

                // Save hashtags
                if (isset($postData['edge_media_to_caption']['edges'][0]['node']['text'])) {
                    $caption = $postData['edge_media_to_caption']['edges'][0]['node']['text'];
                    preg_match_all('/#([a-zA-Z0-9_]+)/', $caption, $matches);

                    if (isset($matches[1]) && !empty($matches[1])) {
                        foreach ($matches[1] as $hashtag) {
                            $this->db->query("
                                INSERT INTO instagram_post_hashtags (post_id, hashtag, created_at)
                                VALUES (:post_id, :hashtag, NOW())
                            ");

                            $this->db->bind(':post_id', $postId);
                            $this->db->bind(':hashtag', $hashtag);
                            $this->db->execute();
                        }
                    }
                }

                return $postId;
            }

            return false;
        }
    }

    /**
     * Save Instagram analytics data
     *
     * @param array $data Analytics data
     * @return bool Success status
     */
    private function saveAnalytics($data) {
        // Check if analytics already exist for this page
        $this->db->query("
            SELECT id FROM instagram_analytics 
            WHERE page_id = :page_id 
            ORDER BY analysis_date DESC 
            LIMIT 1
        ");

        $this->db->bind(':page_id', $data['page_id']);
        $existingAnalytics = $this->db->fetch();

        if ($existingAnalytics) {
            // Update existing analytics
            $fields = [];
            foreach (array_keys($data) as $key) {
                if ($key != 'page_id' && $key != 'created_at') {
                    $fields[] = "{$key} = :{$key}";
                }
            }

            $this->db->query("
                UPDATE instagram_analytics 
                SET " . implode(', ', $fields) . ", updated_at = NOW() 
                WHERE id = :id
            ");

            $this->db->bind(':id', $existingAnalytics['id']);

            foreach ($data as $key => $value) {
                if ($key != 'page_id' && $key != 'created_at') {
                    $this->db->bind(':' . $key, $value);
                }
            }

            return $this->db->execute();
        } else {
            // Insert new analytics
            $fields = implode(', ', array_keys($data));
            $placeholders = ':' . implode(', :', array_keys($data));

            $this->db->query("
                INSERT INTO instagram_analytics ({$fields}) 
                VALUES ({$placeholders})
            ");

            foreach ($data as $key => $value) {
                $this->db->bind(':' . $key, $value);
            }

            return $this->db->execute();
        }
    }

    /**
     * Save follower history for chart
     *
     * @param int $pageId Page ID
     * @param int $followerCount Current follower count
     * @return bool Success status
     */
    private function saveFollowerHistory($pageId, $followerCount) {
        $this->db->query("
            INSERT INTO instagram_follower_history (
                page_id, follower_count, record_date, created_at
            ) VALUES (
                :page_id, :follower_count, NOW(), NOW()
            )
        ");

        $this->db->bind(':page_id', $pageId);
        $this->db->bind(':follower_count', $followerCount);

        return $this->db->execute();
    }

    /**
     * Get Instagram page analytics
     *
     * @param int $pageId Page ID
     * @return array|false Analytics data or false if not found
     */
    public function getPageAnalytics($pageId) {
        $this->db->query("
            SELECT * FROM instagram_analytics 
            WHERE page_id = :page_id 
            ORDER BY analysis_date DESC 
            LIMIT 1
        ");

        $this->db->bind(':page_id', $pageId);

        $analytics = $this->db->fetch();

        if (!$analytics) {
            // If no analytics found, return default values
            $page = $this->getPageById($pageId);

            if (!$page) {
                return false;
            }

            // Calculate active days
            $startDate = new DateTime($page['start_date'] ?? $page['created_at']);
            $now = new DateTime();
            $activeDays = $startDate->diff($now)->days;

            return [
                'impressions' => 0,
                'impressions_growth' => 0,
                'engagement' => 0,
                'engagement_growth' => 0,
                'avg_likes' => 0,
                'avg_likes_growth' => 0,
                'avg_comments' => 0,
                'avg_comments_growth' => 0,
                'post_count' => $page['post_count'],
                'post_count_growth' => 0,
                'follower_count' => $page['follower_count'],
                'follower_growth' => 0,
                'active_days' => $activeDays,
                'engagement_score' => 0,
                'positive_sentiment' => 70,
                'negative_sentiment' => 30,
                'nps_score' => 0,
                'content_sensitivity' => 20,
                'growth_potential' => 80,
                'engagement_rate' => 0
            ];
        }

        return $analytics;
    }

    /**
     * Get follower growth chart data
     *
     * @param int $pageId Page ID
     * @param int $days Number of days to show (default: 30)
     * @return array Chart data
     */
    public function getFollowerGrowthChart($pageId, $days = 30) {
        $this->db->query("
            SELECT follower_count, DATE_FORMAT(record_date, '%Y-%m-%d') as date 
            FROM instagram_follower_history 
            WHERE page_id = :page_id 
            AND record_date >= DATE_SUB(NOW(), INTERVAL :days DAY) 
            ORDER BY record_date ASC
        ");

        $this->db->bind(':page_id', $pageId);
        $this->db->bind(':days', $days);

        $history = $this->db->fetchAll();

        // If no history, generate dummy data
        if (empty($history)) {
            $page = $this->getPageById($pageId);

            if (!$page) {
                return [
                    'labels' => [],
                    'data' => []
                ];
            }

            $history = [];
            $followerCount = $page['follower_count'];
            $growthRate = mt_rand(1, 5) / 100; // 1-5% daily growth rate

            for ($i = $days; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-{$i} days"));
                $pastFollowers = round($followerCount / pow(1 + $growthRate, $i));

                $history[] = [
                    'follower_count' => $pastFollowers,
                    'date' => $date
                ];
            }
        }

        $labels = [];
        $data = [];

        foreach ($history as $record) {
            $labels[] = Helper::formatDate($record['date'], 'j F');
            $data[] = intval($record['follower_count']);
        }

        return [
            'labels' => $labels,
            'data' => $data
        ];
    }

    /**
     * Get top Instagram posts
     *
     * @param int $pageId Page ID
     * @param int $limit Number of posts to return
     * @return array Top posts
     */
    public function getTopPosts($pageId, $limit = 6) {
        $this->db->query("
            SELECT * FROM instagram_posts 
            WHERE page_id = :page_id 
            ORDER BY engagement_rate DESC, like_count DESC 
            LIMIT :limit
        ");

        $this->db->bind(':page_id', $pageId);
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);

        return $this->db->fetchAll();
    }

    /**
     * Get best post times
     *
     * @param int $pageId Page ID
     * @return array Best post times for days and hours
     */
    public function getBestPostTimes($pageId) {
        // In a real application, this would be based on post performance data
        // For demo purposes, we'll return fixed data

        return [
            'days' => [
                'شنبه' => 65,
                'یکشنبه' => 70,
                'دوشنبه' => 85,
                'سه‌شنبه' => 75,
                'چهارشنبه' => 80,
                'پنج‌شنبه' => 90,
                'جمعه' => 60
            ],
            'hours' => [
                '9-11 صبح' => 45,
                '11-13 ظهر' => 60,
                '13-15 بعدازظهر' => 70,
                '15-17 عصر' => 80,
                '17-19 غروب' => 90,
                '19-21 شب' => 75,
                '21-23 شب' => 55
            ]
        ];
    }

    /**
     * Get growth factors
     *
     * @param int $pageId Page ID
     * @return array Growth factors
     */
    public function getGrowthFactors($pageId) {
        // In a real application, this would be based on analytics
        // For demo purposes, we'll return fixed data

        return [
            [
                'positive' => true,
                'title' => 'نرخ تعامل خوب',
                'description' => 'نرخ تعامل پیج شما بالاتر از میانگین در حوزه فعالیت شماست.'
            ],
            [
                'positive' => true,
                'title' => 'کیفیت محتوا',
                'description' => 'محتوای با کیفیت و جذاب برای مخاطبان هدف شما تولید می‌کنید.'
            ],
            [
                'positive' => false,
                'title' => 'تعداد پست',
                'description' => 'تعداد پست‌های شما کمتر از حد بهینه است. توصیه می‌شود حداقل 3 پست در هفته منتشر کنید.'
            ],
            [
                'positive' => true,
                'title' => 'ثبات انتشار',
                'description' => 'پیج شما به طور منظم محتوا منتشر می‌کند که عامل مهمی در رشد است.'
            ],
            [
                'positive' => false,
                'title' => 'استفاده از هشتگ',
                'description' => 'استفاده از هشتگ‌های مناسب و مرتبط می‌تواند دسترسی به پست‌های شما را افزایش دهد.'
            ]
        ];
    }

    /**
     * Get improvement steps
     *
     * @param int $pageId Page ID
     * @return array Improvement steps
     */
    public function getImprovementSteps($pageId) {
        // In a real application, this would be based on page performance
        // For demo purposes, we'll return fixed data

        return [
            [
                'title' => 'افزایش تعداد پست‌ها',
                'description' => 'حداقل 3 پست در هفته منتشر کنید تا الگوریتم اینستاگرام محتوای شما را بیشتر نمایش دهد.',
                'action_url' => '/dashboard/content/post-planner',
                'action_text' => 'برنامه‌ریزی پست'
            ],
            [
                'title' => 'بهبود استفاده از هشتگ',
                'description' => 'از 5-10 هشتگ مرتبط با محتوا و حوزه فعالیت خود استفاده کنید.',
                'action_url' => '/dashboard/instagram/hashtag-suggestions',
                'action_text' => 'پیشنهاد هشتگ'
            ],
            [
                'title' => 'تعامل با مخاطبان',
                'description' => 'به کامنت‌ها پاسخ دهید و با فالوورهای خود تعامل داشته باشید.'
            ],
            [
                'title' => 'استفاده از استوری',
                'description' => 'روزانه حداقل 2-3 استوری منتشر کنید تا حضور فعال خود را نشان دهید.',
                'action_url' => '/dashboard/content/story-planner',
                'action_text' => 'برنامه‌ریزی استوری'
            ],
            [
                'title' => 'همکاری با اینفلوئنسرها',
                'description' => 'با اینفلوئنسرهای مرتبط با حوزه فعالیت خود همکاری کنید.',
                'action_url' => '/dashboard/instagram/influencer-suggestions',
                'action_text' => 'پیشنهاد اینفلوئنسر'
            ]
        ];
    }

    /**
     * Get similar accounts
     *
     * @param int $pageId Page ID
     * @param int $limit Number of accounts to return
     * @return array Similar accounts
     */
    public function getSimilarAccounts($pageId, $limit = 5) {
        // In a real application, this would be fetched from the API or database
        // For demo purposes, we'll return fixed data

        return [
            [
                'username' => 'similar_account1',
                'profile_image' => '/assets/images/instagram/default-profile.jpg',
                'follower_count' => 12500,
                'profile_url' => 'https://instagram.com/similar_account1'
            ],
            [
                'username' => 'similar_account2',
                'profile_image' => '/assets/images/instagram/default-profile.jpg',
                'follower_count' => 28300,
                'profile_url' => 'https://instagram.com/similar_account2'
            ],
            [
                'username' => 'similar_account3',
                'profile_image' => '/assets/images/instagram/default-profile.jpg',
                'follower_count' => 45600,
                'profile_url' => 'https://instagram.com/similar_account3'
            ],
            [
                'username' => 'similar_account4',
                'profile_image' => '/assets/images/instagram/default-profile.jpg',
                'follower_count' => 19200,
                'profile_url' => 'https://instagram.com/similar_account4'
            ],
            [
                'username' => 'similar_account5',
                'profile_image' => '/assets/images/instagram/default-profile.jpg',
                'follower_count' => 34700,
                'profile_url' => 'https://instagram.com/similar_account5'
            ]
        ];
    }

    /**
     * Get growth milestones
     *
     * @param int $pageId Page ID
     * @return array Growth milestones
     */
    public function getGrowthMilestones($pageId) {
        $page = $this->getPageById($pageId);
        $analytics = $this->getPageAnalytics($pageId);

        if (!$page || !$analytics) {
            return [];
        }

        $currentFollowers = $page['follower_count'];

        // Calculate next milestone targets
        $milestone1 = max($currentFollowers * 2, 1000);
        $milestone2 = max($currentFollowers * 5, 5000);
        $milestone3 = max($currentFollowers * 10, 10000);

        // Calculate time estimates based on current growth rate
        $dailyGrowthRate = max(0.5, $analytics['follower_growth'] / 100); // Convert percentage to decimal, minimum 0.5%

        $daysToMilestone1 = $this->calculateDaysToMilestone($currentFollowers, $milestone1, $dailyGrowthRate);
        $daysToMilestone2 = $this->calculateDaysToMilestone($currentFollowers, $milestone2, $dailyGrowthRate);
        $daysToMilestone3 = $this->calculateDaysToMilestone($currentFollowers, $milestone3, $dailyGrowthRate);

        return [
            [
                'follower_count' => $milestone1,
                'time_estimate' => $this->formatTimeEstimate($daysToMilestone1)
            ],
            [
                'follower_count' => $milestone2,
                'time_estimate' => $this->formatTimeEstimate($daysToMilestone2)
            ],
            [
                'follower_count' => $milestone3,
                'time_estimate' => $this->formatTimeEstimate($daysToMilestone3)
            ]
        ];
    }

    /**
     * Calculate days to reach a follower milestone
     *
     * @param int $currentFollowers Current follower count
     * @param int $targetFollowers Target follower count
     * @param float $dailyGrowthRate Daily growth rate as decimal
     * @return int Number of days
     */
    private function calculateDaysToMilestone($currentFollowers, $targetFollowers, $dailyGrowthRate) {
        if ($currentFollowers >= $targetFollowers) {
            return 0;
        }

        if ($dailyGrowthRate <= 0) {
            return 9999; // Effectively infinity
        }

        // Formula: days = log(target/current) / log(1 + daily_growth_rate)
        return ceil(log($targetFollowers / $currentFollowers) / log(1 + $dailyGrowthRate));
    }

    /**
     * Format time estimate
     *
     * @param int $days Number of days
     * @return string Formatted time
     */
    private function formatTimeEstimate($days) {
        if ($days < 30) {
            return $days . ' روز';
        } elseif ($days < 365) {
            $months = ceil($days / 30);
            return $months . ' ماه';
        } else {
            $years = round($days / 365, 1);
            return $years . ' سال';
        }
    }

    /**
     * Get Instagram roadmap
     *
     * @param int $pageId Page ID
     * @return array Roadmap steps
     */
    public function getInstagramRoadmap($pageId) {
        // In a real application, this would be based on page progress
        // For demo purposes, we'll return fixed data

        $page = $this->getPageById($pageId);
        $isPlanningDone = ($page && $page['post_count'] > 0);
        $isContentCreated = ($page && $page['post_count'] > 5);
        $isEngagementImproved = ($page && $page['follower_count'] > 1000);

        return [
            [
                'title' => 'تنظیم استراتژی محتوایی',
                'description' => 'تعیین اهداف، مخاطبان هدف و موضوعات اصلی محتوا برای پیج اینستاگرام',
                'completed' => $isPlanningDone,
                'action_url' => $isPlanningDone ? null : '/dashboard/instagram/content-strategy',
                'action_text' => 'ایجاد استراتژی'
            ],
            [
                'title' => 'تولید محتوای جذاب',
                'description' => 'ایجاد پست‌ها، استوری‌ها و ریلز‌های جذاب و مرتبط با حوزه فعالیت',
                'completed' => $isContentCreated,
                'action_url' => $isContentCreated ? null : '/dashboard/content/post-planner',
                'action_text' => 'تولید محتوا'
            ],
            [
                'title' => 'افزایش تعامل و فالوور',
                'description' => 'استفاده از تکنیک‌های افزایش تعامل و جذب فالوور برای رشد پیج',
                'completed' => $isEngagementImproved,
                'action_url' => $isEngagementImproved ? null : '/dashboard/instagram/engagement-techniques',
                'action_text' => 'تکنیک‌های افزایش تعامل'
            ],
            [
                'title' => 'همکاری با اینفلوئنسرها',
                'description' => 'شناسایی و همکاری با اینفلوئنسرهای مرتبط برای افزایش دسترسی',
                'completed' => false,
                'action_url' => '/dashboard/instagram/influencer-collaboration',
                'action_text' => 'یافتن اینفلوئنسرها'
            ],
            [
                'title' => 'تحلیل و بهینه‌سازی مداوم',
                'description' => 'بررسی منظم آمار و عملکرد و تنظیم استراتژی بر اساس نتایج',
                'completed' => false,
                'action_url' => '/dashboard/instagram/performance-optimization',
                'action_text' => 'بهینه‌سازی عملکرد'
            ]
        ];
    }

    /**
     * Generate name suggestions for Instagram
     *
     * @param string $category Business category
     * @param string $topic Specific topic
     * @param string $style Name style
     * @param string $language Preferred language
     * @param string $keywords Optional keywords
     * @return array Suggested names
     */
    public function generateNameSuggestions($category, $topic, $style, $language, $keywords = '') {
        // For a real application, use OpenAI API
        // For demo purposes, we'll return fixed data

        $prompt = "لطفاً 10 نام پیشنهادی برای یک پیج اینستاگرام در زمینه «{$category}» با موضوع دقیق «{$topic}» ارائه دهید.";
        $prompt .= " سبک نام‌ها «{$style}» باشد و به زبان «{$language}» باشد.";

        if (!empty($keywords)) {
            $prompt .= " لطفاً از این کلمات کلیدی استفاده کنید: {$keywords}";
        }

        // In a real application, call OpenAI API with the prompt
        // $response = Helper::openAiRequest($prompt);

        // For demo purposes, return fixed suggestions
        return [
            [
                'name' => 'social' . mt_rand(100, 999),
                'description' => 'یک نام ساده و به یادماندنی که با موضوع شما مطابقت دارد.'
            ],
            [
                'name' => 'insta_' . strtolower($topic) . mt_rand(10, 99),
                'description' => 'استفاده از کلمه کلیدی اصلی در نام برای بهبود قابلیت جستجو.'
            ],
            [
                'name' => 'the_' . strtolower($category) . '_hub',
                'description' => 'نشان‌دهنده مرکزی برای محتوای مرتبط با حوزه فعالیت شما.'
            ],
            [
                'name' => strtolower($topic) . '_expert',
                'description' => 'نشان‌دهنده تخصص شما در موضوع اصلی پیج.'
            ],
            [
                'name' => 'daily_' . strtolower($topic),
                'description' => 'تأکید بر انتشار منظم محتوا و به‌روز بودن پیج.'
            ],
            [
                'name' => strtolower($topic) . '_insider',
                'description' => 'ایجاد حس دسترسی به اطلاعات خاص و درونی.'
            ],
            [
                'name' => 'pro_' . strtolower($category),
                'description' => 'تأکید بر سطح حرفه‌ای و تخصصی محتوا.'
            ],
            [
                'name' => strtolower($topic) . '_world',
                'description' => 'نشان‌دهنده مجموعه کاملی از محتوا درباره موضوع.'
            ],
            [
                'name' => 'discover_' . strtolower($topic),
                'description' => 'تشویق مخاطبان به کشف و یادگیری درباره موضوع.'
            ],
            [
                'name' => strtolower($topic) . '_inspiration',
                'description' => 'تمرکز بر ارائه ایده‌ها و الهام‌بخشی به مخاطبان.'
            ]
        ];
    }

    /**
     * Get business categories
     *
     * @return array Business categories
     */
    public function getBusinessCategories() {
        return [
            'فروشگاه و خرده‌فروشی',
            'آموزش و یادگیری',
            'سلامت و تندرستی',
            'زیبایی و مراقبت شخصی',
            'غذا و نوشیدنی',
            'سفر و گردشگری',
            'مد و پوشاک',
            'هنر و صنایع دستی',
            'فناوری و دیجیتال',
            'ورزش و تناسب اندام',
            'کسب و کار و کارآفرینی',
            'سرگرمی و محتوای طنز',
            'دکوراسیون و طراحی داخلی',
            'کتاب و ادبیات',
            'موسیقی و هنرهای نمایشی',
            'مالی و سرمایه‌گذاری',
            'کودک و نوزاد',
            'حیوانات خانگی',
            'باغبانی و گیاهان',
            'خودرو و موتورسیکلت',
            'علم و تکنولوژی',
            'محیط زیست و پایداری',
            'معماری و ساختمان',
            'لوازم الکترونیکی',
            'روانشناسی و توسعه فردی',
            'عکاسی و تصویربرداری',
            'بازی‌های ویدیویی',
            'مذهبی و معنوی'
        ];
    }

    /**
     * Get specialist categories
     *
     * @return array Specialist categories
     */
    public function getSpecialistCategories() {
        return [
            'آموزشی',
            'تجاری',
            'سرگرمی',
            'اطلاع‌رسانی',
            'تبلیغاتی',
            'شخصی',
            'اینفلوئنسر',
            'برند شخصی',
            'فروشگاهی',
            'خدماتی',
            'موضوعی',
            'خبری',
            'نیچ مارکت'
        ];
    }

    /**
     * Compare Instagram pages
     *
     * @param array $pageIds Array of page IDs to compare
     * @return array Comparison data
     */
    public function comparePages($pageIds) {
        $comparison = [
            'pages' => [],
            'metrics' => [
                'follower_count' => [
                    'label' => 'تعداد فالوور',
                    'values' => []
                ],
                'engagement_rate' => [
                    'label' => 'نرخ تعامل',
                    'values' => []
                ],
                'impressions' => [
                    'label' => 'ایمپرشن',
                    'values' => []
                ],
                'avg_likes' => [
                    'label' => 'میانگین لایک',
                    'values' => []
                ],
                'avg_comments' => [
                    'label' => 'میانگین کامنت',
                    'values' => []
                ],
                'post_count' => [
                    'label' => 'تعداد پست',
                    'values' => []
                ],
                'positive_sentiment' => [
                    'label' => 'رویکرد مثبت',
                    'values' => []
                ]
            ]
        ];

        foreach ($pageIds as $pageId) {
            $page = $this->getPageById($pageId);
            $analytics = $this->getPageAnalytics($pageId);

            if (!$page || !$analytics) {
                continue;
            }

            $comparison['pages'][] = [
                'id' => $page['id'],
                'username' => $page['username'],
                'profile_image' => $page['profile_image']
            ];

            $comparison['metrics']['follower_count']['values'][] = $page['follower_count'];
            $comparison['metrics']['engagement_rate']['values'][] = $analytics['engagement_rate'];
            $comparison['metrics']['impressions']['values'][] = $analytics['impressions'];
            $comparison['metrics']['avg_likes']['values'][] = $analytics['avg_likes'];
            $comparison['metrics']['avg_comments']['values'][] = $analytics['avg_comments'];
            $comparison['metrics']['post_count']['values'][] = $page['post_count'];
            $comparison['metrics']['positive_sentiment']['values'][] = $analytics['positive_sentiment'];
        }

        return $comparison;
    }

    /**
     * Generate PDF report for Instagram analysis
     *
     * @param int $pageId Page ID
     * @return string|false Report file URL or false on failure
     */
    public function generateReport($pageId) {
        // In a real application, generate a PDF using a library like FPDF or TCPDF
        // For demo purposes, we'll just return a dummy URL

        $page = $this->getPageById($pageId);

        if (!$page) {
            return false;
        }

        // Return a dummy URL
        return '/reports/instagram/' . $page['username'] . '_' . date('Ymd') . '.pdf';
    }
}