<?php

/**
 * UploadController.php
 *
 * کنترلر مدیریت آپلود فایل‌ها در سیستم ادامه‌ای
 */

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Auth;
use App\Core\FileManager;
use Exception;

class UploadController extends Controller {
    private $fileManager;

    public function __construct() {
        parent::__construct();
        $this->fileManager = new FileManager();

        // فقط کاربران لاگین شده می‌توانند به اکثر متدهای این کنترلر دسترسی داشته باشند
        $this->middleware('auth');
    }

    /**
     * آپلود تصویر پروفایل
     *
     * @param Request $request
     * @param Response $response
     */
    public function uploadProfileImage(Request $request, Response $response) {
        try {
            // بررسی وجود فایل
            if (!isset($_FILES['profile_image']) || $_FILES['profile_image']['error'] === UPLOAD_ERR_NO_FILE) {
                return $response->json([
                    'success' => false,
                    'message' => 'لطفا یک تصویر انتخاب کنید'
                ]);
            }

            $user = Auth::getUser();

            // تنظیم محدودیت‌های آپلود
            $this->fileManager->setAllowedImageTypes(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
            $this->fileManager->setMaxImageSize(2097152); // 2 مگابایت

            // آپلود تصویر
            $result = $this->fileManager->uploadProfileImage($_FILES['profile_image'], $user['id']);

            // به‌روزرسانی تصویر پروفایل کاربر در دیتابیس
            if ($result) {
                $userModel = $this->loadModel('User');
                $userModel->updateProfileImage($user['id'], $result['path']);
            }

            return $response->json([
                'success' => true,
                'message' => 'تصویر پروفایل با موفقیت به‌روزرسانی شد',
                'data' => $result
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * حذف تصویر پروفایل
     *
     * @param Request $request
     * @param Response $response
     */
    public function removeProfileImage(Request $request, Response $response) {
        try {
            $user = Auth::getUser();

            // حذف تصویر پروفایل از سرور
            $result = $this->fileManager->removeUserProfileImage($user['id']);

            // به‌روزرسانی اطلاعات کاربر در دیتابیس
            if ($result) {
                $userModel = $this->loadModel('User');
                $userModel->updateProfileImage($user['id'], null);
            }

            return $response->json([
                'success' => true,
                'message' => 'تصویر پروفایل با موفقیت حذف شد'
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * آپلود فایل‌های مورد نیاز برای تولید محتوا
     *
     * @param Request $request
     * @param Response $response
     */
    public function uploadContentFile(Request $request, Response $response) {
        try {
            // بررسی وجود فایل
            if (!isset($_FILES['file']) || $_FILES['file']['error'] === UPLOAD_ERR_NO_FILE) {
                return $response->json([
                    'success' => false,
                    'message' => 'لطفا یک فایل انتخاب کنید'
                ]);
            }

            $user = Auth::getUser();
            $fileType = $request->getPost('file_type', 'general');

            // تنظیم محدودیت‌های آپلود براساس نوع فایل
            switch ($fileType) {
                case 'image':
                    $this->fileManager->setAllowedImageTypes(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
                    $this->fileManager->setMaxFileSize(5242880); // 5 مگابایت
                    break;

                case 'document':
                    $this->fileManager->setAllowedFileTypes([
                        'application/pdf',
                        'application/msword',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'text/plain',
                        'text/csv',
                        'application/vnd.ms-excel',
                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                    ]);
                    $this->fileManager->setMaxFileSize(10485760); // 10 مگابایت
                    break;

                default:
                    // تنظیمات پیش‌فرض
                    break;
            }

            // آپلود فایل
            $result = $this->fileManager->uploadGeneratedFile($_FILES['file'], $user['id'], $fileType);

            // ثبت اطلاعات فایل در دیتابیس
            if ($result) {
                $fileModel = $this->loadModel('File');
                $fileId = $fileModel->saveFileInfo([
                    'user_id' => $user['id'],
                    'file_path' => $result['path'],
                    'file_url' => $result['url'],
                    'file_type' => $result['type'],
                    'file_size' => $result['size'],
                    'file_name' => $result['name'],
                    'thumbnail' => isset($result['thumbnail']) ? $result['thumbnail'] : null,
                    'category' => $fileType,
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                $result['id'] = $fileId;
            }

            return $response->json([
                'success' => true,
                'message' => 'فایل با موفقیت آپلود شد',
                'data' => $result
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * آپلود فایل موقت
     *
     * @param Request $request
     * @param Response $response
     */
    public function uploadTempFile(Request $request, Response $response) {
        try {
            // بررسی وجود فایل
            if (!isset($_FILES['file']) || $_FILES['file']['error'] === UPLOAD_ERR_NO_FILE) {
                return $response->json([
                    'success' => false,
                    'message' => 'لطفا یک فایل انتخاب کنید'
                ]);
            }

            $user = Auth::getUser();

            // آپلود فایل موقت
            $result = $this->fileManager->uploadTempFile($_FILES['file'], $user['id']);

            return $response->json([
                'success' => true,
                'message' => 'فایل با موفقیت آپلود شد',
                'data' => $result
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * انتقال فایل از پوشه موقت به پوشه دائمی
     *
     * @param Request $request
     * @param Response $response
     */
    public function moveTempFile(Request $request, Response $response) {
        try {
            $tempPath = $request->getPost('temp_path');
            $destDir = $request->getPost('dest_dir', FileManager::GENERATED_DIR);
            $newFileName = $request->getPost('new_file_name');
            $category = $request->getPost('category', 'general');

            if (!$tempPath) {
                return $response->json([
                    'success' => false,
                    'message' => 'مسیر فایل موقت مشخص نشده است'
                ]);
            }

            $user = Auth::getUser();

            // انتقال فایل
            $result = $this->fileManager->moveFromTemp($tempPath, $destDir, $newFileName);

            // ثبت اطلاعات فایل در دیتابیس
            if ($result) {
                $fileModel = $this->loadModel('File');
                $fileId = $fileModel->saveFileInfo([
                    'user_id' => $user['id'],
                    'file_path' => $result['path'],
                    'file_url' => $result['url'],
                    'file_type' => $result['type'],
                    'file_size' => $result['size'],
                    'file_name' => $result['name'],
                    'thumbnail' => isset($result['thumbnail']) ? $result['thumbnail'] : null,
                    'category' => $category,
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                $result['id'] = $fileId;
            }

            return $response->json([
                'success' => true,
                'message' => 'فایل با موفقیت منتقل شد',
                'data' => $result
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * حذف فایل
     *
     * @param Request $request
     * @param Response $response
     */
    public function deleteFile(Request $request, Response $response) {
        try {
            $fileId = $request->getPost('file_id');

            if (!$fileId) {
                return $response->json([
                    'success' => false,
                    'message' => 'شناسه فایل مشخص نشده است'
                ]);
            }

            $user = Auth::getUser();
            $fileModel = $this->loadModel('File');

            // دریافت اطلاعات فایل
            $fileInfo = $fileModel->getFileById($fileId);

            if (!$fileInfo) {
                return $response->json([
                    'success' => false,
                    'message' => 'فایل مورد نظر یافت نشد'
                ]);
            }

            // بررسی مالکیت فایل (فقط صاحب فایل یا ادمین می‌توانند فایل را حذف کنند)
            if ($fileInfo['user_id'] != $user['id'] && !Auth::isAdmin()) {
                return $response->json([
                    'success' => false,
                    'message' => 'شما اجازه حذف این فایل را ندارید'
                ]);
            }

            // حذف فایل از سرور
            $result = $this->fileManager->deleteFile($fileInfo['file_path']);

            // حذف اطلاعات فایل از دیتابیس
            if ($result) {
                $fileModel->deleteFile($fileId);
            }

            return $response->json([
                'success' => true,
                'message' => 'فایل با موفقیت حذف شد'
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * دریافت لیست فایل‌های کاربر
     *
     * @param Request $request
     * @param Response $response
     */
    public function getUserFiles(Request $request, Response $response) {
        try {
            $user = Auth::getUser();
            $category = $request->getParam('category', '');
            $page = $request->getParam('page', 1);
            $limit = $request->getParam('limit', 20);

            $fileModel = $this->loadModel('File');
            $files = $fileModel->getUserFiles($user['id'], $category, $limit, ($page - 1) * $limit);
            $totalFiles = $fileModel->getUserFilesCount($user['id'], $category);

            return $response->json([
                'success' => true,
                'data' => [
                    'files' => $files,
                    'total' => $totalFiles,
                    'page' => $page,
                    'limit' => $limit,
                    'totalPages' => ceil($totalFiles / $limit)
                ]
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * اجرای عملیات پاکسازی فایل‌های موقت قدیمی
     * توجه: این متد باید توسط کرون جاب یا یک مدیر سیستم فراخوانی شود
     *
     * @param Request $request
     * @param Response $response
     */
    public function cleanupTempFiles(Request $request, Response $response) {
        try {
            // بررسی دسترسی ادمین یا کلید API معتبر
            if (!Auth::isAdmin() && $request->getParam('api_key') !== CLEANUP_API_KEY) {
                return $response->json([
                    'success' => false,
                    'message' => 'شما اجازه دسترسی به این عملیات را ندارید'
                ], 403);
            }

            // زمان (به ثانیه) برای پاکسازی فایل‌های قدیمی‌تر از آن
            $olderThan = $request->getParam('older_than', 86400); // پیش‌فرض: 24 ساعت

            // پاکسازی فایل‌های موقت قدیمی
            $count = $this->fileManager->cleanupTempFiles($olderThan);

            return $response->json([
                'success' => true,
                'message' => "تعداد {$count} فایل موقت قدیمی با موفقیت حذف شدند",
                'data' => [
                    'deleted_count' => $count,
                    'older_than' => $olderThan
                ]
            ]);

        } catch (Exception $e) {
            return $response->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }
}