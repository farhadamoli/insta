<?php

/**
 * PaymentController.php
 *
 * کنترلر مدیریت پرداخت‌ها و تراکنش‌های مالی در سیستم ادامه‌ای
 */

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Auth;
use App\Models\Payment;
use App\Models\Subscription;
use App\Models\User;

class PaymentController extends Controller {
    private $paymentModel;
    private $subscriptionModel;
    private $userModel;

    public function __construct() {
        parent::__construct();
        $this->paymentModel = new Payment();
        $this->subscriptionModel = new Subscription();
        $this->userModel = new User();

        // فقط کاربران لاگین شده می‌توانند به اکثر متدهای این کنترلر دسترسی داشته باشند
        $this->middleware('auth', ['except' => ['verify', 'showPaymentResult']]);
    }

    /**
     * نمایش صفحه انتخاب اشتراک
     */
    public function showPlans() {
        $plans = $this->subscriptionModel->getAllPlans();

        return $this->render('payment/plans', [
            'title' => 'خرید اشتراک | ادامه‌ای',
            'plans' => $plans
        ]);
    }

    /**
     * نمایش صفحه جزئیات پرداخت
     *
     * @param Request $request
     */
    public function showCheckout(Request $request) {
        $plan_id = $request->getParam('plan_id');

        if (!$plan_id) {
            return $this->redirect('/payment/plans', [
                'error' => 'لطفا یک اشتراک انتخاب کنید'
            ]);
        }

        $plan = $this->subscriptionModel->getPlanById($plan_id);

        if (!$plan) {
            return $this->redirect('/payment/plans', [
                'error' => 'اشتراک مورد نظر یافت نشد'
            ]);
        }

        $user = Auth::getUser();

        return $this->render('payment/checkout', [
            'title' => 'پرداخت اشتراک | ادامه‌ای',
            'plan' => $plan,
            'user' => $user
        ]);
    }

    /**
     * پردازش درخواست پرداخت
     *
     * @param Request $request
     * @param Response $response
     */
    public function processPayment(Request $request, Response $response) {
        $plan_id = $request->getPost('plan_id');
        $description = $request->getPost('description', 'خرید اشتراک از ادامه‌ای');

        if (!$plan_id) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'لطفا یک اشتراک انتخاب کنید'
                ]);
            } else {
                return $this->redirect('/payment/plans', [
                    'error' => 'لطفا یک اشتراک انتخاب کنید'
                ]);
            }
        }

        $plan = $this->subscriptionModel->getPlanById($plan_id);

        if (!$plan) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'اشتراک مورد نظر یافت نشد'
                ]);
            } else {
                return $this->redirect('/payment/plans', [
                    'error' => 'اشتراک مورد نظر یافت نشد'
                ]);
            }
        }

        $user = Auth::getUser();

        // ایجاد پرداخت جدید در دیتابیس
        $payment_id = $this->paymentModel->createPayment(
            $user['id'],
            $plan_id,
            $plan['price'],
            $description
        );

        if (!$payment_id) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'خطا در ایجاد پرداخت. لطفا مجدد تلاش کنید.'
                ]);
            } else {
                return $this->redirect('/payment/checkout?plan_id=' . $plan_id, [
                    'error' => 'خطا در ایجاد پرداخت. لطفا مجدد تلاش کنید.'
                ]);
            }
        }

        // شروع فرآیند پرداخت با زرین‌پال
        $result = $this->paymentModel->startZarinpalPayment($payment_id);

        if ($result && $result['success']) {
            // در صورت موفقیت، کاربر را به درگاه پرداخت هدایت می‌کنیم
            if ($request->isAjax()) {
                return $response->json([
                    'success' => true,
                    'redirect' => $result['payment_url']
                ]);
            } else {
                return $this->redirect($result['payment_url']);
            }
        } else {
            // در صورت خطا
            $error_message = isset($result['error_message']) ? $result['error_message'] : 'خطا در اتصال به درگاه پرداخت';

            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => $error_message
                ]);
            } else {
                return $this->redirect('/payment/checkout?plan_id=' . $plan_id, [
                    'error' => $error_message
                ]);
            }
        }
    }

    /**
     * تأیید پرداخت (کال‌بک زرین‌پال)
     *
     * @param Request $request
     * @param Response $response
     */
    public function verify(Request $request, Response $response) {
        $payment_id = $request->getParam('payment_id');
        $authority = $request->getParam('Authority');
        $status = $request->getParam('Status');

        if (!$payment_id || !$authority) {
            return $this->redirect('/payment/result?status=error&message=' . urlencode('پارامترهای ضروری پرداخت یافت نشد'));
        }

        // تأیید پرداخت با زرین‌پال
        $result = $this->paymentModel->verifyZarinpalPayment($payment_id, $authority, $status);

        if ($result['success']) {
            // در صورت موفقیت پرداخت
            return $this->redirect('/payment/result?status=success&payment_id=' . $payment_id . '&ref_id=' . $result['ref_id']);
        } else {
            // در صورت عدم موفقیت پرداخت
            $error_message = isset($result['message']) ? $result['message'] : 'خطا در تأیید پرداخت';
            return $this->redirect('/payment/result?status=error&message=' . urlencode($error_message));
        }
    }

    /**
     * نمایش نتیجه پرداخت
     *
     * @param Request $request
     */
    public function showPaymentResult(Request $request) {
        $status = $request->getParam('status');
        $payment_id = $request->getParam('payment_id');
        $ref_id = $request->getParam('ref_id');
        $message = $request->getParam('message');

        $payment = null;
        $subscription = null;

        if ($payment_id) {
            $payment = $this->paymentModel->getPaymentById($payment_id);

            if ($payment && $payment['subscription_id']) {
                $subscription = $this->subscriptionModel->getPlanById($payment['subscription_id']);
            }
        }

        return $this->render('payment/result', [
            'title' => 'نتیجه پرداخت | ادامه‌ای',
            'status' => $status,
            'payment' => $payment,
            'subscription' => $subscription,
            'ref_id' => $ref_id,
            'message' => $message
        ]);
    }

    /**
     * نمایش تاریخچه پرداخت‌های کاربر
     */
    public function showHistory() {
        $user = Auth::getUser();
        $payments = $this->paymentModel->getUserPayments($user['id']);

        return $this->render('payment/history', [
            'title' => 'تاریخچه پرداخت‌ها | ادامه‌ای',
            'payments' => $payments
        ]);
    }

    /**
     * نمایش فاکتور پرداخت
     *
     * @param Request $request
     * @param Response $response
     */
    public function showInvoice(Request $request, Response $response) {
        $payment_id = $request->getParam('id');

        if (!$payment_id) {
            return $this->redirect('/payment/history', [
                'error' => 'شناسه پرداخت نامعتبر است'
            ]);
        }

        $payment = $this->paymentModel->getPaymentById($payment_id);

        if (!$payment) {
            return $this->redirect('/payment/history', [
                'error' => 'پرداخت مورد نظر یافت نشد'
            ]);
        }

        $user = Auth::getUser();

        // اطمینان از اینکه فاکتور متعلق به همین کاربر است
        if ($payment['user_id'] != $user['id']) {
            return $this->redirect('/payment/history', [
                'error' => 'شما به این فاکتور دسترسی ندارید'
            ]);
        }

        $subscription = null;
        if ($payment['subscription_id']) {
            $subscription = $this->subscriptionModel->getPlanById($payment['subscription_id']);
        }

        $user_info = $this->userModel->getUserById($payment['user_id']);

        return $this->render('payment/invoice', [
            'title' => 'فاکتور پرداخت | ادامه‌ای',
            'payment' => $payment,
            'subscription' => $subscription,
            'user' => $user_info
        ]);
    }

    /**
     * دریافت فاکتور به صورت PDF
     *
     * @param Request $request
     * @param Response $response
     */
    public function downloadInvoice(Request $request, Response $response) {
        $payment_id = $request->getParam('id');

        if (!$payment_id) {
            return $this->redirect('/payment/history', [
                'error' => 'شناسه پرداخت نامعتبر است'
            ]);
        }

        $payment = $this->paymentModel->getPaymentById($payment_id);

        if (!$payment) {
            return $this->redirect('/payment/history', [
                'error' => 'پرداخت مورد نظر یافت نشد'
            ]);
        }

        $user = Auth::getUser();

        // اطمینان از اینکه فاکتور متعلق به همین کاربر است
        if ($payment['user_id'] != $user['id']) {
            return $this->redirect('/payment/history', [
                'error' => 'شما به این فاکتور دسترسی ندارید'
            ]);
        }

        $subscription = null;
        if ($payment['subscription_id']) {
            $subscription = $this->subscriptionModel->getPlanById($payment['subscription_id']);
        }

        $user_info = $this->userModel->getUserById($payment['user_id']);

        // ایجاد PDF فاکتور (نیاز به کتابخانه TCPDF یا مشابه)
        require_once LIBRARY_PATH . '/tcpdf/tcpdf.php';

        $pdf = new \TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
        $pdf->SetTitle('فاکتور پرداخت ادامه‌ای');
        $pdf->SetAuthor('ادامه‌ای');
        $pdf->SetPrintHeader(false);
        $pdf->SetPrintFooter(false);
        $pdf->SetMargins(15, 15, 15);
        $pdf->SetAutoPageBreak(true, 15);
        $pdf->AddPage();

        // تنظیم فونت فارسی
        $pdf->SetFont('dejavusans', '', 12, '', true);

        // محتوای فاکتور
        $html = $this->view->renderToString('payment/invoice_pdf', [
            'payment' => $payment,
            'subscription' => $subscription,
            'user' => $user_info
        ]);

        $pdf->writeHTML($html, true, false, true, false, '');

        // خروجی فایل
        $pdf->Output('فاکتور_' . $payment_id . '.pdf', 'D');
        exit;
    }

    /**
     * قسمت مدیریتی - مدیریت پرداخت‌ها (فقط برای ادمین)
     */
    public function adminIndex() {
        // بررسی دسترسی ادمین
        if (!Auth::isAdmin()) {
            return $this->redirect('/dashboard', [
                'error' => 'شما به این بخش دسترسی ندارید'
            ]);
        }

        $status = $this->request->getParam('status', '');
        $page = $this->request->getParam('page', 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // دریافت لیست پرداخت‌ها براساس فیلتر وضعیت
        $payments = $this->paymentModel->getPayments($status, $limit, $offset);
        $total = $this->paymentModel->getPaymentsCount($status);

        // آمار پرداخت‌ها
        $stats = $this->paymentModel->getPaymentStats();

        return $this->render('admin/payments/index', [
            'title' => 'مدیریت پرداخت‌ها | ادمین پنل',
            'payments' => $payments,
            'stats' => $stats,
            'status' => $status,
            'page' => $page,
            'total' => $total,
            'limit' => $limit
        ]);
    }

    /**
     * قسمت مدیریتی - جزئیات پرداخت (فقط برای ادمین)
     *
     * @param Request $request
     */
    public function adminViewPayment(Request $request) {
        // بررسی دسترسی ادمین
        if (!Auth::isAdmin()) {
            return $this->redirect('/dashboard', [
                'error' => 'شما به این بخش دسترسی ندارید'
            ]);
        }

        $payment_id = $request->getParam('id');

        if (!$payment_id) {
            return $this->redirect('/admin/payments', [
                'error' => 'شناسه پرداخت نامعتبر است'
            ]);
        }

        $payment = $this->paymentModel->getPaymentById($payment_id);

        if (!$payment) {
            return $this->redirect('/admin/payments', [
                'error' => 'پرداخت مورد نظر یافت نشد'
            ]);
        }

        $user_info = $this->userModel->getUserById($payment['user_id']);

        $subscription = null;
        if ($payment['subscription_id']) {
            $subscription = $this->subscriptionModel->getPlanById($payment['subscription_id']);
        }

        return $this->render('admin/payments/view', [
            'title' => 'جزئیات پرداخت | ادمین پنل',
            'payment' => $payment,
            'user' => $user_info,
            'subscription' => $subscription
        ]);
    }

    /**
     * قسمت مدیریتی - استرداد وجه (فقط برای ادمین)
     *
     * @param Request $request
     * @param Response $response
     */
    public function adminRefundPayment(Request $request, Response $response) {
        // بررسی دسترسی ادمین
        if (!Auth::isAdmin()) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'شما به این بخش دسترسی ندارید'
                ]);
            } else {
                return $this->redirect('/dashboard', [
                    'error' => 'شما به این بخش دسترسی ندارید'
                ]);
            }
        }

        $payment_id = $request->getPost('payment_id');
        $reason = $request->getPost('reason', 'استرداد توسط ادمین');

        if (!$payment_id) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'شناسه پرداخت نامعتبر است'
                ]);
            } else {
                return $this->redirect('/admin/payments', [
                    'error' => 'شناسه پرداخت نامعتبر است'
                ]);
            }
        }

        $result = $this->paymentModel->refundPayment($payment_id, $reason);

        if ($result) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => true,
                    'message' => 'استرداد وجه با موفقیت انجام شد'
                ]);
            } else {
                return $this->redirect('/admin/payments/view?id=' . $payment_id, [
                    'success' => 'استرداد وجه با موفقیت انجام شد'
                ]);
            }
        } else {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'خطا در استرداد وجه. لطفا بررسی کنید که پرداخت در وضعیت تکمیل شده باشد.'
                ]);
            } else {
                return $this->redirect('/admin/payments/view?id=' . $payment_id, [
                    'error' => 'خطا در استرداد وجه. لطفا بررسی کنید که پرداخت در وضعیت تکمیل شده باشد.'
                ]);
            }
        }
    }

    /**
     * قسمت مدیریتی - تغییر وضعیت پرداخت (فقط برای ادمین)
     *
     * @param Request $request
     * @param Response $response
     */
    public function adminUpdatePaymentStatus(Request $request, Response $response) {
        // بررسی دسترسی ادمین
        if (!Auth::isAdmin()) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'شما به این بخش دسترسی ندارید'
                ]);
            } else {
                return $this->redirect('/dashboard', [
                    'error' => 'شما به این بخش دسترسی ندارید'
                ]);
            }
        }

        $payment_id = $request->getPost('payment_id');
        $status = $request->getPost('status');
        $transaction_id = $request->getPost('transaction_id');

        if (!$payment_id || !$status) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'پارامترهای ضروری ارسال نشده است'
                ]);
            } else {
                return $this->redirect('/admin/payments', [
                    'error' => 'پارامترهای ضروری ارسال نشده است'
                ]);
            }
        }

        $result = $this->paymentModel->updatePaymentStatus($payment_id, $status, $transaction_id);

        if ($result) {
            // اگر وضعیت به "تکمیل شده" تغییر کرده باشد، اشتراک کاربر را فعال می‌کنیم
            if ($status == Payment::STATUS_COMPLETED) {
                $payment = $this->paymentModel->getPaymentById($payment_id);
                if ($payment && $payment['subscription_id']) {
                    $this->subscriptionModel->activateUserSubscription($payment['user_id'], $payment['subscription_id']);
                }
            }

            if ($request->isAjax()) {
                return $response->json([
                    'success' => true,
                    'message' => 'وضعیت پرداخت با موفقیت به‌روزرسانی شد'
                ]);
            } else {
                return $this->redirect('/admin/payments/view?id=' . $payment_id, [
                    'success' => 'وضعیت پرداخت با موفقیت به‌روزرسانی شد'
                ]);
            }
        } else {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'خطا در به‌روزرسانی وضعیت پرداخت'
                ]);
            } else {
                return $this->redirect('/admin/payments/view?id=' . $payment_id, [
                    'error' => 'خطا در به‌روزرسانی وضعیت پرداخت'
                ]);
            }
        }
    }
}