/*
* File: controllers/ApiController.php
* Description: API controller for handling external API integrations
*/

<?php
class ApiController {
    private $db;
    private $auth;

    public function __construct() {
        global $app;
        $this->db = $app->db;
        $this->auth = $app->auth;

        // Check if request has valid AJAX header
        if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
            $this->respondError('Invalid request', 403);
        }

        // Check if user is logged in for protected endpoints
        if (!$this->auth->isLoggedIn() && !in_array($_SERVER['REQUEST_URI'], ['/api/public/search'])) {
            $this->respondError('Unauthorized', 401);
        }
    }

    /**
     * Fetch Instagram data from RapidAPI
     */
    public function fetchInstagramData() {
        // Check for required parameters
        if (!isset($_POST['username']) || empty($_POST['username'])) {
            $this->respondError('Username is required');
        }

        $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $endpoint = filter_input(INPUT_POST, 'endpoint', FILTER_SANITIZE_STRING) ?: 'profile';

        try {
            $headers = [
                'x-rapidapi-host' => RAPIDAPI_HOST,
                'x-rapidapi-key' => RAPIDAPI_KEY
            ];

            if ($endpoint === 'profile') {
                $url = "https://" . RAPIDAPI_HOST . "/v1/profile?username={$username}";
            } elseif ($endpoint === 'posts') {
                $url = "https://" . RAPIDAPI_HOST . "/v1/posts?username_or_id_or_url={$username}";
            } elseif ($endpoint === 'post') {
                if (!isset($_POST['shortcode']) || empty($_POST['shortcode'])) {
                    $this->respondError('Post shortcode is required');
                }

                $shortcode = filter_input(INPUT_POST, 'shortcode', FILTER_SANITIZE_STRING);
                $url = "https://" . RAPIDAPI_HOST . "/v1/post?shortcode={$shortcode}";
            } else {
                $this->respondError('Invalid endpoint');
            }

            $response = Helper::apiRequest($url, 'GET', [], $headers);

            if (!$response || isset($response['error'])) {
                $this->respondError('Failed to fetch Instagram data: ' . ($response['error'] ?? 'Unknown error'));
            }

            $this->respond([
                'success' => true,
                'data' => $response
            ]);
        } catch (Exception $e) {
            $this->respondError('Error: ' . $e->getMessage());
        }
    }

    /**
     * Generate content using OpenAI
     */
    public function generateAiContent() {
        // Check for required parameters
        if (!isset($_POST['prompt']) || empty($_POST['prompt'])) {
            $this->respondError('Prompt is required');
        }

        $prompt = filter_input(INPUT_POST, 'prompt', FILTER_SANITIZE_STRING);
        $type = filter_input(INPUT_POST, 'type', FILTER_SANITIZE_STRING) ?: 'text';
        $model = filter_input(INPUT_POST, 'model', FILTER_SANITIZE_STRING) ?: 'gpt-4';
        $temperature = filter_input(INPUT_POST, 'temperature', FILTER_VALIDATE_FLOAT) ?: 0.7;

        // Check if user has enough credits
        $user = $this->auth->getUser();

        if (!$this->auth->canAccessFeature(4)) { // 4 = AI Content Generation feature
            $this->respondError('You do not have access to AI content generation. Please upgrade your subscription.');
        }

        try {
            if ($type === 'text') {
                // Generate text with OpenAI
                $response = Helper::openAiRequest($prompt, $model, $temperature);

                if (!$response) {
                    $this->respondError('Failed to generate content');
                }

                // Log the usage
                $this->logAiUsage($user['id'], 'text', strlen($prompt), strlen($response));

                $this->respond([
                    'success' => true,
                    'content' => $response
                ]);
            } elseif ($type === 'image') {
                // Check for additional parameters
                $size = filter_input(INPUT_POST, 'size', FILTER_SANITIZE_STRING) ?: '1024x1024';

                // Generate image with OpenAI DALL-E
                $imageUrl = Helper::openAiImageRequest($prompt, $size);

                if (!$imageUrl) {
                    $this->respondError('Failed to generate image');
                }

                // Save image locally
                $fileName = 'ai_image_' . time() . '_' . mt_rand(1000, 9999) . '.jpg';
                $localPath = UPLOADS_PATH . '/generated/images/' . $fileName;

                if (!Helper::saveImageFromUrl($imageUrl, $localPath)) {
                    $this->respondError('Failed to save generated image');
                }

                // Log the usage
                $this->logAiUsage($user['id'], 'image', strlen($prompt), 0);

                $this->respond([
                    'success' => true,
                    'image_url' => '/uploads/generated/images/' . $fileName,
                    'original_url' => $imageUrl
                ]);
            } else {
                $this->respondError('Invalid content type');
            }
        } catch (Exception $e) {
            $this->respondError('Error: ' . $e->getMessage());
        }
    }

    /**
     * Log AI usage for tracking and limitations
     *
     * @param int $userId User ID
     * @param string $type Content type (text, image)
     * @param int $promptLength Length of the prompt
     * @param int $responseLength Length of the response
     * @return bool Success status
     */
    private function logAiUsage($userId, $type, $promptLength, $responseLength) {
        try {
            $this->db->query("
                INSERT INTO ai_usage_logs (
                    user_id, content_type, prompt_length, response_length, created_at
                ) VALUES (
                    :user_id, :content_type, :prompt_length, :response_length, NOW()
                )
            ");

            $this->db->bind(':user_id', $userId);
            $this->db->bind(':content_type', $type);
            $this->db->bind(':prompt_length', $promptLength);
            $this->db->bind(':response_length', $responseLength);

            return $this->db->execute();
        } catch (Exception $e) {
            error_log('Error logging AI usage: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Verify payment after processing
     */
    public function verifyPayment() {
        // Check for required parameters
        if (!isset($_POST['authority']) || empty($_POST['authority'])) {
            $this->respondError('Authority is required');
        }

        $authority = filter_input(INPUT_POST, 'authority', FILTER_SANITIZE_STRING);
        $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);

        // Get payment from database
        $this->db->query("
            SELECT * FROM payments 
            WHERE transaction_id = :authority 
            AND status = :status
        ");

        $this->db->bind(':authority', $authority);
        $this->db->bind(':status', PAYMENT_PENDING);

        $payment = $this->db->fetch();

        if (!$payment) {
            $this->respondError('Payment not found or already processed');
        }

        try {
            // For ZarinPal, verify the payment
            if (DEFAULT_PAYMENT_GATEWAY === 'zarinpal') {
                $merchantID = ''; // Add your ZarinPal merchant ID
                $amount = $payment['amount'];
                $verifyUrl = "https://api.zarinpal.com/pg/v4/payment/verify.json";

                $data = [
                    'merchant_id' => $merchantID,
                    'authority' => $authority,
                    'amount' => $amount
                ];

                $response = Helper::apiRequest($verifyUrl, 'POST', $data);

                if ($response['data']['code'] == 100 || $response['data']['code'] == 101) {
                    // Payment successful
                    $this->completePayment($payment['id'], $response['data']['ref_id']);

                    $this->respond([
                        'success' => true,
                        'message' => 'Payment verified successfully',
                        'ref_id' => $response['data']['ref_id']
                    ]);
                } else {
                    // Payment failed
                    $this->failPayment($payment['id'], $response['errors']['code']);

                    $this->respondError('Payment verification failed: ' . $response['errors']['message']);
                }
            } else {
                $this->respondError('Unsupported payment gateway');
            }
        } catch (Exception $e) {
            $this->respondError('Error verifying payment: ' . $e->getMessage());
        }
    }

    /**
     * Complete a payment
     *
     * @param int $paymentId Payment ID
     * @param string $refId Reference ID from payment gateway
     * @return bool Success status
     */
    private function completePayment($paymentId, $refId) {
        try {
            $this->db->beginTransaction();

            // Update payment status
            $this->db->query("
                UPDATE payments 
                SET status = :status, 
                    payment_date = NOW(), 
                    transaction_id = :ref_id,
                    updated_at = NOW() 
                WHERE id = :id
            ");

            $this->db->bind(':status', PAYMENT_COMPLETED);
            $this->db->bind(':ref_id', $refId);
            $this->db->bind(':id', $paymentId);

            $this->db->execute();

            // Get payment details
            $this->db->query("SELECT * FROM payments WHERE id = :id");
            $this->db->bind(':id', $paymentId);
            $payment = $this->db->fetch();

            if (!$payment) {
                throw new Exception('Payment not found');
            }

            // If payment is for subscription, activate or extend it
            if ($payment['subscription_id']) {
                $this->db->query("SELECT * FROM subscriptions WHERE id = :id");
                $this->db->bind(':id', $payment['subscription_id']);
                $subscription = $this->db->fetch();

                if (!$subscription) {
                    throw new Exception('Subscription not found');
                }

                // Get subscription plan details
                $this->db->query("SELECT * FROM subscription_plans WHERE id = :id");
                $this->db->bind(':id', $subscription['plan_id']);
                $plan = $this->db->fetch();

                if (!$plan) {
                    throw new Exception('Subscription plan not found');
                }

                // Calculate new expiry date
                $expiryDate = new DateTime($subscription['expiry_date']);
                $now = new DateTime();

                // If subscription is expired, start from now
                if ($expiryDate < $now) {
                    $expiryDate = $now;
                }

                // Add plan duration to expiry date
                $expiryDate->add(new DateInterval('P' . $plan['duration'] . 'D'));

                // Update subscription
                $this->db->query("
                    UPDATE subscriptions 
                    SET status = :status,
                        expiry_date = :expiry_date,
                        updated_at = NOW() 
                    WHERE id = :id
                ");

                $this->db->bind(':status', SUBSCRIPTION_ACTIVE);
                $this->db->bind(':expiry_date', $expiryDate->format('Y-m-d H:i:s'));
                $this->db->bind(':id', $payment['subscription_id']);

                $this->db->execute();
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log('Error completing payment: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Mark a payment as failed
     *
     * @param int $paymentId Payment ID
     * @param string $errorCode Error code from payment gateway
     * @return bool Success status
     */
    private function failPayment($paymentId, $errorCode) {
        try {
            $this->db->query("
                UPDATE payments 
                SET status = :status, 
                    error_code = :error_code,
                    updated_at = NOW() 
                WHERE id = :id
            ");

            $this->db->bind(':status', PAYMENT_FAILED);
            $this->db->bind(':error_code', $errorCode);
            $this->db->bind(':id', $paymentId);

            return $this->db->execute();
        } catch (Exception $e) {
            error_log('Error failing payment: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send JSON response
     *
     * @param mixed $data Response data
     * @param int $statusCode HTTP status code
     */
    private function respond($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    /**
     * Send JSON error response
     *
     * @param string $message Error message
     * @param int $statusCode HTTP status code
     */
    private function respondError($message, $statusCode = 400) {
        $this->respond([
            'success' => false,
            'error' => $message
        ], $statusCode);
    }
}