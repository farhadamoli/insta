/*
* File: controllers/ContentController.php
* Description: Controller for content generation features
*/

<?php
class ContentController {
    private $db;
    private $auth;

    public function __construct() {
        global $app;
        $this->db = $app->db;
        $this->auth = $app->auth;

        // Check if user is logged in
        if (!$this->auth->isLoggedIn()) {
            App::redirect('login');
        }

        // Check if user has subscription for content generation features
        if (!$this->auth->canAccessFeature(4)) { // 4 = AI Profile Image Generation feature ID
            // Store intended URL for redirect after subscription
            $_SESSION['redirect_after_subscription'] = $_SERVER['REQUEST_URI'];
            App::redirect('dashboard/subscription');
        }
    }

    /**
     * Content services landing page
     */
    public function index() {
        $user = $this->auth->getUser();

        return App::view('dashboard.content.index', [
            'user' => $user
        ]);
    }

    /**
     * Profile image generation form
     */
    public function profileImageForm() {
        $user = $this->auth->getUser();

        return App::view('dashboard.content.profile_image', [
            'user' => $user
        ]);
    }

    /**
     * Generate profile image
     */
    public function generateProfileImage() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/content/profile-image');
        }

        $user = $this->auth->getUser();
        $projectTitle = filter_input(INPUT_POST, 'project_title', FILTER_SANITIZE_STRING);
        $prompt = filter_input(INPUT_POST, 'prompt', FILTER_SANITIZE_STRING);
        $negativePrompt = filter_input(INPUT_POST, 'negative_prompt', FILTER_SANITIZE_STRING) ?: '';
        $size = filter_input(INPUT_POST, 'size', FILTER_SANITIZE_STRING) ?: '1024x1024';
        $creativity = filter_input(INPUT_POST, 'creativity', FILTER_VALIDATE_FLOAT) ?: 0.7;
        $style = filter_input(INPUT_POST, 'style', FILTER_SANITIZE_STRING) ?: '';

        // Validate inputs
        if (empty($prompt)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'موضوع تصویر را وارد کنید.'
            ];
            App::redirect('dashboard/content/profile-image');
        }

        // Enhance prompt with style
        $enhancedPrompt = $prompt;

        if (!empty($style)) {
            $enhancedPrompt .= ", style: {$style}";
        }

        if (!empty($negativePrompt)) {
            $enhancedPrompt .= ", DO NOT include: {$negativePrompt}";
        }

        // Add common profile image parameters
        $enhancedPrompt .= ", professional Instagram profile picture, high quality, studio lighting, centered composition";

        try {
            // Generate image with OpenAI
            $imageUrl = Helper::openAiImageRequest($enhancedPrompt, $size);

            if (!$imageUrl) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'مشکلی در تولید تصویر پیش آمد. لطفاً دوباره تلاش کنید.'
                ];
                App::redirect('dashboard/content/profile-image');
            }

            // Save image locally
            $fileName = 'profile_' . time() . '_' . mt_rand(1000, 9999) . '.jpg';
            $localPath = UPLOADS_PATH . '/generated/images/' . $fileName;

            if (!Helper::saveImageFromUrl($imageUrl, $localPath)) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'مشکلی در ذخیره تصویر پیش آمد. لطفاً دوباره تلاش کنید.'
                ];
                App::redirect('dashboard/content/profile-image');
            }

            // Save to database
            $this->db->query("
                INSERT INTO generated_images (
                    user_id, prompt, negative_prompt, image_url, local_path, 
                    width, height, style, created_at
                ) VALUES (
                    :user_id, :prompt, :negative_prompt, :image_url, :local_path, 
                    :width, :height, :style, NOW()
                )
            ");

            $this->db->bind(':user_id', $user['id']);
            $this->db->bind(':prompt', $prompt);
            $this->db->bind(':negative_prompt', $negativePrompt);
            $this->db->bind(':image_url', $imageUrl);
            $this->db->bind(':local_path', '/uploads/generated/images/' . $fileName);
            $this->db->bind(':width', $size === '1024x1024' ? 1024 : 512);
            $this->db->bind(':height', $size === '1024x1024' ? 1024 : 512);
            $this->db->bind(':style', $style);

            $this->db->execute();

            // Log the generation
            $this->logContentGeneration($user['id'], 'profile_image', $prompt);

            return App::view('dashboard.content.profile_image_result', [
                'user' => $user,
                'image_path' => '/uploads/generated/images/' . $fileName,
                'prompt' => $prompt,
                'project_title' => $projectTitle
            ]);
        } catch (Exception $e) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در تولید تصویر پیش آمد: ' . $e->getMessage()
            ];
            App::redirect('dashboard/content/profile-image');
        }
    }

    /**
     * Post planner form
     */
    public function postPlannerForm() {
        $user = $this->auth->getUser();

        // Get user's Instagram pages
        $this->db->query("SELECT id, username FROM instagram_pages WHERE user_id = :user_id");
        $this->db->bind(':user_id', $user['id']);
        $pages = $this->db->fetchAll();

        // Get post types
        $postTypes = [
            'image' => 'تصویر',
            'carousel' => 'کارسول',
            'video' => 'ویدیو',
            'reels' => 'ریلز'
        ];

        // Get content styles
        $contentStyles = [
            'informative' => 'آموزشی',
            'entertaining' => 'سرگرمی',
            'inspiring' => 'الهام‌بخش',
            'promotional' => 'تبلیغاتی',
            'storytelling' => 'داستانی',
            'behind_the_scenes' => 'پشت صحنه',
            'user_generated' => 'محتوای کاربری',
            'Q_and_A' => 'پرسش و پاسخ',
            'how_to' => 'آموزش گام به گام',
            'tips_and_tricks' => 'نکات و ترفندها'
        ];

        return App::view('dashboard.content.post_planner', [
            'user' => $user,
            'pages' => $pages,
            'post_types' => $postTypes,
            'content_styles' => $contentStyles
        ]);
    }

    /**
     * Generate post plan
     */
    public function postPlanner() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/content/post-planner');
        }

        $user = $this->auth->getUser();
        $pageId = filter_input(INPUT_POST, 'page_id', FILTER_VALIDATE_INT);
        $postDate = filter_input(INPUT_POST, 'post_date', FILTER_SANITIZE_STRING);
        $postTime = filter_input(INPUT_POST, 'post_time', FILTER_SANITIZE_STRING);
        $postType = filter_input(INPUT_POST, 'post_type', FILTER_SANITIZE_STRING);
        $topic = filter_input(INPUT_POST, 'topic', FILTER_SANITIZE_STRING);
        $hashtagCount = filter_input(INPUT_POST, 'hashtag_count', FILTER_VALIDATE_INT) ?: 5;
        $commentHashtag = filter_input(INPUT_POST, 'comment_hashtag', FILTER_VALIDATE_BOOLEAN);
        $contentStyle = filter_input(INPUT_POST, 'content_style', FILTER_SANITIZE_STRING);

        // Validate inputs
        if (empty($topic)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'موضوع پست را وارد کنید.'
            ];
            App::redirect('dashboard/content/post-planner');
        }

        try {
            // Get page info if selected
            $page = null;
            if ($pageId) {
                $this->db->query("SELECT * FROM instagram_pages WHERE id = :id AND user_id = :user_id");
                $this->db->bind(':id', $pageId);
                $this->db->bind(':user_id', $user['id']);
                $page = $this->db->fetch();
            }

            // Build prompt for OpenAI based on inputs
            $prompt = "Generate an Instagram post about \"{$topic}\"";

            if ($page) {
                $prompt .= " for an Instagram page about {$page['business_category']}";

                if (!empty($page['specialist_category'])) {
                    $prompt .= " with a {$page['specialist_category']} approach";
                }
            }

            if (!empty($contentStyle)) {
                $prompt .= " in a {$contentStyle} style";
            }

            if ($postType === 'carousel') {
                $prompt .= ". Create a carousel post with 5 slides, with a content idea for each slide, and an overall theme.";
            } elseif ($postType === 'video' || $postType === 'reels') {
                $prompt .= ". Create a short video script with a hook, main content, and call to action.";
            } else {
                $prompt .= ". Create an engaging single image post.";
            }

            $prompt .= " Provide a content idea, a suggested caption in Persian language, and {$hashtagCount} relevant hashtags";

            if ($commentHashtag) {
                $prompt .= " that should be placed in the first comment";
            } else {
                $prompt .= " that should be included in the caption";
            }

            $prompt .= ". Also suggest an alt text for the image for better accessibility.";

            // Generate content with OpenAI
            $generatedContent = Helper::openAiRequest($prompt);

            if (!$generatedContent) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'مشکلی در تولید محتوا پیش آمد. لطفاً دوباره تلاش کنید.'
                ];
                App::redirect('dashboard/content/post-planner');
            }

            // Parse generated content
            $contentIdea = $this->extractFromContent($generatedContent, 'Content Idea', 'Caption');
            $caption = $this->extractFromContent($generatedContent, 'Caption', 'Hashtags');
            $hashtags = $this->extractFromContent($generatedContent, 'Hashtags', 'Alt Text');
            $altText = $this->extractFromContent($generatedContent, 'Alt Text', null);

            // Generate image prompt for the content idea
            $imagePrompt = "Create an Instagram post image about \"{$topic}\" that represents the following idea: {$contentIdea}";

            if (!empty($contentStyle)) {
                $imagePrompt .= " in a {$contentStyle} style";
            }

            $imagePrompt .= ". The image should be visually appealing with good composition, vibrant colors, and high quality.";

            // Save to database
            $this->db->query("
                INSERT INTO planned_contents (
                    plan_id, content_type, scheduled_date, scheduled_time, topic,
                    hashtag_count, hashtags, caption, idea, content_style,
                    alt_text, status, created_at
                ) VALUES (
                    :plan_id, :content_type, :scheduled_date, :scheduled_time, :topic,
                    :hashtag_count, :hashtags, :caption, :idea, :content_style,
                    :alt_text, :status, NOW()
                )
            ");

            // Get or create content plan
            $planId = null;
            if ($pageId) {
                // Check if plan exists for this page
                $this->db->query("
                    SELECT id FROM content_plans 
                    WHERE user_id = :user_id AND page_id = :page_id
                    AND end_date IS NULL OR end_date >= CURDATE()
                    ORDER BY id DESC LIMIT 1
                ");

                $this->db->bind(':user_id', $user['id']);
                $this->db->bind(':page_id', $pageId);

                $existingPlan = $this->db->fetch();

                if ($existingPlan) {
                    $planId = $existingPlan['id'];
                } else {
                    // Create new plan
                    $this->db->query("
                        INSERT INTO content_plans (
                            user_id, page_id, title, description, start_date, created_at
                        ) VALUES (
                            :user_id, :page_id, :title, :description, CURDATE(), NOW()
                        )
                    ");

                    $this->db->bind(':user_id', $user['id']);
                    $this->db->bind(':page_id', $pageId);
                    $this->db->bind(':title', 'Content Plan for ' . ($page['username'] ?? 'New Page'));
                    $this->db->bind(':description', 'Auto-generated content plan');

                    $this->db->execute();
                    $planId = $this->db->lastInsertId();
                }
            } else {
                // Create new plan without page
                $this->db->query("
                    INSERT INTO content_plans (
                        user_id, title, description, start_date, created_at
                    ) VALUES (
                        :user_id, :title, :description, CURDATE(), NOW()
                    )
                ");

                $this->db->bind(':user_id', $user['id']);
                $this->db->bind(':title', 'General Content Plan');
                $this->db->bind(':description', 'Auto-generated content plan');

                $this->db->execute();
                $planId = $this->db->lastInsertId();
            }

            $this->db->bind(':plan_id', $planId);
            $this->db->bind(':content_type', $postType);
            $this->db->bind(':scheduled_date', $postDate);
            $this->db->bind(':scheduled_time', $postTime);
            $this->db->bind(':topic', $topic);
            $this->db->bind(':hashtag_count', $hashtagCount);
            $this->db->bind(':hashtags', $hashtags);
            $this->db->bind(':caption', $caption);
            $this->db->bind(':idea', $contentIdea);
            $this->db->bind(':content_style', $contentStyle);
            $this->db->bind(':alt_text', $altText);
            $this->db->bind(':status', 1); // 1 = Planned

            $this->db->execute();
            $contentId = $this->db->lastInsertId();

            // Log the generation
            $this->logContentGeneration($user['id'], 'post_plan', $topic);

            // Generate image if it's an image or carousel post
            $imagePath = null;
            if ($postType === 'image' || $postType === 'carousel') {
                $imageUrl = Helper::openAiImageRequest($imagePrompt, '1024x1024');

                if ($imageUrl) {
                    $fileName = 'post_' . time() . '_' . mt_rand(1000, 9999) . '.jpg';
                    $localPath = UPLOADS_PATH . '/generated/images/' . $fileName;

                    if (Helper::saveImageFromUrl($imageUrl, $localPath)) {
                        $imagePath = '/uploads/generated/images/' . $fileName;

                        // Save to database
                        $this->db->query("
                            INSERT INTO generated_images (
                                user_id, prompt, image_url, local_path, width, height, created_at
                            ) VALUES (
                                :user_id, :prompt, :image_url, :local_path, :width, :height, NOW()
                            )
                        ");

                        $this->db->bind(':user_id', $user['id']);
                        $this->db->bind(':prompt', $imagePrompt);
                        $this->db->bind(':image_url', $imageUrl);
                        $this->db->bind(':local_path', $imagePath);
                        $this->db->bind(':width', 1024);
                        $this->db->bind(':height', 1024);

                        $this->db->execute();
                        $imageId = $this->db->lastInsertId();

                        // Link image to content
                        $this->db->query("
                            UPDATE planned_contents 
                            SET image_id = :image_id 
                            WHERE id = :id
                        ");

                        $this->db->bind(':image_id', $imageId);
                        $this->db->bind(':id', $contentId);

                        $this->db->execute();
                    }
                }
            }

            return App::view('dashboard.content.post_planner_result', [
                'user' => $user,
                'page' => $page,
                'post_type' => $postType,
                'post_date' => $postDate,
                'post_time' => $postTime,
                'topic' => $topic,
                'content_idea' => $contentIdea,
                'caption' => $caption,
                'hashtags' => $hashtags,
                'alt_text' => $altText,
                'image_path' => $imagePath,
                'content_id' => $contentId
            ]);
        } catch (Exception $e) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در تولید محتوا پیش آمد: ' . $e->getMessage()
            ];
            App::redirect('dashboard/content/post-planner');
        }
    }

    /**
     * Extract specific section from generated content
     *
     * @param string $content Full content
     * @param string $startSection Section name to start from
     * @param string|null $endSection Section name to end at (null for end of content)
     * @return string Extracted section or empty string
     */
    private function extractFromContent($content, $startSection, $endSection = null) {
        $pattern = '/(?:^|\n)' . preg_quote($startSection, '/') . ':(.*?)(?:(?:\n' . preg_quote($endSection, '/') . ':)|$)/s';

        if (preg_match($pattern, $content, $matches)) {
            return trim($matches[1]);
        }

        // Try alternative format without colon
        $pattern = '/(?:^|\n)' . preg_quote($startSection, '/') . '(.*?)(?:(?:\n' . preg_quote($endSection, '/') . ')|$)/s';

        if (preg_match($pattern, $content, $matches)) {
            return trim($matches[1]);
        }

        return '';
    }

    /**
     * Generate image for content
     */
    public function generateContentImage() {
        // Only accept AJAX requests
        if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
            header('HTTP/1.1 403 Forbidden');
            exit;
        }

        $user = $this->auth->getUser();
        $contentId = filter_input(INPUT_POST, 'content_id', FILTER_VALIDATE_INT);
        $customPrompt = filter_input(INPUT_POST, 'prompt', FILTER_SANITIZE_STRING);

        if (!$contentId) {
            echo json_encode([
                'success' => false,
                'message' => 'Content ID is required'
            ]);
            exit;
        }

        try {
            // Get content details
            $this->db->query("
                SELECT * FROM planned_contents 
                WHERE id = :id AND plan_id IN (
                    SELECT id FROM content_plans WHERE user_id = :user_id
                )
            ");

            $this->db->bind(':id', $contentId);
            $this->db->bind(':user_id', $user['id']);

            $content = $this->db->fetch();

            if (!$content) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Content not found or not owned by user'
                ]);
                exit;
            }

            // Build image prompt
            $prompt = $customPrompt ?: "Create an Instagram post image about \"{$content['topic']}\" that represents the following idea: {$content['idea']}";

            if (!empty($content['content_style'])) {
                $prompt .= " in a {$content['content_style']} style";
            }

            $prompt .= ". The image should be visually appealing with good composition, vibrant colors, and high quality.";

            // Generate image with OpenAI
            $imageUrl = Helper::openAiImageRequest($prompt, '1024x1024');

            if (!$imageUrl) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to generate image'
                ]);
                exit;
            }

            // Save image locally
            $fileName = 'post_' . time() . '_' . mt_rand(1000, 9999) . '.jpg';
            $localPath = UPLOADS_PATH . '/generated/images/' . $fileName;

            if (!Helper::saveImageFromUrl($imageUrl, $localPath)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to save generated image'
                ]);
                exit;
            }

            $imagePath = '/uploads/generated/images/' . $fileName;

            // Save to database
            $this->db->query("
                INSERT INTO generated_images (
                    user_id, prompt, image_url, local_path, width, height, created_at
                ) VALUES (
                    :user_id, :prompt, :image_url, :local_path, :width, :height, NOW()
                )
            ");

            $this->db->bind(':user_id', $user['id']);
            $this->db->bind(':prompt', $prompt);
            $this->db->bind(':image_url', $imageUrl);
            $this->db->bind(':local_path', $imagePath);
            $this->db->bind(':width', 1024);
            $this->db->bind(':height', 1024);

            $this->db->execute();
            $imageId = $this->db->lastInsertId();

            // Link image to content
            $this->db->query("
                UPDATE planned_contents 
                SET image_id = :image_id 
                WHERE id = :id
            ");

            $this->db->bind(':image_id', $imageId);
            $this->db->bind(':id', $contentId);

            $this->db->execute();

            echo json_encode([
                'success' => true,
                'image_path' => $imagePath,
                'message' => 'تصویر با موفقیت تولید شد'
            ]);
            exit;
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ]);
            exit;
        }
    }

    /**
     * Story planner form
     */
    public function storyPlannerForm() {
        $user = $this->auth->getUser();

        // Get user's Instagram pages
        $this->db->query("SELECT id, username FROM instagram_pages WHERE user_id = :user_id");
        $this->db->bind(':user_id', $user['id']);
        $pages = $this->db->fetchAll();

        // Get story types
        $storyTypes = [
            'image' => 'تصویر',
            'video' => 'ویدیو',
            'poll' => 'نظرسنجی',
            'question' => 'سوال',
            'quiz' => 'کوئیز',
            'slider' => 'اسلایدر',
            'countdown' => 'شمارش معکوس',
            'product' => 'محصول'
        ];

        // Get content styles
        $contentStyles = [
            'informative' => 'آموزشی',
            'entertaining' => 'سرگرمی',
            'inspiring' => 'الهام‌بخش',
            'promotional' => 'تبلیغاتی',
            'behind_the_scenes' => 'پشت صحنه',
            'user_generated' => 'محتوای کاربری',
            'daily_life' => 'زندگی روزمره',
            'Q_and_A' => 'پرسش و پاسخ',
            'tutorial' => 'آموزشی',
            'announcement' => 'اطلاعیه'
        ];

        return App::view('dashboard.content.story_planner', [
            'user' => $user,
            'pages' => $pages,
            'story_types' => $storyTypes,
            'content_styles' => $contentStyles
        ]);
    }

    /**
     * Generate story plan
     */
    public function storyPlanner() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/content/story-planner');
        }

        $user = $this->auth->getUser();
        $pageId = filter_input(INPUT_POST, 'page_id', FILTER_VALIDATE_INT);
        $storyDate = filter_input(INPUT_POST, 'story_date', FILTER_SANITIZE_STRING);
        $storyTime = filter_input(INPUT_POST, 'story_time', FILTER_SANITIZE_STRING);
        $storyType = filter_input(INPUT_POST, 'story_type', FILTER_SANITIZE_STRING);
        $topic = filter_input(INPUT_POST, 'topic', FILTER_SANITIZE_STRING);
        $contentStyle = filter_input(INPUT_POST, 'content_style', FILTER_SANITIZE_STRING);

        // Validate inputs
        if (empty($topic)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'موضوع استوری را وارد کنید.'
            ];
            App::redirect('dashboard/content/story-planner');
        }

        try {
            // Get page info if selected
            $page = null;
            if ($pageId) {
                $this->db->query("SELECT * FROM instagram_pages WHERE id = :id AND user_id = :user_id");
                $this->db->bind(':id', $pageId);
                $this->db->bind(':user_id', $user['id']);
                $page = $this->db->fetch();
            }

            // Build prompt for OpenAI based on inputs
            $prompt = "Generate an Instagram story about \"{$topic}\"";

            if ($page) {
                $prompt .= " for an Instagram page about {$page['business_category']}";

                if (!empty($page['specialist_category'])) {
                    $prompt .= " with a {$page['specialist_category']} approach";
                }
            }

            if (!empty($contentStyle)) {
                $prompt .= " in a {$contentStyle} style";
            }

            $prompt .= ". This will be a {$storyType} story.";

            if ($storyType === 'poll') {
                $prompt .= " Include a poll question with two options.";
            } elseif ($storyType === 'question') {
                $prompt .= " Include a question box prompt that encourages engagement.";
            } elseif ($storyType === 'quiz') {
                $prompt .= " Include a quiz question with four options and mark the correct answer.";
            } elseif ($storyType === 'slider') {
                $prompt .= " Include a slider question that fits the topic.";
            }

            $prompt .= " Provide a content idea, suggested text in Persian language, and how the story should look visually.";

            // Generate content with OpenAI
            $generatedContent = Helper::openAiRequest($prompt);

            if (!$generatedContent) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'مشکلی در تولید محتوا پیش آمد. لطفاً دوباره تلاش کنید.'
                ];
                App::redirect('dashboard/content/story-planner');
            }

            // Parse generated content
            $contentIdea = $this->extractFromContent($generatedContent, 'Content Idea', 'Text');
            $text = $this->extractFromContent($generatedContent, 'Text', 'Visual Description');
            $visualDescription = $this->extractFromContent($generatedContent, 'Visual Description', null);

            // Generate image prompt for the content idea
            $imagePrompt = "Create an Instagram story image about \"{$topic}\" that represents the following idea: {$contentIdea}";

            if (!empty($contentStyle)) {
                $imagePrompt .= " in a {$contentStyle} style";
            }

            $imagePrompt .= ". The image should be vertical (9:16 ratio), visually appealing with good composition, vibrant colors, and high quality.";

            if (!empty($visualDescription)) {
                $imagePrompt .= " Visual details: {$visualDescription}";
            }

            // Save to database
            $this->db->query("
                INSERT INTO planned_contents (
                    plan_id, content_type, scheduled_date, scheduled_time, topic,
                    caption, idea, content_style, status, created_at
                ) VALUES (
                    :plan_id, :content_type, :scheduled_date, :scheduled_time, :topic,
                    :caption, :idea, :content_style, :status, NOW()
                )
            ");

            // Get or create content plan
            $planId = null;
            if ($pageId) {
                // Check if plan exists for this page
                $this->db->query("
                    SELECT id FROM content_plans 
                    WHERE user_id = :user_id AND page_id = :page_id
                    AND end_date IS NULL OR end_date >= CURDATE()
                    ORDER BY id DESC LIMIT 1
                ");

                $this->db->bind(':user_id', $user['id']);
                $this->db->bind(':page_id', $pageId);

                $existingPlan = $this->db->fetch();

                if ($existingPlan) {
                    $planId = $existingPlan['id'];
                } else {
                    // Create new plan
                    $this->db->query("
                        INSERT INTO content_plans (
                            user_id, page_id, title, description, start_date, created_at
                        ) VALUES (
                            :user_id, :page_id, :title, :description, CURDATE(), NOW()
                        )
                    ");

                    $this->db->bind(':user_id', $user['id']);
                    $this->db->bind(':page_id', $pageId);
                    $this->db->bind(':title', 'Content Plan for ' . ($page['username'] ?? 'New Page'));
                    $this->db->bind(':description', 'Auto-generated content plan');

                    $this->db->execute();
                    $planId = $this->db->lastInsertId();
                }
            } else {
                // Create new plan without page
                $this->db->query("
                    INSERT INTO content_plans (
                        user_id, title, description, start_date, created_at
                    ) VALUES (
                        :user_id, :title, :description, CURDATE(), NOW()
                    )
                ");

                $this->db->bind(':user_id', $user['id']);
                $this->db->bind(':title', 'General Content Plan');
                $this->db->bind(':description', 'Auto-generated content plan');

                $this->db->execute();
                $planId = $this->db->lastInsertId();
            }

            $this->db->bind(':plan_id', $planId);
            $this->db->bind(':content_type', 'story_' . $storyType);
            $this->db->bind(':scheduled_date', $storyDate);
            $this->db->bind(':scheduled_time', $storyTime);
            $this->db->bind(':topic', $topic);
            $this->db->bind(':caption', $text);
            $this->db->bind(':idea', $contentIdea);
            $this->db->bind(':content_style', $contentStyle);
            $this->db->bind(':status', 1); // 1 = Planned

            $this->db->execute();
            $contentId = $this->db->lastInsertId();

            // Log the generation
            $this->logContentGeneration($user['id'], 'story_plan', $topic);

            // Generate image
            $imagePath = null;
            $imageUrl = Helper::openAiImageRequest($imagePrompt, '1024x1792'); // Approximate 9:16 ratio

            if ($imageUrl) {
                $fileName = 'story_' . time() . '_' . mt_rand(1000, 9999) . '.jpg';
                $localPath = UPLOADS_PATH . '/generated/images/' . $fileName;

                if (Helper::saveImageFromUrl($imageUrl, $localPath)) {
                    $imagePath = '/uploads/generated/images/' . $fileName;

                    // Save to database
                    $this->db->query("
                        INSERT INTO generated_images (
                            user_id, prompt, image_url, local_path, width, height, created_at
                        ) VALUES (
                            :user_id, :prompt, :image_url, :local_path, :width, :height, NOW()
                        )
                    ");

                    $this->db->bind(':user_id', $user['id']);
                    $this->db->bind(':prompt', $imagePrompt);
                    $this->db->bind(':image_url', $imageUrl);
                    $this->db->bind(':local_path', $imagePath);
                    $this->db->bind(':width', 1024);
                    $this->db->bind(':height', 1792);

                    $this->db->execute();
                    $imageId = $this->db->lastInsertId();

                    // Link image to content
                    $this->db->query("
                        UPDATE planned_contents 
                        SET image_id = :image_id 
                        WHERE id = :id
                    ");

                    $this->db->bind(':image_id', $imageId);
                    $this->db->bind(':id', $contentId);

                    $this->db->execute();
                }
            }

            return App::view('dashboard.content.story_planner_result', [
                'user' => $user,
                'page' => $page,
                'story_type' => $storyType,
                'story_date' => $storyDate,
                'story_time' => $storyTime,
                'topic' => $topic,
                'content_idea' => $contentIdea,
                'text' => $text,
                'visual_description' => $visualDescription,
                'image_path' => $imagePath,
                'content_id' => $contentId
            ]);
        } catch (Exception $e) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در تولید محتوا پیش آمد: ' . $e->getMessage()
            ];
            App::redirect('dashboard/content/story-planner');
        }
    }

    /**
     * Content ideas form
     */
    public function contentIdeasForm() {
        $user = $this->auth->getUser();

        // Get user's Instagram pages
        $this->db->query("SELECT id, username FROM instagram_pages WHERE user_id = :user_id");
        $this->db->bind(':user_id', $user['id']);
        $pages = $this->db->fetchAll();

        // Get content types
        $contentTypes = [
            'general' => 'ایده کلی محتوا',
            'educational' => 'محتوای آموزشی',
            'promotional' => 'محتوای تبلیغاتی',
            'entertainment' => 'محتوای سرگرمی',
            'inspirational' => 'محتوای انگیزشی',
            'storytelling' => 'داستان‌سرایی',
            'behind_the_scenes' => 'پشت صحنه',
            'trends' => 'ترندهای روز',
            'seasonal' => 'مناسبتی و فصلی',
            'products' => 'معرفی محصولات'
        ];

        // Get audience types
        $audienceTypes = [
            'general' => 'عمومی',
            'teenagers' => 'نوجوانان',
            'young_adults' => 'جوانان',
            'adults' => 'بزرگسالان',
            'seniors' => 'سالمندان',
            'parents' => 'والدین',
            'professionals' => 'متخصصان',
            'students' => 'دانش‌آموزان و دانشجویان',
            'business_owners' => 'صاحبان کسب و کار',
            'tech_savvy' => 'علاقه‌مندان به تکنولوژی'
        ];

        return App::view('dashboard.content.content_ideas', [
            'user' => $user,
            'pages' => $pages,
            'content_types' => $contentTypes,
            'audience_types' => $audienceTypes
        ]);
    }

    /**
     * Generate content ideas
     */
    public function generateContentIdeas() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/content/ideas');
        }

        $user = $this->auth->getUser();
        $pageId = filter_input(INPUT_POST, 'page_id', FILTER_VALIDATE_INT);
        $contentType = filter_input(INPUT_POST, 'content_type', FILTER_SANITIZE_STRING);
        $audienceType = filter_input(INPUT_POST, 'audience_type', FILTER_SANITIZE_STRING);
        $count = filter_input(INPUT_POST, 'count', FILTER_VALIDATE_INT) ?: 5;
        $additionalInfo = filter_input(INPUT_POST, 'additional_info', FILTER_SANITIZE_STRING);

        try {
            // Get page info if selected
            $page = null;
            if ($pageId) {
                $this->db->query("SELECT * FROM instagram_pages WHERE id = :id AND user_id = :user_id");
                $this->db->bind(':id', $pageId);
                $this->db->bind(':user_id', $user['id']);
                $page = $this->db->fetch();
            }

            // Build prompt for OpenAI based on inputs
            $prompt = "Generate {$count} creative and unique content ideas for Instagram";

            if ($page) {
                $prompt .= " for a page about {$page['business_category']}";

                if (!empty($page['specialist_category'])) {
                    $prompt .= " with a {$page['specialist_category']} approach";
                }
            }

            if (!empty($contentType) && $contentType !== 'general') {
                $prompt .= ", specifically for {$contentType} content";
            }

            if (!empty($audienceType) && $audienceType !== 'general') {
                $prompt .= " targeting {$audienceType}";
            }

            if (!empty($additionalInfo)) {
                $prompt .= ". Additional context: {$additionalInfo}";
            }

            $prompt .= ". For each idea, provide a title, description, and recommendation for the content format (image, carousel, video, or story). Write in Persian language.";

            // Generate content with OpenAI
            $generatedContent = Helper::openAiRequest($prompt);

            if (!$generatedContent) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'مشکلی در تولید ایده‌های محتوایی پیش آمد. لطفاً دوباره تلاش کنید.'
                ];
                App::redirect('dashboard/content/ideas');
            }

            // Parse ideas from generated content
            $ideas = $this->parseIdeas($generatedContent);

            // Save ideas to database
            foreach ($ideas as $idea) {
                $this->db->query("
                    INSERT INTO content_ideas (
                        user_id, page_id, title, description, format, content_type,
                        audience_type, created_at
                    ) VALUES (
                        :user_id, :page_id, :title, :description, :format, :content_type,
                        :audience_type, NOW()
                    )
                ");

                $this->db->bind(':user_id', $user['id']);
                $this->db->bind(':page_id', $pageId);
                $this->db->bind(':title', $idea['title']);
                $this->db->bind(':description', $idea['description']);
                $this->db->bind(':format', $idea['format']);
                $this->db->bind(':content_type', $contentType);
                $this->db->bind(':audience_type', $audienceType);

                $this->db->execute();
            }

            // Log the generation
            $this->logContentGeneration($user['id'], 'content_ideas', $contentType . ' for ' . $audienceType);

            return App::view('dashboard.content.content_ideas_result', [
                'user' => $user,
                'page' => $page,
                'content_type' => $contentType,
                'audience_type' => $audienceType,
                'ideas' => $ideas
            ]);
        } catch (Exception $e) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در تولید ایده‌های محتوایی پیش آمد: ' . $e->getMessage()
            ];
            App::redirect('dashboard/content/ideas');
        }
    }

    /**
     * Parse content ideas from OpenAI response
     *
     * @param string $content Generated content
     * @return array Array of parsed ideas
     */
    private function parseIdeas($content) {
        $ideas = [];

        // Try to find ideas by numbering pattern (1., 2., etc.)
        if (preg_match_all('/(\d+\.\s*)(.*?)(?=(?:\d+\.\s*)|$)/s', $content, $matches)) {
            foreach ($matches[2] as $ideaContent) {
                $idea = $this->parseIdeaContent($ideaContent);

                if ($idea) {
                    $ideas[] = $idea;
                }
            }
        }
        // If no numbered ideas found, try to split by double newlines
        else if (empty($ideas)) {
            $sections = preg_split('/\n\s*\n/', $content);

            foreach ($sections as $section) {
                $idea = $this->parseIdeaContent($section);

                if ($idea) {
                    $ideas[] = $idea;
                }
            }
        }

        return $ideas;
    }

    /**
     * Parse individual idea content
     *
     * @param string $content Idea content
     * @return array|null Parsed idea or null if invalid
     */
    private function parseIdeaContent($content) {
        $title = '';
        $description = '';
        $format = '';

        // Look for title
        if (preg_match('/(عنوان|موضوع|ایده)(:|：)?\s*(.*?)(\n|$)/i', $content, $titleMatch)) {
            $title = trim($titleMatch[3]);
        } else if (preg_match('/^(.*?)(\n|:)/', $content, $firstLineMatch)) {
            $title = trim($firstLineMatch[1]);
        }

        // Look for description
        if (preg_match('/(توضیحات|شرح|توصیف)(:|：)?\s*(.*?)(\n(فرمت|قالب)|$)/is', $content, $descMatch)) {
            $description = trim($descMatch[3]);
        } else {
            // If no explicit description marker, use content after title
            $contentWithoutTitle = trim(str_replace($title, '', $content));
            if (preg_match('/(.*?)(\n(فرمت|قالب)|$)/s', $contentWithoutTitle, $remainingMatch)) {
                $description = trim($remainingMatch[1]);
            }
        }

        // Look for format
        if (preg_match('/(فرمت|قالب)(:|：)?\s*(.*?)(\n|$)/i', $content, $formatMatch)) {
            $format = trim($formatMatch[3]);
        }

        // If we have at least a title and description, return the idea
        if (!empty($title) && !empty($description)) {
            return [
                'title' => $title,
                'description' => $description,
                'format' => $format
            ];
        }

        return null;
    }

    /**
     * Caption generator form
     */
    public function captionGeneratorForm() {
        $user = $this->auth->getUser();

        // Get user's Instagram pages
        $this->db->query("SELECT id, username FROM instagram_pages WHERE user_id = :user_id");
        $this->db->bind(':user_id', $user['id']);
        $pages = $this->db->fetchAll();

        // Get caption tones
        $captionTones = [
            'professional' => 'حرفه‌ای',
            'casual' => 'دوستانه',
            'humorous' => 'طنز',
            'inspirational' => 'انگیزشی',
            'educational' => 'آموزشی',
            'promotional' => 'تبلیغاتی',
            'formal' => 'رسمی',
            'storytelling' => 'داستانی',
            'personal' => 'شخصی',
            'poetic' => 'شاعرانه'
        ];

        return App::view('dashboard.content.caption_generator', [
            'user' => $user,
            'pages' => $pages,
            'caption_tones' => $captionTones
        ]);
    }

    /**
     * Generate caption
     */
    public function generateCaption() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/content/caption');
        }

        $user = $this->auth->getUser();
        $pageId = filter_input(INPUT_POST, 'page_id', FILTER_VALIDATE_INT);
        $topic = filter_input(INPUT_POST, 'topic', FILTER_SANITIZE_STRING);
        $tone = filter_input(INPUT_POST, 'tone', FILTER_SANITIZE_STRING);
        $includeHashtags = filter_input(INPUT_POST, 'include_hashtags', FILTER_VALIDATE_BOOLEAN);
        $hashtagCount = filter_input(INPUT_POST, 'hashtag_count', FILTER_VALIDATE_INT) ?: 5;
        $includeEmojis = filter_input(INPUT_POST, 'include_emojis', FILTER_VALIDATE_BOOLEAN);

        // Validate inputs
        if (empty($topic)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'موضوع کپشن را وارد کنید.'
            ];
            App::redirect('dashboard/content/caption');
        }

        try {
            // Get page info if selected
            $page = null;
            if ($pageId) {
                $this->db->query("SELECT * FROM instagram_pages WHERE id = :id AND user_id = :user_id");
                $this->db->bind(':id', $pageId);
                $this->db->bind(':user_id', $user['id']);
                $page = $this->db->fetch();
            }

            // Build prompt for OpenAI based on inputs
            $prompt = "Generate an Instagram caption about \"{$topic}\"";

            if ($page) {
                $prompt .= " for an Instagram page about {$page['business_category']}";

                if (!empty($page['specialist_category'])) {
                    $prompt .= " with a {$page['specialist_category']} approach";
                }
            }

            if (!empty($tone)) {
                $prompt .= " in a {$tone} tone";
            }

            if ($includeEmojis) {
                $prompt .= " with appropriate emojis";
            }

            if ($includeHashtags) {
                $prompt .= " and include {$hashtagCount} relevant hashtags";
            }

            $prompt .= ". Write in Persian language and make it engaging for Instagram audience.";

            // Generate content with OpenAI
            $generatedContent = Helper::openAiRequest($prompt);

            if (!$generatedContent) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'مشکلی در تولید کپشن پیش آمد. لطفاً دوباره تلاش کنید.'
                ];
                App::redirect('dashboard/content/caption');
            }

            // Extract caption and hashtags if separated
            $caption = $generatedContent;
            $hashtags = '';

            if ($includeHashtags && strpos($generatedContent, 'Hashtags:') !== false) {
                $parts = explode('Hashtags:', $generatedContent, 2);
                $caption = trim($parts[0]);
                $hashtags = trim($parts[1]);
            } elseif ($includeHashtags && strpos($generatedContent, 'هشتگ‌ها:') !== false) {
                $parts = explode('هشتگ‌ها:', $generatedContent, 2);
                $caption = trim($parts[0]);
                $hashtags = trim($parts[1]);
            }

            // Log the generation
            $this->logContentGeneration($user['id'], 'caption', $topic);

            // Save to database
            $this->db->query("
                INSERT INTO generated_captions (
                    user_id, page_id, topic, tone, caption, hashtags, created_at
                ) VALUES (
                    :user_id, :page_id, :topic, :tone, :caption, :hashtags, NOW()
                )
            ");

            $this->db->bind(':user_id', $user['id']);
            $this->db->bind(':page_id', $pageId);
            $this->db->bind(':topic', $topic);
            $this->db->bind(':tone', $tone);
            $this->db->bind(':caption', $caption);
            $this->db->bind(':hashtags', $hashtags);

            $this->db->execute();
            $captionId = $this->db->lastInsertId();

            return App::view('dashboard.content.caption_result', [
                'user' => $user,
                'page' => $page,
                'topic' => $topic,
                'tone' => $tone,
                'caption' => $caption,
                'hashtags' => $hashtags,
                'caption_id' => $captionId
            ]);
        } catch (Exception $e) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در تولید کپشن پیش آمد: ' . $e->getMessage()
            ];
            App::redirect('dashboard/content/caption');
        }
    }

    /**
     * Hashtag generator form
     */
    public function hashtagGeneratorForm() {
        $user = $this->auth->getUser();

        return App::view('dashboard.content.hashtag_generator', [
            'user' => $user
        ]);
    }

    /**
     * Generate hashtags
     */
    public function generateHashtags() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            App::redirect('dashboard/content/hashtags');
        }

        $user = $this->auth->getUser();
        $topic = filter_input(INPUT_POST, 'topic', FILTER_SANITIZE_STRING);
        $count = filter_input(INPUT_POST, 'count', FILTER_VALIDATE_INT) ?: 15;
        $includePopular = filter_input(INPUT_POST, 'include_popular', FILTER_VALIDATE_BOOLEAN);
        $includeNiche = filter_input(INPUT_POST, 'include_niche', FILTER_VALIDATE_BOOLEAN);

        // Validate inputs
        if (empty($topic)) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'موضوع هشتگ‌ها را وارد کنید.'
            ];
            App::redirect('dashboard/content/hashtags');
        }

        try {
            // Build prompt for OpenAI based on inputs
            $prompt = "Generate {$count} Instagram hashtags for a post about \"{$topic}\"";

            if ($includePopular && $includeNiche) {
                $prompt .= " with a mix of popular and niche hashtags";
            } elseif ($includePopular) {
                $prompt .= " focusing on popular hashtags";
            } elseif ($includeNiche) {
                $prompt .= " focusing on niche, less competitive hashtags";
            }

            $prompt .= ". For each hashtag, provide an estimate of how many posts use it (popularity). Include both Persian and English hashtags as appropriate.";

            // Generate content with OpenAI
            $generatedContent = Helper::openAiRequest($prompt);

            if (!$generatedContent) {
                $_SESSION['notification'] = [
                    'type' => 'error',
                    'title' => 'خطا',
                    'message' => 'مشکلی در تولید هشتگ‌ها پیش آمد. لطفاً دوباره تلاش کنید.'
                ];
                App::redirect('dashboard/content/hashtags');
            }

            // Parse hashtags
            $hashtags = $this->parseHashtags($generatedContent);

            // Log the generation
            $this->logContentGeneration($user['id'], 'hashtags', $topic);

            // Save to database
            $this->db->query("
                INSERT INTO generated_hashtags (
                    user_id, topic, hashtags_json, created_at
                ) VALUES (
                    :user_id, :topic, :hashtags_json, NOW()
                )
            ");

            $this->db->bind(':user_id', $user['id']);
            $this->db->bind(':topic', $topic);
            $this->db->bind(':hashtags_json', json_encode($hashtags, JSON_UNESCAPED_UNICODE));

            $this->db->execute();
            $hashtagsId = $this->db->lastInsertId();

            return App::view('dashboard.content.hashtags_result', [
                'user' => $user,
                'topic' => $topic,
                'hashtags' => $hashtags,
                'hashtags_id' => $hashtagsId
            ]);
        } catch (Exception $e) {
            $_SESSION['notification'] = [
                'type' => 'error',
                'title' => 'خطا',
                'message' => 'مشکلی در تولید هشتگ‌ها پیش آمد: ' . $e->getMessage()
            ];
            App::redirect('dashboard/content/hashtags');
        }
    }

    /**
     * Parse hashtags from generated content
     *
     * @param string $content Generated content
     * @return array Parsed hashtags with popularity
     */
    private function parseHashtags($content) {
        $hashtags = [];

        // Try to match hashtag pattern with popularity
        preg_match_all('/(#[^\s#]+)(?:\s*[-–—]\s*([^#\n]+))?/u', $content, $matches, PREG_SET_ORDER);

        foreach ($matches as $match) {
            $hashtag = trim($match[1]);
            $popularity = isset($match[2]) ? trim($match[2]) : '';

            $hashtags[] = [
                'hashtag' => $hashtag,
                'popularity' => $popularity
            ];
        }

        // If no matches found, just extract all hashtags
        if (empty($hashtags)) {
            preg_match_all('/(#[^\s#]+)/u', $content, $simpleMatches);

            foreach ($simpleMatches[1] as $hashtag) {
                $hashtags[] = [
                    'hashtag' => trim($hashtag),
                    'popularity' => ''
                ];
            }
        }

        return $hashtags;
    }

    /**
     * Log content generation for usage tracking
     *
     * @param int $userId User ID
     * @param string $type Generation type (profile_image, post_plan, etc.)
     * @param string $topic Topic/prompt used
     * @return bool Success status
     */
    private function logContentGeneration($userId, $type, $topic) {
        try {
            $this->db->query("
                INSERT INTO content_generation_logs (
                    user_id, generation_type, topic, created_at
                ) VALUES (
                    :user_id, :generation_type, :topic, NOW()
                )
            ");

            $this->db->bind(':user_id', $userId);
            $this->db->bind(':generation_type', $type);
            $this->db->bind(':topic', $topic);

            // Update user usage count
            $this->db->query("
                INSERT INTO user_usage (user_id, feature_id, usage_count, last_used, created_at)
                VALUES (:user_id, :feature_id, 1, NOW(), NOW())
                ON DUPLICATE KEY UPDATE 
                usage_count = usage_count + 1,
                last_used = NOW(),
                updated_at = NOW()
            ");

            $featureId = 4; // Content generation feature ID
            $this->db->bind(':user_id', $userId);
            $this->db->bind(':feature_id', $featureId);

            return $this->db->execute();
        } catch (Exception $e) {
            error_log('Error logging content generation: ' . $e->getMessage());
            return false;
        }
    }
}