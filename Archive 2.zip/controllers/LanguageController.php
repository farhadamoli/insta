<?php

/**
 * LanguageController.php
 *
 * کنترلر مدیریت زبان برای پروژه ادامه‌ای
 */

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Language;

class LanguageController extends Controller
{

    /**
     * تغییر زبان سیستم
     *
     * @param Request $request
     * @param Response $response
     */
    public function setLanguage(Request $request, Response $response)
    {
        $lang = $request->getParam('lang');
        $redirect = $request->getParam('redirect', '/');

        // بررسی معتبر بودن زبان
        if (!$lang || !Language::isSupported($lang)) {
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'زبان انتخابی معتبر نیست.'
                ]);
            } else {
                $this->flash('error', 'زبان انتخابی معتبر نیست.');
                return $this->redirect($redirect);
            }
        }

        // تنظیم زبان
        Language::setLang($lang);
        Language::setSessionLang($lang);
        Language::setCookieLang($lang);

        if ($request->isAjax()) {
            return $response->json([
                'success' => true,
                'message' => Language::get('general.language_changed_successfully', [], 'زبان با موفقیت تغییر کرد.')
            ]);
        } else {
            $this->flash('success', Language::get('general.language_changed_successfully', [], 'زبان با موفقیت تغییر کرد.'));
            return $this->redirect($redirect);
        }
    }

    /**
     * نمایش صفحه انتخاب زبان
     */
    public function showLanguageSelector()
    {
        $languages = Language::getSupportedLangs();
        $currentLang = Language::getCurrentLang();

        return $this->render('language/selector', [
            'title' => Language::get('general.select_language'),
            'languages' => $languages,
            'currentLang' => $currentLang
        ]);
    }

    /**
     * راه‌اندازی زبان برای کل برنامه (معمولاً در bootstrap)
     */
    public static function initLanguage()
    {
        // تشخیص زبان کاربر
        $userLang = Language::getUserPreferredLang();

        // بارگذاری فایل‌های زبان
        Language::load($userLang);

        // راه‌اندازی تابع کمکی __() برای دسترسی سریع به ترجمه‌ها
        Language::setupHelperFunction();
    }
}