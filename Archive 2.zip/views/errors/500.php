<!DOCTYPE html>
<html lang="<?= \App\Core\Language::getCurrentLang() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('general.error_500') ?> | <?= __('general.app_name') ?></title>
    <style>
        body {
            font-family: 'IRANSans', Tahoma, Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            direction: <?= \App\Core\Language::getCurrentLang() === 'fa' ? 'rtl' : 'ltr' ?>;
        }

        .error-container {
            max-width: 600px;
            width: 90%;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
        }

        .error-code {
            font-size: 120px;
            font-weight: bold;
            color: #e74c3c;
            margin: 0;
            line-height: 1;
        }

        .error-title {
            font-size: 24px;
            color: #2c3e50;
            margin: 10px 0 20px;
        }

        .error-message {
            font-size: 16px;
            color: #7f8c8d;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .error-image {
            max-width: 200px;
            margin-bottom: 20px;
        }

        .btn-home {
            display: inline-block;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 4px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .btn-home:hover {
            background-color: #2980b9;
        }

        .support-info {
            margin-top: 30px;
            font-size: 14px;
            color: #95a5a6;
        }
    </style>
</head>
<body>
<div class="error-container">
    <img src="<?= asset('images/error.svg') ?>" alt="Error" class="error-image">
    <h1 class="error-code">500</h1>
    <h2 class="error-title"><?= __('general.error_500') ?></h2>
    <p class="error-message">
        <?= __('general.error_500_message', [], 'متأسفانه خطایی در سرور رخ داده است. تیم فنی ما در حال بررسی و رفع مشکل است. لطفاً بعداً دوباره تلاش کنید.') ?>
    </p>
    <a href="<?= base_url() ?>" class="btn-home"><?= __('general.back_to_home') ?></a>

    <div class="support-info">
        <?= __('general.error_support_info', [], 'در صورت ادامه این مشکل، لطفاً با پشتیبانی تماس بگیرید.') ?>
        <br>
        <a href="mailto:<?= APP_EMAIL ?>"><?= APP_EMAIL ?></a>
    </div>
</div>
</body>
</html>