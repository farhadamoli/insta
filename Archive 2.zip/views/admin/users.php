<?php $this->renderPartial('admin/partials/header', ['title' => 'User Management', 'active_menu' => 'users']) ?>

    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-users"></i> User Management</h1>
            <div class="admin-actions">
                <a href="<?= url('admin/users/export') ?>" class="btn btn-outline-primary">
                    <i class="fas fa-file-export"></i> Export Users
                </a>
                <a href="<?= url('admin/users/create') ?>" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> Add New User
                </a>
            </div>
        </div>

        <!-- Filters and Search -->
        <div class="admin-filters">
            <form action="<?= url('admin/users') ?>" method="get" class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="">All Statuses</option>
                            <option value="active" <?= isset($filters['status']) && $filters['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= isset($filters['status']) && $filters['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                            <option value="pending" <?= isset($filters['status']) && $filters['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="suspended" <?= isset($filters['status']) && $filters['status'] === 'suspended' ? 'selected' : '' ?>>Suspended</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select name="role" id="role" class="form-control">
                            <option value="">All Roles</option>
                            <?php foreach ($roles as $roleId => $roleName): ?>
                                <option value="<?= $roleId ?>" <?= isset($filters['role']) && $filters['role'] == $roleId ? 'selected' : '' ?>>
                                    <?= $roleName ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="plan">Subscription Plan</label>
                        <select name="plan" id="plan" class="form-control">
                            <option value="">All Plans</option>
                            <?php foreach ($plans as $planId => $planName): ?>
                                <option value="<?= $planId ?>" <?= isset($filters['plan']) && $filters['plan'] == $planId ? 'selected' : '' ?>>
                                    <?= $planName ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="search">Search</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="search" name="search" placeholder="Name, email, or ID..." value="<?= $filters['search'] ?? '' ?>">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <!-- User Stats -->
        <div class="admin-stats">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-primary">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <h3>Total Users</h3>
                            <div class="stat-value"><?= number_format($stats['total_users']) ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-success">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <div class="stat-content">
                            <h3>Active Users</h3>
                            <div class="stat-value"><?= number_format($stats['active_users']) ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-info">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div class="stat-content">
                            <h3>New Users (30d)</h3>
                            <div class="stat-value"><?= number_format($stats['new_users']) ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-warning">
                            <i class="fas fa-user-clock"></i>
                        </div>
                        <div class="stat-content">
                            <h3>Pending Activation</h3>
                            <div class="stat-value"><?= number_format($stats['pending_users']) ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Flash Messages -->
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $success ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>

        <!-- Users Table -->
        <div class="admin-card">
            <div class="card-body">
                <?php if (empty($users)): ?>
                    <div class="empty-state">
                        <img src="<?= asset_url('images/admin/empty-users.svg') ?>" alt="No users found">
                        <h3>No users found</h3>
                        <p>No users match your search criteria. Try adjusting your filters.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>
                                <th width="50">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="selectAll">
                                        <label class="custom-control-label" for="selectAll"></label>
                                    </div>
                                </th>
                                <th>User</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Plan</th>
                                <th>Status</th>
                                <th>Registered</th>
                                <th>Last Login</th>
                                <th width="100">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input user-checkbox" id="user<?= $user->id ?>" value="<?= $user->id ?>">
                                            <label class="custom-control-label" for="user<?= $user->id ?>"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-cell">
                                            <?php if ($user->profile_image): ?>
                                                <img src="<?= $user->profile_image ?>" alt="<?= $user->first_name ?>" class="user-avatar">
                                            <?php else: ?>
                                                <div class="user-avatar-placeholder">
                                                    <?= strtoupper(substr($user->first_name, 0, 1) . substr($user->last_name, 0, 1)) ?>
                                                </div>
                                            <?php endif; ?>
                                            <div class="user-info">
                                                <div class="user-name"><?= $user->first_name ?> <?= $user->last_name ?></div>
                                                <div class="user-id">ID: <?= $user->id ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?= $user->email ?></td>
                                    <td>
                                <span class="badge <?= $user->role_id == 1 ? 'badge-danger' : ($user->role_id == 2 ? 'badge-primary' : 'badge-secondary') ?>">
                                    <?= $user->role_name ?>
                                </span>
                                    </td>
                                    <td>
                                        <?php if ($user->subscription_plan): ?>
                                            <span class="badge badge-info"><?= $user->subscription_plan ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-light">Free</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                <span class="badge badge-<?= $user->status === 'active' ? 'success' : ($user->status === 'pending' ? 'warning' : ($user->status === 'suspended' ? 'danger' : 'secondary')) ?>">
                                    <?= ucfirst($user->status) ?>
                                </span>
                                    </td>
                                    <td><?= $this->helper->formatDate($user->created_at, 'M d, Y') ?></td>
                                    <td>
                                        <?php if ($user->last_login): ?>
                                            <?= $this->helper->formatDate($user->last_login, 'M d, Y H:i') ?>
                                        <?php else: ?>
                                            <span class="text-muted">Never</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-icon" type="button" data-toggle="dropdown">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="<?= url('admin/users/view/' . $user->id) ?>">
                                                    <i class="fas fa-eye"></i> View Details
                                                </a>
                                                <a class="dropdown-item" href="<?= url('admin/users/edit/' . $user->id) ?>">
                                                    <i class="fas fa-edit"></i> Edit User
                                                </a>
                                                <a class="dropdown-item" href="<?= url('admin/users/login-as/' . $user->id) ?>">
                                                    <i class="fas fa-sign-in-alt"></i> Login as User
                                                </a>
                                                <div class="dropdown-divider"></div>
                                                <?php if ($user->status === 'active'): ?>
                                                    <a class="dropdown-item text-warning user-status-action" href="#" data-id="<?= $user->id ?>" data-action="suspend">
                                                        <i class="fas fa-user-slash"></i> Suspend User
                                                    </a>
                                                <?php elseif ($user->status === 'suspended'): ?>
                                                    <a class="dropdown-item text-success user-status-action" href="#" data-id="<?= $user->id ?>" data-action="activate">
                                                        <i class="fas fa-user-check"></i> Activate User
                                                    </a>
                                                <?php elseif ($user->status === 'pending'): ?>
                                                    <a class="dropdown-item text-success user-status-action" href="#" data-id="<?= $user->id ?>" data-action="approve">
                                                        <i class="fas fa-user-check"></i> Approve User
                                                    </a>
                                                <?php endif; ?>
                                                <a class="dropdown-item text-danger delete-user" href="#" data-id="<?= $user->id ?>">
                                                    <i class="fas fa-trash-alt"></i> Delete User
                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Bulk Actions -->
                    <div class="bulk-actions">
                        <div class="bulk-actions-wrapper">
                            <span class="bulk-count">0 users selected</span>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-toggle="dropdown">
                                    Bulk Actions
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item bulk-action" href="#" data-action="activate">
                                        <i class="fas fa-user-check"></i> Activate Selected
                                    </a>
                                    <a class="dropdown-item bulk-action" href="#" data-action="suspend">
                                        <i class="fas fa-user-slash"></i> Suspend Selected
                                    </a>
                                    <a class="dropdown-item bulk-action" href="#" data-action="delete">
                                        <i class="fas fa-trash-alt"></i> Delete Selected
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item bulk-action" href="#" data-action="export">
                                        <i class="fas fa-file-export"></i> Export Selected
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav aria-label="Users pagination">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?= $currentPage <= 1 ? 'disabled' : '' ?>">
                                    <a class="page-link" href="<?= url('admin/users?' . http_build_query(array_merge($filters, ['page' => $currentPage - 1]))) ?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>

                                <?php for ($i = max(1, $currentPage - 2); $i <= min($currentPage + 2, $totalPages); $i++): ?>
                                    <li class="page-item <?= $i === $currentPage ? 'active' : '' ?>">
                                        <a class="page-link" href="<?= url('admin/users?' . http_build_query(array_merge($filters, ['page' => $i]))) ?>">
                                            <?= $i ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <li class="page-item <?= $currentPage >= $totalPages ? 'disabled' : '' ?>">
                                    <a class="page-link" href="<?= url('admin/users?' . http_build_query(array_merge($filters, ['page' => $currentPage + 1]))) ?>" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Delete User Confirmation Modal -->
    <div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Delete User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this user? This action cannot be undone and will remove all user data including:</p>
                    <ul>
                        <li>Account information</li>
                        <li>Social media connections</li>
                        <li>Content and scheduled posts</li>
                        <li>Analytics data</li>
                        <li>Subscription information</li>
                    </ul>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="confirmDelete">
                        <label class="form-check-label" for="confirmDelete">
                            I understand that this action is permanent
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteUser" disabled>Delete User</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bulk Action Confirmation Modal -->
    <div class="modal fade" id="bulkActionModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Bulk Action</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="bulkActionMessage">Are you sure you want to perform this action on the selected users?</p>
                    <div class="form-check" id="bulkDeleteConfirm" style="display: none;">
                        <input class="form-check-input" type="checkbox" id="confirmBulkDelete">
                        <label class="form-check-label" for="confirmBulkDelete">
                            I understand that this action is permanent
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmBulkAction">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Status Change Modal -->
    <div class="modal fade" id="statusChangeModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Change User Status</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="statusChangeMessage">Are you sure you want to change this user's status?</p>
                    <div id="suspendReasonContainer" style="display: none;">
                        <div class="form-group">
                            <label for="suspendReason">Reason for suspension:</label>
                            <select class="form-control" id="suspendReason">
                                <option value="terms_violation">Terms of Service Violation</option>
                                <option value="spam">Spam Activity</option>
                                <option value="payment_issue">Payment Issue</option>
                                <option value="security">Security Concern</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group" id="otherReasonContainer" style="display: none;">
                            <label for="otherReason">Please specify:</label>
                            <textarea class="form-control" id="otherReason" rows="3"></textarea>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="notifyUser">
                            <label class="form-check-label" for="notifyUser">
                                Send notification email to user
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmStatusChange">Confirm</button>
                </div>
            </div>
        </div>
    </div>

<?php $this->renderPartial('admin/partials/footer', ['scripts' => [
    'js/admin/users.js'
]]) ?>