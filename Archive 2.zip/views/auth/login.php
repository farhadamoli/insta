<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Social Monitor</title>
    <link rel="stylesheet" href="<?= asset_url('css/auth.css') ?>">
    <link rel="stylesheet" href="<?= asset_url('css/components.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php $this->renderPartial('auth/partials/head-scripts') ?>
</head>
<body>
<div class="auth-container">
    <div class="auth-left">
        <div class="auth-logo">
            <a href="<?= url('') ?>">
                <img src="<?= asset_url('images/logo.svg') ?>" alt="Social Monitor Logo">
            </a>
        </div>
        <div class="auth-content">
            <h1>Welcome Back!</h1>
            <p>Log in to your Social Monitor account to continue managing your social media presence.</p>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <?php if (isset($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <form action="<?= url('login') ?>" method="post" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-icon">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" value="<?= isset($email) ? $email : '' ?>" required autofocus>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" required>
                        <button type="button" class="password-toggle" aria-label="Toggle password visibility">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="form-group form-check">
                    <label class="form-check-label">
                        <input type="checkbox" name="remember" class="form-check-input" <?= isset($remember) && $remember ? 'checked' : '' ?>>
                        Keep me logged in
                    </label>
                    <a href="<?= url('forgot-password') ?>" class="forgot-password">Forgot password?</a>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-block">Log In</button>
                </div>
            </form>

            <div class="auth-divider">
                <span>or continue with</span>
            </div>

            <div class="social-login">
                <a href="<?= url('auth/google') ?>" class="btn btn-social btn-google">
                    <img src="<?= asset_url('images/auth/google.svg') ?>" alt="Google"> Google
                </a>
                <a href="<?= url('auth/facebook') ?>" class="btn btn-social btn-facebook">
                    <img src="<?= asset_url('images/auth/facebook.svg') ?>" alt="Facebook"> Facebook
                </a>
                <a href="<?= url('auth/apple') ?>" class="btn btn-social btn-apple">
                    <img src="<?= asset_url('images/auth/apple.svg') ?>" alt="Apple"> Apple
                </a>
            </div>

            <div class="auth-footer">
                <p>Don't have an account? <a href="<?= url('register') ?>">Sign up</a></p>
            </div>
        </div>
    </div>
    <div class="auth-right">
        <div class="auth-features">
            <div class="auth-feature">
                <div class="auth-feature-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="auth-feature-text">
                    <h3>Advanced Analytics</h3>
                    <p>Gain deep insights into your social media performance with comprehensive analytics.</p>
                </div>
            </div>
            <div class="auth-feature">
                <div class="auth-feature-icon">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="auth-feature-text">
                    <h3>AI Content Generation</h3>
                    <p>Create engaging content in seconds with our AI-powered content generator.</p>
                </div>
            </div>
            <div class="auth-feature">
                <div class="auth-feature-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="auth-feature-text">
                    <h3>Smart Scheduling</h3>
                    <p>Schedule your posts at the optimal times to reach your audience.</p>
                </div>
            </div>
        </div>
        <div class="auth-testimonial">
            <div class="testimonial-content">
                <p>"Social Monitor has completely transformed our social media strategy. The analytics tools helped us understand what content works best, and the AI content generator saves us hours every week."</p>
            </div>
            <div class="testimonial-author">
                <img src="<?= asset_url('images/landing/testimonials/user1.jpg') ?>" alt="Sarah Johnson">
                <div class="author-info">
                    <h4>Sarah Johnson</h4>
                    <p>Marketing Director, TechStart Inc.</p>
                </div>
            </div>
        </div>
        <div class="auth-background-overlay"></div>
    </div>
</div>

<!-- Scripts -->
<script src="<?= asset_url('js/auth.js') ?>"></script>
<?php $this->renderPartial('auth/partials/footer-scripts') ?>
</body>
</html>