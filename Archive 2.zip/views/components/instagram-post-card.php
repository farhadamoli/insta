<?php
/**
 * Instagram Post Card Component
 *
 * Displays an Instagram post in a card format with engagement metrics
 *
 * @param object $post The post object with all necessary data
 * @param bool $showActions Whether to show action buttons (default: true)
 * @param bool $showAnalytics Whether to show analytics data (default: true)
 * @param bool $isCompact Whether to use compact view (default: false)
 */
?>

<div class="social-post-card <?= $isCompact ?? false ? 'post-card-compact' : '' ?>" data-post-id="<?= $post->id ?>" data-platform="instagram">
    <div class="post-card-header">
        <div class="post-account">
            <img src="<?= $post->profile_image ?? asset_url('images/platforms/instagram.svg') ?>" alt="<?= $post->username ?>" class="post-account-image">
            <div class="post-account-info">
                <div class="post-account-name"><?= $post->username ?></div>
                <div class="post-date"><?= $this->helper->formatSocialTimestamp($post->created_at) ?></div>
            </div>
        </div>
        <?php if (($showActions ?? true) && !($isCompact ?? false)): ?>
            <div class="post-actions">
                <div class="dropdown">
                    <button class="btn btn-sm btn-icon" type="button" data-toggle="dropdown">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="<?= url('instagram/posts/view/' . $post->id) ?>">
                            <i class="fas fa-eye"></i> View Details
                        </a>
                        <a class="dropdown-item" href="<?= $post->permalink ?>" target="_blank">
                            <i class="fas fa-external-link-alt"></i> View on Instagram
                        </a>
                        <a class="dropdown-item copy-link" href="#" data-link="<?= $post->permalink ?>">
                            <i class="fas fa-link"></i> Copy Link
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-primary" href="<?= url('content/create?template=' . $post->id) ?>">
                            <i class="fas fa-clone"></i> Use as Template
                        </a>
                        <a class="dropdown-item text-primary analyze-sentiment" href="#" data-id="<?= $post->id ?>">
                            <i class="fas fa-brain"></i> Analyze Sentiment
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="post-card-content">
        <?php if ($post->media_type == 'IMAGE' || $post->media_type == 'CAROUSEL_ALBUM'): ?>
            <div class="post-media">
                <img src="<?= $post->media_url ?>" alt="Instagram post" class="post-image">
                <?php if ($post->media_type == 'CAROUSEL_ALBUM'): ?>
                    <div class="carousel-indicator">
                        <i class="fas fa-clone"></i>
                    </div>
                <?php endif; ?>
            </div>
        <?php elseif ($post->media_type == 'VIDEO'): ?>
            <div class="post-media video-media">
                <div class="video-placeholder" style="background-image: url('<?= $post->thumbnail_url ?>');">
                    <div class="play-button">
                        <i class="fas fa-play"></i>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="post-text">
            <?php if (!empty($post->caption)): ?>
                <p><?= $this->helper->formatInstagramCaption($post->caption) ?></p>
            <?php else: ?>
                <p class="text-muted">No caption</p>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($showAnalytics ?? true): ?>
        <div class="post-card-footer">
            <div class="post-engagement">
                <div class="engagement-item">
                    <i class="fas fa-heart"></i>
                    <span class="engagement-count"><?= number_format($post->likes_count) ?></span>
                    <?php if (!($isCompact ?? false)): ?>
                        <span class="engagement-label">Likes</span>
                    <?php endif; ?>
                </div>
                <div class="engagement-item">
                    <i class="fas fa-comment"></i>
                    <span class="engagement-count"><?= number_format($post->comments_count) ?></span>
                    <?php if (!($isCompact ?? false)): ?>
                        <span class="engagement-label">Comments</span>
                    <?php endif; ?>
                </div>
                <?php if (!($isCompact ?? false)): ?>
                    <div class="engagement-item">
                        <i class="fas fa-bookmark"></i>
                        <span class="engagement-count"><?= number_format($post->saved_count ?? 0) ?></span>
                        <span class="engagement-label">Saved</span>
                    </div>
                <?php endif; ?>
                <div class="engagement-item">
                    <i class="fas fa-chart-line"></i>
                    <span class="engagement-count"><?= $post->engagement_rate ?>%</span>
                    <?php if (!($isCompact ?? false)): ?>
                        <span class="engagement-label">Engagement</span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!($isCompact ?? false) && ($post->sentiment ?? false)): ?>
                <div class="post-sentiment">
            <span class="sentiment-badge sentiment-<?= strtolower($post->sentiment) ?>">
                <?php if ($post->sentiment == 'positive'): ?>
                    <i class="fas fa-smile"></i> Positive
                <?php elseif ($post->sentiment == 'negative'): ?>
                    <i class="fas fa-frown"></i> Negative
                <?php else: ?>
                    <i class="fas fa-meh"></i> Neutral
                <?php endif; ?>
            </span>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if (!($isCompact ?? false) && !empty($post->hashtags)): ?>
        <div class="post-hashtags">
            <?php foreach (explode(',', $post->hashtags) as $hashtag): ?>
                <span class="hashtag">#<?= trim($hashtag) ?></span>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>