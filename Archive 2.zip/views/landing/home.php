<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Monitor - Comprehensive Social Media Monitoring Platform</title>
    <meta name="description" content="Monitor, analyze and optimize your social media presence with our all-in-one platform">
    <link rel="stylesheet" href="<?= asset_url('css/landing.css') ?>">
    <link rel="stylesheet" href="<?= asset_url('css/components.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php $this->renderPartial('landing/partials/head-scripts') ?>
</head>
<body>
<!-- Header -->
<?php $this->renderPartial('landing/partials/header', ['active' => 'home']) ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>Unlock the Power of Social Media</h1>
            <p>Monitor, analyze, and optimize your social media presence with our comprehensive platform.</p>
            <div class="hero-cta">
                <a href="<?= url('register') ?>" class="btn btn-primary btn-lg">Get Started</a>
                <a href="<?= url('tour') ?>" class="btn btn-outline-light btn-lg">Take a Tour</a>
            </div>
        </div>
        <div class="hero-image">
            <img src="<?= asset_url('images/landing/hero-dashboard.png') ?>" alt="Social Monitor Dashboard" class="img-fluid">
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <div class="section-header">
            <h2>Key Features</h2>
            <p>Everything you need to succeed on social media</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h3>Advanced Analytics</h3>
                <p>Gain deep insights into your social media performance with comprehensive analytics and beautiful visualizations.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-robot"></i>
                </div>
                <h3>AI Content Generation</h3>
                <p>Create engaging content in seconds with our AI-powered content generator optimized for each platform.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-bullhorn"></i>
                </div>
                <h3>Campaign Management</h3>
                <p>Plan, execute, and track your marketing campaigns across multiple channels from one place.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-search"></i>
                </div>
                <h3>SEO Optimization</h3>
                <p>Improve your search engine rankings with keyword research and content optimization tools.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-laptop-code"></i>
                </div>
                <h3>Website Builder</h3>
                <p>Create beautiful, responsive websites that convert visitors into customers without coding.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h3>CRM Integration</h3>
                <p>Manage customer relationships and track your social media leads from the first interaction.</p>
            </div>
        </div>
    </div>
</section>

<!-- Platforms Section -->
<section class="platforms">
    <div class="container">
        <div class="section-header">
            <h2>One Platform, All Networks</h2>
            <p>Monitor and manage all your social media accounts in one place</p>
        </div>
        <div class="platforms-logos">
            <div class="platform-logo">
                <img src="<?= asset_url('images/landing/platforms/instagram.svg') ?>" alt="Instagram">
                <span>Instagram</span>
            </div>
            <div class="platform-logo">
                <img src="<?= asset_url('images/landing/platforms/facebook.svg') ?>" alt="Facebook">
                <span>Facebook</span>
            </div>
            <div class="platform-logo">
                <img src="<?= asset_url('images/landing/platforms/twitter.svg') ?>" alt="Twitter">
                <span>Twitter</span>
            </div>
            <div class="platform-logo">
                <img src="<?= asset_url('images/landing/platforms/linkedin.svg') ?>" alt="LinkedIn">
                <span>LinkedIn</span>
            </div>
            <div class="platform-logo">
                <img src="<?= asset_url('images/landing/platforms/youtube.svg') ?>" alt="YouTube">
                <span>YouTube</span>
            </div>
            <div class="platform-logo">
                <img src="<?= asset_url('images/landing/platforms/tiktok.svg') ?>" alt="TikTok">
                <span>TikTok</span>
            </div>
            <div class="platform-logo">
                <img src="<?= asset_url('images/landing/platforms/pinterest.svg') ?>" alt="Pinterest">
                <span>Pinterest</span>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials">
    <div class="container">
        <div class="section-header">
            <h2>What Our Customers Say</h2>
            <p>Success stories from businesses just like yours</p>
        </div>
        <div class="testimonials-slider">
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <p>"Social Monitor has completely transformed our social media strategy. The analytics tools helped us understand what content works best, and the AI content generator saves us hours every week."</p>
                </div>
                <div class="testimonial-author">
                    <img src="<?= asset_url('images/landing/testimonials/user1.jpg') ?>" alt="Sarah Johnson">
                    <div class="author-info">
                        <h4>Sarah Johnson</h4>
                        <p>Marketing Director, TechStart Inc.</p>
                    </div>
                </div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <p>"The campaign management features are incredible. We've increased our ROI by 45% since we started using Social Monitor to plan and track our marketing campaigns."</p>
                </div>
                <div class="testimonial-author">
                    <img src="<?= asset_url('images/landing/testimonials/user2.jpg') ?>" alt="David Chen">
                    <div class="author-info">
                        <h4>David Chen</h4>
                        <p>CEO, Retail Solutions</p>
                    </div>
                </div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <p>"As a small business owner, I was struggling to maintain a consistent social media presence. Social Monitor's scheduling and content suggestions have been a game-changer for us."</p>
                </div>
                <div class="testimonial-author">
                    <img src="<?= asset_url('images/landing/testimonials/user3.jpg') ?>" alt="Emma Rodriguez">
                    <div class="author-info">
                        <h4>Emma Rodriguez</h4>
                        <p>Owner, Artisan Bakery</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="testimonial-controls">
            <button class="prev-testimonial"><i class="fas fa-arrow-left"></i></button>
            <button class="next-testimonial"><i class="fas fa-arrow-right"></i></button>
        </div>
    </div>
</section>

<!-- Pricing Section -->
<section class="pricing">
    <div class="container">
        <div class="section-header">
            <h2>Simple, Transparent Pricing</h2>
            <p>Choose the plan that's right for your business</p>
        </div>
        <div class="pricing-toggle">
            <span>Monthly</span>
            <label class="switch">
                <input type="checkbox" id="billing-toggle">
                <span class="slider round"></span>
            </label>
            <span>Annual <span class="discount">Save 20%</span></span>
        </div>
        <div class="pricing-grid">
            <div class="pricing-card">
                <div class="pricing-header">
                    <h3>Starter</h3>
                    <div class="price">
                        <span class="currency">$</span>
                        <span class="amount monthly">29</span>
                        <span class="amount annual">23</span>
                        <span class="period">/month</span>
                    </div>
                </div>
                <div class="pricing-features">
                    <ul>
                        <li><i class="fas fa-check"></i> 5 social accounts</li>
                        <li><i class="fas fa-check"></i> Basic analytics</li>
                        <li><i class="fas fa-check"></i> Content scheduler</li>
                        <li><i class="fas fa-check"></i> 50 AI-generated posts/month</li>
                        <li><i class="fas fa-check"></i> Email support</li>
                        <li class="disabled"><i class="fas fa-times"></i> Campaign management</li>
                        <li class="disabled"><i class="fas fa-times"></i> SEO tools</li>
                        <li class="disabled"><i class="fas fa-times"></i> Website builder</li>
                        <li class="disabled"><i class="fas fa-times"></i> CRM integration</li>
                    </ul>
                </div>
                <div class="pricing-cta">
                    <a href="<?= url('register?plan=starter') ?>" class="btn btn-outline-primary btn-block">Get Started</a>
                </div>
            </div>
            <div class="pricing-card popular">
                <div class="popular-badge">Most Popular</div>
                <div class="pricing-header">
                    <h3>Professional</h3>
                    <div class="price">
                        <span class="currency">$</span>
                        <span class="amount monthly">79</span>
                        <span class="amount annual">63</span>
                        <span class="period">/month</span>
                    </div>
                </div>
                <div class="pricing-features">
                    <ul>
                        <li><i class="fas fa-check"></i> 15 social accounts</li>
                        <li><i class="fas fa-check"></i> Advanced analytics</li>
                        <li><i class="fas fa-check"></i> Content scheduler</li>
                        <li><i class="fas fa-check"></i> 200 AI-generated posts/month</li>
                        <li><i class="fas fa-check"></i> Priority email support</li>
                        <li><i class="fas fa-check"></i> Campaign management</li>
                        <li><i class="fas fa-check"></i> Basic SEO tools</li>
                        <li><i class="fas fa-check"></i> 1 website</li>
                        <li class="disabled"><i class="fas fa-times"></i> CRM integration</li>
                    </ul>
                </div>
                <div class="pricing-cta">
                    <a href="<?= url('register?plan=professional') ?>" class="btn btn-primary btn-block">Get Started</a>
                </div>
            </div>
            <div class="pricing-card">
                <div class="pricing-header">
                    <h3>Business</h3>
                    <div class="price">
                        <span class="currency">$</span>
                        <span class="amount monthly">199</span>
                        <span class="amount annual">159</span>
                        <span class="period">/month</span>
                    </div>
                </div>
                <div class="pricing-features">
                    <ul>
                        <li><i class="fas fa-check"></i> Unlimited social accounts</li>
                        <li><i class="fas fa-check"></i> Enterprise analytics</li>
                        <li><i class="fas fa-check"></i> Content scheduler</li>
                        <li><i class="fas fa-check"></i> Unlimited AI-generated posts</li>
                        <li><i class="fas fa-check"></i> 24/7 phone & email support</li>
                        <li><i class="fas fa-check"></i> Campaign management</li>
                        <li><i class="fas fa-check"></i> Advanced SEO tools</li>
                        <li><i class="fas fa-check"></i> 5 websites</li>
                        <li><i class="fas fa-check"></i> CRM integration</li>
                    </ul>
                </div>
                <div class="pricing-cta">
                    <a href="<?= url('register?plan=business') ?>" class="btn btn-outline-primary btn-block">Get Started</a>
                </div>
            </div>
        </div>
        <div class="enterprise-plan">
            <div class="enterprise-content">
                <h3>Need a custom solution?</h3>
                <p>Contact us for Enterprise pricing with custom features, dedicated support, and tailored onboarding.</p>
            </div>
            <a href="<?= url('contact?subject=Enterprise') ?>" class="btn btn-outline-light">Contact Sales</a>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <div class="cta-content">
            <h2>Ready to Transform Your Social Media Strategy?</h2>
            <p>Join thousands of businesses that are growing their online presence with Social Monitor.</p>
            <a href="<?= url('register') ?>" class="btn btn-primary btn-lg">Start Your Free Trial</a>
            <p class="cta-note">No credit card required. 14-day free trial.</p>
        </div>
    </div>
</section>

<!-- Footer -->
<?php $this->renderPartial('landing/partials/footer') ?>

<!-- Scripts -->
<script src="<?= asset_url('js/landing.js') ?>"></script>
<?php $this->renderPartial('landing/partials/footer-scripts') ?>
</body>
</html>