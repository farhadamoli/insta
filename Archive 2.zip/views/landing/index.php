<!-- File: views/landing/index.php -->
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOCIALKOCH.CO - رصد، پایش و تحلیل شبکه‌های اجتماعی</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Vazir Font (Persian Font) -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css" rel="stylesheet" type="text/css" />

    <style>
        :root {
            --primary-color: #4f46e5;
            --secondary-color: #7c3aed;
            --accent-color: #f59e0b;
            --dark-color: #1f2937;
            --light-color: #f3f4f6;
        }

        body {
            font-family: 'Vazir', 'Tahoma', sans-serif;
        }

        .gradient-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        .gradient-accent {
            background: linear-gradient(135deg, var(--accent-color), #ef4444);
        }

        .text-gradient {
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-image: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        .floating {
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }

        .mobile-menu-visible {
            transform: translateX(0%);
        }

        .mobile-menu-hidden {
            transform: translateX(100%);
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800">
<!-- Header -->
<header class="relative bg-white shadow-md">
    <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <a href="/" class="flex items-center">
                    <img src="/assets/images/logo.png" alt="SOCIALKOCH.CO" class="h-10 w-auto">
                    <span class="mr-3 text-xl font-bold text-gradient">SOCIALKOCH.CO</span>
                </a>
            </div>

            <!-- Desktop Menu -->
            <nav class="hidden md:flex items-center space-x-1 space-x-reverse">
                <a href="#features" class="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    امکانات
                </a>
                <a href="#pricing" class="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    تعرفه‌ها
                </a>
                <a href="#about" class="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    درباره ما
                </a>
                <a href="/blog" class="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    وبلاگ
                </a>
                <a href="/contact" class="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    تماس با ما
                </a>
            </nav>

            <!-- Authentication Links -->
            <div class="hidden md:flex items-center space-x-3 space-x-reverse">
                <a href="/login" class="px-4 py-2 border border-indigo-600 rounded-md text-sm font-medium text-indigo-600 hover:bg-indigo-50 transition duration-150">
                    ورود
                </a>
                <a href="/register" class="px-4 py-2 bg-indigo-600 border border-transparent rounded-md text-sm font-medium text-white hover:bg-indigo-700 transition duration-150">
                    ثبت نام
                </a>
            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button id="mobile-menu-button" class="text-gray-500 hover:text-gray-700 p-2">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="md:hidden fixed top-0 right-0 bottom-0 w-64 bg-white shadow-xl z-50 transform translate-x-full transition-transform duration-300 ease-in-out">
        <div class="p-4 border-b">
            <div class="flex items-center justify-between">
                <a href="/" class="flex items-center">
                    <img src="/assets/images/logo.png" alt="SOCIALKOCH.CO" class="h-8 w-auto">
                    <span class="mr-2 text-lg font-bold text-gradient">SOCIALKOCH</span>
                </a>
                <button id="mobile-menu-close" class="text-gray-500 hover:text-gray-700 p-2">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        <nav class="p-4">
            <div class="space-y-1">
                <a href="#features" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    امکانات
                </a>
                <a href="#pricing" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    تعرفه‌ها
                </a>
                <a href="#about" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    درباره ما
                </a>
                <a href="/blog" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    وبلاگ
                </a>
                <a href="/contact" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-100 transition duration-150">
                    تماس با ما
                </a>
            </div>
            <div class="mt-4 pt-4 border-t border-gray-300">
                <a href="/login" class="block w-full text-center px-4 py-2 border border-indigo-600 rounded-md text-sm font-medium text-indigo-600 hover:bg-indigo-50 transition duration-150 mb-3">
                    ورود
                </a>
                <a href="/register" class="block w-full text-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md text-sm font-medium text-white hover:bg-indigo-700 transition duration-150">
                    ثبت نام
                </a>
            </div>
        </nav>
    </div>
</header>

<!-- Hero Section -->
<section class="gradient-primary text-white py-20">
    <div class="container mx-auto px-4">
        <div class="flex flex-wrap items-center">
            <div class="w-full lg:w-1/2 mb-10 lg:mb-0">
                <h1 class="text-4xl md:text-5xl font-bold mb-6">رصد، پایش و تحلیل شبکه‌های اجتماعی با هوش مصنوعی</h1>
                <p class="text-xl md:text-2xl mb-8">سوشال کوچ، همراه هوشمند شما برای مدیریت حرفه‌ای شبکه‌های اجتماعی و تولید محتوای اختصاصی</p>
                <div class="flex flex-wrap gap-4">
                    <a href="/register" class="px-8 py-4 bg-white text-indigo-700 rounded-full font-bold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition duration-300">
                        شروع رایگان
                    </a>
                    <a href="#features" class="px-8 py-4 bg-transparent border-2 border-white text-white rounded-full font-bold hover:bg-white hover:text-indigo-700 transition duration-300">
                        امکانات
                    </a>
                </div>
            </div>
            <div class="w-full lg:w-1/2">
                <img src="/assets/images/hero-image.png" alt="Social Media Analytics" class="floating max-w-full rounded-lg shadow-2xl">
            </div>
        </div>
    </div>
</section>

<!-- Statistics -->
<section class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="text-center p-6 bg-gray-50 rounded-xl shadow-md">
                <div class="text-4xl font-bold text-indigo-600 mb-2">۱۵۰۰+</div>
                <div class="text-gray-600">کاربر فعال</div>
            </div>
            <div class="text-center p-6 bg-gray-50 rounded-xl shadow-md">
                <div class="text-4xl font-bold text-indigo-600 mb-2">۵۰۰۰+</div>
                <div class="text-gray-600">پروژه انجام شده</div>
            </div>
            <div class="text-center p-6 bg-gray-50 rounded-xl shadow-md">
                <div class="text-4xl font-bold text-indigo-600 mb-2">۹۸٪</div>
                <div class="text-gray-600">رضایت مشتریان</div>
            </div>
        </div>
    </div>
</section>

<!-- Features -->
<section id="features" class="py-20 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold mb-4">امکانات و خدمات</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">سوشال کوچ با ارائه مجموعه‌ای کامل از ابزارهای هوشمند، مدیریت شبکه‌های اجتماعی شما را متحول می‌کند</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!-- Feature 1 -->
            <div class="feature-card bg-white rounded-xl shadow-md p-6 transition duration-300">
                <div class="rounded-full bg-indigo-100 p-3 w-14 h-14 flex items-center justify-center mb-4">
                    <i class="fas fa-chart-line text-indigo-600 text-xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">آنالیز پیج اینستاگرام</h3>
                <p class="text-gray-600">تحلیل جامع پیج اینستاگرام شما با بیش از ۳۰ شاخص مهم و ارائه راهکارهای بهبود</p>
            </div>

            <!-- Feature 2 -->
            <div class="feature-card bg-white rounded-xl shadow-md p-6 transition duration-300">
                <div class="rounded-full bg-indigo-100 p-3 w-14 h-14 flex items-center justify-center mb-4">
                    <i class="fas fa-robot text-indigo-600 text-xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">تولید محتوا با هوش مصنوعی</h3>
                <p class="text-gray-600">ایجاد کپشن، استوری و ایده‌های محتوایی اختصاصی با استفاده از هوش مصنوعی پیشرفته</p>
            </div>

            <!-- Feature 3 -->
            <div class="feature-card bg-white rounded-xl shadow-md p-6 transition duration-300">
                <div class="rounded-full bg-indigo-100 p-3 w-14 h-14 flex items-center justify-center mb-4">
                    <i class="fas fa-calendar-alt text-indigo-600 text-xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">برنامه‌ریزی محتوا</h3>
                <p class="text-gray-600">مدیریت حرفه‌ای تقویم محتوایی با قابلیت زمانبندی انتشار پست‌ها و استوری‌ها</p>
            </div>

            <!-- Feature 4 -->
            <div class="feature-card bg-white rounded-xl shadow-md p-6 transition duration-300">
                <div class="rounded-full bg-indigo-100 p-3 w-14 h-14 flex items-center justify-center mb-4">
                    <i class="fas fa-image text-indigo-600 text-xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">تولید تصویر هوشمند</h3>
                <p class="text-gray-600">ساخت تصاویر اختصاصی برای پست، استوری، پروفایل و کاور با هوش مصنوعی</p>
            </div>

            <!-- Feature 5 -->
            <div class="feature-card bg-white rounded-xl shadow-md p-6 transition duration-300">
                <div class="rounded-full bg-indigo-100 p-3 w-14 h-14 flex items-center justify-center mb-4">
                    <i class="fas fa-bullhorn text-indigo-600 text-xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">خدمات برندینگ</h3>
                <p class="text-gray-600">طراحی هویت برند، لوگو، اسلوگان و رنگ‌بندی اختصاصی برای کسب و کار شما</p>
            </div>

            <!-- Feature 6 -->
            <div class="feature-card bg-white rounded-xl shadow-md p-6 transition duration-300">
                <div class="rounded-full bg-indigo-100 p-3 w-14 h-14 flex items-center justify-center mb-4">
                    <i class="fas fa-globe text-indigo-600 text-xl"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">طراحی وب‌سایت و فروشگاه</h3>
                <p class="text-gray-600">ساخت وب‌سایت و فروشگاه اختصاصی با سازنده هوشمند و بدون نیاز به دانش فنی</p>
            </div>
        </div>

        <div class="text-center mt-12">
            <a href="/features" class="inline-block px-6 py-3 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700 transition duration-150">
                مشاهده همه امکانات <i class="fas fa-arrow-left mr-2"></i>
            </a>
        </div>
    </div>
</section>

<!-- How It Works -->
<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold mb-4">چگونه کار می‌کند؟</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">در سه مرحله ساده، مدیریت شبکه‌های اجتماعی خود را متحول کنید</p>
        </div>

        <div class="flex flex-wrap justify-center">
            <!-- Step 1 -->
            <div class="w-full md:w-1/3 px-4 mb-8 md:mb-0">
                <div class="text-center">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-600 text-white text-2xl font-bold mb-6">1</div>
                    <h3 class="text-xl font-bold mb-4">ثبت‌نام و اشتراک</h3>
                    <p class="text-gray-600">حساب کاربری خود را ایجاد کنید و اشتراک مناسب نیاز خود را انتخاب نمایید</p>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="w-full md:w-1/3 px-4 mb-8 md:mb-0">
                <div class="text-center">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-600 text-white text-2xl font-bold mb-6">2</div>
                    <h3 class="text-xl font-bold mb-4">ثبت پیج اینستاگرام</h3>
                    <p class="text-gray-600">پیج اینستاگرام خود را ثبت کنید و گزارش تحلیلی کامل دریافت نمایید</p>
                </div>
            </div>

            <!-- Step 3 -->
            <div class="w-full md:w-1/3 px-4">
                <div class="text-center">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-600 text-white text-2xl font-bold mb-6">3</div>
                    <h3 class="text-xl font-bold mb-4">استفاده از ابزارها</h3>
                    <p class="text-gray-600">از ابزارهای هوشمند برای تولید محتوا، برنامه‌ریزی و بهبود عملکرد استفاده کنید</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Pricing -->
<section id="pricing" class="py-20 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold mb-4">تعرفه‌های اشتراک</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">بهترین طرح را متناسب با نیاز خود انتخاب کنید</p>
        </div>

        <div class="flex flex-wrap justify-center">
            <!-- Monthly Plan -->
            <div class="w-full md:w-1/3 px-4 mb-8">
                <div class="bg-white rounded-xl shadow-md p-8 h-full flex flex-col">
                    <div class="mb-6">
                        <h3 class="text-xl font-bold mb-2">اشتراک یک‌ماهه</h3>
                        <div class="flex items-end mb-2">
                            <span class="text-4xl font-bold text-indigo-600">۱۰۰,۰۰۰</span>
                            <span class="text-gray-600 mr-2">تومان</span>
                        </div>
                        <p class="text-gray-600">مناسب برای شروع و آشنایی با سیستم</p>
                    </div>

                    <div class="mb-6 flex-grow">
                        <ul class="space-y-3">
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>دسترسی به تمام ابزارها</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>ثبت نامحدود پیج اینستاگرام</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>تولید محتوا با هوش مصنوعی</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>پشتیبانی آنلاین</span>
                            </li>
                        </ul>
                    </div>

                    <a href="/register?plan=monthly" class="block w-full text-center px-6 py-3 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700 transition duration-150">
                        انتخاب طرح
                    </a>
                </div>
            </div>

            <!-- Quarterly Plan -->
            <div class="w-full md:w-1/3 px-4 mb-8">
                <div class="bg-white rounded-xl shadow-lg p-8 h-full flex flex-col relative transform scale-105 border-2 border-indigo-500">
                    <div class="absolute top-0 right-0 bg-indigo-500 text-white px-4 py-1 rounded-bl-lg rounded-tr-lg text-sm font-bold">
                        پیشنهاد ویژه
                    </div>

                    <div class="mb-6">
                        <h3 class="text-xl font-bold mb-2">اشتراک سه‌ماهه</h3>
                        <div class="flex items-end mb-2">
                            <span class="text-4xl font-bold text-indigo-600">۵۰۰,۰۰۰</span>
                            <span class="text-gray-600 mr-2">تومان</span>
                        </div>
                        <p class="text-gray-600">صرفه‌جویی ۲۰٪ نسبت به طرح ماهانه</p>
                    </div>

                    <div class="mb-6 flex-grow">
                        <ul class="space-y-3">
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>تمام امکانات طرح ماهانه</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>آنالیز پیشرفته پیج</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>طراحی تقویم محتوایی</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>پشتیبانی ویژه و اولویت‌دار</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>آموزش اختصاصی کار با سیستم</span>
                            </li>
                        </ul>
                    </div>

                    <a href="/register?plan=quarterly" class="block w-full text-center px-6 py-3 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700 transition duration-150">
                        انتخاب طرح
                    </a>
                </div>
            </div>

            <!-- Yearly Plan -->
            <div class="w-full md:w-1/3 px-4 mb-8">
                <div class="bg-white rounded-xl shadow-md p-8 h-full flex flex-col">
                    <div class="mb-6">
                        <h3 class="text-xl font-bold mb-2">اشتراک سالانه</h3>
                        <div class="flex items-end mb-2">
                            <span class="text-4xl font-bold text-indigo-600">۲,۰۰۰,۰۰۰</span>
                            <span class="text-gray-600 mr-2">تومان</span>
                        </div>
                        <p class="text-gray-600">صرفه‌جویی بیش از ۳۰٪ نسبت به طرح ماهانه</p>
                    </div>

                    <div class="mb-6 flex-grow">
                        <ul class="space-y-3">
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>تمام امکانات طرح سه ماهه</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>مشاوره اختصاصی ماهانه</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>آنالیز رقبا</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>استراتژی بازاریابی محتوایی</span>
                            </li>
                            <li class="flex items-center">
                                <i class="fas fa-check text-green-500 ml-2"></i>
                                <span>آموزش‌های ویدیویی پیشرفته</span>
                            </li>
                        </ul>
                    </div>

                    <a href="/register?plan=yearly" class="block w-full text-center px-6 py-3 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700 transition duration-150">
                        انتخاب طرح
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold mb-4">نظرات مشتریان</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">از تجربه کاربران ما بشنوید</p>
        </div>

        <div class="flex flex-wrap -mx-4">
            <!-- Testimonial 1 -->
            <div class="w-full md:w-1/2 lg:w-1/3 px-4 mb-8">
                <div class="bg-gray-50 rounded-xl shadow-md p-6 h-full">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 rounded-full bg-indigo-200 flex items-center justify-center mr-4">
                            <span class="text-indigo-700 font-bold">ع</span>
                        </div>
                        <div>
                            <h4 class="font-bold">علی محمدی</h4>
                            <p class="text-gray-600 text-sm">صاحب فروشگاه لوازم خانگی</p>
                        </div>
                    </div>
                    <p class="text-gray-700">"سوشال کوچ به من کمک کرد تا پیج اینستاگرام فروشگاهم را به صورت حرفه‌ای مدیریت کنم. تولید محتوا با هوش مصنوعی واقعاً زمان زیادی برای من صرفه‌جویی کرد."</p>
                    <div class="flex items-center mt-4">
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                    </div>
                </div>
            </div>

            <!-- Testimonial 2 -->
            <div class="w-full md:w-1/2 lg:w-1/3 px-4 mb-8">
                <div class="bg-gray-50 rounded-xl shadow-md p-6 h-full">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 rounded-full bg-indigo-200 flex items-center justify-center mr-4">
                            <span class="text-indigo-700 font-bold">س</span>
                        </div>
                        <div>
                            <h4 class="font-bold">سارا احمدی</h4>
                            <p class="text-gray-600 text-sm">تولیدکننده محتوا</p>
                        </div>
                    </div>
                    <p class="text-gray-700">"آنالیز دقیق پیج و پیشنهادهای بهبود، به من کمک کرد تا نرخ تعامل پیجم را دو برابر کنم. ابزارهای تولید تصویر هوشمند بسیار کاربردی و باکیفیت هستند."</p>
                    <div class="flex items-center mt-4">
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star-half-alt text-yellow-400"></i>
                    </div>
                </div>
            </div>

            <!-- Testimonial 3 -->
            <div class="w-full md:w-1/2 lg:w-1/3 px-4 mb-8 md:mb-0">
                <div class="bg-gray-50 rounded-xl shadow-md p-6 h-full">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 rounded-full bg-indigo-200 flex items-center justify-center mr-4">
                            <span class="text-indigo-700 font-bold">م</span>
                        </div>
                        <div>
                            <h4 class="font-bold">محمد کریمی</h4>
                            <p class="text-gray-600 text-sm">مدیر آژانس دیجیتال مارکتینگ</p>
                        </div>
                    </div>
                    <p class="text-gray-700">"سوشال کوچ یک ابزار ضروری برای آژانس ما شده است. برنامه‌ریزی محتوا و آنالیز پیج‌های مشتریان‌مان بسیار ساده‌تر شده و نتایج فوق‌العاده‌ای داشته است."</p>
                    <div class="flex items-center mt-4">
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-20 gradient-primary text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl md:text-4xl font-bold mb-6">آماده ارتقای حضور دیجیتال خود هستید؟</h2>
        <p class="text-xl mb-8 max-w-3xl mx-auto">همین امروز با سوشال کوچ شروع کنید و شاهد تحول در مدیریت شبکه‌های اجتماعی خود باشید</p>
        <div class="flex flex-wrap justify-center gap-4">
            <a href="/register" class="px-8 py-4 bg-white text-indigo-700 rounded-full font-bold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition duration-300">
                ثبت نام رایگان
            </a>
            <a href="/contact" class="px-8 py-4 bg-transparent border-2 border-white text-white rounded-full font-bold hover:bg-white hover:text-indigo-700 transition duration-300">
                تماس با ما
            </a>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="bg-gray-900 text-white py-12">
    <div class="container mx-auto px-4">
        <div class="flex flex-wrap">
            <!-- Company Info -->
            <div class="w-full md:w-1/4 mb-8 md:mb-0">
                <a href="/" class="flex items-center mb-4">
                    <img src="/assets/images/logo-white.png" alt="SOCIALKOCH.CO" class="h-10 w-auto">
                    <span class="mr-3 text-xl font-bold">SOCIALKOCH.CO</span>
                </a>
                <p class="text-gray-400 mb-4">رصد، پایش و تحلیل شبکه‌های اجتماعی با هوش مصنوعی</p>
                <div class="flex space-x-4 space-x-reverse">
                    <a href="#" class="text-gray-400 hover:text-white transition duration-150">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition duration-150">
                        <i class="fab fa-telegram"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition duration-150">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition duration-150">
                        <i class="fab fa-linkedin"></i>
                    </a>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="w-full md:w-1/4 mb-8 md:mb-0">
                <h4 class="text-lg font-bold mb-4">دسترسی سریع</h4>
                <ul class="space-y-2">
                    <li><a href="/" class="text-gray-400 hover:text-white transition duration-150">صفحه اصلی</a></li>
                    <li><a href="#features" class="text-gray-400 hover:text-white transition duration-150">امکانات</a></li>
                    <li><a href="#pricing" class="text-gray-400 hover:text-white transition duration-150">تعرفه‌ها</a></li>
                    <li><a href="/blog" class="text-gray-400 hover:text-white transition duration-150">وبلاگ</a></li>
                    <li><a href="/contact" class="text-gray-400 hover:text-white transition duration-150">تماس با ما</a></li>
                </ul>
            </div>

            <!-- Legal -->
            <div class="w-full md:w-1/4 mb-8 md:mb-0">
                <h4 class="text-lg font-bold mb-4">قوانین و مقررات</h4>
                <ul class="space-y-2">
                    <li><a href="/terms" class="text-gray-400 hover:text-white transition duration-150">شرایط و قوانین</a></li>
                    <li><a href="/privacy" class="text-gray-400 hover:text-white transition duration-150">حریم خصوصی</a></li>
                    <li><a href="/faq" class="text-gray-400 hover:text-white transition duration-150">سوالات متداول</a></li>
                </ul>
            </div>

            <!-- Contact -->
            <div class="w-full md:w-1/4">
                <h4 class="text-lg font-bold mb-4">ارتباط با ما</h4>
                <ul class="space-y-2">
                    <li class="flex items-start">
                        <i class="fas fa-map-marker-alt mt-1 ml-2 text-gray-400"></i>
                        <span class="text-gray-400">تهران، خیابان ولیعصر، پلاک ۱۲۳</span>
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-phone ml-2 text-gray-400"></i>
                        <span class="text-gray-400">۰۲۱-۱۲۳۴۵۶۷۸</span>
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-envelope ml-2 text-gray-400"></i>
                        <span class="text-gray-400">info@socialkoch.co</span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="border-t border-gray-800 mt-12 pt-8 text-center">
            <p class="text-gray-400">&copy; ۱۴۰۴ سوشال کوچ. تمامی حقوق محفوظ است.</p>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script>
    // Mobile Menu Toggle
    document.addEventListener('DOMContentLoaded', function() {
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const mobileMenuClose = document.getElementById('mobile-menu-close');
        const mobileMenu = document.getElementById('mobile-menu');

        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.remove('mobile-menu-hidden');
            mobileMenu.classList.add('mobile-menu-visible');
        });

        mobileMenuClose.addEventListener('click', function() {
            mobileMenu.classList.remove('mobile-menu-visible');
            mobileMenu.classList.add('mobile-menu-hidden');
        });

        // Close menu when clicking on a menu item
        const mobileMenuItems = mobileMenu.querySelectorAll('a');
        mobileMenuItems.forEach(item => {
            item.addEventListener('click', function() {
                mobileMenu.classList.remove('mobile-menu-visible');
                mobileMenu.classList.add('mobile-menu-hidden');
            });
        });
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
</script>
</body>
</html>