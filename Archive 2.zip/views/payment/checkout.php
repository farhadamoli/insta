<?php
/**
 * views/payment/checkout.php
 *
 * قالب صفحه تکمیل خرید - مثالی از استفاده از سیستم چندزبانه
 */

// دسترسی به متغیرهای ارسال شده از کنترلر
/* @var $title string */
/* @var $plan array */
/* @var $user array */
?>

<!DOCTYPE html>
<html lang="<?= \App\Core\Language::getCurrentLang() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?> | <?= __('general.app_name') ?></title>
    <!-- استایل‌ها و اسکریپت‌ها -->
</head>
<body class="<?= \App\Core\Language::getCurrentLang() === 'fa' ? 'rtl' : 'ltr' ?>">
<!-- هدر سایت -->
<?php include_once 'views/partials/header.php'; ?>

<main class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h2 class="h4 mb-0"><?= __('payment.checkout_title') ?></h2>
                </div>

                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h3 class="h5 border-bottom pb-2"><?= __('payment.checkout_plan_details') ?></h3>

                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <p><strong><?= __('payment.checkout_plan_name') ?></strong> <?= __('payment.plan_' . strtolower($plan['type'])) ?></p>
                                    <p><strong><?= __('payment.checkout_plan_duration') ?></strong> <?= __('payment.subscription_duration', ['duration' => $plan['duration']]) ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><?= __('payment.checkout_plan_price') ?></strong> <?= __('payment.plan_price', ['price' => number_format($plan['price'])]) ?></p>

                                    <?php if (isset($plan['discount']) && $plan['discount'] > 0): ?>
                                        <p><strong><?= __('payment.checkout_discount') ?></strong> <?= __('payment.plan_discount', ['percent' => $plan['discount']]) ?></p>
                                    <?php endif; ?>

                                    <p><strong><?= __('payment.checkout_total_price') ?></strong> <?= __('payment.plan_price', ['price' => number_format($plan['total_price'])]) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h3 class="h5 border-bottom pb-2"><?= __('payment.checkout_billing_info') ?></h3>

                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <p><strong><?= __('general.form_first_name') ?>:</strong> <?= $user['first_name'] ?></p>
                                    <p><strong><?= __('general.form_last_name') ?>:</strong> <?= $user['last_name'] ?></p>
                                    <p><strong><?= __('general.form_email') ?>:</strong> <?= $user['email'] ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><?= __('general.form_phone') ?>:</strong> <?= $user['phone'] ?? '-' ?></p>
                                    <p><strong><?= __('general.form_company') ?>:</strong> <?= $user['company'] ?? '-' ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <form action="/payment/process" method="post" id="payment-form">
                        <input type="hidden" name="plan_id" value="<?= $plan['id'] ?>">

                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h3 class="h5 border-bottom pb-2"><?= __('payment.checkout_payment_method') ?></h3>

                                <div class="form-group mt-3">
                                    <label for="payment_gateway"><?= __('payment.checkout_payment_gateway') ?></label>
                                    <select name="payment_gateway" id="payment_gateway" class="form-control">
                                        <option value="zarinpal"><?= __('payment.checkout_gateway_zarinpal') ?></option>
                                        <option value="payir"><?= __('payment.checkout_gateway_payir') ?></option>
                                        <option value="idpay"><?= __('payment.checkout_gateway_idpay') ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group form-check mb-4">
                            <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                            <label class="form-check-label" for="terms">
                                <?= __('payment.checkout_terms', ['terms_url' => '/terms']) ?>
                            </label>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg px-5">
                                <?= __('payment.btn_pay', ['price' => number_format($plan['total_price'])]) ?>
                            </button>

                            <a href="/payment/plans" class="btn btn-outline-secondary ml-2">
                                <?= __('payment.btn_back_to_plans') ?>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- فوتر سایت -->
<?php include_once 'views/partials/footer.php'; ?>

<!-- اسکریپت‌های صفحه -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // اسکریپت‌های مخصوص صفحه پرداخت
    });
</script>
</body>
</html>