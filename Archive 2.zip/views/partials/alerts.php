<?php
/**
 * views/partials/alerts.php
 *
 * این فایل شامل کدهای مورد نیاز برای نمایش هشدارها با استفاده از SweetAlert2 است
 * این قسمت باید در همه صفحات گنجانده شود (معمولاً در فایل layout اصلی)
 */

use App\Core\AlertHelper;
?>

<!-- نمایش هشدارهای فلش (ذخیره شده در سشن) -->
<?= AlertHelper::displayFlash() ?>

<!-- اضافه کردن کتابخانه SweetAlert2 از CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- تنظیمات سفارشی برای SweetAlert2 -->
<script>
    // تنظیمات پیش‌فرض براساس جهت نوشتار
    const isRTL = document.dir === 'rtl' || document.documentElement.lang === 'fa';

    // تنظیم پیش‌فرض‌های SweetAlert2
    const sweetAlertDefaults = {
        confirmButtonText: isRTL ? 'تأیید' : 'Confirm',
        cancelButtonText: isRTL ? 'انصراف' : 'Cancel',
        denyButtonText: isRTL ? 'رد' : 'Deny',
        position: 'center',
        grow: false,
        showClass: {
            popup: 'animate__animated animate__fadeIn animate__faster'
        },
        hideClass: {
            popup: 'animate__animated animate__fadeOut animate__faster'
        }
    };

    // اعمال تنظیمات پیش‌فرض
    Swal.mixin(sweetAlertDefaults);

    // تنظیم توست (هشدار کوچک)
    window.Toast = Swal.mixin({
        toast: true,
        position: isRTL ? 'top-start' : 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
        }
    });

    // توابع کمکی برای نمایش توست
    window.showToast = function(text, icon = 'success') {
        Toast.fire({
            icon: icon,
            title: text
        });
    };

    // تابع تأیید حذف با SweetAlert2
    window.confirmDelete = function(url, message = null) {
        Swal.fire({
            title: isRTL ? 'آیا مطمئن هستید؟' : 'Are you sure?',
            text: message || (isRTL ? 'این مورد به طور دائم حذف خواهد شد!' : 'This item will be permanently deleted!'),
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: isRTL ? 'بله، حذف شود!' : 'Yes, delete it!',
            cancelButtonText: isRTL ? 'انصراف' : 'Cancel',
            reverseButtons: isRTL
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });

        return false; // جلوگیری از ارسال فرم
    };

    // تابع ارسال فرم با تأیید
    window.confirmSubmit = function(formId, message = null) {
        Swal.fire({
            title: isRTL ? 'آیا مطمئن هستید؟' : 'Are you sure?',
            text: message || (isRTL ? 'آیا از انجام این عملیات اطمینان دارید؟' : 'Are you sure you want to perform this action?'),
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: isRTL ? 'بله، ادامه!' : 'Yes, continue!',
            cancelButtonText: isRTL ? 'انصراف' : 'Cancel',
            reverseButtons: isRTL
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById(formId).submit();
            }
        });

        return false; // جلوگیری از ارسال فرم
    };
</script>