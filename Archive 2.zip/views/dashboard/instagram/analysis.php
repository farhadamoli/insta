<!-- File: views/dashboard/instagram/analysis.php -->
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>آنالیز پیج اینستاگرام - SOCIALKOCH.CO</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Vazir Font (Persian Font) -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css" rel="stylesheet" type="text/css" />

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --primary-color: #4f46e5;
            --secondary-color: #7c3aed;
            --accent-color: #f59e0b;
            --dark-color: #1f2937;
            --light-color: #f3f4f6;
        }

        body {
            font-family: 'Vazir', 'Tahoma', sans-serif;
        }

        .gradient-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        .gradient-accent {
            background: linear-gradient(135deg, var(--accent-color), #ef4444);
        }

        .text-gradient {
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-image: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        .sidebar-item.active {
            background-color: rgba(79, 70, 229, 0.1);
            color: var(--primary-color);
            border-right: 3px solid var(--primary-color);
        }

        .progress-bar {
            height: 8px;
            border-radius: 4px;
            background-color: #e5e7eb;
            overflow: hidden;
        }

        .progress-bar-fill {
            height: 100%;
            border-radius: 4px;
        }

        @media (max-width: 768px) {
            .sidebar-open {
                transform: translateX(0);
            }

            .sidebar-closed {
                transform: translateX(100%);
            }
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800">
<div class="flex h-screen">
    <!-- Sidebar (Mobile Toggle) -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-20 hidden md:hidden"></div>

    <!-- Sidebar (Same as dashboard.php) -->
    <!-- ... Include sidebar here ... -->

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-hidden">
        <!-- Top Navbar (Same as dashboard.php) -->
        <!-- ... Include navbar here ... -->

        <!-- Main Content Area -->
        <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
            <!-- Page Header -->
            <div class="mb-8">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">آنالیز پیج اینستاگرام</h1>
                        <p class="text-gray-600 mt-1">تحلیل جامع و دقیق پیج <?= $instagram_page['username'] ?></p>
                    </div>
                    <div class="flex space-x-4 space-x-reverse">
                        <button id="refreshAnalysisBtn" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200">
                            <i class="fas fa-sync-alt ml-2"></i>
                            بروزرسانی آنالیز
                        </button>
                        <button id="exportReportBtn" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700">
                            <i class="fas fa-download ml-2"></i>
                            دانلود گزارش
                        </button>
                    </div>
                </div>
            </div>

            <!-- Profile Overview Card -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                <div class="flex flex-wrap md:flex-nowrap items-start">
                    <!-- Profile Image and Basic Info -->
                    <div class="w-full md:w-auto flex flex-col items-center md:ml-8 mb-6 md:mb-0">
                        <img src="<?= $instagram_page['profile_image'] ?>" alt="تصویر پروفایل" class="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md">
                        <h2 class="text-xl font-bold mt-4 text-center"><?= $instagram_page['username'] ?></h2>
                        <p class="text-gray-600 text-center"><?= $instagram_page['business_category'] ?></p>
                        <div class="flex items-center mt-2">
                            <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full"><?= $instagram_page['specialist_category'] ?></span>
                        </div>
                    </div>

                    <!-- Account Stats -->
                    <div class="flex-grow">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <!-- Followers -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm text-gray-500">فالوورها</span>
                                    <span class="text-xs font-medium <?= $instagram_analytics['follower_growth'] >= 0 ? 'text-green-500' : 'text-red-500' ?>">
                                            <i class="fas fa-<?= $instagram_analytics['follower_growth'] >= 0 ? 'caret-up' : 'caret-down' ?>"></i>
                                            <?= abs($instagram_analytics['follower_growth']) ?>%
                                        </span>
                                </div>
                                <div class="text-2xl font-bold"><?= number_format($instagram_analytics['follower_count']) ?></div>
                            </div>

                            <!-- Following -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm text-gray-500">فالوینگ</span>
                                </div>
                                <div class="text-2xl font-bold"><?= number_format($instagram_page['following_count']) ?></div>
                            </div>

                            <!-- Posts -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm text-gray-500">پست‌ها</span>
                                    <span class="text-xs font-medium <?= $instagram_analytics['post_count_growth'] >= 0 ? 'text-green-500' : 'text-red-500' ?>">
                                            <i class="fas fa-<?= $instagram_analytics['post_count_growth'] >= 0 ? 'caret-up' : 'caret-down' ?>"></i>
                                            <?= abs($instagram_analytics['post_count_growth']) ?>%
                                        </span>
                                </div>
                                <div class="text-2xl font-bold"><?= number_format($instagram_analytics['post_count']) ?></div>
                            </div>

                            <!-- Engagement Rate -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm text-gray-500">نرخ تعامل</span>
                                    <span class="text-xs font-medium <?= $instagram_analytics['engagement_growth'] >= 0 ? 'text-green-500' : 'text-red-500' ?>">
                                            <i class="fas fa-<?= $instagram_analytics['engagement_growth'] >= 0 ? 'caret-up' : 'caret-down' ?>"></i>
                                            <?= abs($instagram_analytics['engagement_growth']) ?>%
                                        </span>
                                </div>
                                <div class="text-2xl font-bold"><?= $instagram_analytics['engagement_rate'] ?>%</div>
                            </div>
                        </div>

                        <!-- Account Description -->
                        <div class="mt-6 bg-gray-50 rounded-lg p-4">
                            <div class="flex items-center mb-2">
                                <i class="fas fa-info-circle text-indigo-500 ml-2"></i>
                                <h3 class="text-base font-medium text-gray-900">توضیحات پیج</h3>
                            </div>
                            <p class="text-gray-700 whitespace-pre-line"><?= $instagram_page['description'] ?: 'بدون توضیحات' ?></p>
                        </div>

                        <!-- Activity Info -->
                        <div class="mt-4 bg-gray-50 rounded-lg p-4">
                            <div class="flex items-center mb-2">
                                <i class="fas fa-calendar-alt text-indigo-500 ml-2"></i>
                                <h3 class="text-base font-medium text-gray-900">اطلاعات فعالیت</h3>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="flex items-center">
                                    <div class="text-gray-600 ml-2">تاریخ شروع فعالیت:</div>
                                    <div class="text-gray-900"><?= Helper::formatDate($instagram_page['start_date'], 'j F Y') ?></div>
                                </div>
                                <div class="flex items-center">
                                    <div class="text-gray-600 ml-2">مدت فعالیت:</div>
                                    <div class="text-gray-900"><?= $instagram_analytics['active_days'] ?> روز</div>
                                </div>
                                <div class="flex items-center">
                                    <div class="text-gray-600 ml-2">آخرین آنالیز:</div>
                                    <div class="text-gray-900"><?= Helper::formatDate($instagram_page['last_analysis'], 'j F Y H:i') ?></div>
                                </div>
                                <div class="flex items-center">
                                    <div class="text-gray-600 ml-2">تاریخ ثبت پیج:</div>
                                    <div class="text-gray-900"><?= Helper::formatDate($instagram_page['created_at'], 'j F Y') ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Analytics Content -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Left Column (2/3) -->
                <div class="lg:col-span-2 space-y-8">
                    <!-- Metrics Overview -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">شاخص‌های کلیدی</h3>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Impression -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-gray-700">ایمپرشن</span>
                                    <span class="text-xs font-medium <?= $instagram_analytics['impressions_growth'] >= 0 ? 'text-green-500' : 'text-red-500' ?>">
                                            <i class="fas fa-<?= $instagram_analytics['impressions_growth'] >= 0 ? 'caret-up' : 'caret-down' ?>"></i>
                                            <?= abs($instagram_analytics['impressions_growth']) ?>%
                                        </span>
                                </div>
                                <div class="text-2xl font-bold mb-1"><?= number_format($instagram_analytics['impressions']) ?></div>
                                <p class="text-xs text-gray-500">تعداد بازدیدهای پیج شما در ۳۰ روز گذشته</p>
                            </div>

                            <!-- Engagement -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-gray-700">اینگیجمنت</span>
                                    <span class="text-xs font-medium <?= $instagram_analytics['engagement_growth'] >= 0 ? 'text-green-500' : 'text-red-500' ?>">
                                            <i class="fas fa-<?= $instagram_analytics['engagement_growth'] >= 0 ? 'caret-up' : 'caret-down' ?>"></i>
                                            <?= abs($instagram_analytics['engagement_growth']) ?>%
                                        </span>
                                </div>
                                <div class="text-2xl font-bold mb-1"><?= number_format($instagram_analytics['engagement']) ?></div>
                                <p class="text-xs text-gray-500">مجموع تعاملات در ۳۰ روز گذشته</p>
                            </div>

                            <!-- Average Likes -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-gray-700">میانگین لایک</span>
                                    <span class="text-xs font-medium <?= $instagram_analytics['avg_likes_growth'] >= 0 ? 'text-green-500' : 'text-red-500' ?>">
                                            <i class="fas fa-<?= $instagram_analytics['avg_likes_growth'] >= 0 ? 'caret-up' : 'caret-down' ?>"></i>
                                            <?= abs($instagram_analytics['avg_likes_growth']) ?>%
                                        </span>
                                </div>
                                <div class="text-2xl font-bold mb-1"><?= number_format($instagram_analytics['avg_likes']) ?></div>
                                <p class="text-xs text-gray-500">میانگین لایک‌های دریافتی برای هر پست</p>
                            </div>

                            <!-- Average Comments -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-gray-700">میانگین کامنت</span>
                                    <span class="text-xs font-medium <?= $instagram_analytics['avg_comments_growth'] >= 0 ? 'text-green-500' : 'text-red-500' ?>">
                                            <i class="fas fa-<?= $instagram_analytics['avg_comments_growth'] >= 0 ? 'caret-up' : 'caret-down' ?>"></i>
                                            <?= abs($instagram_analytics['avg_comments_growth']) ?>%
                                        </span>
                                </div>
                                <div class="text-2xl font-bold mb-1"><?= number_format($instagram_analytics['avg_comments']) ?></div>
                                <p class="text-xs text-gray-500">میانگین کامنت‌های دریافتی برای هر پست</p>
                            </div>
                        </div>
                    </div>

                    <!-- Follower Growth Chart -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">نمودار تغییرات تعداد فالوورها</h3>
                        <div class="h-80">
                            <canvas id="followerGrowthChart"></canvas>
                        </div>
                    </div>

                    <!-- Engagement Analysis -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">تحلیل تعاملات</h3>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                            <!-- Engagement Score -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="text-center">
                                    <div class="text-gray-700 mb-2">امتیاز تعامل</div>
                                    <div class="text-3xl font-bold mb-1"><?= $instagram_analytics['engagement_score'] ?>/100</div>
                                    <div class="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                                        <div class="h-full <?= $instagram_analytics['engagement_score'] >= 70 ? 'bg-green-500' : ($instagram_analytics['engagement_score'] >= 40 ? 'bg-yellow-500' : 'bg-red-500') ?>" style="width: <?= $instagram_analytics['engagement_score'] ?>%"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Positive Sentiment -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="text-center">
                                    <div class="text-gray-700 mb-2">رویکرد مثبت</div>
                                    <div class="text-3xl font-bold mb-1"><?= $instagram_analytics['positive_sentiment'] ?>%</div>
                                    <div class="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                                        <div class="h-full bg-green-500" style="width: <?= $instagram_analytics['positive_sentiment'] ?>%"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Negative Sentiment -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="text-center">
                                    <div class="text-gray-700 mb-2">رویکرد منفی</div>
                                    <div class="text-3xl font-bold mb-1"><?= $instagram_analytics['negative_sentiment'] ?>%</div>
                                    <div class="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                                        <div class="h-full bg-red-500" style="width: <?= $instagram_analytics['negative_sentiment'] ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- NPS -->
                        <div class="bg-gray-50 rounded-lg p-4 mb-6">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-gray-700">میزان خشنودی (NPS)</span>
                                <span class="text-sm font-medium"><?= $instagram_analytics['nps_score'] ?></span>
                            </div>
                            <div class="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                                <div class="h-full <?= $instagram_analytics['nps_score'] >= 50 ? 'bg-green-500' : ($instagram_analytics['nps_score'] >= 0 ? 'bg-yellow-500' : 'bg-red-500') ?>" style="width: <?= max(0, ($instagram_analytics['nps_score'] + 100) / 2) ?>%"></div>
                            </div>
                            <div class="flex justify-between mt-1">
                                <span class="text-xs text-gray-500">-100</span>
                                <span class="text-xs text-gray-500">0</span>
                                <span class="text-xs text-gray-500">+100</span>
                            </div>
                        </div>

                        <!-- Best Post Times -->
                        <div class="bg-gray-50 rounded-lg p-4">
                            <h4 class="text-lg font-medium mb-4">بهترین زمان‌های پست‌گذاری</h4>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Days -->
                                <div>
                                    <h5 class="text-sm font-medium text-gray-700 mb-2">روزهای هفته</h5>
                                    <div class="space-y-2">
                                        <?php foreach($best_post_times['days'] as $day => $score): ?>
                                            <div>
                                                <div class="flex items-center justify-between mb-1">
                                                    <span class="text-sm"><?= $day ?></span>
                                                    <span class="text-xs"><?= $score ?>%</span>
                                                </div>
                                                <div class="progress-bar">
                                                    <div class="progress-bar-fill bg-indigo-500" style="width: <?= $score ?>%"></div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <!-- Hours -->
                                <div>
                                    <h5 class="text-sm font-medium text-gray-700 mb-2">ساعات روز</h5>
                                    <div class="space-y-2">
                                        <?php foreach($best_post_times['hours'] as $hour => $score): ?>
                                            <div>
                                                <div class="flex items-center justify-between mb-1">
                                                    <span class="text-sm"><?= $hour ?></span>
                                                    <span class="text-xs"><?= $score ?>%</span>
                                                </div>
                                                <div class="progress-bar">
                                                    <div class="progress-bar-fill bg-indigo-500" style="width: <?= $score ?>%"></div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Top Posts -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">بهترین پست‌ها</h3>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <?php foreach($top_posts as $post): ?>
                                <div class="bg-gray-50 rounded-lg overflow-hidden">
                                    <img src="<?= $post['thumbnail_url'] ?>" alt="تصویر پست" class="w-full h-48 object-cover">
                                    <div class="p-4">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center">
                                                <i class="fas fa-heart text-red-500 ml-1"></i>
                                                <span class="text-sm"><?= number_format($post['like_count']) ?></span>
                                            </div>
                                            <div class="flex items-center">
                                                <i class="fas fa-comment text-blue-500 ml-1"></i>
                                                <span class="text-sm"><?= number_format($post['comment_count']) ?></span>
                                            </div>
                                            <div class="flex items-center">
                                                <i class="fas fa-chart-line text-green-500 ml-1"></i>
                                                <span class="text-sm"><?= $post['engagement_rate'] ?>%</span>
                                            </div>
                                        </div>
                                        <p class="text-xs text-gray-500 line-clamp-3"><?= Helper::shortenText($post['caption'], 80) ?></p>
                                        <a href="<?= $post['post_url'] ?>" target="_blank" class="inline-block mt-3 text-xs text-indigo-600 hover:text-indigo-800">
                                            مشاهده پست <i class="fas fa-external-link-alt mr-1"></i>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="text-center mt-6">
                            <a href="/dashboard/instagram/posts/<?= $instagram_page['id'] ?>" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200">
                                مشاهده همه پست‌ها
                                <i class="fas fa-arrow-left mr-2"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Right Column (1/3) -->
                <div class="space-y-8">
                    <!-- Growth Potential -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">پتانسیل رشد</h3>

                        <div class="text-center mb-6">
                            <div class="inline-block relative">
                                <svg class="w-36 h-36" viewBox="0 0 36 36">
                                    <path d="M18 2.0845
                                            a 15.9155 15.9155 0 0 1 0 31.831
                                            a 15.9155 15.9155 0 0 1 0 -31.831"
                                          fill="none" stroke="#eee" stroke-width="3" stroke-dasharray="100, 100" />
                                    <path d="M18 2.0845
                                            a 15.9155 15.9155 0 0 1 0 31.831
                                            a 15.9155 15.9155 0 0 1 0 -31.831"
                                          fill="none" stroke="#4f46e5" stroke-width="3" stroke-dasharray="<?= $instagram_analytics['growth_potential'] ?>, 100" />
                                </svg>
                                <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                                    <div class="text-3xl font-bold"><?= $instagram_analytics['growth_potential'] ?>%</div>
                                </div>
                            </div>
                        </div>

                        <p class="text-gray-700 text-center mb-4">پیج شما <?= $instagram_analytics['growth_potential'] ?>% از پتانسیل رشد خود را داراست</p>

                        <div class="space-y-4">
                            <?php foreach($growth_factors as $factor): ?>
                                <div class="bg-gray-50 rounded-lg p-3">
                                    <div class="flex items-start">
                                        <div class="flex-shrink-0 mt-1">
                                            <i class="fas fa-<?= $factor['positive'] ? 'check text-green-500' : 'times text-red-500' ?>"></i>
                                        </div>
                                        <div class="mr-3">
                                            <h4 class="text-sm font-medium text-gray-900"><?= $factor['title'] ?></h4>
                                            <p class="mt-1 text-xs text-gray-600"><?= $factor['description'] ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Content Sensitivity -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">حساسیت محتوا</h3>

                        <div class="text-center mb-6">
                            <div class="inline-block w-36 h-36 relative">
                                <?php
                                $sensitivity = $instagram_analytics['content_sensitivity'];
                                $color = $sensitivity < 30 ? 'green' : ($sensitivity < 70 ? 'yellow' : 'red');
                                ?>
                                <svg class="w-36 h-36" viewBox="0 0 36 36">
                                    <path d="M18 2.0845
                                            a 15.9155 15.9155 0 0 1 0 31.831
                                            a 15.9155 15.9155 0 0 1 0 -31.831"
                                          fill="none" stroke="#eee" stroke-width="3" stroke-dasharray="100, 100" />
                                    <path d="M18 2.0845
                                            a 15.9155 15.9155 0 0 1 0 31.831
                                            a 15.9155 15.9155 0 0 1 0 -31.831"
                                          fill="none" stroke="<?= $color === 'green' ? '#10b981' : ($color === 'yellow' ? '#f59e0b' : '#ef4444') ?>" stroke-width="3" stroke-dasharray="<?= $sensitivity ?>, 100" />
                                </svg>
                                <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                                    <div class="text-3xl font-bold"><?= $sensitivity ?>%</div>
                                </div>
                            </div>
                        </div>

                        <div class="text-center mb-6">
                            <div class="text-sm font-medium text-gray-700 mb-2">میزان حساسیت محتوا</div>
                            <div class="inline-block px-3 py-1 rounded-full text-sm font-medium <?= $color === 'green' ? 'bg-green-100 text-green-800' : ($color === 'yellow' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') ?>">
                                <?= $color === 'green' ? 'پایین' : ($color === 'yellow' ? 'متوسط' : 'بالا') ?>
                            </div>
                        </div>

                        <p class="text-sm text-gray-600 mb-4">
                            <?php if($color === 'green'): ?>
                                محتوای پیج شما از نظر الگوریتم اینستاگرام مناسب است و محدودیتی برای نمایش آن وجود ندارد.
                            <?php elseif($color === 'yellow'): ?>
                                محتوای پیج شما تا حدودی دارای حساسیت است و ممکن است در برخی موارد با محدودیت نمایش مواجه شود.
                            <?php else: ?>
                                محتوای پیج شما از نظر الگوریتم اینستاگرام دارای حساسیت بالایی است و احتمالاً با محدودیت نمایش مواجه می‌شود.
                            <?php endif; ?>
                        </p>
                    </div>

                    <!-- Improvement Steps -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">مراحل پیشنهادی برای بهبود</h3>

                        <div class="space-y-4">
                            <?php foreach($improvement_steps as $index => $step): ?>
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <div class="flex">
                                        <div class="flex-shrink-0">
                                            <div class="flex items-center justify-center w-8 h-8 rounded-full bg-indigo-100 text-indigo-800 font-bold text-sm">
                                                <?= $index + 1 ?>
                                            </div>
                                        </div>
                                        <div class="mr-4">
                                            <h4 class="text-sm font-medium text-gray-900"><?= $step['title'] ?></h4>
                                            <p class="mt-1 text-xs text-gray-600"><?= $step['description'] ?></p>
                                            <?php if(isset($step['action_url'])): ?>
                                                <a href="<?= $step['action_url'] ?>" class="mt-2 inline-block text-xs text-indigo-600 hover:text-indigo-800">
                                                    <?= $step['action_text'] ?> <i class="fas fa-arrow-left mr-1"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Similar Accounts -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-bold mb-6">حساب‌های مشابه</h3>

                        <div class="space-y-4">
                            <?php foreach($similar_accounts as $account): ?>
                                <div class="bg-gray-50 rounded-lg p-3">
                                    <div class="flex items-center">
                                        <img src="<?= $account['profile_image'] ?>" alt="<?= $account['username'] ?>" class="w-10 h-10 rounded-full object-cover ml-3">
                                        <div class="flex-grow">
                                            <div class="font-medium text-gray-900"><?= $account['username'] ?></div>
                                            <div class="text-xs text-gray-500"><?= number_format($account['follower_count']) ?> فالوور</div>
                                        </div>
                                        <a href="<?= $account['profile_url'] ?>" target="_blank" class="text-indigo-600 hover:text-indigo-800">
                                            <i class="fas fa-external-link-alt"></i>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="text-center mt-4">
                            <a href="/dashboard/instagram/similar/<?= $instagram_page['id'] ?>" class="text-sm text-indigo-600 hover:text-indigo-800">
                                مشاهده همه حساب‌های مشابه <i class="fas fa-arrow-left mr-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Time to Reach Goals -->
            <div class="bg-white rounded-lg shadow-md p-6 mt-8">
                <h3 class="text-xl font-bold mb-6">زمان تخمینی برای رسیدن به اهداف</h3>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Milestone 1 -->
                    <div class="bg-gray-50 rounded-lg p-4">
                        <div class="text-center">
                            <div class="text-2xl font-bold mb-2"><?= number_format($growth_milestones[0]['follower_count']) ?></div>
                            <div class="text-sm text-gray-700 mb-4">فالوور</div>

                            <div class="inline-block px-4 py-2 rounded-full bg-indigo-100 text-indigo-800">
                                <div class="text-xs font-medium mb-1">زمان تخمینی</div>
                                <div class="text-lg font-bold"><?= $growth_milestones[0]['time_estimate'] ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Milestone 2 -->
                    <div class="bg-gray-50 rounded-lg p-4">
                        <div class="text-center">
                            <div class="text-2xl font-bold mb-2"><?= number_format($growth_milestones[1]['follower_count']) ?></div>
                            <div class="text-sm text-gray-700 mb-4">فالوور</div>

                            <div class="inline-block px-4 py-2 rounded-full bg-indigo-100 text-indigo-800">
                                <div class="text-xs font-medium mb-1">زمان تخمینی</div>
                                <div class="text-lg font-bold"><?= $growth_milestones[1]['time_estimate'] ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Milestone 3 -->
                    <div class="bg-gray-50 rounded-lg p-4">
                        <div class="text-center">
                            <div class="text-2xl font-bold mb-2"><?= number_format($growth_milestones[2]['follower_count']) ?></div>
                            <div class="text-sm text-gray-700 mb-4">فالوور</div>

                            <div class="inline-block px-4 py-2 rounded-full bg-indigo-100 text-indigo-800">
                                <div class="text-xs font-medium mb-1">زمان تخمینی</div>
                                <div class="text-lg font-bold"><?= $growth_milestones[2]['time_estimate'] ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-6">
                    <p class="text-sm text-gray-600 mb-4">
                        تخمین‌های بالا بر اساس نرخ رشد فعلی پیج شما و با فرض ادامه فعالیت مشابه محاسبه شده‌اند. با بهبود استراتژی محتوایی و افزایش تعامل، می‌توانید به این اهداف سریع‌تر برسید.
                    </p>
                    <a href="/dashboard/instagram/growth-plan/<?= $instagram_page['id'] ?>" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700">
                        دریافت برنامه رشد اختصاصی
                    </a>
                </div>
            </div>

            <!-- Roadmap -->
            <div class="bg-white rounded-lg shadow-md p-6 mt-8">
                <h3 class="text-xl font-bold mb-6">نقشه راه اینستاگرام</h3>

                <div class="relative">
                    <!-- Progress Bar -->
                    <div class="absolute top-5 right-5 bottom-5 w-1 bg-gray-200 z-0"></div>

                    <!-- Steps -->
                    <div class="relative z-10">
                        <?php foreach($instagram_roadmap as $index => $step): ?>
                            <div class="flex mb-8 last:mb-0">
                                <div class="flex-shrink-0 relative">
                                    <div class="w-10 h-10 rounded-full <?= $step['completed'] ? 'bg-green-500' : 'bg-gray-300' ?> flex items-center justify-center mr-1">
                                        <?php if($step['completed']): ?>
                                            <i class="fas fa-check text-white"></i>
                                        <?php else: ?>
                                            <span class="text-white font-medium"><?= $index + 1 ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="absolute top-10 right-5 h-full w-0.5 bg-transparent"></div>
                                </div>
                                <div class="mr-6 bg-gray-50 rounded-lg p-4 flex-grow">
                                    <h4 class="text-base font-medium text-gray-900 mb-2"><?= $step['title'] ?></h4>
                                    <p class="text-sm text-gray-600 mb-3"><?= $step['description'] ?></p>

                                    <?php if(!$step['completed'] && isset($step['action_url'])): ?>
                                        <a href="<?= $step['action_url'] ?>" class="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200">
                                            <?= $step['action_text'] ?>
                                        </a>
                                    <?php elseif($step['completed']): ?>
                                        <span class="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-green-700 bg-green-100">
                                        <i class="fas fa-check ml-1"></i> تکمیل شده
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Loading Modal -->
<div id="loadingModal" class="fixed inset-0 z-50 flex items-center justify-center hidden">
    <div class="absolute inset-0 bg-black bg-opacity-50"></div>
    <div class="bg-white p-8 rounded-lg shadow-xl z-10 w-80 flex flex-col items-center">
        <div class="spinner mb-4">
            <div class="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
        </div>
        <p class="text-gray-700" id="loadingText">در حال پردازش...</p>
    </div>
</div>

<!-- Scripts -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Sidebar Toggle for Mobile
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('sidebar-closed');
                sidebar.classList.toggle('sidebar-open');
                sidebarOverlay.classList.toggle('hidden');
            });
        }

        if (sidebarOverlay) {
            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('sidebar-open');
                sidebar.classList.add('sidebar-closed');
                sidebarOverlay.classList.add('hidden');
            });
        }

        // Refresh Analysis Button
        const refreshAnalysisBtn = document.getElementById('refreshAnalysisBtn');
        if (refreshAnalysisBtn) {
            refreshAnalysisBtn.addEventListener('click', function() {
                showLoading('در حال بروزرسانی آنالیز...');

                // AJAX request to refresh analysis
                fetch('/dashboard/instagram/refresh-analysis/<?= $instagram_page['id'] ?>', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        hideLoading();

                        if (data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'آنالیز بروز شد',
                                text: 'اطلاعات پیج اینستاگرام شما با موفقیت بروزرسانی شد.',
                                confirmButtonText: 'تایید',
                                timer: 3000,
                                timerProgressBar: true
                            }).then(() => {
                                // Reload page to show updated data
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'خطا در بروزرسانی',
                                text: data.message || 'مشکلی در بروزرسانی اطلاعات پیش آمد. لطفاً دوباره تلاش کنید.',
                                confirmButtonText: 'تایید'
                            });
                        }
                    })
                    .catch(error => {
                        hideLoading();
                        Swal.fire({
                            icon: 'error',
                            title: 'خطا در ارتباط',
                            text: 'مشکلی در ارتباط با سرور پیش آمد. لطفاً دوباره تلاش کنید.',
                            confirmButtonText: 'تایید'
                        });
                    });
            });
        }

        // Export Report Button
        const exportReportBtn = document.getElementById('exportReportBtn');
        if (exportReportBtn) {
            exportReportBtn.addEventListener('click', function() {
                showLoading('در حال آماده‌سازی گزارش...');

                // AJAX request to generate report
                fetch('/dashboard/instagram/export-report/<?= $instagram_page['id'] ?>', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        hideLoading();

                        if (data.success && data.fileUrl) {
                            // Create a temporary link to download the file
                            const link = document.createElement('a');
                            link.href = data.fileUrl;
                            link.download = data.fileName || 'instagram-report.pdf';
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);

                            Swal.fire({
                                icon: 'success',
                                title: 'گزارش آماده شد',
                                text: 'گزارش آنالیز پیج اینستاگرام شما با موفقیت دانلود شد.',
                                confirmButtonText: 'تایید',
                                timer: 3000,
                                timerProgressBar: true
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'خطا در تهیه گزارش',
                                text: data.message || 'مشکلی در تهیه گزارش پیش آمد. لطفاً دوباره تلاش کنید.',
                                confirmButtonText: 'تایید'
                            });
                        }
                    })
                    .catch(error => {
                        hideLoading();
                        Swal.fire({
                            icon: 'error',
                            title: 'خطا در ارتباط',
                            text: 'مشکلی در ارتباط با سرور پیش آمد. لطفاً دوباره تلاش کنید.',
                            confirmButtonText: 'تایید'
                        });
                    });
            });
        }

        // Follower Growth Chart
        const followerCtx = document.getElementById('followerGrowthChart');
        if (followerCtx) {
            const followerGrowthChart = new Chart(followerCtx, {
                type: 'line',
                data: {
                    labels: <?= json_encode($followers_chart['labels']) ?>,
                    datasets: [{
                        label: 'فالوورها',
                        data: <?= json_encode($followers_chart['data']) ?>,
                        backgroundColor: 'rgba(79, 70, 229, 0.2)',
                        borderColor: 'rgba(79, 70, 229, 1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            grid: {
                                drawBorder: false,
                                color: 'rgba(0, 0, 0, 0.05)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        // Loading Modal Functions
        window.showLoading = function(text = 'در حال پردازش...') {
            document.getElementById('loadingText').textContent = text;
            document.getElementById('loadingModal').classList.remove('hidden');
        };

        window.hideLoading = function() {
            document.getElementById('loadingModal').classList.add('hidden');
        };
    });
</script>
</body>
</html>