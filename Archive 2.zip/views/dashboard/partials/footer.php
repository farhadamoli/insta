</main>

<!-- Footer -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; <?= date('Y') ?> Social Monitor. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-right">
                <nav class="footer-nav">
                    <a href="<?= url('terms') ?>">Terms</a>
                    <a href="<?= url('privacy') ?>">Privacy</a>
                    <a href="<?= url('help') ?>">Help</a>
                    <a href="<?= url('contact') ?>">Contact</a>
                </nav>
            </div>
        </div>
    </div>
</footer>
</div>
</div>

<!-- Tour Guide -->
<div class="tour-overlay" id="tourOverlay" style="display: none;"></div>
<div class="tour-tooltip" id="tourTooltip" style="display: none;">
    <div class="tour-tooltip-header">
        <h3 id="tourTitle">Welcome to the tour!</h3>
        <button class="tour-close" id="tourClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="tour-tooltip-body">
        <p id="tourDescription">Let's get you started with a quick tour of the dashboard.</p>
    </div>
    <div class="tour-tooltip-footer">
        <div class="tour-progress">
            <span id="tourStep">1</span>/<span id="tourTotal">5</span>
        </div>
        <div class="tour-buttons">
            <button class="btn btn-sm btn-outline-secondary" id="tourPrev">Previous</button>
            <button class="btn btn-sm btn-primary" id="tourNext">Next</button>
        </div>
    </div>
</div>

<!-- Global Search Modal -->
<div class="modal fade" id="globalSearchModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="global-search">
                    <div class="global-search-header">
                        <i class="fas fa-search"></i>
                        <input type="text" id="globalSearchInput" placeholder="Search for anything..." autofocus>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="global-search-results" id="globalSearchResults">
                        <div class="search-message" id="searchInitialMessage">
                            <i class="fas fa-keyboard"></i>
                            <h4>Start typing to search</h4>
                            <p>Search for accounts, posts, campaigns, and more...</p>
                        </div>
                        <div class="search-message" id="searchLoadingMessage" style="display: none;">
                            <div class="spinner-border text-primary" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                            <h4>Searching...</h4>
                        </div>
                        <div class="search-message" id="searchEmptyMessage" style="display: none;">
                            <i class="fas fa-search"></i>
                            <h4>No results found</h4>
                            <p>Try different keywords or check your spelling</p>
                        </div>
                        <div class="search-categories" id="searchCategories" style="display: none;"></div>
                    </div>
                    <div class="global-search-footer">
                        <div class="search-shortcuts">
                            <span><kbd>↑</kbd><kbd>↓</kbd> to navigate</span>
                            <span><kbd>Enter</kbd> to select</span>
                            <span><kbd>Esc</kbd> to close</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Help Modal -->
<div class="modal fade" id="quickHelpModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Quick Help</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="quick-help-tabs">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="faq-tab" data-toggle="tab" href="#faq" role="tab">FAQs</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="videos-tab" data-toggle="tab" href="#videos" role="tab">Videos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="support-tab" data-toggle="tab" href="#support" role="tab">Support</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="faq" role="tabpanel">
                            <div class="accordion" id="faqAccordion">
                                <div class="card">
                                    <div class="card-header" id="faqHeading1">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#faqCollapse1">
                                                How do I connect my social accounts?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="faqCollapse1" class="collapse show" aria-labelledby="faqHeading1" data-parent="#faqAccordion">
                                        <div class="card-body">
                                            Go to the Accounts section in the sidebar, then click "Connect Account" and follow the instructions to authorize access to your social media accounts.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="faqHeading2">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#faqCollapse2">
                                                How to schedule posts?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="faqCollapse2" class="collapse" aria-labelledby="faqHeading2" data-parent="#faqAccordion">
                                        <div class="card-body">
                                            Navigate to Schedule section, click "Schedule Post", create your content, select target accounts, set date and time, and click "Schedule".
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="faqHeading3">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#faqCollapse3">
                                                How to use AI content generation?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="faqCollapse3" class="collapse" aria-labelledby="faqHeading3" data-parent="#faqAccordion">
                                        <div class="card-body">
                                            Go to AI Content section, select content type, fill in the topic and preferences, click "Generate" and our AI will create content suggestions that you can use or modify.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?= url('help/faq') ?>" class="btn btn-outline-primary btn-block mt-3">View all FAQs</a>
                        </div>
                        <div class="tab-pane fade" id="videos" role="tabpanel">
                            <div class="video-list">
                                <div class="video-item">
                                    <a href="https://www.youtube.com/watch?v=example1" class="video-link" target="_blank">
                                        <div class="video-thumbnail">
                                            <img src="<?= asset_url('images/help/video-thumbnail-1.jpg') ?>" alt="Getting Started">
                                            <div class="play-icon"><i class="fas fa-play-circle"></i></div>
                                        </div>
                                        <div class="video-info">
                                            <h6>Getting Started Guide</h6>
                                            <span>3:45</span>
                                        </div>
                                    </a>
                                </div>
                                <div class="video-item">
                                    <a href="https://www.youtube.com/watch?v=example2" class="video-link" target="_blank">
                                        <div class="video-thumbnail">
                                            <img src="<?= asset_url('images/help/video-thumbnail-2.jpg') ?>" alt="Content Creation">
                                            <div class="play-icon"><i class="fas fa-play-circle"></i></div>
                                        </div>
                                        <div class="video-info">
                                            <h6>Content Creation Tutorial</h6>
                                            <span>5:12</span>
                                        </div>
                                    </a>
                                </div>
                                <div class="video-item">
                                    <a href="https://www.youtube.com/watch?v=example3" class="video-link" target="_blank">
                                        <div class="video-thumbnail">
                                            <img src="<?= asset_url('images/help/video-thumbnail-3.jpg') ?>" alt="Analytics">
                                            <div class="play-icon"><i class="fas fa-play-circle"></i></div>
                                        </div>
                                        <div class="video-info">
                                            <h6>Understanding Analytics</h6>
                                            <span>4:30</span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <a href="<?= url('help/videos') ?>" class="btn btn-outline-primary btn-block mt-3">View all videos</a>
                        </div>
                        <div class="tab-pane fade" id="support" role="tabpanel">
                            <div class="support-options">
                                <a href="<?= url('help/documentation') ?>" class="support-option">
                                    <div class="support-icon">
                                        <i class="fas fa-book"></i>
                                    </div>
                                    <div class="support-text">
                                        <h6>Documentation</h6>
                                        <p>Browse our comprehensive guides</p>
                                    </div>
                                </a>
                                <a href="<?= url('tickets/create') ?>" class="support-option">
                                    <div class="support-icon">
                                        <i class="fas fa-ticket-alt"></i>
                                    </div>
                                    <div class="support-text">
                                        <h6>Submit a Ticket</h6>
                                        <p>Get help from our support team</p>
                                    </div>
                                </a>
                                <a href="https://community.socialmonitor.com" target="_blank" class="support-option">
                                    <div class="support-icon">
                                        <i class="fas fa-users"></i>
                                    </div>
                                    <div class="support-text">
                                        <h6>Community Forum</h6>
                                        <p>Connect with other users</p>
                                    </div>
                                </a>
                            </div>
                            <div class="live-chat mt-4">
                                <button class="btn btn-primary btn-block" id="startLiveChat">
                                    <i class="fas fa-comment-dots"></i> Start Live Chat
                                </button>
                                <p class="text-muted small text-center mt-2">Available Monday-Friday, 9am-5pm ET</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="<?= asset_url('js/jquery.min.js') ?>"></script>
<script src="<?= asset_url('js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= asset_url('js/dashboard.js') ?>"></script>

<?php if (isset($scripts) && is_array($scripts)): ?>
    <?php foreach ($scripts as $script): ?>
        <script src="<?= asset_url($script) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Custom page scripts -->
<?php if (isset($pageScripts)): ?>
    <script>
        <?= $pageScripts ?>
    </script>
<?php endif; ?>

<!-- Tour initialization -->
<?php if (isset($showTour) && $showTour): ?>
    <script>
        $(document).ready(function() {
            initTour();
        });
    </script>
<?php endif; ?>
</body>
</html>