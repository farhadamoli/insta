<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Dashboard' ?> - Social Monitor</title>
    <link rel="stylesheet" href="<?= asset_url('css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= asset_url('css/dashboard.css') ?>">
    <link rel="stylesheet" href="<?= asset_url('css/components.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="icon" href="<?= asset_url('images/favicon.ico') ?>" type="image/x-icon">
    <?php if (isset($extraStyles) && is_array($extraStyles)): ?>
        <?php foreach ($extraStyles as $style): ?>
            <link rel="stylesheet" href="<?= asset_url($style) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
    <!-- Custom page styles -->
    <?php if (isset($pageStyles)): ?>
        <style>
            <?= $pageStyles ?>
        </style>
    <?php endif; ?>
</head>
<body>
<!-- Loader -->
<div class="page-loader">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>

<!-- Main container -->
<div class="dashboard-layout">
    <!-- Sidebar navigation -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <a href="<?= url('dashboard') ?>" class="logo">
                <img src="<?= asset_url('images/logo.svg') ?>" alt="Social Monitor" class="logo-large">
                <img src="<?= asset_url('images/logo-icon.svg') ?>" alt="SM" class="logo-small">
            </a>
            <button class="btn btn-icon sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>

        <div class="sidebar-content">
            <nav class="sidebar-nav">
                <ul>
                    <li class="nav-item <?= ($active_menu ?? '') === 'dashboard' ? 'active' : '' ?>">
                        <a href="<?= url('dashboard') ?>" class="nav-link">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'analytics' ? 'active' : '' ?>">
                        <a href="<?= url('analytics') ?>" class="nav-link">
                            <i class="fas fa-chart-bar"></i>
                            <span>Analytics</span>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'content' ? 'active' : '' ?>">
                        <a href="<?= url('content') ?>" class="nav-link">
                            <i class="fas fa-pen-square"></i>
                            <span>Content</span>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'schedule' ? 'active' : '' ?>">
                        <a href="<?= url('schedule') ?>" class="nav-link">
                            <i class="fas fa-calendar-alt"></i>
                            <span>Schedule</span>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'accounts' ? 'active' : '' ?>">
                        <a href="<?= url('accounts') ?>" class="nav-link">
                            <i class="fas fa-users"></i>
                            <span>Accounts</span>
                        </a>
                    </li>

                    <li class="nav-section">
                        <span class="nav-section-title">Tools</span>
                    </li>

                    <li class="nav-item <?= ($active_menu ?? '') === 'contentgen' ? 'active' : '' ?>">
                        <a href="<?= url('contentgen') ?>" class="nav-link">
                            <i class="fas fa-robot"></i>
                            <span>AI Content</span>
                            <?php if ($user->hasFeature('ai_content')): ?>
                                <span class="badge badge-primary">PRO</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">UPGRADE</span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'campaigns' ? 'active' : '' ?>">
                        <a href="<?= url('marketing/campaigns') ?>" class="nav-link">
                            <i class="fas fa-bullhorn"></i>
                            <span>Campaigns</span>
                            <?php if ($user->hasFeature('campaigns')): ?>
                                <span class="badge badge-primary">PRO</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">UPGRADE</span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'seo' ? 'active' : '' ?>">
                        <a href="<?= url('seo') ?>" class="nav-link">
                            <i class="fas fa-search"></i>
                            <span>SEO Tools</span>
                            <?php if ($user->hasFeature('seo_tools')): ?>
                                <span class="badge badge-primary">PRO</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">UPGRADE</span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'websites' ? 'active' : '' ?>">
                        <a href="<?= url('web/websites') ?>" class="nav-link">
                            <i class="fas fa-laptop-code"></i>
                            <span>Websites</span>
                            <?php if ($user->hasFeature('website_builder')): ?>
                                <span class="badge badge-primary">PRO</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">UPGRADE</span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'crm' ? 'active' : '' ?>">
                        <a href="<?= url('crm') ?>" class="nav-link">
                            <i class="fas fa-address-book"></i>
                            <span>CRM</span>
                            <?php if ($user->hasFeature('crm')): ?>
                                <span class="badge badge-primary">PRO</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">UPGRADE</span>
                            <?php endif; ?>
                        </a>
                    </li>

                    <li class="nav-section">
                        <span class="nav-section-title">System</span>
                    </li>

                    <li class="nav-item <?= ($active_menu ?? '') === 'reports' ? 'active' : '' ?>">
                        <a href="<?= url('reports') ?>" class="nav-link">
                            <i class="fas fa-file-alt"></i>
                            <span>Reports</span>
                        </a>
                    </li>
                    <li class="nav-item <?= ($active_menu ?? '') === 'settings' ? 'active' : '' ?>">
                        <a href="<?= url('settings') ?>" class="nav-link">
                            <i class="fas fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                    <?php if ($user->isAdmin()): ?>
                        <li class="nav-item <?= ($active_menu ?? '') === 'admin' ? 'active' : '' ?>">
                            <a href="<?= url('admin') ?>" class="nav-link">
                                <i class="fas fa-shield-alt"></i>
                                <span>Admin Panel</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="<?= url('help') ?>" class="nav-link">
                            <i class="fas fa-question-circle"></i>
                            <span>Help & Support</span>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <?php if ($user->subscription && $user->subscription->plan_id != 'free'): ?>
                    <div class="plan-info">
                        <span class="plan-name"><?= $user->subscription->plan_name ?> Plan</span>
                        <div class="plan-usage">
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: <?= $user->usage_percent ?>%"></div>
                            </div>
                            <span class="usage-text"><?= $user->usage_percent ?>% used</span>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= url('plans') ?>" class="upgrade-btn">
                        <i class="fas fa-arrow-circle-up"></i> Upgrade to Pro
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </aside>

    <div class="main-content">
        <!-- Top navigation bar -->
        <header class="top-navbar">
            <div class="container-fluid">
                <div class="navbar-left">
                    <button class="btn btn-icon mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="page-title"><?= $title ?? 'Dashboard' ?></h1>
                </div>
                <div class="navbar-right">
                    <div class="nav-item">
                        <button class="btn btn-icon" id="darkModeToggle">
                            <i class="fas fa-moon"></i>
                        </button>
                    </div>
                    <div class="nav-item">
                        <button class="btn btn-icon position-relative" id="notificationsDropdown" data-toggle="dropdown">
                            <i class="fas fa-bell"></i>
                            <?php if ($unreadNotificationsCount > 0): ?>
                                <span class="badge badge-danger notification-badge"><?= $unreadNotificationsCount ?></span>
                            <?php endif; ?>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right notifications-dropdown">
                            <div class="notifications-header">
                                <h6 class="dropdown-header">Notifications</h6>
                                <?php if ($unreadNotificationsCount > 0): ?>
                                    <a href="<?= url('notifications/mark-all-read') ?>" class="mark-all-read">Mark all as read</a>
                                <?php endif; ?>
                            </div>
                            <div class="notifications-body">
                                <?php if (empty($notifications)): ?>
                                    <div class="empty-notifications">
                                        <i class="fas fa-bell-slash"></i>
                                        <p>No notifications</p>
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($notifications as $notification): ?>
                                        <a href="<?= url('notifications/view/' . $notification->id) ?>" class="dropdown-item notification-item <?= $notification->is_read ? '' : 'unread' ?>">
                                            <div class="notification-icon">
                                                <i class="fas fa-<?= $notification->icon ?>"></i>
                                            </div>
                                            <div class="notification-content">
                                                <p class="notification-text"><?= $notification->message ?></p>
                                                <span class="notification-time"><?= $this->helper->formatSocialTimestamp($notification->created_at) ?></span>
                                            </div>
                                        </a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="notifications-footer">
                                <a href="<?= url('notifications') ?>" class="dropdown-item text-center">View all notifications</a>
                            </div>
                        </div>
                    </div>
                    <div class="nav-item">
                        <button class="btn btn-primary create-button" id="createDropdown" data-toggle="dropdown">
                            <i class="fas fa-plus"></i>
                            <span class="d-none d-md-inline-block">Create</span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="<?= url('content/create') ?>">
                                <i class="fas fa-pen-square"></i> Create Post
                            </a>
                            <a class="dropdown-item" href="<?= url('schedule/create') ?>">
                                <i class="fas fa-calendar-plus"></i> Schedule Post
                            </a>
                            <a class="dropdown-item" href="<?= url('contentgen/create') ?>">
                                <i class="fas fa-robot"></i> Generate AI Content
                            </a>
                            <?php if ($user->hasFeature('campaigns')): ?>
                                <a class="dropdown-item" href="<?= url('marketing/campaigns/create') ?>">
                                    <i class="fas fa-bullhorn"></i> Create Campaign
                                </a>
                            <?php endif; ?>
                            <?php if ($user->hasFeature('website_builder')): ?>
                                <a class="dropdown-item" href="<?= url('web/websites/create') ?>">
                                    <i class="fas fa-laptop-code"></i> Create Website
                                </a>
                            <?php endif; ?>
                            <?php if ($user->hasFeature('crm')): ?>
                                <a class="dropdown-item" href="<?= url('crm/customers/create') ?>">
                                    <i class="fas fa-user-plus"></i> Add Customer
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="nav-item">
                        <div class="user-dropdown">
                            <button class="user-dropdown-toggle" id="userDropdown" data-toggle="dropdown">
                                <?php if ($user->profile_image): ?>
                                    <img src="<?= $user->profile_image ?>" alt="<?= $user->first_name ?>" class="user-avatar">
                                <?php else: ?>
                                    <div class="user-avatar-placeholder">
                                        <?= strtoupper(substr($user->first_name, 0, 1)) ?>
                                    </div>
                                <?php endif; ?>
                                <span class="user-name d-none d-md-inline-block"><?= $user->first_name ?></span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <div class="dropdown-header">
                                    <div class="user-info">
                                        <h6><?= $user->first_name ?> <?= $user->last_name ?></h6>
                                        <p><?= $user->email ?></p>
                                    </div>
                                </div>
                                <a class="dropdown-item" href="<?= url('profile') ?>">
                                    <i class="fas fa-user"></i> My Profile
                                </a>
                                <a class="dropdown-item" href="<?= url('settings') ?>">
                                    <i class="fas fa-cog"></i> Account Settings
                                </a>
                                <?php if ($user->subscription && $user->subscription->plan_id != 'free'): ?>
                                    <a class="dropdown-item" href="<?= url('billing') ?>">
                                        <i class="fas fa-credit-card"></i> Billing
                                    </a>
                                <?php else: ?>
                                    <a class="dropdown-item" href="<?= url('plans') ?>">
                                        <i class="fas fa-arrow-circle-up"></i> Upgrade to Pro
                                    </a>
                                <?php endif; ?>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?= url('help') ?>">
                                    <i class="fas fa-question-circle"></i> Help & Support
                                </a>
                                <a class="dropdown-item" href="<?= url('logout') ?>">
                                    <i class="fas fa-sign-out-alt"></i> Log Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main content -->
        <main class="content">