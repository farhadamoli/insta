<?php $this->renderPartial('dashboard/partials/header', ['title' => 'Dashboard', 'active_menu' => 'dashboard']) ?>

<div class="dashboard-container">
    <!-- Welcome Banner -->
    <?php if ($showWelcomeBanner): ?>
        <div class="welcome-banner">
            <div class="welcome-content">
                <h2>Welcome to Social Monitor, <?= $user->first_name ?>!</h2>
                <p>Let's get you started with monitoring your social media accounts.</p>
                <div class="welcome-actions">
                    <a href="<?= url('accounts/connect') ?>" class="btn btn-primary">Connect Accounts</a>
                    <a href="<?= url('tour') ?>" class="btn btn-outline-primary">Take a Tour</a>
                    <button type="button" class="btn-close" id="close-welcome-banner" aria-label="Close welcome banner"></button>
                </div>
            </div>
            <div class="welcome-image">
                <img src="<?= asset_url('images/dashboard/welcome-illustration.svg') ?>" alt="Welcome illustration">
            </div>
        </div>
    <?php endif; ?>

    <!-- Dashboard Stats -->
    <div class="dashboard-stats">
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Followers</h3>
                        <div class="stat-value"><?= number_format($stats['total_followers']) ?></div>
                        <div class="stat-change <?= $stats['followers_change'] >= 0 ? 'positive' : 'negative' ?>">
                            <i class="fas fa-<?= $stats['followers_change'] >= 0 ? 'arrow-up' : 'arrow-down' ?>"></i>
                            <?= abs($stats['followers_change']) ?>% in 30 days
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Engagement</h3>
                        <div class="stat-value"><?= number_format($stats['total_engagement']) ?></div>
                        <div class="stat-change <?= $stats['engagement_change'] >= 0 ? 'positive' : 'negative' ?>">
                            <i class="fas fa-<?= $stats['engagement_change'] >= 0 ? 'arrow-up' : 'arrow-down' ?>"></i>
                            <?= abs($stats['engagement_change']) ?>% in 30 days
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Impressions</h3>
                        <div class="stat-value"><?= number_format($stats['total_impressions']) ?></div>
                        <div class="stat-change <?= $stats['impressions_change'] >= 0 ? 'positive' : 'negative' ?>">
                            <i class="fas fa-<?= $stats['impressions_change'] >= 0 ? 'arrow-up' : 'arrow-down' ?>"></i>
                            <?= abs($stats['impressions_change']) ?>% in 30 days
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Growth Rate</h3>
                        <div class="stat-value"><?= $stats['growth_rate'] ?>%</div>
                        <div class="stat-change <?= $stats['growth_rate_change'] >= 0 ? 'positive' : 'negative' ?>">
                            <i class="fas fa-<?= $stats['growth_rate_change'] >= 0 ? 'arrow-up' : 'arrow-down' ?>"></i>
                            <?= abs($stats['growth_rate_change']) ?>% in 30 days
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Social Accounts Summary -->
        <div class="col-lg-6">
            <div class="dashboard-card">
                <div class="card-header">
                    <h2>Social Accounts</h2>
                    <a href="<?= url('accounts') ?>" class="btn btn-sm btn-outline-primary">Manage Accounts</a>
                </div>
                <div class="card-body">
                    <?php if (empty($accounts)): ?>
                        <div class="empty-state">
                            <img src="<?= asset_url('images/dashboard/empty-accounts.svg') ?>" alt="No accounts connected">
                            <h3>No social accounts connected</h3>
                            <p>Connect your social media accounts to start monitoring your performance.</p>
                            <a href="<?= url('accounts/connect') ?>" class="btn btn-primary">Connect Accounts</a>
                        </div>
                    <?php else: ?>
                        <div class="accounts-list">
                            <?php foreach ($accounts as $account): ?>
                                <div class="account-item">
                                    <div class="account-platform">
                                        <img src="<?= asset_url('images/platforms/' . $account->platform . '.svg') ?>" alt="<?= ucfirst($account->platform) ?>">
                                    </div>
                                    <div class="account-info">
                                        <h4><?= $account->username ?></h4>
                                        <p><?= ucfirst($account->platform) ?> <?= $account->account_type ?></p>
                                    </div>
                                    <div class="account-stats">
                                        <div class="mini-stat">
                                            <span class="mini-stat-value"><?= number_format($account->followers_count) ?></span>
                                            <span class="mini-stat-label">Followers</span>
                                        </div>
                                        <div class="mini-stat">
                                            <span class="mini-stat-value"><?= $account->engagement_rate ?>%</span>
                                            <span class="mini-stat-label">Engagement</span>
                                        </div>
                                    </div>
                                    <div class="account-action">
                                        <a href="<?= url('analytics/' . $account->platform . '/' . $account->id) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Posts Summary -->
        <div class="col-lg-6">
            <div class="dashboard-card">
                <div class="card-header">
                    <h2>Recent Posts</h2>
                    <a href="<?= url('content') ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (empty($recentPosts)): ?>
                        <div class="empty-state">
                            <img src="<?= asset_url('images/dashboard/empty-posts.svg') ?>" alt="No recent posts">
                            <h3>No posts found</h3>
                            <p>Start creating and scheduling content for your social media accounts.</p>
                            <a href="<?= url('content/create') ?>" class="btn btn-primary">Create Post</a>
                        </div>
                    <?php else: ?>
                        <div class="posts-list">
                            <?php foreach ($recentPosts as $post): ?>
                                <div class="post-item">
                                    <div class="post-preview">
                                        <?php if ($post->media_type == 'image'): ?>
                                            <img src="<?= $post->media_url ?>" alt="Post image">
                                        <?php elseif ($post->media_type == 'video'): ?>
                                            <div class="video-preview">
                                                <i class="fas fa-play-circle"></i>
                                                <img src="<?= $post->thumbnail_url ?>" alt="Video thumbnail">
                                            </div>
                                        <?php else: ?>
                                            <div class="text-preview">
                                                <i class="fas fa-align-left"></i>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="post-info">
                                        <div class="post-platform">
                                            <img src="<?= asset_url('images/platforms/' . $post->platform . '.svg') ?>" alt="<?= ucfirst($post->platform) ?>">
                                            <span><?= ucfirst($post->platform) ?></span>
                                        </div>
                                        <p class="post-content"><?= $this->helper->truncate($post->content, 80) ?></p>
                                        <div class="post-meta">
                                            <span><i class="fas fa-heart"></i> <?= number_format($post->likes_count) ?></span>
                                            <span><i class="fas fa-comment"></i> <?= number_format($post->comments_count) ?></span>
                                            <span><i class="fas fa-calendar"></i> <?= $this->helper->formatDate($post->created_at, 'M d, Y') ?></span>
                                        </div>
                                    </div>
                                    <div class="post-action">
                                        <a href="<?= url('content/view/' . $post->id) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Engagement Chart -->
        <div class="col-lg-8">
            <div class="dashboard-card">
                <div class="card-header">
                    <h2>Engagement Overview</h2>
                    <div class="chart-filters">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-outline-secondary active" data-period="30">30 Days</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-period="90">90 Days</button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <canvas id="engagementChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- Top Performing Content -->
        <div class="col-lg-4">
            <div class="dashboard-card">
                <div class="card-header">
                    <h2>Top Performing Content</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($topPosts)): ?>
                        <div class="empty-state">
                            <img src="<?= asset_url('images/dashboard/empty-analytics.svg') ?>" alt="No data available">
                            <h3>No data available</h3>
                            <p>Create more content to see performance analytics.</p>
                        </div>
                    <?php else: ?>
                        <div class="top-posts-list">
                            <?php foreach ($topPosts as $index => $post): ?>
                                <div class="top-post-item">
                                    <div class="top-post-rank">#<?= $index + 1 ?></div>
                                    <div class="top-post-preview">
                                        <?php if ($post->media_type == 'image'): ?>
                                            <img src="<?= $post->media_url ?>" alt="Post image">
                                        <?php elseif ($post->media_type == 'video'): ?>
                                            <div class="video-preview">
                                                <i class="fas fa-play-circle"></i>
                                                <img src="<?= $post->thumbnail_url ?>" alt="Video thumbnail">
                                            </div>
                                        <?php else: ?>
                                            <div class="text-preview">
                                                <i class="fas fa-align-left"></i>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="top-post-info">
                                        <div class="top-post-platform">
                                            <img src="<?= asset_url('images/platforms/' . $post->platform . '.svg') ?>" alt="<?= ucfirst($post->platform) ?>">
                                        </div>
                                        <p class="top-post-content"><?= $this->helper->truncate($post->content, 60) ?></p>
                                        <div class="top-post-stats">
                                            <span><i class="fas fa-heart"></i> <?= number_format($post->likes_count) ?></span>
                                            <span><i class="fas fa-comment"></i> <?= number_format($post->comments_count) ?></span>
                                            <span><i class="fas fa-chart-line"></i> <?= $post->engagement_rate ?>% ER</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Upcoming Schedule -->
        <div class="col-lg-6">
            <div class="dashboard-card">
                <div class="card-header">
                    <h2>Upcoming Schedule</h2>
                    <a href="<?= url('schedule') ?>" class="btn btn-sm btn-outline-primary">View Calendar</a>
                </div>
                <div class="card-body">
                    <?php if (empty($scheduledPosts)): ?>
                        <div class="empty-state">
                            <img src="<?= asset_url('images/dashboard/empty-schedule.svg') ?>" alt="No scheduled posts">
                            <h3>No scheduled posts</h3>
                            <p>Plan your content ahead by scheduling posts for your accounts.</p>
                            <a href="<?= url('content/schedule') ?>" class="btn btn-primary">Schedule Post</a>
                        </div>
                    <?php else: ?>
                        <div class="schedule-list">
                            <?php foreach ($scheduledPosts as $post): ?>
                                <div class="schedule-item">
                                    <div class="schedule-time">
                                        <div class="schedule-date"><?= $this->helper->formatDate($post->scheduled_at, 'M d') ?></div>
                                        <div class="schedule-hour"><?= $this->helper->formatDate($post->scheduled_at, 'h:i A') ?></div>
                                    </div>
                                    <div class="schedule-platform">
                                        <img src="<?= asset_url('images/platforms/' . $post->platform . '.svg') ?>" alt="<?= ucfirst($post->platform) ?>">
                                    </div>
                                    <div class="schedule-info">
                                        <p class="schedule-content"><?= $this->helper->truncate($post->content, 80) ?></p>
                                        <div class="schedule-meta">
                                            <?php if ($post->media_type): ?>
                                                <span><i class="fas fa-<?= $post->media_type == 'image' ? 'image' : 'video' ?>"></i> <?= ucfirst($post->media_type) ?></span>
                                            <?php endif; ?>
                                            <span><i class="fas fa-user"></i> <?= $post->account_username ?></span>
                                        </div>
                                    </div>
                                    <div class="schedule-action">
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-icon" type="button" data-toggle="dropdown">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="<?= url('content/edit/' . $post->id) ?>">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                                <a class="dropdown-item" href="<?= url('content/reschedule/' . $post->id) ?>">
                                                    <i class="fas fa-calendar-alt"></i> Reschedule
                                                </a>
                                                <a class="dropdown-item text-danger delete-post" href="#" data-id="<?= $post->id ?>">
                                                    <i class="fas fa-trash-alt"></i> Delete
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- AI Content Suggestions -->
        <div class="col-lg-6">
            <div class="dashboard-card">
                <div class="card-header">
                    <h2>Content Suggestions</h2>
                    <a href="<?= url('content/suggestions') ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (empty($contentSuggestions)): ?>
                        <div class="empty-state">
                            <img src="<?= asset_url('images/dashboard/empty-suggestions.svg') ?>" alt="No content suggestions">
                            <h3>No suggestions available</h3>
                            <p>Connect your accounts to receive AI-powered content suggestions.</p>
                        </div>
                    <?php else: ?>
                        <div class="suggestions-list">
                            <?php foreach ($contentSuggestions as $suggestion): ?>
                                <div class="suggestion-item">
                                    <div class="suggestion-platform">
                                        <img src="<?= asset_url('images/platforms/' . $suggestion->platform . '.svg') ?>" alt="<?= ucfirst($suggestion->platform) ?>">
                                    </div>
                                    <div class="suggestion-content">
                                        <div class="suggestion-type">
                                            <span class="badge badge-primary"><?= ucfirst($suggestion->type) ?></span>
                                        </div>
                                        <p><?= $suggestion->content ?></p>
                                        <?php if (!empty($suggestion->hashtags)): ?>
                                            <div class="suggestion-hashtags">
                                                <?php foreach (explode(',', $suggestion->hashtags) as $hashtag): ?>
                                                    <span class="hashtag">#<?= trim($hashtag) ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="suggestion-actions">
                                        <button class="btn btn-sm btn-outline-primary use-suggestion" data-id="<?= $suggestion->id ?>">
                                            <i class="fas fa-plus"></i> Use
                                        </button>
                                        <button class="btn btn-sm btn-icon dismiss-suggestion" data-id="<?= $suggestion->id ?>">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Post Confirmation Modal -->
<div class="modal fade" id="deletePostModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Scheduled Post</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this scheduled post? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeletePost">Delete</button>
            </div>
        </div>
    </div>
</div>

<!-- Success Notification -->
<div class="toast-container">
    <div class="toast success-toast" role="alert" aria-live="assertive" aria-atomic="true" data-delay="5000">
        <div class="toast-header">
            <i class="fas fa-check-circle text-success mr-2"></i>
            <strong class="mr-auto">Success</strong>
            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="toast-body">
            Operation completed successfully.
        </div>
    </div>
</div>

<?php $this->renderPartial('dashboard/partials/footer', ['scripts' => [
    'vendor/chart.js/chart.min.js',
    'js/dashboard/engagement-chart.js',
    'js/dashboard/dashboard.js'
]]) ?>

<script>
    // Chart data from PHP to JS
    const engagementData = <?= json_encode($engagementData) ?>;
</script>