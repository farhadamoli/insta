<?php
/**
 * core/App.php
 *
 * کلاس اصلی برنامه SOCIALKOCH.CO
 * این کلاس هسته اصلی برنامه است و مسئول راه‌اندازی، مدیریت و اجرای جریان اصلی برنامه است
 */

class App {
    /**
     * @var Database شیء پایگاه داده
     */
    public $db;

    /**
     * @var Router شیء مسیریاب
     */
    public $router;

    /**
     * @var Auth شیء احراز هویت
     */
    public $auth;

    /**
     * @var array تنظیمات برنامه
     */
    private $settings = [];

    /**
     * @var array لیست خطاهای برنامه
     */
    private $errors = [];

    /**
     * @var array نمونه‌های کلاس‌های بارگذاری شده
     */
    private $instances = [];

    /**
     * @var array متغیرهای سیستمی
     */
    private $globals = [];

    /**
     * @var bool آیا برنامه در حالت تعمیر و نگهداری است؟
     */
    private $maintenanceMode = false;

    /**
     * @var float زمان شروع اجرای برنامه
     */
    private $startTime;

    /**
     * ایجاد یک نمونه از کلاس App
     */
    public function __construct() {
        // ذخیره زمان شروع برنامه برای محاسبه زمان اجرا
        $this->startTime = microtime(true);

        // تنظیم ناحیه زمانی
        date_default_timezone_set(DEFAULT_TIMEZONE);

        // بررسی حالت تعمیر و نگهداری
        $this->checkMaintenanceMode();

        // خواندن تنظیمات سیستمی از پایگاه داده
        $this->loadSettings();

        // راه‌اندازی اجزای اصلی برنامه
        $this->initializeComponents();

        // راه‌اندازی متغیرهای سراسری
        $this->initializeGlobals();

        // نصب هندلرهای خطا
        $this->setupErrorHandlers();
    }

    /**
     * بررسی حالت تعمیر و نگهداری
     *
     * @return void
     */
    private function checkMaintenanceMode() {
        $this->maintenanceMode = defined('MAINTENANCE_MODE') && MAINTENANCE_MODE;

        // اگر برنامه در حالت تعمیر و نگهداری است و کاربر مدیر نیست، صفحه تعمیر و نگهداری نمایش داده می‌شود
        if ($this->maintenanceMode && (!isset($_SESSION['user_id']) || !$this->isAdmin($_SESSION['user_id']))) {
            $this->showMaintenancePage();
        }
    }

    /**
     * بررسی اینکه آیا کاربر مدیر است
     *
     * @param int $userId شناسه کاربر
     * @return bool نتیجه بررسی
     */
    private function isAdmin($userId) {
        $db = new Database();
        $user = $db->selectOne('users', 'role_id', 'id = :id', [':id' => $userId]);

        return $user && ($user['role_id'] == ROLE_ADMIN || $user['role_id'] == ROLE_SUPERADMIN);
    }

    /**
     * نمایش صفحه تعمیر و نگهداری
     *
     * @return void
     */
    private function showMaintenancePage() {
        header('HTTP/1.1 503 Service Unavailable');
        header('Retry-After: 3600'); // 1 ساعت بعد دوباره تلاش کن

        $maintenanceFile = VIEWS_PATH . '/errors/maintenance.php';

        if (file_exists($maintenanceFile)) {
            include $maintenanceFile;
        } else {
            echo '<!DOCTYPE html>
            <html lang="fa" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>در حال تعمیر و نگهداری - SOCIALKOCH.CO</title>
                <style>
                    body {
                        font-family: Tahoma, Arial, sans-serif;
                        line-height: 1.6;
                        color: #333;
                        text-align: center;
                        padding: 50px;
                        background: #f5f5f5;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        background: white;
                        padding: 30px;
                        border-radius: 10px;
                        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    }
                    h1 {
                        color: #4f46e5;
                    }
                    p {
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>در حال تعمیر و نگهداری</h1>
                    <p>' . (defined('MAINTENANCE_MESSAGE') ? MAINTENANCE_MESSAGE : 'سیستم در حال بروزرسانی است. لطفاً بعداً مراجعه کنید.') . '</p>
                </div>
            </body>
            </html>';
        }

        exit;
    }

    /**
     * بارگذاری تنظیمات سیستمی از پایگاه داده
     *
     * @return void
     */
    private function loadSettings() {
        // ابتدا تنظیمات پیش‌فرض را از ثابت‌ها بارگذاری می‌کنیم
        $this->loadDefaultSettings();

        try {
            // اتصال به پایگاه داده
            $db = new Database();

            // دریافت تنظیمات از پایگاه داده
            $settings = $db->executeQuery("SELECT category, key_name, value FROM settings");

            if ($settings) {
                foreach ($settings as $setting) {
                    $category = $setting['category'];
                    $key = $setting['key_name'];
                    $value = $setting['value'];

                    // ذخیره تنظیم
                    if (!isset($this->settings[$category])) {
                        $this->settings[$category] = [];
                    }

                    $this->settings[$category][$key] = $value;
                }
            }
        } catch (Exception $e) {
            // ثبت خطا
            $this->errors[] = 'Error loading settings: ' . $e->getMessage();

            // استفاده از تنظیمات پیش‌فرض در صورت خطا
        }
    }

    /**
     * بارگذاری تنظیمات پیش‌فرض از ثابت‌ها
     *
     * @return void
     */
    private function loadDefaultSettings() {
        $this->settings['general'] = [
            'site_name' => defined('APP_NAME') ? APP_NAME : 'SOCIALKOCH.CO',
            'site_url' => defined('APP_URL') ? APP_URL : 'http://localhost',
            'default_language' => defined('APP_LANGUAGE') ? APP_LANGUAGE : 'fa',
            'default_timezone' => defined('DEFAULT_TIMEZONE') ? DEFAULT_TIMEZONE : 'Asia/Tehran'
        ];

        $this->settings['subscription'] = [
            'monthly_price' => defined('SUBSCRIPTION_MONTHLY') ? SUBSCRIPTION_MONTHLY : 100000,
            'quarterly_price' => defined('SUBSCRIPTION_QUARTERLY') ? SUBSCRIPTION_QUARTERLY : 500000,
            'yearly_price' => defined('SUBSCRIPTION_YEARLY') ? SUBSCRIPTION_YEARLY : 2000000
        ];

        $this->settings['payment'] = [
            'default_gateway' => defined('DEFAULT_PAYMENT_GATEWAY') ? DEFAULT_PAYMENT_GATEWAY : 'zarinpal'
        ];

        $this->settings['mail'] = [
            'from_address' => defined('MAIL_FROM_ADDRESS') ? MAIL_FROM_ADDRESS : 'info@socialkoch.co',
            'from_name' => defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'SOCIALKOCH.CO'
        ];
    }

    /**
     * راه‌اندازی اجزای اصلی برنامه
     *
     * @return void
     */
    private function initializeComponents() {
        // راه‌اندازی پایگاه داده
        $this->db = new Database();
        $this->instances['db'] = $this->db;

        // راه‌اندازی مسیریاب
        $this->router = new Router();
        $this->instances['router'] = $this->router;

        // راه‌اندازی سیستم احراز هویت
        $this->auth = new Auth($this->db);
        $this->instances['auth'] = $this->auth;

        // بررسی ورود با توکن یادآوری
        if (!$this->auth->isLoggedIn()) {
            $this->auth->loginFromRememberToken();
        }
    }

    /**
     * راه‌اندازی متغیرهای سراسری
     *
     * @return void
     */
    private function initializeGlobals() {
        $this->globals['settings'] = $this->settings;
        $this->globals['errors'] = $this->errors;
        $this->globals['app_version'] = defined('APP_VERSION') ? APP_VERSION : '1.0.0';
        $this->globals['current_language'] = $this->getCurrentLanguage();
    }

    /**
     * نصب هندلرهای خطا
     *
     * @return void
     */
    private function setupErrorHandlers() {
        // تنظیم هندلر خطا
        set_error_handler([$this, 'errorHandler']);

        // تنظیم هندلر استثناها
        set_exception_handler([$this, 'exceptionHandler']);

        // تنظیم هندلر خطاهای فاتال
        register_shutdown_function([$this, 'fatalErrorHandler']);
    }

    /**
     * هندلر خطا
     *
     * @param int $errno شماره خطا
     * @param string $errstr پیام خطا
     * @param string $errfile فایل خطا
     * @param int $errline خط خطا
     * @return bool همیشه true برای جلوگیری از اجرای هندلر پیش‌فرض PHP
     */
    public function errorHandler($errno, $errstr, $errfile, $errline) {
        // نادیده گرفتن خطاهایی که با @ سرکوب شده‌اند
        if (!(error_reporting() & $errno)) {
            return true;
        }

        // تبدیل شماره خطا به متن
        $errorTypes = [
            E_ERROR => 'خطای فاتال',
            E_WARNING => 'هشدار',
            E_PARSE => 'خطای پارس',
            E_NOTICE => 'نکته',
            E_CORE_ERROR => 'خطای هسته',
            E_CORE_WARNING => 'هشدار هسته',
            E_COMPILE_ERROR => 'خطای کامپایل',
            E_COMPILE_WARNING => 'هشدار کامپایل',
            E_USER_ERROR => 'خطای کاربر',
            E_USER_WARNING => 'هشدار کاربر',
            E_USER_NOTICE => 'نکته کاربر',
            E_STRICT => 'خطای دقیق',
            E_RECOVERABLE_ERROR => 'خطای قابل بازیابی',
            E_DEPRECATED => 'منسوخ',
            E_USER_DEPRECATED => 'منسوخ کاربر'
        ];

        $errorType = isset($errorTypes[$errno]) ? $errorTypes[$errno] : "خطای ناشناخته ({$errno})";

        // ساخت پیام خطا
        $errorMessage = "{$errorType}: {$errstr} در {$errfile}:{$errline}";

        // ثبت خطا در لاگ
        if (defined('LOG_ERRORS') && LOG_ERRORS) {
            error_log($errorMessage);
        }

        // اگر خطا جدی است، آن را به استثنا تبدیل می‌کنیم
        if ($errno == E_USER_ERROR) {
            throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
        }

        // اگر نمایش خطا فعال است، پیام را نمایش می‌دهیم
        if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
            $this->displayError($errorMessage);
        }

        // ثبت خطا در لیست خطاهای برنامه
        $this->errors[] = $errorMessage;

        return true;
    }

    /**
     * هندلر استثناها
     *
     * @param Throwable $exception استثنا
     * @return void
     */
    public function exceptionHandler($exception) {
        // ساخت پیام خطا
        $errorMessage = "استثنا: " . $exception->getMessage() . " در " . $exception->getFile() . ":" . $exception->getLine();

        // ثبت خطا در لاگ
        if (defined('LOG_ERRORS') && LOG_ERRORS) {
            error_log($errorMessage);
            error_log($exception->getTraceAsString());
        }

        // اگر نمایش خطا فعال است، پیام را نمایش می‌دهیم
        if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
            $this->displayException($exception);
        } else {
            // نمایش صفحه خطای 500
            $this->showErrorPage(500);
        }

        // ثبت خطا در لیست خطاهای برنامه
        $this->errors[] = $errorMessage;

        exit;
    }

    /**
     * هندلر خطاهای فاتال
     *
     * @return void
     */
    public function fatalErrorHandler() {
        $error = error_get_last();

        if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
            // ساخت پیام خطا
            $errorMessage = "خطای فاتال: " . $error['message'] . " در " . $error['file'] . ":" . $error['line'];

            // ثبت خطا در لاگ
            if (defined('LOG_ERRORS') && LOG_ERRORS) {
                error_log($errorMessage);
            }

            // اگر نمایش خطا فعال است، پیام را نمایش می‌دهیم
            if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
                $this->displayError($errorMessage);
            } else {
                // نمایش صفحه خطای 500
                $this->showErrorPage(500);
            }

            // ثبت خطا در لیست خطاهای برنامه
            $this->errors[] = $errorMessage;
        }
    }

    /**
     * نمایش پیام خطا
     *
     * @param string $errorMessage پیام خطا
     * @return void
     */
    private function displayError($errorMessage) {
        echo '<div style="background-color: #f8d7da; color: #721c24; padding: 10px; margin: 10px 0; border: 1px solid #f5c6cb; border-radius: 4px;">';
        echo '<strong>خطا:</strong> ' . htmlspecialchars($errorMessage);
        echo '</div>';
    }

    /**
     * نمایش اطلاعات استثنا
     *
     * @param Throwable $exception استثنا
     * @return void
     */
    private function displayException($exception) {
        echo '<div style="background-color: #f8d7da; color: #721c24; padding: 15px; margin: 15px 0; border: 1px solid #f5c6cb; border-radius: 4px;">';
        echo '<h2 style="margin-top: 0;">استثنا: ' . htmlspecialchars(get_class($exception)) . '</h2>';
        echo '<p><strong>پیام:</strong> ' . htmlspecialchars($exception->getMessage()) . '</p>';
        echo '<p><strong>فایل:</strong> ' . htmlspecialchars($exception->getFile()) . '</p>';
        echo '<p><strong>خط:</strong> ' . $exception->getLine() . '</p>';

        echo '<h3>ردیابی:</h3>';
        echo '<pre style="background-color: #f5f5f5; padding: 10px; overflow: auto; max-height: 300px;">';
        echo htmlspecialchars($exception->getTraceAsString());
        echo '</pre>';
        echo '</div>';
    }

    /**
     * نمایش صفحه خطا
     *
     * @param int $code کد خطا
     * @return void
     */
    private function showErrorPage($code) {
        $errorFile = VIEWS_PATH . '/errors/' . $code . 'Payment.php';

        header("HTTP/1.1 {$code}");

        if (file_exists($errorFile)) {
            include $errorFile;
        } else {
            echo '<!DOCTYPE html>
            <html lang="fa" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>خطای ' . $code . ' - SOCIALKOCH.CO</title>
                <style>
                    body {
                        font-family: Tahoma, Arial, sans-serif;
                        line-height: 1.6;
                        color: #333;
                        text-align: center;
                        padding: 50px;
                        background: #f5f5f5;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        background: white;
                        padding: 30px;
                        border-radius: 10px;
                        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    }
                    h1 {
                        color: #4f46e5;
                    }
                    p {
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>خطای ' . $code . '</h1>';

            if ($code == 404) {
                echo '<p>صفحه مورد نظر پیدا نشد.</p>';
            } else if ($code == 403) {
                echo '<p>شما اجازه دسترسی به این صفحه را ندارید.</p>';
            } else {
                echo '<p>خطایی در سرور رخ داده است. لطفاً بعداً دوباره تلاش کنید.</p>';
            }

            echo '      <p><a href="' . APP_URL . '" style="color: #4f46e5; text-decoration: none;">بازگشت به صفحه اصلی</a></p>
                </div>
            </body>
            </html>';
        }

        exit;
    }

    /**
     * اجرای برنامه
     *
     * @return void
     */
    public function run() {
        try {
            // حل کردن مسیر درخواست و اجرای عملگر مربوطه
            $response = $this->router->resolve();

            // نمایش پاسخ (در صورتی که رشته یا شیء قابل تبدیل به رشته باشد)
            if (is_string($response) || (is_object($response) && method_exists($response, '__toString'))) {
                echo $response;
            }
        } catch (Exception $e) {
            // هندلر استثناها اینجا اجرا می‌شود
            $this->exceptionHandler($e);
        }
    }

    /**
     * نمایش یک قالب
     *
     * @param string $view مسیر قالب
     * @param array $data داده‌های قالب
     * @return string محتوای قالب
     */
    public static function view($view, $data = []) {
        // استخراج داده‌ها به متغیرهای محلی
        extract($data);

        // مسیر کامل فایل قالب
        $viewPath = VIEWS_PATH . '/' . str_replace('.', '/', $view) . 'Payment.php';

        // بررسی وجود فایل قالب
        if (!file_exists($viewPath)) {
            throw new Exception("View not found: {$view}");
        }

        // شروع بافر خروجی
        ob_start();

        // شامل کردن فایل قالب
        include $viewPath;

        // دریافت محتوای بافر و پایان آن
        return ob_get_clean();
    }

    /**
     * تغییر مسیر به URL مشخص شده
     *
     * @param string $url مسیر مقصد
     * @param int $statusCode کد وضعیت HTTP
     * @return void
     */
    public static function redirect($url, $statusCode = 302) {
        // اگر URL با http شروع نشود، URL را نسبی در نظر می‌گیریم و URL پایه را اضافه می‌کنیم
        if (!preg_match('/^https?:\/\//', $url)) {
            $url = APP_URL . '/' . ltrim($url, '/');
        }

        header('Location: ' . $url, true, $statusCode);
        exit;
    }

    /**
     * دریافت URL کامل برای یک مسیر
     *
     * @param string $path مسیر مورد نظر
     * @param array $params پارامترهای اختیاری برای query string
     * @return string URL کامل
     */
    public static function url($path, $params = []) {
        $url = APP_URL . '/' . ltrim($path, '/');

        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        return $url;
    }

    /**
     * دریافت دسترسی به یک نمونه کلاس موجود
     *
     * @param string $name نام کلاس
     * @return mixed شیء مورد نظر یا null
     */
    public function getInstance($name) {
        return isset($this->instances[$name]) ? $this->instances[$name] : null;
    }

    /**
     * تنظیم یک نمونه کلاس
     *
     * @param string $name نام کلاس
     * @param mixed $instance شیء مورد نظر
     * @return void
     */
    public function setInstance($name, $instance) {
        $this->instances[$name] = $instance;
    }

    /**
     * دریافت یک تنظیم
     *
     * @param string $category دسته تنظیم
     * @param string $key کلید تنظیم
     * @param mixed $default مقدار پیش‌فرض در صورت عدم وجود
     * @return mixed مقدار تنظیم
     */
    public function getSetting($category, $key, $default = null) {
        if (isset($this->settings[$category]) && isset($this->settings[$category][$key])) {
            return $this->settings[$category][$key];
        }

        return $default;
    }

    /**
     * دریافت زبان فعلی
     *
     * @return string کد زبان
     */
    public function getCurrentLanguage() {
        // اگر زبان در جلسه ذخیره شده باشد، آن را برمی‌گردانیم
        if (isset($_SESSION['language'])) {
            return $_SESSION['language'];
        }

        // در غیر این صورت، زبان پیش‌فرض را برمی‌گردانیم
        return $this->getSetting('general', 'default_language', 'fa');
    }

    /**
     * تنظیم زبان فعلی
     *
     * @param string $language کد زبان
     * @return bool نتیجه عملیات
     */
    public function setCurrentLanguage($language) {
        // بررسی وجود زبان در لیست زبان‌های موجود
        if (defined('AVAILABLE_LANGUAGES') && is_array(AVAILABLE_LANGUAGES) && in_array($language, AVAILABLE_LANGUAGES)) {
            $_SESSION['language'] = $language;
            return true;
        }

        return false;
    }

    /**
     * دریافت ترجمه یک متن
     *
     * @param string $key کلید ترجمه
     * @param array $params پارامترهای ترجمه
     * @param string $language زبان مورد نظر (اختیاری)
     * @return string متن ترجمه شده
     */
    public function translate($key, $params = [], $language = null) {
        // اگر زبان مشخص نشده، از زبان فعلی استفاده می‌کنیم
        if ($language === null) {
            $language = $this->getCurrentLanguage();
        }

        // تقسیم کلید به فایل و کلید
        $parts = explode('.', $key);
        $file = $parts[0];
        $translationKey = $parts[1] ?? '';

        // مسیر فایل ترجمه
        $langFile = LANG_PATH . '/' . $language . '/' . $file . 'Payment.php';

        // بررسی وجود فایل ترجمه
        if (file_exists($langFile)) {
            $translations = include $langFile;

            if (isset($translations[$translationKey])) {
                $text = $translations[$translationKey];

                // جایگزینی پارامترها
                foreach ($params as $param => $value) {
                    $text = str_replace(':' . $param, $value, $text);
                }

                return $text;
            }
        }

        // در صورت عدم وجود ترجمه، کلید را برمی‌گردانیم
        return $translationKey;
    }

    /**
     * دریافت زمان اجرای برنامه
     *
     * @return float زمان اجرا (ثانیه)
     */
    public function getExecutionTime() {
        return microtime(true) - $this->startTime;
    }

    /**
     * دریافت لیست خطاهای برنامه
     *
     * @return array لیست خطاها
     */
    public function getErrors() {
        return $this->errors;
    }

    /**
     * دریافت آخرین خطای برنامه
     *
     * @return string|null آخرین خطا
     */
    public function getLastError() {
        return empty($this->errors) ? null : end($this->errors);
    }

    /**
     * دریافت اطلاعات مصرف منابع
     *
     * @return array اطلاعات مصرف منابع
     */
    public function getResourceUsage() {
        return [
            'memory' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true),
            'execution_time' => $this->getExecutionTime(),
            'query_count' => $this->db->getQueryCount(),
            'average_query_time' => $this->db->getAverageQueryTime()
        ];
    }
}