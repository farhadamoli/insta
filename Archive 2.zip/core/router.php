<?php
/**
 * core/Router.php
 *
 * کلاس مسیریاب برای سیستم SOCIALKOCH.CO
 * این کلاس مسئول مدیریت مسیرهای سیستم و هدایت درخواست‌ها به کنترلرهای مناسب است
 */

class Router {
    /**
     * @var array مسیرهای GET ثبت شده
     */
    private $routes = [
        'GET' => [],
        'POST' => [],
        'PUT' => [],
        'DELETE' => [],
        'PATCH' => []
    ];

    /**
     * @var array پارامترهای مسیر جاری
     */
    private $params = [];

    /**
     * @var string کنترلر پیش‌فرض
     */
    private $defaultController = 'HomeController';

    /**
     * @var string متد پیش‌فرض
     */
    private $defaultMethod = 'index';

    /**
     * @var array نگاشت‌های ویژه برای اعمال به مسیرها
     */
    private $middlewares = [];

    /**
     * @var array نگاشت‌های فعال در درخواست فعلی
     */
    private $currentMiddlewares = [];

    /**
     * ثبت مسیر GET
     *
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر (نام کنترلر@متد یا تابع)
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function get($route, $handler) {
        return $this->addRoute('GET', $route, $handler);
    }

    /**
     * ثبت مسیر POST
     *
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر (نام کنترلر@متد یا تابع)
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function post($route, $handler) {
        return $this->addRoute('POST', $route, $handler);
    }

    /**
     * ثبت مسیر PUT
     *
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر (نام کنترلر@متد یا تابع)
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function put($route, $handler) {
        return $this->addRoute('PUT', $route, $handler);
    }

    /**
     * ثبت مسیر DELETE
     *
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر (نام کنترلر@متد یا تابع)
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function delete($route, $handler) {
        return $this->addRoute('DELETE', $route, $handler);
    }

    /**
     * ثبت مسیر PATCH
     *
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر (نام کنترلر@متد یا تابع)
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function patch($route, $handler) {
        return $this->addRoute('PATCH', $route, $handler);
    }

    /**
     * ثبت مسیر برای چندین متد HTTP
     *
     * @param array $methods آرایه‌ای از متدهای HTTP
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function map(array $methods, $route, $handler) {
        foreach ($methods as $method) {
            $this->addRoute(strtoupper($method), $route, $handler);
        }
        return $this;
    }

    /**
     * ثبت مسیر برای تمام متدهای HTTP
     *
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function any($route, $handler) {
        $methods = array_keys($this->routes);
        return $this->map($methods, $route, $handler);
    }

    /**
     * افزودن مسیر به لیست مسیرها
     *
     * @param string $method متد HTTP
     * @param string $route مسیر درخواست
     * @param mixed $handler عملگر مسیر
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    private function addRoute($method, $route, $handler) {
        // تبدیل الگوی مسیر به الگوی regex برای تطبیق
        $pattern = $this->routeToRegex($route);

        $this->routes[$method][$pattern] = [
            'route' => $route,
            'handler' => $handler,
            'middlewares' => $this->currentMiddlewares
        ];

        // پاک کردن میدل‌ویرهای فعلی پس از ثبت مسیر
        $this->currentMiddlewares = [];

        return $this;
    }

    /**
     * تبدیل الگوی مسیر به الگوی regex
     *
     * @param string $route مسیر درخواست
     * @return string الگوی regex معادل
     */
    private function routeToRegex($route) {
        // تبدیل پارامترهای مسیر مانند {id} به الگوهای regex
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $route);
        $pattern = str_replace('/', '\/', $pattern);

        return '^' . $pattern . '$';
    }

    /**
     * افزودن میدل‌ویر به مسیر بعدی
     *
     * @param string|array $middleware نام میدل‌ویر یا آرایه‌ای از نام‌های میدل‌ویر
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function middleware($middleware) {
        if (is_array($middleware)) {
            $this->currentMiddlewares = array_merge($this->currentMiddlewares, $middleware);
        } else {
            $this->currentMiddlewares[] = $middleware;
        }

        return $this;
    }

    /**
     * تعریف میدل‌ویر با نام برای استفاده بعدی
     *
     * @param string $name نام میدل‌ویر
     * @param callable $callback تابع میدل‌ویر
     * @return Router خود این شی برای زنجیره‌ای کردن
     */
    public function defineMiddleware($name, $callback) {
        $this->middlewares[$name] = $callback;
        return $this;
    }

    /**
     * اجرای میدل‌ویرها برای یک مسیر
     *
     * @param array $middlewares آرایه‌ای از نام‌های میدل‌ویر
     * @param callable $next تابعی که پس از میدل‌ویرها باید اجرا شود
     * @return mixed نتیجه اجرای میدل‌ویرها و تابع بعدی
     */
    private function runMiddlewares(array $middlewares, callable $next) {
        if (empty($middlewares)) {
            return $next();
        }

        $middleware = array_shift($middlewares);

        if (!isset($this->middlewares[$middleware])) {
            throw new Exception("Middleware '$middleware' not defined");
        }

        $middlewareCallback = $this->middlewares[$middleware];

        return $middlewareCallback(function() use ($middlewares, $next) {
            return $this->runMiddlewares($middlewares, $next);
        });
    }

    /**
     * حل کردن مسیر درخواست و اجرای عملگر مربوطه
     *
     * @return mixed نتیجه اجرای عملگر مسیر
     */
    public function resolve() {
        // دریافت متد HTTP و مسیر درخواست
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = $this->getRequestUri();

        // پشتیبانی از متدهای PUT، DELETE، PATCH از طریق فیلد _method
        if ($method === 'POST' && isset($_POST['_method'])) {
            $overrideMethod = strtoupper($_POST['_method']);
            if (in_array($overrideMethod, ['PUT', 'DELETE', 'PATCH'])) {
                $method = $overrideMethod;
            }
        }

        // پشتیبانی از هدر X-HTTP-Method-Override
        if (isset($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'])) {
            $method = strtoupper($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE']);
        }

        // بررسی وجود مسیر مطابق با درخواست
        if (isset($this->routes[$method])) {
            foreach ($this->routes[$method] as $pattern => $routeData) {
                if (preg_match('/' . $pattern . '/', $uri, $matches)) {
                    // استخراج پارامترها
                    $this->params = $this->extractParams($matches);

                    // اجرای میدل‌ویرها و سپس عملگر مسیر
                    return $this->runMiddlewares($routeData['middlewares'], function() use ($routeData) {
                        return $this->callHandler($routeData['handler'], $this->params);
                    });
                }
            }
        }

        // مسیر پیدا نشد
        return $this->notFound();
    }

    /**
     * دریافت مسیر درخواست
     *
     * @return string مسیر درخواست پس از پردازش
     */
    private function getRequestUri() {
        $uri = isset($_GET['url']) ? $_GET['url'] : '';

        // اگر url در GET نبود، از REQUEST_URI استفاده می‌کنیم
        if (empty($uri) && isset($_SERVER['REQUEST_URI'])) {
            $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

            // حذف مسیر پایه اگر سایت در یک زیرپوشه قرار دارد
            $basePath = dirname($_SERVER['SCRIPT_NAME']);
            if ($basePath !== '/' && $basePath !== '\\') {
                $uri = substr($uri, strlen($basePath));
            }
        }

        // حذف اسلش‌های ابتدا و انتها
        $uri = trim($uri, '/');

        // اگر مسیر خالی بود، به صفحه اصلی برمی‌گردیم
        if (empty($uri)) {
            $uri = '';
        }

        return $uri;
    }

    /**
     * استخراج پارامترهای مسیر از نتیجه تطبیق regex
     *
     * @param array $matches نتایج تطبیق regex
     * @return array پارامترهای استخراج شده
     */
    private function extractParams($matches) {
        $params = [];

        foreach ($matches as $key => $value) {
            if (is_string($key)) {
                $params[$key] = $value;
            }
        }

        return $params;
    }

    /**
     * فراخوانی عملگر مسیر (کنترلر@متد یا تابع)
     *
     * @param mixed $handler عملگر مسیر
     * @param array $params پارامترهای مسیر
     * @return mixed نتیجه اجرای عملگر
     */
    private function callHandler($handler, $params) {
        // اگر handler یک تابع باشد، آن را با پارامترها اجرا می‌کنیم
        if (is_callable($handler)) {
            return call_user_func_array($handler, $params);
        }

        // اگر handler یک رشته در قالب "Controller@method" باشد، آن را پردازش می‌کنیم
        if (is_string($handler) && strpos($handler, '@') !== false) {
            list($controller, $method) = explode('@', $handler);

            // مسیر فایل کنترلر
            $controllerPath = 'controllers/' . $controller . 'Payment.php';

            // بررسی وجود فایل کنترلر
            if (file_exists($controllerPath)) {
                require_once $controllerPath;

                // بررسی وجود کلاس کنترلر
                if (class_exists($controller)) {
                    $controllerInstance = new $controller();

                    // بررسی وجود متد در کنترلر
                    if (method_exists($controllerInstance, $method)) {
                        return call_user_func_array([$controllerInstance, $method], $params);
                    }
                }
            }
        }

        // در صورت عدم پیدا کردن کنترلر یا متد، به صفحه 404 هدایت می‌کنیم
        return $this->notFound();
    }

    /**
     * نمایش صفحه 404 (صفحه پیدا نشد)
     *
     * @return void
     */
    private function notFound() {
        // تنظیم هدر 404
        header('HTTP/1.0 404 Not Found');

        // نمایش صفحه خطای 404
        $viewPath = VIEWS_PATH . '/errors/404.php';

        if (file_exists($viewPath)) {
            require $viewPath;
        } else {
            echo '<h1>404 - صفحه مورد نظر یافت نشد</h1>';
            echo '<p>متاسفانه صفحه‌ای که به دنبال آن هستید وجود ندارد.</p>';
            echo '<a href="/">بازگشت به صفحه اصلی</a>';
        }

        exit;
    }

    /**
     * تغییر مسیر به آدرس مشخص شده
     *
     * @param string $url آدرس مقصد
     * @param int $statusCode کد وضعیت HTTP
     * @return void
     */
    public static function redirect($url, $statusCode = 302) {
        // اگر URL با http شروع نشود، URL را نسبی در نظر می‌گیریم و URL پایه را اضافه می‌کنیم
        if (!preg_match('/^https?:\/\//', $url)) {
            $url = APP_URL . '/' . ltrim($url, '/');
        }

        header('Location: ' . $url, true, $statusCode);
        exit;
    }

    /**
     * ایجاد URL کامل برای یک مسیر
     *
     * @param string $path مسیر مورد نظر
     * @param array $params پارامترهای اختیاری برای query string
     * @return string URL کامل
     */
    public static function url($path, $params = []) {
        $url = APP_URL . '/' . ltrim($path, '/');

        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        return $url;
    }

    /**
     * تنظیم کنترلر پیش‌فرض
     *
     * @param string $controller نام کنترلر پیش‌فرض
     * @return Router خود این شی
     */
    public function setDefaultController($controller) {
        $this->defaultController = $controller;
        return $this;
    }

    /**
     * تنظیم متد پیش‌فرض
     *
     * @param string $method نام متد پیش‌فرض
     * @return Router خود این شی
     */
    public function setDefaultMethod($method) {
        $this->defaultMethod = $method;
        return $this;
    }

    /**
     * افزودن گروهی از مسیرها با پیشوند یکسان
     *
     * @param string $prefix پیشوند مشترک برای تمام مسیرها
     * @param callable $callback تابعی که مسیرهای درون گروه را تعریف می‌کند
     * @return Router خود این شی
     */
    public function group($prefix, callable $callback) {
        // ذخیره میدل‌ویرهای فعلی برای بازیابی پس از اتمام گروه
        $previousMiddlewares = $this->currentMiddlewares;

        // اضافه کردن پیشوند به مسیرها و پردازش آن‌ها
        $groupRouter = new GroupRouter($this, $prefix);
        $callback($groupRouter);

        // بازیابی میدل‌ویرهای قبلی
        $this->currentMiddlewares = $previousMiddlewares;

        return $this;
    }

    /**
     * ایجاد مسیرهای RESTful برای یک منبع
     *
     * @param string $name نام منبع
     * @param string $controller نام کنترلر
     * @param array $options گزینه‌های اضافی
     * @return Router خود این شی
     */
    public function resource($name, $controller, array $options = []) {
        $only = isset($options['only']) ? (array) $options['only'] : null;
        $except = isset($options['except']) ? (array) $options['except'] : null;

        $actions = [
            'index' => ['get', ''],
            'create' => ['get', 'create'],
            'store' => ['post', ''],
            'show' => ['get', '{id}'],
            'edit' => ['get', '{id}/edit'],
            'update' => ['put', '{id}'],
            'destroy' => ['delete', '{id}']
        ];

        foreach ($actions as $action => $details) {
            // بررسی محدودیت‌های only و except
            if (($only && !in_array($action, $only)) || ($except && in_array($action, $except))) {
                continue;
            }

            list($method, $path) = $details;
            $route = $name . ($path ? '/' . $path : '');
            $handler = $controller . '@' . $action;

            $this->$method($route, $handler);
        }

        return $this;
    }
}

/**
 * کلاس کمکی برای مدیریت گروه‌های مسیر
 */
class GroupRouter {
    /**
     * @var Router شی مسیریاب اصلی
     */
    private $router;

    /**
     * @var string پیشوند گروه
     */
    private $prefix;

    /**
     * ایجاد یک نمونه از کلاس GroupRouter
     *
     * @param Router $router شی مسیریاب اصلی
     * @param string $prefix پیشوند گروه
     */
    public function __construct(Router $router, $prefix) {
        $this->router = $router;
        $this->prefix = $prefix;
    }

    /**
     * متدی که تمام فراخوانی‌های ناشناخته را به مسیریاب اصلی منتقل می‌کند
     *
     * @param string $method نام متد
     * @param array $arguments آرگومان‌های متد
     * @return mixed نتیجه فراخوانی متد در مسیریاب اصلی
     */
    public function __call($method, $arguments) {
        if (method_exists($this->router, $method)) {
            // اعمال پیشوند به آرگومان اول (مسیر)
            if (isset($arguments[0])) {
                $route = $arguments[0];
                $prefixedRoute = rtrim($this->prefix, '/') . '/' . ltrim($route, '/');
                $arguments[0] = $prefixedRoute;
            }

            // فراخوانی متد در مسیریاب اصلی
            return call_user_func_array([$this->router, $method], $arguments);
        }

        throw new Exception("Method '{$method}' does not exist in Router");
    }
}