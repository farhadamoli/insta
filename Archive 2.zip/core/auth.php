<?php
/**
 * core/Auth.php
 *
 * کلاس احراز هویت برای سیستم SOCIALKOCH.CO
 * این کلاس مسئول مدیریت ورود، خروج، ثبت‌نام و کنترل دسترسی کاربران است
 */

class Auth {
    /**
     * @var Database شیء ارتباط با پایگاه داده
     */
    private $db;

    /**
     * @var array اطلاعات کاربر جاری
     */
    private $user = null;

    /**
     * @var array دسترسی‌های کاربر جاری
     */
    private $permissions = [];

    /**
     * @var array اشتراک‌های کاربر جاری
     */
    private $subscriptions = [];

    /**
     * @var bool آیا اطلاعات کاربر بارگذاری شده است؟
     */
    private $userLoaded = false;

    /**
     * @var bool آیا دسترسی‌های کاربر بارگذاری شده است؟
     */
    private $permissionsLoaded = false;

    /**
     * @var bool آیا اشتراک‌های کاربر بارگذاری شده است؟
     */
    private $subscriptionsLoaded = false;

    /**
     * ایجاد یک نمونه از کلاس Auth
     *
     * @param Database $db شیء ارتباط با پایگاه داده
     */
    public function __construct(Database $db) {
        $this->db = $db;
        $this->checkSession();
    }

    /**
     * بررسی جلسه کاربر و بارگذاری اطلاعات در صورت وجود
     */
    private function checkSession() {
        if (isset($_SESSION['user_id'])) {
            $this->loadUser($_SESSION['user_id']);
        }
    }

    /**
     * بارگذاری اطلاعات کاربر
     *
     * @param int $userId شناسه کاربر
     * @return bool آیا کاربر با موفقیت بارگذاری شد؟
     */
    private function loadUser($userId) {
        if ($this->userLoaded && $this->user && $this->user['id'] == $userId) {
            return true;
        }

        $this->user = $this->getUserById($userId);
        $this->userLoaded = ($this->user !== false);

        // اگر کاربر غیرفعال است، جلسه را پاک می‌کنیم
        if ($this->userLoaded && isset($this->user['status']) && $this->user['status'] != USER_STATUS_ACTIVE) {
            $this->logout();
            return false;
        }

        return $this->userLoaded;
    }

    /**
     * بارگذاری دسترسی‌های کاربر جاری
     *
     * @return array دسترسی‌های کاربر
     */
    private function loadPermissions() {
        if ($this->permissionsLoaded) {
            return $this->permissions;
        }

        if (!$this->isLoggedIn()) {
            $this->permissions = [];
            $this->permissionsLoaded = true;
            return $this->permissions;
        }

        // دریافت دسترسی‌های نقش کاربر
        $rolePermissions = $this->db->executeQuery(
            "SELECT p.name 
            FROM role_permissions rp 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE rp.role_id = :role_id",
            [':role_id' => $this->user['role_id']]
        );

        // دریافت دسترسی‌های اختصاصی کاربر
        $userPermissions = $this->db->executeQuery(
            "SELECT p.name 
            FROM user_permissions up 
            JOIN permissions p ON up.permission_id = p.id 
            WHERE up.user_id = :user_id",
            [':user_id' => $this->user['id']]
        );

        // ترکیب دسترسی‌ها
        $this->permissions = [];

        if ($rolePermissions) {
            foreach ($rolePermissions as $permission) {
                $this->permissions[] = $permission['name'];
            }
        }

        if ($userPermissions) {
            foreach ($userPermissions as $permission) {
                if (!in_array($permission['name'], $this->permissions)) {
                    $this->permissions[] = $permission['name'];
                }
            }
        }

        $this->permissionsLoaded = true;
        return $this->permissions;
    }

    /**
     * بارگذاری اشتراک‌های کاربر جاری
     *
     * @return array اشتراک‌های کاربر
     */
    private function loadSubscriptions() {
        if ($this->subscriptionsLoaded) {
            return $this->subscriptions;
        }

        if (!$this->isLoggedIn()) {
            $this->subscriptions = [];
            $this->subscriptionsLoaded = true;
            return $this->subscriptions;
        }

        // دریافت اشتراک‌های فعال کاربر
        $this->subscriptions = $this->db->executeQuery(
            "SELECT s.*, sp.name AS plan_name, sp.price, sp.duration 
            FROM subscriptions s 
            JOIN subscription_plans sp ON s.plan_id = sp.id 
            WHERE s.user_id = :user_id AND s.status = :status AND s.expiry_date >= NOW() 
            ORDER BY s.expiry_date DESC",
            [
                ':user_id' => $this->user['id'],
                ':status' => SUBSCRIPTION_ACTIVE
            ]
        );

        $this->subscriptionsLoaded = true;
        return $this->subscriptions;
    }

    /**
     * بررسی ورود کاربر
     *
     * @return bool آیا کاربر وارد شده است؟
     */
    public function isLoggedIn() {
        return $this->user !== null;
    }

    /**
     * ورود کاربر با ایمیل و رمز عبور
     *
     * @param string $email ایمیل کاربر
     * @param string $password رمز عبور کاربر
     * @param bool $remember ذخیره اطلاعات ورود؟
     * @return bool نتیجه عملیات ورود
     */
    public function login($email, $password, $remember = false) {
        // دریافت کاربر با ایمیل
        $user = $this->getUserByEmail($email);

        if (!$user) {
            return false;
        }

        // بررسی وضعیت کاربر
        if ($user['status'] != USER_STATUS_ACTIVE) {
            return false;
        }

        // بررسی رمز عبور
        if (!password_verify($password, $user['password'])) {
            // ثبت تلاش ناموفق
            $this->logLoginAttempt($user['id'], false);
            return false;
        }

        // بررسی نیاز به بروزرسانی الگوریتم هش
        if (password_needs_rehash($user['password'], PASSWORD_BCRYPT, ['cost' => HASH_COST])) {
            $this->updateUserPassword($user['id'], $password);
        }

        // ذخیره اطلاعات در جلسه
        $_SESSION['user_id'] = $user['id'];

        // ایجاد توکن یادآوری در صورت نیاز
        if ($remember) {
            $this->createRememberToken($user['id']);
        }

        // بارگذاری اطلاعات کاربر
        $this->loadUser($user['id']);

        // بروزرسانی زمان آخرین ورود
        $this->updateLastLogin($user['id']);

        // ثبت تلاش موفق
        $this->logLoginAttempt($user['id'], true);

        return true;
    }

    /**
     * خروج کاربر
     */
    public function logout() {
        // پاک کردن اطلاعات جلسه
        unset($_SESSION['user_id']);

        // پاک کردن توکن یادآوری
        if (isset($_COOKIE['remember_token'])) {
            $this->deleteRememberToken($_COOKIE['remember_token']);
            setcookie('remember_token', '', time() - 3600, '/', '', true, true);
        }

        // پاک کردن اطلاعات کاربر
        $this->user = null;
        $this->permissions = [];
        $this->subscriptions = [];
        $this->userLoaded = false;
        $this->permissionsLoaded = false;
        $this->subscriptionsLoaded = false;

        // بازسازی ID جلسه
        session_regenerate_id(true);
    }

    /**
     * ثبت‌نام کاربر جدید
     *
     * @param array $data اطلاعات کاربر
     * @return int|false شناسه کاربر جدید یا false در صورت خطا
     */
    public function register(array $data) {
        // بررسی وجود ایمیل
        if ($this->getUserByEmail($data['email'])) {
            return false;
        }

        // هش کردن رمز عبور
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => HASH_COST]);

        // تنظیم مقادیر پیش‌فرض
        $data['role_id'] = isset($data['role_id']) ? $data['role_id'] : ROLE_USER;
        $data['status'] = isset($data['status']) ? $data['status'] : USER_STATUS_ACTIVE;
        $data['created_at'] = date('Y-m-d H:i:s');

        // درج کاربر در پایگاه داده
        return $this->db->insert('users', $data);
    }

    /**
     * دریافت کاربر با شناسه
     *
     * @param int $id شناسه کاربر
     * @return array|false اطلاعات کاربر یا false در صورت عدم وجود
     */
    public function getUserById($id) {
        return $this->db->selectOne('users', '*', 'id = :id', [':id' => $id]);
    }

    /**
     * دریافت کاربر با ایمیل
     *
     * @param string $email ایمیل کاربر
     * @return array|false اطلاعات کاربر یا false در صورت عدم وجود
     */
    public function getUserByEmail($email) {
        return $this->db->selectOne('users', '*', 'email = :email', [':email' => $email]);
    }

    /**
     * دریافت اطلاعات کاربر جاری
     *
     * @return array|null اطلاعات کاربر جاری یا null در صورت عدم ورود
     */
    public function getUser() {
        return $this->user;
    }

    /**
     * بررسی دسترسی کاربر
     *
     * @param string $permission نام دسترسی
     * @return bool آیا کاربر دسترسی دارد؟
     */
    public function hasPermission($permission) {
        if (!$this->isLoggedIn()) {
            return false;
        }

        // اگر کاربر مدیر ارشد است، به همه چیز دسترسی دارد
        if ($this->user['role_id'] == ROLE_SUPERADMIN) {
            return true;
        }

        // بارگذاری دسترسی‌ها اگر لازم است
        if (!$this->permissionsLoaded) {
            $this->loadPermissions();
        }

        return in_array($permission, $this->permissions);
    }

    /**
     * بررسی دسترسی کاربر به یک ویژگی بر اساس اشتراک
     *
     * @param int $featureId شناسه ویژگی
     * @return bool آیا کاربر به ویژگی دسترسی دارد؟
     */
    public function canAccessFeature($featureId) {
        if (!$this->isLoggedIn()) {
            return false;
        }

        // مدیران به همه ویژگی‌ها دسترسی دارند
        if ($this->user['role_id'] == ROLE_SUPERADMIN || $this->user['role_id'] == ROLE_ADMIN) {
            return true;
        }

        // بررسی وجود اشتراک فعال
        if (!$this->hasActiveSubscription()) {
            return false;
        }

        // بارگذاری اشتراک‌ها اگر لازم است
        if (!$this->subscriptionsLoaded) {
            $this->loadSubscriptions();
        }

        // دریافت اولین اشتراک فعال (با تاریخ انقضای دورتر)
        if (empty($this->subscriptions)) {
            return false;
        }

        $subscription = $this->subscriptions[0];

        // بررسی دسترسی به ویژگی در اشتراک
        $featureAccess = $this->db->selectOne(
            'plan_features',
            '*',
            'plan_id = :plan_id AND feature_id = :feature_id',
            [
                ':plan_id' => $subscription['plan_id'],
                ':feature_id' => $featureId
            ]
        );

        return ($featureAccess !== false);
    }

    /**
     * بررسی محدودیت استفاده از یک ویژگی
     *
     * @param int $featureId شناسه ویژگی
     * @param string $period دوره زمانی (daily, monthly, total)
     * @return bool آیا محدودیت استفاده رعایت شده است؟
     */
    public function checkFeatureUsageLimit($featureId, $period = 'daily') {
        if (!$this->isLoggedIn()) {
            return false;
        }

        // مدیران محدودیتی ندارند
        if ($this->user['role_id'] == ROLE_SUPERADMIN || $this->user['role_id'] == ROLE_ADMIN) {
            return true;
        }

        // بررسی دسترسی به ویژگی
        if (!$this->canAccessFeature($featureId)) {
            return false;
        }

        // دریافت اشتراک فعال
        $subscription = $this->getActiveSubscription();

        if (!$subscription) {
            return false;
        }

        // دریافت محدودیت ویژگی در اشتراک
        $featureAccess = $this->db->selectOne(
            'plan_features',
            '*',
            'plan_id = :plan_id AND feature_id = :feature_id',
            [
                ':plan_id' => $subscription['plan_id'],
                ':feature_id' => $featureId
            ]
        );

        if (!$featureAccess || $featureAccess['usage_limit'] === null) {
            // اگر محدودیتی تعریف نشده باشد، محدودیتی نداریم
            return true;
        }

        // دریافت میزان استفاده در دوره زمانی
        $where = 'user_id = :user_id AND feature_id = :feature_id';
        $params = [
            ':user_id' => $this->user['id'],
            ':feature_id' => $featureId
        ];

        if ($period === 'daily') {
            $where .= ' AND DATE(last_used) = CURDATE()';
        } elseif ($period === 'monthly') {
            $where .= ' AND MONTH(last_used) = MONTH(CURDATE()) AND YEAR(last_used) = YEAR(CURDATE())';
        }

        $usage = $this->db->selectOne('user_usage', 'usage_count', $where, $params);

        if (!$usage) {
            // اگر هنوز استفاده‌ای نشده، مشکلی نیست
            return true;
        }

        // بررسی محدودیت
        return $usage['usage_count'] < $featureAccess['usage_limit'];
    }

    /**
     * ثبت استفاده از یک ویژگی
     *
     * @param int $featureId شناسه ویژگی
     * @return bool نتیجه عملیات
     */
    public function logFeatureUsage($featureId) {
        if (!$this->isLoggedIn()) {
            return false;
        }

        // بررسی وجود رکورد استفاده
        $usage = $this->db->selectOne(
            'user_usage',
            '*',
            'user_id = :user_id AND feature_id = :feature_id',
            [
                ':user_id' => $this->user['id'],
                ':feature_id' => $featureId
            ]
        );

        if ($usage) {
            // بروزرسانی رکورد موجود
            return $this->db->update(
                'user_usage',
                [
                    'usage_count' => $usage['usage_count'] + 1,
                    'last_used' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'id = :id',
                [':id' => $usage['id']]
            );
        } else {
            // ایجاد رکورد جدید
            return $this->db->insert('user_usage', [
                'user_id' => $this->user['id'],
                'feature_id' => $featureId,
                'usage_count' => 1,
                'last_used' => date('Y-m-d H:i:s'),
                'created_at' => date('Y-m-d H:i:s')
            ]);
        }
    }

    /**
     * دریافت وضعیت نقش کاربر
     *
     * @param int $roleId شناسه نقش
     * @return bool آیا کاربر نقش مورد نظر را دارد؟
     */
    public function hasRole($roleId) {
        if (!$this->isLoggedIn()) {
            return false;
        }

        return $this->user['role_id'] == $roleId;
    }

    /**
     * بررسی اینکه آیا کاربر مدیر است
     *
     * @return bool آیا کاربر مدیر است؟
     */
    public function isAdmin() {
        if (!$this->isLoggedIn()) {
            return false;
        }

        return $this->user['role_id'] == ROLE_ADMIN || $this->user['role_id'] == ROLE_SUPERADMIN;
    }

    /**
     * بررسی اینکه آیا کاربر مدیر ارشد است
     *
     * @return bool آیا کاربر مدیر ارشد است؟
     */
    public function isSuperAdmin() {
        if (!$this->isLoggedIn()) {
            return false;
        }

        return $this->user['role_id'] == ROLE_SUPERADMIN;
    }

    /**
     * بررسی وجود اشتراک فعال
     *
     * @return bool آیا کاربر اشتراک فعال دارد؟
     */
    public function hasActiveSubscription() {
        if (!$this->isLoggedIn()) {
            return false;
        }

        // مدیران همیشه اشتراک فعال دارند
        if ($this->user['role_id'] == ROLE_SUPERADMIN || $this->user['role_id'] == ROLE_ADMIN) {
            return true;
        }

        // بررسی وجود اشتراک فعال
        $subscription = $this->db->selectOne(
            'subscriptions',
            '*',
            'user_id = :user_id AND status = :status AND expiry_date >= NOW()',
            [
                ':user_id' => $this->user['id'],
                ':status' => SUBSCRIPTION_ACTIVE
            ]
        );

        return ($subscription !== false);
    }

    /**
     * دریافت اشتراک فعال کاربر
     *
     * @return array|false اطلاعات اشتراک یا false در صورت عدم وجود
     */
    public function getActiveSubscription() {
        if (!$this->isLoggedIn()) {
            return false;
        }

        // بارگذاری اشتراک‌ها اگر لازم است
        if (!$this->subscriptionsLoaded) {
            $this->loadSubscriptions();
        }

        if (empty($this->subscriptions)) {
            return false;
        }

        return $this->subscriptions[0];
    }

    /**
     * دریافت تمام اشتراک‌های کاربر
     *
     * @param bool $activeOnly فقط اشتراک‌های فعال را برگرداند؟
     * @return array آرایه‌ای از اشتراک‌ها
     */
    public function getSubscriptions($activeOnly = true) {
        if (!$this->isLoggedIn()) {
            return [];
        }

        $where = 'user_id = :user_id';
        $params = [':user_id' => $this->user['id']];

        if ($activeOnly) {
            $where .= ' AND status = :status AND expiry_date >= NOW()';
            $params[':status'] = SUBSCRIPTION_ACTIVE;
        }

        return $this->db->executeQuery(
            "SELECT s.*, sp.name AS plan_name, sp.price, sp.duration 
            FROM subscriptions s 
            JOIN subscription_plans sp ON s.plan_id = sp.id 
            WHERE {$where} 
            ORDER BY s.expiry_date DESC",
            $params
        );
    }

    /**
     * ایجاد یک توکن برای ریست رمز عبور
     *
     * @param string $email ایمیل کاربر
     * @return string|false توکن ایجاد شده یا false در صورت خطا
     */
    public function createPasswordResetToken($email) {
        $user = $this->getUserByEmail($email);

        if (!$user) {
            return false;
        }

        // ایجاد توکن تصادفی
        $token = bin2hex(random_bytes(32));
        $expiryDate = date('Y-m-d H:i:s', time() + PASSWORD_RESET_TOKEN_LIFETIME);

        // حذف توکن‌های قبلی
        $this->db->delete(
            'password_resets',
            'user_id = :user_id',
            [':user_id' => $user['id']]
        );

        // ثبت توکن جدید
        $inserted = $this->db->insert('password_resets', [
            'user_id' => $user['id'],
            'token' => $token,
            'expiry_date' => $expiryDate,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return $inserted ? $token : false;
    }

    /**
     * بررسی اعتبار توکن ریست رمز عبور
     *
     * @param string $token توکن
     * @return int|false شناسه کاربر یا false در صورت نامعتبر بودن
     */
    public function validatePasswordResetToken($token) {
        $resetInfo = $this->db->selectOne(
            'password_resets',
            '*',
            'token = :token AND expiry_date > NOW()',
            [':token' => $token]
        );

        return $resetInfo ? $resetInfo['user_id'] : false;
    }

    /**
     * تغییر رمز عبور کاربر
     *
     * @param int $userId شناسه کاربر
     * @param string $newPassword رمز عبور جدید
     * @return bool نتیجه عملیات
     */
    public function resetPassword($userId, $newPassword) {
        // بررسی وجود کاربر
        $user = $this->getUserById($userId);

        if (!$user) {
            return false;
        }

        // بروزرسانی رمز عبور
        $result = $this->updateUserPassword($userId, $newPassword);

        if ($result) {
            // حذف توکن‌های ریست رمز عبور
            $this->db->delete(
                'password_resets',
                'user_id = :user_id',
                [':user_id' => $userId]
            );
        }

        return $result;
    }

    /**
     * بروزرسانی رمز عبور کاربر
     *
     * @param int $userId شناسه کاربر
     * @param string $newPassword رمز عبور جدید
     * @return bool نتیجه عملیات
     */
    private function updateUserPassword($userId, $newPassword) {
        return $this->db->update(
            'users',
            [
                'password' => password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => HASH_COST]),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            'id = :id',
            [':id' => $userId]
        );
    }

    /**
     * ایجاد توکن یادآوری برای ورود خودکار
     *
     * @param int $userId شناسه کاربر
     * @return bool نتیجه عملیات
     */
    private function createRememberToken($userId) {
        // ایجاد توکن تصادفی
        $token = bin2hex(random_bytes(32));
        $expiry = time() + (30 * 24 * 60 * 60); // ۳۰ روز

        // حذف توکن‌های قبلی
        $this->db->delete(
            'remember_tokens',
            'user_id = :user_id',
            [':user_id' => $userId]
        );

        // ثبت توکن جدید
        $inserted = $this->db->insert('remember_tokens', [
            'user_id' => $userId,
            'token' => $token,
            'expiry_date' => date('Y-m-d H:i:s', $expiry),
            'created_at' => date('Y-m-d H:i:s')
        ]);

        if ($inserted) {
            // ذخیره توکن در کوکی
            setcookie('remember_token', $token, $expiry, '/', '', true, true);
            return true;
        }

        return false;
    }

    /**
     * حذف توکن یادآوری
     *
     * @param string $token توکن
     * @return bool نتیجه عملیات
     */
    private function deleteRememberToken($token) {
        return $this->db->delete(
            'remember_tokens',
            'token = :token',
            [':token' => $token]
        );
    }

    /**
     * بررسی توکن یادآوری و ورود خودکار
     *
     * @return bool آیا ورود خودکار انجام شد؟
     */
    public function loginFromRememberToken() {
        if ($this->isLoggedIn() || !isset($_COOKIE['remember_token'])) {
            return false;
        }

        $token = $_COOKIE['remember_token'];

        // دریافت اطلاعات توکن
        $tokenInfo = $this->db->selectOne(
            'remember_tokens',
            '*',
            'token = :token AND expiry_date > NOW()',
            [':token' => $token]
        );

        if (!$tokenInfo) {
            // توکن نامعتبر است، پاک کردن کوکی
            setcookie('remember_token', '', time() - 3600, '/', '', true, true);
            return false;
        }

        // بارگذاری کاربر
        $userId = $tokenInfo['user_id'];

        if ($this->loadUser($userId)) {
            // ثبت در جلسه
            $_SESSION['user_id'] = $userId;

            // ساخت توکن جدید برای امنیت بیشتر
            $this->createRememberToken($userId);

            // بروزرسانی زمان آخرین ورود
            $this->updateLastLogin($userId);

            return true;
        }

        return false;
    }

    /**
     * بروزرسانی زمان آخرین ورود
     *
     * @param int $userId شناسه کاربر
     * @return bool نتیجه عملیات
     */
    private function updateLastLogin($userId) {
        return $this->db->update(
            'users',
            [
                'last_login' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            'id = :id',
            [':id' => $userId]
        );
    }

    /**
     * ثبت تلاش ورود
     *
     * @param int $userId شناسه کاربر
     * @param bool $success آیا تلاش موفق بوده؟
     * @return bool نتیجه عملیات
     */
    private function logLoginAttempt($userId, $success) {
        return $this->db->insert('login_attempts', [
            'user_id' => $userId,
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'success' => $success ? 1 : 0,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * دریافت اطلاعات فعالیت‌های اخیر کاربر
     *
     * @param int $limit تعداد فعالیت‌ها
     * @return array آرایه‌ای از فعالیت‌ها
     */
    public function getUserActivities($limit = 10) {
        if (!$this->isLoggedIn()) {
            return [];
        }

        return $this->db->executeQuery(
            "SELECT * FROM user_activities 
            WHERE user_id = :user_id 
            ORDER BY created_at DESC 
            LIMIT :limit",
            [
                ':user_id' => $this->user['id'],
                ':limit' => $limit
            ]
        );
    }

    /**
     * ثبت فعالیت کاربر
     *
     * @param string $activity توضیح فعالیت
     * @param string $type نوع فعالیت
     * @param int $relatedId شناسه مرتبط (اختیاری)
     * @return bool نتیجه عملیات
     */
    public function logActivity($activity, $type, $relatedId = null) {
        if (!$this->isLoggedIn()) {
            return false;
        }

        return $this->db->insert('user_activities', [
            'user_id' => $this->user['id'],
            'activity' => $activity,
            'activity_type' => $type,
            'related_id' => $relatedId,
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * دریافت اطلاعات پروفایل کاربر
     *
     * @return array|false اطلاعات پروفایل یا false در صورت عدم وجود
     */
    public function getUserProfile() {
        if (!$this->isLoggedIn()) {
            return false;
        }

        return $this->db->selectOne(
            'user_profiles',
            '*',
            'user_id = :user_id',
            [':user_id' => $this->user['id']]
        );
    }

    /**
     * دریافت تعداد اعلان‌های خوانده نشده
     *
     * @return int تعداد اعلان‌ها
     */
    public function getUnreadNotificationsCount() {
        if (!$this->isLoggedIn()) {
            return 0;
        }

        $result = $this->db->selectOne(
            'notifications',
            'COUNT(*) as count',
            'user_id = :user_id AND status = :status',
            [
                ':user_id' => $this->user['id'],
                ':status' => NOTIFICATION_STATUS_UNREAD
            ]
        );

        return $result ? (int) $result['count'] : 0;
    }

    /**
     * ارسال اعلان به کاربر
     *
     * @param string $title عنوان اعلان
     * @param string $message متن اعلان
     * @param int $type نوع اعلان
     * @param string $link لینک اعلان (اختیاری)
     * @return bool نتیجه عملیات
     */
    public function sendNotification($title, $message, $type = NOTIFICATION_TYPE_INFO, $link = null) {
        if (!$this->isLoggedIn()) {
            return false;
        }

        return $this->db->insert('notifications', [
            'user_id' => $this->user['id'],
            'title' => $title,
            'message' => $message,
            'type' => $type,
            'link' => $link,
            'status' => NOTIFICATION_STATUS_UNREAD,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
}