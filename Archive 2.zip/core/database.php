<?php
/**
 * core/Database.php
 *
 * کلاس دیتابیس برای سیستم SOCIALKOCH.CO
 * این کلاس مسئول مدیریت ارتباط با پایگاه داده و اجرای کوئری‌ها است
 */

class Database {
    /**
     * @var PDO شیء اتصال به پایگاه داده
     */
    private $pdo;

    /**
     * @var PDOStatement شیء دستور SQL آماده‌سازی شده
     */
    private $statement;

    /**
     * @var array آرایه‌ای از پارامترهای اجرای اخیر
     */
    private $parameters = [];

    /**
     * @var array آرایه‌ای از خطاهای اخیر
     */
    private $errors = [];

    /**
     * @var bool آیا ارتباط با پایگاه داده برقرار است؟
     */
    private $connected = false;

    /**
     * @var int تعداد کوئری‌های اجرا شده
     */
    private $queryCount = 0;

    /**
     * @var array آرایه‌ای از کوئری‌های اجرا شده (در حالت دیباگ)
     */
    private $queries = [];

    /**
     * @var float زمان شروع آخرین کوئری
     */
    private $queryStartTime = 0;

    /**
     * @var array آرایه‌ای از زمان‌های اجرای کوئری‌ها
     */
    private $queryTimes = [];

    /**
     * ایجاد یک نمونه از کلاس Database
     *
     * @param string $host نام میزبان MySQL
     * @param string $username نام کاربری MySQL
     * @param string $password رمز عبور MySQL
     * @param string $database نام پایگاه داده
     * @param string $charset کاراکترست پایگاه داده
     * @param int $port پورت اتصال
     */
    public function __construct($host = DB_HOST, $username = DB_USER, $password = DB_PASS, $database = DB_NAME, $charset = DB_CHARSET, $port = DB_PORT) {
        try {
            // ساخت DSN
            $dsn = "mysql:host={$host};dbname={$database};charset={$charset}";

            // اضافه کردن پورت به DSN اگر مقدار پیش‌فرض نباشد
            if ($port !== 3306) {
                $dsn .= ";port={$port}";
            }

            // تنظیمات اتصال
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$charset} COLLATE " . DB_COLLATION
            ];

            // ایجاد شیء PDO
            $this->pdo = new PDO($dsn, $username, $password, $options);
            $this->connected = true;

            // ثبت زمان اتصال در حالت دیباگ
            if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
                $this->queries[] = [
                    'query' => 'CONNECTION ESTABLISHED',
                    'params' => [],
                    'time' => microtime(true)
                ];
            }
        } catch (PDOException $e) {
            // ثبت خطا
            $this->errors[] = $e->getMessage();
            $this->connected = false;

            // نمایش خطا در حالت دیباگ
            if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
                throw new Exception('Database Connection Error: ' . $e->getMessage());
            }

            // ثبت در لاگ
            if (defined('LOG_ERRORS') && LOG_ERRORS) {
                error_log('Database Connection Error: ' . $e->getMessage());
            }
        }
    }

    /**
     * اجرای یک کوئری SQL
     *
     * @param string $sql دستور SQL
     * @param array $params پارامترهای دستور (اختیاری)
     * @return Database خود شیء برای زنجیره‌ای کردن
     */
    public function query($sql) {
        // بررسی وضعیت اتصال
        if (!$this->connected) {
            throw new Exception('Cannot execute query: Database not connected');
        }

        // ذخیره زمان شروع کوئری
        $this->queryStartTime = microtime(true);

        try {
            // آماده‌سازی دستور SQL
            $this->statement = $this->pdo->prepare($sql);

            // پاک کردن پارامترهای قبلی
            $this->parameters = [];

            // افزایش شمارنده کوئری
            $this->queryCount++;

            // ثبت کوئری در حالت دیباگ
            if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
                $this->queries[] = [
                    'query' => $sql,
                    'params' => [],
                    'time' => microtime(true)
                ];
            }

            return $this;
        } catch (PDOException $e) {
            // ثبت خطا
            $this->errors[] = $e->getMessage();

            // نمایش خطا در حالت دیباگ
            if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
                throw new Exception('Query Error: ' . $e->getMessage() . ' in query: ' . $sql);
            }

            // ثبت در لاگ
            if (defined('LOG_ERRORS') && LOG_ERRORS) {
                error_log('Query Error: ' . $e->getMessage() . ' in query: ' . $sql);
            }

            return $this;
        }
    }

    /**
     * بایند کردن یک پارامتر به دستور SQL
     *
     * @param string|int $param نام یا شماره پارامتر
     * @param mixed $value مقدار پارامتر
     * @param int $type نوع پارامتر (از ثابت‌های PDO::PARAM_*)
     * @return Database خود شیء برای زنجیره‌ای کردن
     */
    public function bind($param, $value, $type = null) {
        // تعیین نوع پارامتر اگر مشخص نشده باشد
        if (is_null($type)) {
            switch (true) {
                case is_int($value):
                    $type = PDO::PARAM_INT;
                    break;
                case is_bool($value):
                    $type = PDO::PARAM_BOOL;
                    break;
                case is_null($value):
                    $type = PDO::PARAM_NULL;
                    break;
                default:
                    $type = PDO::PARAM_STR;
            }
        }

        // بایند کردن پارامتر
        $this->statement->bindValue($param, $value, $type);

        // ذخیره پارامتر برای دیباگ
        $this->parameters[$param] = [
            'value' => $value,
            'type' => $type
        ];

        // بروزرسانی کوئری در حالت دیباگ
        if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS && !empty($this->queries)) {
            $last = count($this->queries) - 1;
            $this->queries[$last]['params'][$param] = $value;
        }

        return $this;
    }

    /**
     * اجرای دستور SQL آماده‌سازی شده
     *
     * @return bool نتیجه اجرای دستور
     */
    public function execute() {
        // بررسی وجود دستور آماده‌سازی شده
        if (!$this->statement) {
            return false;
        }

        try {
            // اجرای دستور
            $result = $this->statement->execute();

            // محاسبه زمان اجرا
            $executionTime = microtime(true) - $this->queryStartTime;
            $this->queryTimes[] = $executionTime;

            // بروزرسانی زمان اجرا در حالت دیباگ
            if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS && !empty($this->queries)) {
                $last = count($this->queries) - 1;
                $this->queries[$last]['execution_time'] = $executionTime;
            }

            return $result;
        } catch (PDOException $e) {
            // ثبت خطا
            $this->errors[] = $e->getMessage();

            // نمایش خطا در حالت دیباگ
            if (defined('DISPLAY_ERRORS') && DISPLAY_ERRORS) {
                throw new Exception('Execution Error: ' . $e->getMessage());
            }

            // ثبت در لاگ
            if (defined('LOG_ERRORS') && LOG_ERRORS) {
                error_log('Execution Error: ' . $e->getMessage());
            }

            return false;
        }
    }

    /**
     * اجرای یک دستور SQL و بازگرداندن همه نتایج
     *
     * @param string $sql دستور SQL
     * @param array $params پارامترهای دستور
     * @return array آرایه‌ای از تمام نتایج
     */
    public function executeQuery($sql, array $params = []) {
        $this->query($sql);

        // بایند کردن پارامترها
        foreach ($params as $key => $value) {
            $this->bind($key, $value);
        }

        $this->execute();
        return $this->fetchAll();
    }

    /**
     * اجرای یک دستور SQL و بازگرداندن اولین نتیجه
     *
     * @param string $sql دستور SQL
     * @param array $params پارامترهای دستور
     * @return array|false اولین نتیجه یا false در صورت خالی بودن نتایج
     */
    public function executeQuerySingle($sql, array $params = []) {
        $this->query($sql);

        // بایند کردن پارامترها
        foreach ($params as $key => $value) {
            $this->bind($key, $value);
        }

        $this->execute();
        return $this->fetch();
    }

    /**
     * دریافت همه سطرهای نتیجه
     *
     * @return array آرایه‌ای از سطرهای نتیجه
     */
    public function fetchAll() {
        try {
            return $this->statement->fetchAll();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return [];
        }
    }

    /**
     * دریافت یک سطر از نتیجه
     *
     * @return array|false سطر نتیجه یا false در صورت خالی بودن نتایج
     */
    public function fetch() {
        try {
            return $this->statement->fetch();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * دریافت یک سطر از نتیجه به صورت شیء
     *
     * @param string $className نام کلاس شیء (اختیاری)
     * @return object|false شیء نتیجه یا false در صورت خالی بودن نتایج
     */
    public function fetchObject($className = 'stdClass') {
        try {
            return $this->statement->fetchObject($className);
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * دریافت یک ستون از یک سطر
     *
     * @param int $columnNumber شماره ستون (شروع از 0)
     * @return mixed مقدار ستون یا false در صورت خالی بودن نتایج
     */
    public function fetchColumn($columnNumber = 0) {
        try {
            return $this->statement->fetchColumn($columnNumber);
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * دریافت تعداد سطرهای متاثر از دستور اخیر
     *
     * @return int تعداد سطرهای متاثر
     */
    public function rowCount() {
        try {
            return $this->statement->rowCount();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return 0;
        }
    }

    /**
     * دریافت آخرین ID درج شده
     *
     * @return string|false آخرین ID درج شده یا false در صورت خطا
     */
    public function lastInsertId() {
        try {
            return $this->pdo->lastInsertId();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * شروع یک تراکنش
     *
     * @return bool نتیجه عملیات
     */
    public function beginTransaction() {
        try {
            return $this->pdo->beginTransaction();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * تایید و اتمام یک تراکنش
     *
     * @return bool نتیجه عملیات
     */
    public function commit() {
        try {
            return $this->pdo->commit();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * لغو یک تراکنش
     *
     * @return bool نتیجه عملیات
     */
    public function rollBack() {
        try {
            return $this->pdo->rollBack();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * بررسی وضعیت داخل تراکنش بودن
     *
     * @return bool آیا داخل یک تراکنش هستیم؟
     */
    public function inTransaction() {
        try {
            return $this->pdo->inTransaction();
        } catch (PDOException $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * درج یک رکورد در جدول
     *
     * @param string $table نام جدول
     * @param array $data داده‌های رکورد (نام ستون => مقدار)
     * @return int|false ID رکورد درج شده یا false در صورت خطا
     */
    public function insert($table, array $data) {
        // ساخت فیلدها و پلیس‌هولدرها
        $fields = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));

        // ساخت دستور SQL
        $sql = "INSERT INTO {$table} ({$fields}) VALUES ({$placeholders})";

        $this->query($sql);

        // بایند کردن مقادیر
        foreach ($data as $key => $value) {
            $this->bind(':' . $key, $value);
        }

        // اجرای دستور
        if ($this->execute()) {
            return $this->lastInsertId();
        }

        return false;
    }

    /**
     * بروزرسانی رکوردها در جدول
     *
     * @param string $table نام جدول
     * @param array $data داده‌های جدید (نام ستون => مقدار)
     * @param string $where شرط WHERE (بدون کلمه WHERE)
     * @param array $whereParams پارامترهای شرط WHERE
     * @return int|false تعداد رکوردهای بروزرسانی شده یا false در صورت خطا
     */
    public function update($table, array $data, $where = '', array $whereParams = []) {
        // ساخت بخش SET
        $set = [];
        foreach (array_keys($data) as $key) {
            $set[] = "{$key} = :{$key}";
        }
        $setClause = implode(', ', $set);

        // ساخت دستور SQL
        $sql = "UPDATE {$table} SET {$setClause}";

        if (!empty($where)) {
            $sql .= " WHERE {$where}";
        }

        $this->query($sql);

        // بایند کردن مقادیر SET
        foreach ($data as $key => $value) {
            $this->bind(':' . $key, $value);
        }

        // بایند کردن پارامترهای WHERE
        foreach ($whereParams as $key => $value) {
            $this->bind($key, $value);
        }

        // اجرای دستور
        if ($this->execute()) {
            return $this->rowCount();
        }

        return false;
    }

    /**
     * حذف رکوردها از جدول
     *
     * @param string $table نام جدول
     * @param string $where شرط WHERE (بدون کلمه WHERE)
     * @param array $params پارامترهای شرط WHERE
     * @return int|false تعداد رکوردهای حذف شده یا false در صورت خطا
     */
    public function delete($table, $where = '', array $params = []) {
        // ساخت دستور SQL
        $sql = "DELETE FROM {$table}";

        if (!empty($where)) {
            $sql .= " WHERE {$where}";
        }

        $this->query($sql);

        // بایند کردن پارامترها
        foreach ($params as $key => $value) {
            $this->bind($key, $value);
        }

        // اجرای دستور
        if ($this->execute()) {
            return $this->rowCount();
        }

        return false;
    }

    /**
     * اجرای یک دستور SELECT ساده
     *
     * @param string $table نام جدول
     * @param string $columns ستون‌های مورد نظر (جدا شده با کاما)
     * @param string $where شرط WHERE (بدون کلمه WHERE)
     * @param array $params پارامترهای شرط WHERE
     * @param string $orderBy ترتیب نتایج (بدون کلمه ORDER BY)
     * @param int $limit محدودیت تعداد نتایج
     * @param int $offset شروع از رکورد چندم
     * @return array نتایج
     */
    public function select($table, $columns = '*', $where = '', array $params = [], $orderBy = '', $limit = null, $offset = null) {
        // ساخت دستور SQL
        $sql = "SELECT {$columns} FROM {$table}";

        if (!empty($where)) {
            $sql .= " WHERE {$where}";
        }

        if (!empty($orderBy)) {
            $sql .= " ORDER BY {$orderBy}";
        }

        if ($limit !== null) {
            $sql .= " LIMIT {$limit}";

            if ($offset !== null) {
                $sql .= " OFFSET {$offset}";
            }
        }

        return $this->executeQuery($sql, $params);
    }

    /**
     * اجرای یک دستور SELECT و دریافت اولین نتیجه
     *
     * @param string $table نام جدول
     * @param string $columns ستون‌های مورد نظر (جدا شده با کاما)
     * @param string $where شرط WHERE (بدون کلمه WHERE)
     * @param array $params پارامترهای شرط WHERE
     * @param string $orderBy ترتیب نتایج (بدون کلمه ORDER BY)
     * @return array|false نتیجه یا false در صورت خالی بودن نتایج
     */
    public function selectOne($table, $columns = '*', $where = '', array $params = [], $orderBy = '') {
        // استفاده از متد select با محدودیت یک نتیجه
        $results = $this->select($table, $columns, $where, $params, $orderBy, 1);

        if (!empty($results)) {
            return $results[0];
        }

        return false;
    }

    /**
     * شمارش تعداد رکوردها
     *
     * @param string $table نام جدول
     * @param string $where شرط WHERE (بدون کلمه WHERE)
     * @param array $params پارامترهای شرط WHERE
     * @return int تعداد رکوردها
     */
    public function count($table, $where = '', array $params = []) {
        // ساخت دستور SQL
        $sql = "SELECT COUNT(*) FROM {$table}";

        if (!empty($where)) {
            $sql .= " WHERE {$where}";
        }

        $this->query($sql);

        // بایند کردن پارامترها
        foreach ($params as $key => $value) {
            $this->bind($key, $value);
        }

        $this->execute();

        return (int) $this->fetchColumn();
    }

    /**
     * بررسی وجود رکورد
     *
     * @param string $table نام جدول
     * @param string $where شرط WHERE (بدون کلمه WHERE)
     * @param array $params پارامترهای شرط WHERE
     * @return bool آیا رکورد وجود دارد؟
     */
    public function exists($table, $where, array $params = []) {
        return $this->count($table, $where, $params) > 0;
    }

    /**
     * دریافت آخرین خطای رخ داده
     *
     * @return string|null آخرین خطا یا null در صورت نبود خطا
     */
    public function getLastError() {
        return empty($this->errors) ? null : end($this->errors);
    }

    /**
     * دریافت تمام خطاهای رخ داده
     *
     * @return array آرایه‌ای از خطاها
     */
    public function getErrors() {
        return $this->errors;
    }

    /**
     * دریافت تعداد کوئری‌های اجرا شده
     *
     * @return int تعداد کوئری‌ها
     */
    public function getQueryCount() {
        return $this->queryCount;
    }

    /**
     * دریافت لیست کوئری‌های اجرا شده (در حالت دیباگ)
     *
     * @return array آرایه‌ای از کوئری‌ها
     */
    public function getQueries() {
        return $this->queries;
    }

    /**
     * دریافت میانگین زمان اجرای کوئری‌ها
     *
     * @return float میانگین زمان اجرا (ثانیه)
     */
    public function getAverageQueryTime() {
        if (empty($this->queryTimes)) {
            return 0;
        }

        return array_sum($this->queryTimes) / count($this->queryTimes);
    }

    /**
     * دریافت کل زمان صرف شده برای اجرای کوئری‌ها
     *
     * @return float کل زمان اجرا (ثانیه)
     */
    public function getTotalQueryTime() {
        return array_sum($this->queryTimes);
    }

    /**
     * دریافت وضعیت اتصال به پایگاه داده
     *
     * @return bool آیا اتصال برقرار است؟
     */
    public function isConnected() {
        return $this->connected;
    }

    /**
     * دریافت اطلاعات یک جدول
     *
     * @param string $table نام جدول
     * @return array اطلاعات جدول
     */
    public function getTableInfo($table) {
        return $this->executeQuery("DESCRIBE {$table}");
    }

    /**
     * اجرای یک فایل SQL
     *
     * @param string $filePath مسیر فایل SQL
     * @return bool نتیجه عملیات
     */
    public function importSqlFile($filePath) {
        if (!file_exists($filePath)) {
            $this->errors[] = "SQL file not found: {$filePath}";
            return false;
        }

        $sql = file_get_contents($filePath);
        $queries = explode(';', $sql);

        try {
            $this->beginTransaction();

            foreach ($queries as $query) {
                $query = trim($query);

                if (empty($query)) {
                    continue;
                }

                $this->query($query);
                $this->execute();
            }

            return $this->commit();
        } catch (Exception $e) {
            $this->rollBack();
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    /**
     * ایجاد بکاپ از پایگاه داده
     *
     * @param string $outputPath مسیر خروجی فایل بکاپ
     * @param array $tables آرایه‌ای از جداول برای بکاپ (خالی برای همه جداول)
     * @return bool|string مسیر فایل بکاپ یا false در صورت خطا
     */
    public function backup($outputPath = null, array $tables = []) {
        if (!$this->connected) {
            $this->errors[] = 'Cannot create backup: Database not connected';
            return false;
        }

        if ($outputPath === null) {
            $outputPath = defined('DB_BACKUP_PATH') ? DB_BACKUP_PATH : dirname(__DIR__) . '/backups';

            if (!file_exists($outputPath)) {
                if (!mkdir($outputPath, 0755, true)) {
                    $this->errors[] = "Cannot create backup directory: {$outputPath}";
                    return false;
                }
            }

            $outputPath .= '/' . DB_NAME . '_' . date('Y-m-d_H-i-s') . '.sql';
        }

        // دریافت لیست جداول
        if (empty($tables)) {
            $tables = array_column($this->executeQuery('SHOW TABLES'), 'Tables_in_' . DB_NAME);
        }

        // ایجاد فایل خروجی
        $output = fopen($outputPath, 'w');

        if (!$output) {
            $this->errors[] = "Cannot create backup file: {$outputPath}";
            return false;
        }

        // نوشتن هدر فایل بکاپ
        fwrite($output, "-- SOCIALKOCH.CO Database Backup\n");
        fwrite($output, "-- Date: " . date('Y-m-d H:i:s') . "\n");
        fwrite($output, "-- Database: " . DB_NAME . "\n\n");

        // پردازش هر جدول
        foreach ($tables as $table) {
            // نوشتن هدر جدول
            fwrite($output, "-- Table structure for table `{$table}`\n\n");

            // نوشتن دستور DROP TABLE
            if (defined('DB_BACKUP_WITH_DROP') && DB_BACKUP_WITH_DROP) {
                fwrite($output, "DROP TABLE IF EXISTS `{$table}`;\n\n");
            }

            // دریافت دستور CREATE TABLE
            $createTable = $this->executeQuerySingle("SHOW CREATE TABLE `{$table}`");

            if ($createTable && isset($createTable['Create Table'])) {
                fwrite($output, $createTable['Create Table'] . ";\n\n");
            }

            // دریافت داده‌های جدول
            $rows = $this->executeQuery("SELECT * FROM `{$table}`");

            if (!empty($rows)) {
                fwrite($output, "-- Data for table `{$table}`\n\n");

                // دریافت نام ستون‌ها
                $columns = array_keys($rows[0]);
                $columnNames = '`' . implode('`, `', $columns) . '`';

                // تقسیم داده‌ها به بخش‌های کوچکتر برای جلوگیری از خطای اجرا
                $chunks = array_chunk($rows, 100);

                foreach ($chunks as $chunk) {
                    $values = [];

                    foreach ($chunk as $row) {
                        $rowValues = [];

                        foreach ($row as $value) {
                            if ($value === null) {
                                $rowValues[] = 'NULL';
                            } elseif (is_numeric($value)) {
                                $rowValues[] = $value;
                            } else {
                                $rowValues[] = $this->pdo->quote($value);
                            }
                        }

                        $values[] = '(' . implode(', ', $rowValues) . ')';
                    }

                    fwrite($output, "INSERT INTO `{$table}` ({$columnNames}) VALUES\n");
                    fwrite($output, implode(",\n", $values) . ";\n\n");
                }
            }

            fwrite($output, "\n");
        }

        fclose($output);

        // فشرده‌سازی فایل در صورت نیاز
        if (defined('DB_BACKUP_COMPRESS') && DB_BACKUP_COMPRESS && extension_loaded('zip')) {
            $zip = new ZipArchive();
            $zipFile = $outputPath . '.zip';

            if ($zip->open($zipFile, ZipArchive::CREATE) === true) {
                $zip->addFile($outputPath, basename($outputPath));
                $zip->close();

                // حذف فایل اصلی
                unlink($outputPath);

                return $zipFile;
            }
        }

        return $outputPath;
    }

    /**
     * بستن اتصال
     */
    public function close() {
        $this->statement = null;
        $this->pdo = null;
        $this->connected = false;
    }

    /**
     * آزاد کردن منابع در هنگام از بین رفتن شیء
     */
    public function __destruct() {
        $this->close();
    }
}