<?php
/**
 * Social Media Monitoring Platform - Helper Class
 *
 * A collection of utility methods for social media data processing and analysis
 * Used for extracting, formatting and analyzing social media data across platforms
 *
 * @author Original Development Team
 * @version 2.1.3
 * @copyright Social Monitor Inc.
 */
namespace Core;

class Helper
{
    /**
     * Sanitize user input to prevent XSS attacks
     *
     * @param string $input
     * @return string
     */
    public static function sanitize($input)
    {
        return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    }

    /**
     * Sanitize social media content for display
     * Handles emojis, hashtags, mentions and special characters
     *
     * @param string $content Social media post content
     * @param bool $preserveLinks Keep URLs as clickable links
     * @return string Sanitized content
     */
    public static function sanitizeSocialContent($content, $preserveLinks = true)
    {
        // First sanitize the basic content
        $content = self::sanitize($content);

        // Preserve hashtags with special formatting
        $content = preg_replace('/(#\w+)/', '<span class="hashtag">$1</span>', $content);

        // Preserve mentions with special formatting
        $content = preg_replace('/(@\w+)/', '<span class="mention">$1</span>', $content);

        // Convert URLs to clickable links if requested
        if ($preserveLinks) {
            $urlPattern = '/(https?:\/\/[^\s]+)/';
            $content = preg_replace($urlPattern, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>', $content);
        }

        return $content;
    }

    /**
     * Format a date according to the given format
     *
     * @param string|int|\DateTime $date
     * @param string $format
     * @return string
     */
    public static function formatDate($date, $format = 'Y-m-d H:i:s')
    {
        if (is_numeric($date)) {
            $date = new \DateTime('@' . $date);
        } elseif (is_string($date)) {
            $date = new \DateTime($date);
        }

        return $date->format($format);
    }

    /**
     * Format social media timestamp in a human-readable way
     * (e.g., "5 minutes ago", "2 hours ago", "yesterday", etc.)
     *
     * @param string|int|\DateTime $timestamp
     * @return string
     */
    public static function formatSocialTimestamp($timestamp)
    {
        if (is_numeric($timestamp)) {
            $date = new \DateTime('@' . $timestamp);
        } elseif (is_string($timestamp)) {
            $date = new \DateTime($timestamp);
        } elseif ($timestamp instanceof \DateTime) {
            $date = $timestamp;
        } else {
            return '';
        }

        $now = new \DateTime();
        $diff = $now->diff($date);
        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = [
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        ];

        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$diff->invert) {
            return 'just now';
        }

        $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }

    /**
     * Generate a random string
     *
     * @param int $length
     * @param string $characters
     * @return string
     */
    public static function randomString($length = 10, $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
    {
        $charactersLength = strlen($characters);
        $randomString = '';

        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[random_int(0, $charactersLength - 1)];
        }

        return $randomString;
    }

    /**
     * Shorten a text to a specified length
     *
     * @param string $text
     * @param int $length
     * @param string $suffix
     * @return string
     */
    public static function truncate($text, $length = 100, $suffix = '...')
    {
        if (strlen($text) <= $length) {
            return $text;
        }

        return substr($text, 0, $length) . $suffix;
    }

    /**
     * Convert a string to slug format
     *
     * @param string $text
     * @return string
     */
    public static function slugify($text)
    {
        // Replace non letter or digits by -
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);

        // Transliterate
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

        // Remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);

        // Trim
        $text = trim($text, '-');

        // Remove duplicate -
        $text = preg_replace('~-+~', '-', $text);

        // Lowercase
        $text = strtolower($text);

        return $text ?: 'n-a';
    }

    /**
     * Check if string starts with a given substring
     *
     * @param string $haystack
     * @param string $needle
     * @return bool
     */
    public static function startsWith($haystack, $needle)
    {
        return substr($haystack, 0, strlen($needle)) === $needle;
    }

    /**
     * Check if string ends with a given substring
     *
     * @param string $haystack
     * @param string $needle
     * @return bool
     */
    public static function endsWith($haystack, $needle)
    {
        return substr($haystack, -strlen($needle)) === $needle;
    }

    /**
     * Convert bytes to human readable format
     *
     * @param int $bytes
     * @param int $precision
     * @return string
     */
    public static function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];

        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);

        $bytes /= pow(1024, $pow);

        return round($bytes, $precision) . ' ' . $units[$pow];
    }

    /**
     * Get client IP address
     *
     * @return string
     */
    public static function getClientIp()
    {
        $ipAddress = '';

        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ipAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
            $ipAddress = $_SERVER['HTTP_X_FORWARDED'];
        } elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
            $ipAddress = $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_FORWARDED'])) {
            $ipAddress = $_SERVER['HTTP_FORWARDED'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ipAddress = $_SERVER['REMOTE_ADDR'];
        } else {
            $ipAddress = 'UNKNOWN';
        }

        return $ipAddress;
    }

    /**
     * Redirect to another URL
     *
     * @param string $url
     * @param int $statusCode
     * @return void
     */
    public static function redirect($url, $statusCode = 302)
    {
        header('Location: ' . $url, true, $statusCode);
        exit;
    }

    /**
     * Generate a token for CSRF protection
     *
     * @return string
     */
    public static function generateCsrfToken()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['csrf_token'];
    }

    /**
     * Verify CSRF token
     *
     * @param string $token
     * @return bool
     */
    public static function verifyCsrfToken($token)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['csrf_token']) || !$token) {
            return false;
        }

        return hash_equals($_SESSION['csrf_token'], $token);
    }

    /**
     * Extract all hashtags from a social media post
     *
     * @param string $text
     * @return array Array of hashtags (without the # symbol)
     */
    public static function extractHashtags($text)
    {
        preg_match_all('/#(\w+)/', $text, $matches);
        return $matches[1];
    }

    /**
     * Extract all mentions from a social media post
     *
     * @param string $text
     * @return array Array of mentions (without the @ symbol)
     */
    public static function extractMentions($text)
    {
        preg_match_all('/@(\w+)/', $text, $matches);
        return $matches[1];
    }

    /**
     * Extract all URLs from a social media post
     *
     * @param string $text
     * @return array Array of URLs
     */
    public static function extractUrls($text)
    {
        preg_match_all('/(https?:\/\/[^\s]+)/', $text, $matches);
        return $matches[1];
    }

    /**
     * Calculate engagement rate for a social media post
     *
     * @param int $likes Number of likes
     * @param int $comments Number of comments
     * @param int $shares Number of shares
     * @param int $followers Account followers count
     * @param string $platform Social media platform name
     * @return float Engagement rate percentage
     */
    public static function calculateEngagementRate($likes, $comments, $shares, $followers, $platform = 'default')
    {
        if ($followers <= 0) {
            return 0;
        }

        // Different platforms may use different engagement calculations
        switch (strtolower($platform)) {
            case 'instagram':
                // Instagram: (likes + comments) / followers * 100
                return (($likes + $comments) / $followers) * 100;

            case 'facebook':
                // Facebook considers shares more valuable
                return (($likes * 1 + $comments * 2 + $shares * 3) / $followers) * 100;

            case 'twitter':
            case 'x':
                // Twitter/X weighs retweets highly
                return (($likes * 1 + $comments * 2 + $shares * 3) / $followers) * 100;

            case 'linkedin':
                // LinkedIn focuses more on comments
                return (($likes * 1 + $comments * 3 + $shares * 2) / $followers) * 100;

            default:
                // Generic engagement rate
                return (($likes + $comments + $shares) / $followers) * 100;
        }
    }

    /**
     * Categorize sentiment of a social media post
     * Basic implementation - for advanced analysis use the SentimentAnalyzer class
     *
     * @param string $text
     * @return string 'positive', 'negative', or 'neutral'
     */
    public static function quickSentimentAnalysis($text)
    {
        $text = strtolower($text);

        // Very basic positive words list
        $positiveWords = [
            'good', 'great', 'excellent', 'amazing', 'awesome', 'fantastic',
            'wonderful', 'love', 'happy', 'best', 'beautiful', 'perfect', 'thanks',
            'excited', 'like', 'enjoy', 'impressive', 'impressive'
        ];

        // Very basic negative words list
        $negativeWords = [
            'bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike', 'poor',
            'worst', 'disappointed', 'disappointing', 'sad', 'ugly', 'failure',
            'broken', 'problem', 'issue', 'annoying', 'useless'
        ];

        $positiveScore = 0;
        $negativeScore = 0;

        foreach ($positiveWords as $word) {
            $positiveScore += substr_count($text, $word);
        }

        foreach ($negativeWords as $word) {
            $negativeScore += substr_count($text, $word);
        }

        if ($positiveScore > $negativeScore) {
            return 'positive';
        } elseif ($negativeScore > $positiveScore) {
            return 'neutral';
        } else {
            return 'neutral';
        }
    }
}