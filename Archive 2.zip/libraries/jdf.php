<?php
/**
 * jdf.php - Jalali Date Functions
 *
 * کتابخانه توابع تاریخ جلالی (شمسی) برای پروژه ادامه‌ای
 * این کتابخانه برای تبدیل تاریخ میلادی به شمسی و بالعکس استفاده می‌شود
 *
 * @author Reza Gholampanahi
 * @version 2.0.0
 */

/**
 * تبدیل تاریخ میلادی به شمسی
 *
 * @param string $g_date تاریخ میلادی با فرمت Y-m-d یا timestamp
 * @param string $format فرمت خروجی
 * @return string تاریخ شمسی
 */
function gregorian_to_jalali($g_date, $format = 'Y/m/d') {
    // اگر تاریخ به صورت timestamp باشد
    if (is_numeric($g_date) && strlen($g_date) > 6) {
        $g_date = date('Y-m-d', $g_date);
    }

    // جداسازی سال، ماه و روز میلادی
    $g_date = explode('-', $g_date);
    $g_y = (int) $g_date[0];
    $g_m = (int) $g_date[1];
    $g_d = (int) $g_date[2];

    // محاسبات تبدیل تاریخ
    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

    // بررسی سال کبیسه
    $gy = $g_y - 1600;
    $gm = $g_m - 1;
    $gd = $g_d - 1;

    $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);

    for ($i = 0; $i < $gm; ++$i) {
        $g_day_no += $g_days_in_month[$i];
    }

    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0))) {
        $g_day_no++;
    }

    $g_day_no += $gd;

    $j_day_no = $g_day_no - 79;
    $j_np = floor($j_day_no / 12053);
    $j_day_no %= 12053;
    $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
    $j_day_no %= 1461;

    if ($j_day_no >= 366) {
        $jy += floor(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }

    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) {
        $j_day_no -= $j_days_in_month[$i];
    }

    $jm = $i + 1;
    $jd = $j_day_no + 1;

    // فرمت‌بندی خروجی
    $output = $format;
    $output = str_replace('Y', $jy, $output);
    $output = str_replace('y', substr($jy, 2), $output);
    $output = str_replace('m', str_pad($jm, 2, '0', STR_PAD_LEFT), $output);
    $output = str_replace('n', $jm, $output);
    $output = str_replace('d', str_pad($jd, 2, '0', STR_PAD_LEFT), $output);
    $output = str_replace('j', $jd, $output);

    return $output;
}

/**
 * تبدیل تاریخ شمسی به میلادی
 *
 * @param string $j_date تاریخ شمسی با فرمت Y/m/d
 * @param string $format فرمت خروجی
 * @return string تاریخ میلادی
 */
function jalali_to_gregorian($j_date, $format = 'Y-m-d') {
    // جداسازی سال، ماه و روز شمسی
    $j_date = str_replace(['/', '-', '\\', '.'], '-', $j_date);
    $j_date = explode('-', $j_date);
    $j_y = (int) $j_date[0];
    $j_m = (int) $j_date[1];
    $j_d = (int) $j_date[2];

    // محاسبات تبدیل تاریخ
    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

    $jy = $j_y - 979;
    $jm = $j_m - 1;
    $jd = $j_d - 1;

    $j_day_no = 365 * $jy + floor($jy / 33) * 8 + floor(($jy % 33 + 3) / 4);

    for ($i = 0; $i < $jm; ++$i) {
        $j_day_no += $j_days_in_month[$i];
    }

    $j_day_no += $jd;

    $g_day_no = $j_day_no + 79;

    $gy = 1600 + 400 * floor($g_day_no / 146097);
    $g_day_no %= 146097;

    $leap = true;
    if ($g_day_no >= 36525) {
        $g_day_no--;
        $gy += 100 * floor($g_day_no / 36524);
        $g_day_no %= 36524;

        if ($g_day_no >= 365) {
            $g_day_no++;
        } else {
            $leap = false;
        }
    }

    $gy += 4 * floor($g_day_no / 1461);
    $g_day_no %= 1461;

    if ($g_day_no >= 366) {
        $leap = false;
        $g_day_no--;
        $gy += floor($g_day_no / 365);
        $g_day_no %= 365;
    }

    for ($i = 0; $g_day_no >= $g_days_in_month[$i] + ($i == 1 && $leap); $i++) {
        $g_day_no -= $g_days_in_month[$i] + ($i == 1 && $leap);
    }

    $gm = $i + 1;
    $gd = $g_day_no + 1;

    // فرمت‌بندی خروجی
    $output = $format;
    $output = str_replace('Y', $gy, $output);
    $output = str_replace('y', substr($gy, 2), $output);
    $output = str_replace('m', str_pad($gm, 2, '0', STR_PAD_LEFT), $output);
    $output = str_replace('n', $gm, $output);
    $output = str_replace('d', str_pad($gd, 2, '0', STR_PAD_LEFT), $output);
    $output = str_replace('j', $gd, $output);

    return $output;
}

/**
 * نمایش نام ماه شمسی
 *
 * @param int $month شماره ماه (1-12)
 * @return string نام ماه
 */
function jdate_month_name($month) {
    $months = [
        1 => 'فروردین',
        2 => 'اردیبهشت',
        3 => 'خرداد',
        4 => 'تیر',
        5 => 'مرداد',
        6 => 'شهریور',
        7 => 'مهر',
        8 => 'آبان',
        9 => 'آذر',
        10 => 'دی',
        11 => 'بهمن',
        12 => 'اسفند'
    ];

    return $months[$month] ?? '';
}

/**
 * نمایش نام روز هفته شمسی
 *
 * @param int $day شماره روز هفته (0-6)
 * @return string نام روز
 */
function jdate_day_name($day) {
    $days = [
        0 => 'یکشنبه',
        1 => 'دوشنبه',
        2 => 'سه‌شنبه',
        3 => 'چهارشنبه',
        4 => 'پنج‌شنبه',
        5 => 'جمعه',
        6 => 'شنبه'
    ];

    return $days[$day] ?? '';
}

/**
 * تبدیل اعداد انگلیسی به فارسی
 *
 * @param string $str متن حاوی اعداد انگلیسی
 * @return string متن با اعداد فارسی
 */
function en_to_fa_numbers($str) {
    $fa_numbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $en_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

    return str_replace($en_numbers, $fa_numbers, $str);
}

/**
 * تبدیل اعداد فارسی به انگلیسی
 *
 * @param string $str متن حاوی اعداد فارسی
 * @return string متن با اعداد انگلیسی
 */
function fa_to_en_numbers($str) {
    $fa_numbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $en_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

    return str_replace($fa_numbers, $en_numbers, $str);
}

/**
 * تاریخ و زمان شمسی
 *
 * @param string $format فرمت خروجی
 * @param int|null $timestamp زمان یونیکس
 * @param bool $fa_numbers تبدیل اعداد به فارسی
 * @return string تاریخ و زمان شمسی
 */
function jdate($format, $timestamp = null, $fa_numbers = true) {
    // تنظیم timestamp
    if ($timestamp === null) {
        $timestamp = time();
    }

    // دریافت تاریخ و زمان میلادی
    $date = date('Y-m-d', $timestamp);
    $time = date('H:i:s', $timestamp);

    // تبدیل تاریخ به شمسی
    $jalali_date = gregorian_to_jalali($date, 'Y/m/d');
    list($j_y, $j_m, $j_d) = explode('/', $jalali_date);

    // محاسبه روز هفته
    $w = date('w', $timestamp);

    // جایگزینی ماه‌های شمسی و نام روزها
    $format = str_replace(['F', 'M'], ['xxxx', 'xxx'], $format);

    // جایگزینی سایر پارامترهای فرمت
    $date = date($format, $timestamp);
    $date = str_replace(['xxxx', 'xxx'], [jdate_month_name((int) $j_m), mb_substr(jdate_month_name((int) $j_m), 0, 3, 'UTF-8')], $date);

    // جایگزینی تاریخ شمسی
    $date = str_replace(['Y', 'y', 'm', 'n', 'd', 'j', 'l', 'D', 'w'], [
        $j_y,
        substr($j_y, 2),
        str_pad($j_m, 2, '0', STR_PAD_LEFT),
        $j_m,
        str_pad($j_d, 2, '0', STR_PAD_LEFT),
        $j_d,
        jdate_day_name($w),
        mb_substr(jdate_day_name($w), 0, 3, 'UTF-8'),
        $w
    ], $date);

    // تبدیل اعداد به فارسی در صورت نیاز
    if ($fa_numbers) {
        $date = en_to_fa_numbers($date);
    }

    return $date;
}

/**
 * تبدیل تاریخ و زمان به شکل "چند دقیقه/ساعت/روز/هفته/ماه/سال پیش"
 *
 * @param int|string $timestamp زمان یونیکس یا تاریخ میلادی
 * @param bool $fa_numbers تبدیل اعداد به فارسی
 * @return string زمان نسبی
 */
function jdate_ago($timestamp, $fa_numbers = true) {
    if (!is_numeric($timestamp)) {
        $timestamp = strtotime($timestamp);
    }

    $diff = time() - $timestamp;

    if ($diff < 60) {
        $text = 'چند لحظه پیش';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        $text = $mins . ' دقیقه پیش';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        $text = $hours . ' ساعت پیش';
    } elseif ($diff < 2592000) {
        $days = floor($diff / 86400);
        if ($days == 1) {
            $text = 'دیروز';
        } else {
            $text = $days . ' روز پیش';
        }
    } elseif ($diff < 31536000) {
        $months = floor($diff / 2592000);
        $text = $months . ' ماه پیش';
    } else {
        $years = floor($diff / 31536000);
        $text = $years . ' سال پیش';
    }

    // تبدیل اعداد به فارسی در صورت نیاز
    if ($fa_numbers) {
        $text = en_to_fa_numbers($text);
    }

    return $text;
}

/**
 * محاسبه سن براساس تاریخ تولد شمسی
 *
 * @param string $birth_date تاریخ تولد شمسی با فرمت Y/m/d
 * @return int سن
 */
function jdate_calculate_age($birth_date) {
    // تبدیل تاریخ تولد شمسی به میلادی
    $birth_date_gregorian = jalali_to_gregorian($birth_date);

    // محاسبه سن
    $birth_date = new DateTime($birth_date_gregorian);
    $today = new DateTime('today');
    $age = $birth_date->diff($today)->y;

    return $age;
}

/**
 * بررسی معتبر بودن تاریخ شمسی
 *
 * @param string $date تاریخ شمسی با فرمت Y/m/d
 * @return bool نتیجه بررسی
 */
function jdate_is_valid($date) {
    // حذف جداکننده‌ها و تبدیل به آرایه
    $date = str_replace(['/', '-', '\\', '.'], '-', $date);
    $date_parts = explode('-', $date);

    if (count($date_parts) !== 3) {
        return false;
    }

    $j_y = (int) $date_parts[0];
    $j_m = (int) $date_parts[1];
    $j_d = (int) $date_parts[2];

    // بررسی محدوده مجاز سال، ماه و روز
    if ($j_y < 1300 || $j_y > 1500 || $j_m < 1 || $j_m > 12 || $j_d < 1 || $j_d > 31) {
        return false;
    }

    // بررسی تعداد روزهای ماه
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

    // بررسی سال کبیسه
    if ($j_m == 12 && $j_d == 30 && (($j_y % 33 % 4) - 1) == (int) (($j_y % 33) / 4)) {
        return true;
    }

    if ($j_d > $j_days_in_month[$j_m - 1]) {
        return false;
    }

    return true;
}