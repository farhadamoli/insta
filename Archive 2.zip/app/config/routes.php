<?php
/**
 * routes.php - مسیرهای پروژه ادامه‌ای
 *
 * این فایل شامل تمام مسیرهای تعریف شده برای برنامه است
 */

// میان‌افزارهای عمومی برای کل برنامه
$router->middleware('Security');

//----------------------------------------
// مسیرهای عمومی
//----------------------------------------

// صفحه اصلی
$router->get('/', 'HomeController@index');
$router->get('/about', 'HomeController@about');
$router->get('/contact', 'HomeController@contact');
$router->post('/contact', 'HomeController@submitContact');
$router->get('/terms', 'HomeController@terms');
$router->get('/privacy', 'HomeController@privacy');

// تنظیم زبان
$router->get('/language/set', 'LanguageController@setLanguage');
$router->get('/language/selector', 'LanguageController@showLanguageSelector');

//----------------------------------------
// مسیرهای احراز هویت
//----------------------------------------
$router->group('/auth', function ($router) {
    $router->get('/login', 'AuthController@showLogin');
    $router->post('/login', 'AuthController@login');
    $router->get('/register', 'AuthController@showRegister');
    $router->post('/register', 'AuthController@register');
    $router->get('/logout', 'AuthController@logout');
    $router->get('/forgot-password', 'AuthController@showForgotPassword');
    $router->post('/forgot-password', 'AuthController@forgotPassword');
    $router->get('/reset-password/{token}', 'AuthController@showResetPassword');
    $router->post('/reset-password', 'AuthController@resetPassword');
    $router->get('/verify-email/{token}', 'AuthController@verifyEmail');
});

//----------------------------------------
// مسیرهای داشبورد کاربر (با احراز هویت)
//----------------------------------------
$router->group('/dashboard', function ($router) {
    $router->get('/', 'DashboardController@index');
    $router->get('/profile', 'DashboardController@profile');
    $router->post('/profile', 'DashboardController@updateProfile');
    $router->get('/settings', 'DashboardController@settings');
    $router->post('/settings', 'DashboardController@updateSettings');
    $router->get('/change-password', 'DashboardController@showChangePassword');
    $router->post('/change-password', 'DashboardController@changePassword');
}, ['Auth']);

//----------------------------------------
// مسیرهای مدیریت رسانه‌های اجتماعی
//----------------------------------------
$router->group('/monitoring', function ($router) {
    $router->get('/', 'MonitoringController@index');
    $router->get('/platforms', 'MonitoringController@platforms');
    $router->get('/keywords', 'MonitoringController@keywords');
    $router->post('/keywords', 'MonitoringController@addKeyword');
    $router->delete('/keywords/{id}', 'MonitoringController@deleteKeyword');
    $router->get('/mentions', 'MonitoringController@mentions');
    $router->get('/mentions/{id}', 'MonitoringController@mentionDetails');
    $router->get('/alerts', 'MonitoringController@alerts');
    $router->post('/alerts', 'MonitoringController@addAlert');
    $router->delete('/alerts/{id}', 'MonitoringController@deleteAlert');
}, ['Auth']);

//----------------------------------------
// مسیرهای تحلیل‌ها
//----------------------------------------
$router->group('/analytics', function ($router) {
    $router->get('/', 'AnalyticsController@index');
    $router->get('/sentiment', 'AnalyticsController@sentiment');
    $router->get('/trends', 'AnalyticsController@trends');
    $router->get('/comparison', 'AnalyticsController@comparison');
    $router->get('/export/{type}', 'AnalyticsController@export');
}, ['Auth']);

//----------------------------------------
// مسیرهای گزارش‌ها
//----------------------------------------
$router->group('/reports', function ($router) {
    $router->get('/', 'ReportController@index');
    $router->get('/create', 'ReportController@create');
    $router->post('/create', 'ReportController@store');
    $router->get('/{id}', 'ReportController@show');
    $router->get('/{id}/edit', 'ReportController@edit');
    $router->post('/{id}/edit', 'ReportController@update');
    $router->delete('/{id}', 'ReportController@delete');
    $router->get('/{id}/export/{type}', 'ReportController@export');
}, ['Auth']);

//----------------------------------------
// مسیرهای مدیریت فایل‌ها و آپلود
//----------------------------------------
$router->group('/upload', function ($router) {
    $router->post('/profile-image', 'UploadController@uploadProfileImage');
    $router->post('/content-file', 'UploadController@uploadContentFile');
    $router->post('/temp-file', 'UploadController@uploadTempFile');
    $router->post('/move-temp', 'UploadController@moveTempFile');
    $router->post('/delete', 'UploadController@deleteFile');
    $router->get('/files', 'UploadController@getUserFiles');
}, ['Auth']);

//----------------------------------------
// مسیرهای پرداخت و اشتراک
//----------------------------------------
$router->group('/payment', function ($router) {
    $router->get('/plans', 'PaymentController@showPlans');
    $router->get('/checkout', 'PaymentController@showCheckout');
    $router->post('/process', 'PaymentController@processPayment');
    $router->get('/verify', 'PaymentController@verify');
    $router->get('/result', 'PaymentController@showPaymentResult');
    $router->get('/history', 'PaymentController@showHistory');
    $router->get('/invoice', 'PaymentController@showInvoice');
    $router->get('/invoice/download', 'PaymentController@downloadInvoice');
}, ['Auth']);

//----------------------------------------
// مسیرهای پشتیبانی
//----------------------------------------
$router->group('/support', function ($router) {
    $router->get('/', 'SupportController@index');
    $router->get('/tickets', 'SupportController@tickets');
    $router->get('/tickets/create', 'SupportController@createTicket');
    $router->post('/tickets/create', 'SupportController@storeTicket');
    $router->get('/tickets/{id}', 'SupportController@showTicket');
    $router->post('/tickets/{id}/reply', 'SupportController@replyTicket');
    $router->get('/faq', 'SupportController@faq');
    $router->get('/documentation', 'SupportController@documentation');
}, ['Auth']);

//----------------------------------------
// مسیرهای بخش مدیریت (ادمین)
//----------------------------------------
$router->group('/admin', function ($router) {
    $router->get('/', 'AdminController@index');

    // مدیریت کاربران
    $router->get('/users', 'AdminController@users');
    $router->get('/users/{id}', 'AdminController@userDetails');
    $router->post('/users/{id}', 'AdminController@updateUser');
    $router->delete('/users/{id}', 'AdminController@deleteUser');

    // مدیریت اشتراک‌ها
    $router->get('/subscriptions', 'AdminController@subscriptions');
    $router->get('/subscriptions/create', 'AdminController@createSubscription');
    $router->post('/subscriptions/create', 'AdminController@storeSubscription');
    $router->get('/subscriptions/{id}/edit', 'AdminController@editSubscription');
    $router->post('/subscriptions/{id}/edit', 'AdminController@updateSubscription');
    $router->delete('/subscriptions/{id}', 'AdminController@deleteSubscription');

    // مدیریت پرداخت‌ها
    $router->get('/payments', 'AdminController@adminIndex');
    $router->get('/payments/view', 'AdminController@adminViewPayment');
    $router->post('/payments/refund', 'AdminController@adminRefundPayment');
    $router->post('/payments/update-status', 'AdminController@adminUpdatePaymentStatus');

    // مدیریت تیکت‌های پشتیبانی
    $router->get('/tickets', 'AdminController@tickets');
    $router->get('/tickets/{id}', 'AdminController@showTicket');
    $router->post('/tickets/{id}/reply', 'AdminController@replyTicket');
    $router->post('/tickets/{id}/close', 'AdminController@closeTicket');

    // تنظیمات سیستم
    $router->get('/settings', 'AdminController@settings');
    $router->post('/settings', 'AdminController@updateSettings');

    // مدیریت فایل‌ها
    $router->get('/files', 'AdminController@files');
    $router->post('/files/delete', 'AdminController@deleteFile');
    $router->get('/files/cleanup', 'AdminController@showCleanup');
    $router->post('/files/cleanup', 'AdminController@cleanupFiles');
}, ['Auth', 'AdminOnly']);

//----------------------------------------
// مسیرهای API
//----------------------------------------
$router->group('/api', function ($router) {
    // API اصلی
    $router->get('/platforms', 'ApiController@getPlatforms');
    $router->get('/mentions', 'ApiController@getMentions');
    $router->get('/keywords', 'ApiController@getKeywords');
    $router->get('/stats', 'ApiController@getStats');

    // API نگهداری سیستم (فقط برای کرون جاب‌ها)
    $router->get('/maintenance/cleanup-temp', 'UploadController@cleanupTempFiles');
    $router->get('/maintenance/clear-old-logs', 'MaintenanceController@clearOldLogs');
}, ['ApiAuth']);

//----------------------------------------
// مسیریاب پیش‌فرض (صفحه 404)
//----------------------------------------
$router->fallback('ErrorController@notFound');