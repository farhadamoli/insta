<?php

/**
 * config.php - تنظیمات اصلی پروژه ادامه‌ای
 *
 * این فایل شامل ثابت‌ها و تنظیمات اصلی پروژه است
 */

// جلوگیری از خطاهای تنظیمات نشست
if (!isset($_SESSION)) {
    session_start();
}

// تنظیمات پایگاه داده
define('DB_HOST', 'localhost');
define('DB_NAME', 'socialkoch2');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// تنظیمات برنامه
define('APP_NAME', 'ادامه‌ای');
define('APP_URL', 'http://localhost/insta_new');
define('APP_VERSION', '1.0.0');
define('APP_EMAIL', 'info@edameye.com');

// تنظیمات زبان
define('DEFAULT_LANG', 'fa');

// تنظیمات امنیتی
define('AUTH_SALT', 'your-secure-auth-salt-here');
define('JWT_SECRET', 'your-secure-jwt-secret-here');
define('CSRF_TOKEN_EXPIRE', 3600); // 1 ساعت
define('PASSWORD_MIN_LENGTH', 8);
define('SESSION_EXPIRE', 7200); // 2 ساعت

// تنظیمات ایمیل
define('MAIL_DRIVER', 'smtp');
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'your-email@gmail.com');
define('MAIL_PASSWORD', 'your-email-password');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'noreply@edameye.com');
define('MAIL_FROM_NAME', 'ادامه‌ای');

// تنظیمات آپلود فایل
define('UPLOAD_MAX_SIZE', 50 * 1024 * 1024); // 50 مگابایت
define('ALLOWED_IMAGE_TYPES', 'jpg,jpeg,png,gif,webp');
define('ALLOWED_FILE_TYPES', 'pdf,doc,docx,xls,xlsx,ppt,pptx,txt,csv,zip');

// تنظیمات کش
define('CACHE_ENABLE', true);
define('CACHE_EXPIRE', 3600); // 1 ساعت

// تنظیمات لاگ
define('LOG_ENABLE', true);
define('LOG_LEVEL', 'error'); // debug, info, warning, error
define('LOG_FILE', ROOT_PATH . '/logs/app.log');

// کلیدهای API
define('ZARINPAL_MERCHANT_ID', 'your-zarinpal-merchant-id');
define('ZARINPAL_CALLBACK_URL', APP_URL . '/payment/verify');

// تنظیمات مربوط به نظارت رسانه‌های اجتماعی
define('INSTAGRAM_API_KEY', 'your-instagram-api-key');
define('TWITTER_API_KEY', 'your-twitter-api-key');
define('TWITTER_API_SECRET', 'your-twitter-api-secret');
define('TWITTER_ACCESS_TOKEN', 'your-twitter-access-token');
define('TWITTER_ACCESS_SECRET', 'your-twitter-access-secret');

// تنظیمات مربوط به امنیت API
define('API_RATE_LIMIT', 100); // تعداد درخواست در هر ساعت
define('API_TOKEN_EXPIRE', 86400); // 24 ساعت
define('CLEANUP_API_KEY', 'your-secure-cleanup-api-key');

// تنظیمات مرتبط با Admin
define('ADMIN_EMAIL', 'admin@edameye.com');

// تنظیمات مربوط به محیط‌های مختلف
$environment = DEVELOPMENT_ENVIRONMENT ? 'development' : 'production';

$config = [
    'development' => [
        'display_errors' => true,
        'debug' => true,
        'cache' => false,
        'minify_assets' => false
    ],
    'production' => [
        'display_errors' => false,
        'debug' => false,
        'cache' => true,
        'minify_assets' => true
    ]
];

// اعمال تنظیمات محیط فعلی
$current_config = $config[$environment];
foreach ($current_config as $key => $value) {
    define(strtoupper($key), $value);
}

// تنظیم نمایش خطاها براساس محیط
ini_set('display_errors', DISPLAY_ERRORS ? 1 : 0);
error_reporting(DISPLAY_ERRORS ? E_ALL : 0);

// تنظیم منطقه زمانی
date_default_timezone_set('Asia/Tehran');

// تنظیمات مرتبط با اشتراک‌ها
$subscription_plans = [
    'free' => [
        'name' => 'رایگان',
        'price' => 0,
        'duration' => 1, // ماه
        'features' => [
            'platforms' => 1,
            'keywords' => 5,
            'mentions' => 100,
            'reports' => false,
            'alerts' => false,
            'analytics' => false
        ]
    ],
    'basic' => [
        'name' => 'پایه',
        'price' => 99000,
        'duration' => 1, // ماه
        'features' => [
            'platforms' => 3,
            'keywords' => 20,
            'mentions' => 1000,
            'reports' => true,
            'alerts' => true,
            'analytics' => false
        ]
    ],
    'professional' => [
        'name' => 'حرفه‌ای',
        'price' => 199000,
        'duration' => 1, // ماه
        'features' => [
            'platforms' => 5,
            'keywords' => 50,
            'mentions' => 5000,
            'reports' => true,
            'alerts' => true,
            'analytics' => true
        ]
    ],
    'enterprise' => [
        'name' => 'سازمانی',
        'price' => 499000,
        'duration' => 1, // ماه
        'features' => [
            'platforms' => 'نامحدود',
            'keywords' => 'نامحدود',
            'mentions' => 'نامحدود',
            'reports' => true,
            'alerts' => true,
            'analytics' => true
        ]
    ]
];

// تعریف ثابت برای اشتراک‌ها
define('SUBSCRIPTION_PLANS', json_encode($subscription_plans));