<?php

/**
 * ReportController.php
 *
 * کنترلر مدیریت گزارش‌ها در پروژه ادامه‌ای
 */

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Auth;

class ReportController extends Controller {

    /**
     * سازنده کلاس
     */
    public function __construct() {
        parent::__construct();

        // تنظیم میان‌افزارها - فقط کاربران لاگین شده دسترسی دارند
        $this->middleware('Auth');
    }

    /**
     * نمایش صفحه اصلی گزارش‌ها
     *
     * @param Request $request
     * @param Response $response
     */
    public function index(Request $request, Response $response) {
        // نمونه کد برای نمایش صفحه اصلی گزارش‌ها
        return $this->render('reports/index', [
            'title' => 'گزارش‌ها | ادامه‌ای',
            'reports' => [], // در نسخه نهایی، این داده‌ها از دیتابیس خوانده می‌شوند
            'page' => 'reports'
        ]);
    }

    /**
     * نمایش صفحه ایجاد گزارش جدید
     *
     * @param Request $request
     * @param Response $response
     */
    public function create(Request $request, Response $response) {
        // نمونه کد برای نمایش فرم ایجاد گزارش جدید
        return $this->render('reports/create', [
            'title' => 'ایجاد گزارش جدید | ادامه‌ای',
            'platforms' => [], // لیست پلتفرم‌ها
            'keywords' => [], // لیست کلمات کلیدی
            'page' => 'reports'
        ]);
    }

    /**
     * ذخیره گزارش جدید
     *
     * @param Request $request
     * @param Response $response
     */
    public function store(Request $request, Response $response) {
        // نمونه کد برای پردازش فرم ایجاد گزارش
        $title = $request->getPost('title');
        $description = $request->getPost('description');
        $platforms = $request->getPost('platforms');
        $keywords = $request->getPost('keywords');
        $dateRange = $request->getPost('date_range');

        // اعتبارسنجی داده‌ها
        $validation = $this->validate([
            'title' => $title,
            'description' => $description,
            'platforms' => $platforms,
            'keywords' => $keywords,
            'date_range' => $dateRange
        ], [
            'title' => 'required|max:100',
            'platforms' => 'required'
        ]);

        if ($validation !== true) {
            // در صورت خطای اعتبارسنجی
            if ($request->isAjax()) {
                return $this->json([
                    'success' => false,
                    'errors' => $validation
                ]);
            }

            return $this->render('reports/create', [
                'title' => 'ایجاد گزارش جدید | ادامه‌ای',
                'platforms' => [], // لیست پلتفرم‌ها
                'keywords' => [], // لیست کلمات کلیدی
                'errors' => $validation,
                'input' => [
                    'title' => $title,
                    'description' => $description,
                    'platforms' => $platforms,
                    'keywords' => $keywords,
                    'date_range' => $dateRange
                ],
                'page' => 'reports'
            ]);
        }

        // در نسخه نهایی، این داده‌ها در دیتابیس ذخیره می‌شوند

        // ارسال پاسخ
        if ($request->isAjax()) {
            return $this->json([
                'success' => true,
                'message' => 'گزارش با موفقیت ایجاد شد',
                'redirect' => '/reports'
            ]);
        }

        $this->flash('success', 'گزارش با موفقیت ایجاد شد');
        return $this->redirect('/reports');
    }

    /**
     * نمایش جزئیات گزارش
     *
     * @param Request $request
     * @param Response $response
     * @param array $params پارامترهای URL
     */
    public function show(Request $request, Response $response, $params) {
        $id = isset($params['id']) ? $params['id'] : null;

        if (!$id) {
            return $this->redirect('/reports', ['error' => 'شناسه گزارش نامعتبر است']);
        }

        // در نسخه نهایی، اطلاعات گزارش از دیتابیس خوانده می‌شود
        $report = [
            'id' => $id,
            'title' => 'گزارش نمونه',
            'description' => 'این یک گزارش نمونه است',
            'platforms' => ['twitter', 'instagram'],
            'keywords' => ['ادامه‌ای', 'رسانه اجتماعی'],
            'created_at' => date('Y-m-d H:i:s'),
            'user_id' => Auth::getUserId()
        ];

        return $this->render('reports/show', [
            'title' => $report['title'] . ' | ادامه‌ای',
            'report' => $report,
            'charts' => [], // داده‌های نمودارها
            'mentions' => [], // لیست منشن‌ها
            'page' => 'reports'
        ]);
    }

    /**
     * نمایش صفحه ویرایش گزارش
     *
     * @param Request $request
     * @param Response $response
     * @param array $params پارامترهای URL
     */
    public function edit(Request $request, Response $response, $params) {
        $id = isset($params['id']) ? $params['id'] : null;

        if (!$id) {
            return $this->redirect('/reports', ['error' => 'شناسه گزارش نامعتبر است']);
        }

        // در نسخه نهایی، اطلاعات گزارش از دیتابیس خوانده می‌شود
        $report = [
            'id' => $id,
            'title' => 'گزارش نمونه',
            'description' => 'این یک گزارش نمونه است',
            'platforms' => ['twitter', 'instagram'],
            'keywords' => ['ادامه‌ای', 'رسانه اجتماعی'],
            'created_at' => date('Y-m-d H:i:s'),
            'user_id' => Auth::getUserId()
        ];

        return $this->render('reports/edit', [
            'title' => 'ویرایش گزارش | ادامه‌ای',
            'report' => $report,
            'platforms' => [], // لیست پلتفرم‌ها
            'keywords' => [], // لیست کلمات کلیدی
            'page' => 'reports'
        ]);
    }

    /**
     * به‌روزرسانی گزارش
     *
     * @param Request $request
     * @param Response $response
     * @param array $params پارامترهای URL
     */
    public function update(Request $request, Response $response, $params) {
        $id = isset($params['id']) ? $params['id'] : null;

        if (!$id) {
            return $this->redirect('/reports', ['error' => 'شناسه گزارش نامعتبر است']);
        }

        $title = $request->getPost('title');
        $description = $request->getPost('description');
        $platforms = $request->getPost('platforms');
        $keywords = $request->getPost('keywords');

        // اعتبارسنجی داده‌ها
        $validation = $this->validate([
            'title' => $title,
            'description' => $description,
            'platforms' => $platforms,
            'keywords' => $keywords
        ], [
            'title' => 'required|max:100',
            'platforms' => 'required'
        ]);

        if ($validation !== true) {
            // در صورت خطای اعتبارسنجی
            if ($request->isAjax()) {
                return $this->json([
                    'success' => false,
                    'errors' => $validation
                ]);
            }

            return $this->render('reports/edit', [
                'title' => 'ویرایش گزارش | ادامه‌ای',
                'report' => [
                    'id' => $id,
                    'title' => $title,
                    'description' => $description,
                    'platforms' => $platforms,
                    'keywords' => $keywords
                ],
                'platforms' => [], // لیست پلتفرم‌ها
                'keywords' => [], // لیست کلمات کلیدی
                'errors' => $validation,
                'page' => 'reports'
            ]);
        }

        // در نسخه نهایی، این داده‌ها در دیتابیس به‌روزرسانی می‌شوند

        // ارسال پاسخ
        if ($request->isAjax()) {
            return $this->json([
                'success' => true,
                'message' => 'گزارش با موفقیت به‌روزرسانی شد',
                'redirect' => '/reports/' . $id
            ]);
        }

        $this->flash('success', 'گزارش با موفقیت به‌روزرسانی شد');
        return $this->redirect('/reports/' . $id);
    }


    /**
     * حذف گزارش
     *
     * @param Request $request
     * @param Response $response
     * @param array $params پارامترهای URL
     */
    public function delete(Request $request, Response $response, $params) {
        $id = isset($params['id']) ? $params['id'] : null;

        if (!$id) {
            return $this->redirect('/reports', ['error' => 'شناسه گزارش نامعتبر است']);
        }

        // در نسخه نهایی، گزارش از دیتابیس حذف می‌شود

        // ارسال پاسخ
        if ($request->isAjax()) {
            return $this->json([
                'success' => true,
                'message' => 'گزارش با موفقیت حذف شد'
            ]);
        }

        $this->flash('success', 'گزارش با موفقیت حذف شد');
        return $this->redirect('/reports');
    }

    /**
     * خروجی گرفتن از گزارش
     *
     * @param Request $request
     * @param Response $response
     * @param array $params پارامترهای URL
     */
    public function export(Request $request, Response $response, $params) {
        $id = isset($params['id']) ? $params['id'] : null;
        $type = isset($params['type']) ? $params['type'] : 'pdf';

        if (!$id) {
            return $this->redirect('/reports', ['error' => 'شناسه گزارش نامعتبر است']);
        }

        // در نسخه نهایی، داده‌های گزارش از دیتابیس خوانده می‌شوند

        // ارسال خروجی براساس نوع درخواستی
        switch ($type) {
            case 'pdf':
                // کد تولید PDF
                $this->generatePdf($id);
                break;

            case 'excel':
                // کد تولید Excel
                $this->generateExcel($id);
                break;

            case 'csv':
                // کد تولید CSV
                $this->generateCsv($id);
                break;

            default:
                return $this->redirect('/reports/' . $id, ['error' => 'فرمت خروجی نامعتبر است']);
        }
    }

    /**
     * تولید خروجی PDF
     *
     * @param int $reportId شناسه گزارش
     */
    private function generatePdf($reportId) {
        // این متد در نسخه نهایی پیاده‌سازی می‌شود
        echo "Generating PDF for report {$reportId}";
        exit;
    }

    /**
     * تولید خروجی Excel
     *
     * @param int $reportId شناسه گزارش
     */
    private function generateExcel($reportId) {
        // این متد در نسخه نهایی پیاده‌سازی می‌شود
        echo "Generating Excel for report {$reportId}";
        exit;
    }

    /**
     * تولید خروجی CSV
     *
     * @param int $reportId شناسه گزارش
     */
    private function generateCsv($reportId) {
        // این متد در نسخه نهایی پیاده‌سازی می‌شود

        // نمونه داده
        $data = [
            ['id' => 1, 'platform' => 'Twitter', 'keyword' => 'ادامه‌ای', 'mentions' => 150],
            ['id' => 2, 'platform' => 'Instagram', 'keyword' => 'ادامه‌ای', 'mentions' => 230],
            ['id' => 3, 'platform' => 'Twitter', 'keyword' => 'رسانه اجتماعی', 'mentions' => 85],
            ['id' => 4, 'platform' => 'Instagram', 'keyword' => 'رسانه اجتماعی', 'mentions' => 120]
        ];

        // تنظیم هدرهای خروجی
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="report_' . $reportId . '.csv"');

        // ایجاد خروجی CSV
        $output = fopen('php://output', 'w');

        // ایجاد BOM برای UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        // نوشتن سرستون‌ها
        fputcsv($output, array_keys($data[0]));

        // نوشتن داده‌ها
        foreach ($data as $row) {
            fputcsv($output, $row);
        }

        fclose($output);
        exit;
    }
}