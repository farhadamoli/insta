<?php
// app/Controllers/TestController.php

namespace App\Controllers;

class TestController {
    public function index($request, $response) {
        $response->setContent("<h1>تست کنترلر</h1><p>اگر این متن را می‌بینید، سیستم به درستی کار می‌کند!</p>");
        $response->send();
    }
}