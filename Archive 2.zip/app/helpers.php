<?php

/**
 * helpers.php - توابع کمکی برای پروژه ادامه‌ای
 *
 * این فایل شامل توابع کاربردی است که در سراسر برنامه قابل استفاده هستند
 */

/**
 * دریافت مسیر مطلق یک فایل یا پوشه
 *
 * @param string $path مسیر نسبی
 * @return string مسیر مطلق
 */
function base_path($path = '') {
    return ROOT_PATH . ($path ? '/' . ltrim($path, '/') : '');
}

/**
 * دریافت URL پایه برنامه
 *
 * @param string $path مسیر نسبی
 * @return string URL کامل
 */
function base_url($path = '') {
    return APP_URL . ($path ? '/' . ltrim($path, '/') : '');
}

/**
 * دریافت آدرس کامل asset ها
 *
 * @param string $path مسیر فایل
 * @param boolean $version افزودن شماره نسخه به URL
 * @return string URL کامل
 */
function asset($path, $version = true) {
    $url = base_url('assets/' . ltrim($path, '/'));
    return $version ? $url . '?v=' . APP_VERSION : $url;
}

/**
 * تمیز کردن ورودی
 *
 * @param string $input ورودی
 * @return string ورودی تمیز شده
 */
function clean_input($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

/**
 * رمزنگاری رمز عبور
 *
 * @param string $password رمز عبور
 * @return string رمز عبور رمزنگاری شده
 */
function hash_password($password) {
    return password_hash($password . AUTH_SALT, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * بررسی صحت رمز عبور
 *
 * @param string $password رمز عبور وارد شده
 * @param string $hash هش ذخیره شده
 * @return boolean نتیجه بررسی
 */
function verify_password($password, $hash) {
    return password_verify($password . AUTH_SALT, $hash);
}

/**
 * تولید توکن امنیتی
 *
 * @param int $length طول توکن
 * @return string توکن
 */
function generate_token($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * رها کردن خروجی و اتمام اجرای اسکریپت
 *
 * @param mixed $data داده برای نمایش
 * @param string $content_type نوع محتوا
 */
function dd($data, $content_type = 'text/html') {
    header('Content-Type: ' . $content_type);

    if (is_array($data) || is_object($data)) {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    } else {
        echo $data;
    }

    exit;
}

/**
 * تبدیل آرایه به JSON و نمایش آن
 *
 * @param array $data داده برای تبدیل به JSON
 * @param int $status_code کد وضعیت HTTP
 */
function json($data, $status_code = 200) {
    http_response_code($status_code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * تغییر مسیر به URL دیگر
 *
 * @param string $url آدرس مقصد
 * @param array $flash_message پیام فلش
 */
function redirect($url, $flash_message = null) {
    if ($flash_message) {
        $type = key($flash_message);
        $message = $flash_message[$type];
        \App\Core\AlertHelper::flash($type, $message);
    }

    header('Location: ' . $url);
    exit;
}

/**
 * بررسی وجود پارامتر در درخواست (GET یا POST)
 *
 * @param string $key کلید پارامتر
 * @return boolean نتیجه بررسی
 */
function has_param($key) {
    return isset($_REQUEST[$key]);
}

/**
 * دریافت مقدار پارامتر از درخواست (GET یا POST)
 *
 * @param string $key کلید پارامتر
 * @param mixed $default مقدار پیش‌فرض
 * @return mixed مقدار پارامتر
 */
function get_param($key, $default = null) {
    return isset($_REQUEST[$key]) ? clean_input($_REQUEST[$key]) : $default;
}

/**
 * محاسبه زمان اجرای اسکریپت
 *
 * @param float $start_time زمان شروع
 * @return string زمان اجرا به میلی‌ثانیه
 */
function execution_time($start_time) {
    return round((microtime(true) - $start_time) * 1000, 2) . 'ms';
}

/**
 * ثبت رویداد در فایل لاگ
 *
 * @param string $message پیام
 * @param string $level سطح لاگ (debug, info, warning, error)
 */
function log_message($message, $level = 'info') {
    if (!LOG_ENABLE || !in_array($level, ['debug', 'info', 'warning', 'error'])) {
        return;
    }

    // اگر سطح لاگ تعیین شده کمتر از سطح لاگ فعلی باشد، لاگ ثبت نمی‌شود
    $log_levels = ['debug' => 0, 'info' => 1, 'warning' => 2, 'error' => 3];
    if ($log_levels[$level] < $log_levels[LOG_LEVEL]) {
        return;
    }

    $log_dir = dirname(LOG_FILE);
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_message = '[' . date('Y-m-d H:i:s') . '] [' . strtoupper($level) . '] ' . $message . PHP_EOL;
    file_put_contents(LOG_FILE, $log_message, FILE_APPEND);
}

/**
 * کوتاه کردن متن با حفظ کلمات کامل
 *
 * @param string $text متن اصلی
 * @param int $length طول مورد نظر
 * @param string $suffix پسوند
 * @return string متن کوتاه شده
 */
function str_limit($text, $length = 100, $suffix = '...') {
    if (mb_strlen($text, 'UTF-8') <= $length) {
        return $text;
    }

    return mb_substr($text, 0, $length, 'UTF-8') . $suffix;
}

/**
 * تولید URL دوستانه (slug) از یک رشته
 *
 * @param string $string رشته ورودی
 * @return string slug
 */
function slugify($string) {
    // حروف غیر لاتین و کاراکترهای خاص را با - جایگزین می‌کند
    $string = preg_replace('/[^\p{L}\p{N}]+/u', '-', $string);
    // حذف - از ابتدا و انتهای رشته
    $string = trim($string, '-');
    // تبدیل به حروف کوچک
    $string = mb_strtolower($string, 'UTF-8');

    return $string;
}

/**
 * دریافت ترجمه متن
 *
 * @param string $key کلید ترجمه
 * @param array $params پارامترها
 * @param string|null $default متن پیش‌فرض
 * @return string متن ترجمه شده
 */
function __($key, $params = [], $default = null) {
    return \App\Core\Language::get($key, $params, $default);
}

/**
 * تبدیل اعداد انگلیسی به فارسی
 *
 * @param string|int|float $input ورودی
 * @return string خروجی با اعداد فارسی
 */
function fa_num($input) {
    return \App\Core\DateHelper::convertNumbers((string) $input, 'fa');
}

/**
 * تبدیل اعداد فارسی به انگلیسی
 *
 * @param string $input ورودی
 * @return string خروجی با اعداد انگلیسی
 */
function en_num($input) {
    return \App\Core\DateHelper::convertNumbers($input, 'en');
}

/**
 * فرمت‌بندی قیمت
 *
 * @param int|float $price قیمت
 * @param string $currency واحد پول
 * @param bool $convert_to_fa تبدیل به اعداد فارسی
 * @return string قیمت فرمت‌بندی شده
 */
function format_price($price, $currency = 'تومان', $convert_to_fa = true) {
    $formatted = number_format($price);

    if ($convert_to_fa && \App\Core\Language::getCurrentLang() === 'fa') {
        $formatted = fa_num($formatted);
        return $formatted . ' ' . $currency;
    }

    return $currency === 'تومان' ? '$' . $formatted : $formatted . ' ' . $currency;
}

/**
 * تبدیل تاریخ به فرمت مناسب براساس زبان
 *
 * @param string|int $date تاریخ یا timestamp
 * @param string $format فرمت خروجی
 * @return string تاریخ فرمت‌بندی شده
 */
function format_date($date, $format = null) {
    return \App\Core\DateHelper::formatForDisplay($date, false);
}

/**
 * تبدیل تاریخ و زمان به فرمت مناسب براساس زبان
 *
 * @param string|int $datetime تاریخ و زمان یا timestamp
 * @param string $format فرمت خروجی
 * @return string تاریخ و زمان فرمت‌بندی شده
 */
function format_datetime($datetime, $format = null) {
    return \App\Core\DateHelper::formatForDisplay($datetime, true);
}

/**
 * نمایش زمان نسبی (مثل "چند دقیقه پیش")
 *
 * @param string|int $datetime تاریخ و زمان یا timestamp
 * @return string زمان نسبی
 */
function time_ago($datetime) {
    return \App\Core\DateHelper::timeAgo($datetime);
}

/**
 * بررسی وجود فایل و نمایش تصویر پیش‌فرض در صورت عدم وجود
 *
 * @param string $path مسیر فایل
 * @param string $default مسیر فایل پیش‌فرض
 * @return string مسیر فایل
 */
function get_file($path, $default = 'assets/images/default.png') {
    if (file_exists($path)) {
        return base_url($path);
    }

    return base_url($default);
}

/**
 * دریافت آواتار کاربر
 *
 * @param string|null $avatar مسیر آواتار
 * @param string $default مسیر آواتار پیش‌فرض
 * @return string مسیر آواتار
 */
function get_avatar($avatar, $default = 'assets/images/avatar.png') {
    return get_file($avatar, $default);
}

/**
 * تبدیل تعداد به فرمت خلاصه (مثل 1K, 1M)
 *
 * @param int $number عدد
 * @param int $precision تعداد اعشار
 * @return string عدد فرمت‌بندی شده
 */
function format_number($number, $precision = 1) {
    $suffixes = ['', 'K', 'M', 'B', 'T'];
    $suffix_index = 0;

    while ($number >= 1000 && $suffix_index < count($suffixes) - 1) {
        $number /= 1000;
        $suffix_index++;
    }

    $formatted = round($number, $precision);
    if ($precision > 0) {
        $formatted = rtrim(rtrim($formatted, '0'), '.');
    }

    $result = $formatted . $suffixes[$suffix_index];

    if (\App\Core\Language::getCurrentLang() === 'fa') {
        return fa_num($result);
    }

    return $result;
}

/**
 * تولید رنگ تصادفی
 *
 * @param int $min حداقل روشنایی (0-255)
 * @param int $max حداکثر روشنایی (0-255)
 * @return string کد HEX رنگ
 */
function random_color($min = 0, $max = 255) {
    $r = mt_rand($min, $max);
    $g = mt_rand($min, $max);
    $b = mt_rand($min, $max);

    return sprintf('#%02x%02x%02x', $r, $g, $b);
}

/**
 * تبدیل آدرس ایمیل به نمایش امن (مثلاً u***@example.com)
 *
 * @param string $email آدرس ایمیل
 * @return string آدرس ایمیل مبهم شده
 */
function obfuscate_email($email) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return $email;
    }

    list($username, $domain) = explode('@', $email);
    $username_length = mb_strlen($username);

    if ($username_length <= 2) {
        $obfuscated_username = $username[0] . str_repeat('*', $username_length - 1);
    } else {
        $obfuscated_username = $username[0] . str_repeat('*', $username_length - 2) . $username[$username_length - 1];
    }

    return $obfuscated_username . '@' . $domain;
}

/**
 * دریافت IP کاربر
 *
 * @return string آدرس IP
 */
function get_client_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}

/**
 * دریافت مرورگر کاربر
 *
 * @return string نام مرورگر
 */
function get_browser_name() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    if (strpos($user_agent, 'MSIE') !== false || strpos($user_agent, 'Trident') !== false) {
        return 'Internet Explorer';
    } elseif (strpos($user_agent, 'Edge') !== false) {
        return 'Edge';
    } elseif (strpos($user_agent, 'Chrome') !== false) {
        return 'Chrome';
    } elseif (strpos($user_agent, 'Safari') !== false) {
        return 'Safari';
    } elseif (strpos($user_agent, 'Firefox') !== false) {
        return 'Firefox';
    } elseif (strpos($user_agent, 'Opera') !== false) {
        return 'Opera';
    } else {
        return 'Unknown';
    }
}

/**
 * دریافت سیستم عامل کاربر
 *
 * @return string نام سیستم عامل
 */
function get_os_name() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    if (strpos($user_agent, 'Windows') !== false) {
        return 'Windows';
    } elseif (strpos($user_agent, 'Android') !== false) {
        return 'Android';
    } elseif (strpos($user_agent, 'iOS') !== false || strpos($user_agent, 'iPhone') !== false || strpos($user_agent, 'iPad') !== false) {
        return 'iOS';
    } elseif (strpos($user_agent, 'Mac') !== false) {
        return 'Mac OS';
    } elseif (strpos($user_agent, 'Linux') !== false) {
        return 'Linux';
    } else {
        return 'Unknown';
    }
}

/**
 * بررسی درخواست AJAX
 *
 * @return boolean نتیجه بررسی
 */
function is_ajax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * تبدیل HTML به متن ساده
 *
 * @param string $html متن HTML
 * @return string متن ساده
 */
function html_to_text($html) {
    $html = preg_replace('/<br\s*\/?>/', "\n", $html);
    $html = preg_replace('/<\/p>/', "\n\n", $html);
    $html = strip_tags($html);
    $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');

    return trim($html);
}

/**
 * تبدیل URL داخل متن به لینک
 *
 * @param string $text متن
 * @return string متن با لینک‌های فعال
 */
function make_clickable($text) {
    $pattern = '/(https?:\/\/[^\s]+)/i';
    $replacement = '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>';

    return preg_replace($pattern, $replacement, $text);
}

/**
 * دریافت تنظیمات اشتراک‌ها
 *
 * @return array تنظیمات اشتراک‌ها
 */
function get_subscription_plans() {
    return json_decode(SUBSCRIPTION_PLANS, true);
}

/**
 * تولید آدرس کوتاه
 *
 * @param string $url آدرس اصلی
 * @return string کد کوتاه
 */
function generate_short_url($url) {
    // ترکیب URL با یک رشته تصادفی برای ایجاد hash یکتا
    $hash = md5($url . random_bytes(5));

    // استفاده از 8 کاراکتر اول hash
    return substr($hash, 0, 8);
}

/**
 * دریافت اندازه فایل به صورت خوانا
 *
 * @param int $bytes اندازه به بایت
 * @param int $precision تعداد اعشار
 * @return string اندازه فایل خوانا
 */
function format_file_size($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);

    $bytes /= pow(1024, $pow);

    $result = round($bytes, $precision) . ' ' . $units[$pow];

    if (\App\Core\Language::getCurrentLang() === 'fa') {
        return fa_num($result);
    }

    return $result;
}