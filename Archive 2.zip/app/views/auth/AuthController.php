<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Auth;

class AuthController extends Controller
{
    private $db;
    private $auth;

    public function __construct()
    {
        $this->db = new Database();
        $this->auth = new Auth();
    }

    public function showLoginForm()
    {
        // اگر کاربر قبلاً لاگین کرده باشد، ریدایرکت به داشبورد
        if ($this->auth->isLoggedIn()) {
            if ($this->auth->isAdmin()) {
                Response::redirect('/admin/dashboard');
            } else {
                Response::redirect('/dashboard');
            }
        }

        return $this->view('auth/login');
    }

    public function login()
    {
        $request = new Request();

        // بررسی اعتبار درخواست
        $validation = $this->validate($request->getBody(), [
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);

        if (!$validation['valid']) {
            // اگر خطایی رخ داده، برگرداندن به صفحه لاگین با پیام خطا
            $_SESSION['errors'] = $validation['errors'];
            $_SESSION['old_input'] = $request->getBody();
            Response::redirect('/login');
            return;
        }

        $email = $request->getBody()['email'];
        $password = $request->getBody()['password'];
        $remember = isset($request->getBody()['remember-me']) ? true : false;

        // تلاش برای لاگین کردن کاربر
        $loggedIn = $this->auth->login($email, $password, $remember);

        if ($loggedIn) {
            // اگر لاگین موفق بود، ریدایرکت به صفحه مناسب
            if ($this->auth->isAdmin()) {
                Response::redirect('/admin/dashboard');
            } else {
                Response::redirect('/dashboard');
            }
        } else {
            // اگر لاگین ناموفق بود، برگرداندن به صفحه لاگین با پیام خطا
            $_SESSION['errors'] = ['auth' => 'نام کاربری یا رمز عبور اشتباه است'];
            $_SESSION['old_input'] = ['email' => $email];
            Response::redirect('/login');
        }
    }

    public function showRegisterForm()
    {
        // اگر کاربر قبلاً لاگین کرده باشد، ریدایرکت به داشبورد
        if ($this->auth->isLoggedIn()) {
            if ($this->auth->isAdmin()) {
                Response::redirect('/admin/dashboard');
            } else {
                Response::redirect('/dashboard');
            }
        }

        // دریافت اشتراک‌ها برای نمایش در فرم ثبت نام
        $subscriptions = $this->db->select('SELECT * FROM subscriptions WHERE status = "active" ORDER BY price');

        return $this->view('auth/register', ['subscriptions' => $subscriptions]);
    }

    public function register()
    {
        $request = new Request();

        // بررسی اعتبار درخواست
        $validation = $this->validate($request->getBody(), [
            'fullname' => ['required', 'min:3'],
            'email' => ['required', 'email', 'unique:users,email'],
            'phone' => ['required', 'min:10'],
            'password' => ['required', 'min:8'],
            'password_confirm' => ['required', 'match:password'],
            'username' => ['required', 'alphanumeric', 'unique:users,username'],
            'plan' => ['required']
        ]);

        if (!$validation['valid']) {
            // اگر خطایی رخ داده، برگرداندن به صفحه ثبت نام با پیام خطا
            $_SESSION['errors'] = $validation['errors'];
            $_SESSION['old_input'] = $request->getBody();
            Response::redirect('/register');
            return;
        }

        $data = $request->getBody();

        // ایجاد کاربر جدید
        $userId = $this->auth->register([
            'fullname' => $data['fullname'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'password' => password_hash($data['password'], PASSWORD_DEFAULT),
            'username' => $data['username'],
            'company' => $data['company'] ?? null,
            'website' => $data['website'] ?? null,
            'about' => $data['about'] ?? null,
            'instagram' => $data['instagram'] ?? null,
            'role' => 'user',
            'status' => 'active'
        ]);

        if ($userId) {
            // ایجاد اشتراک برای کاربر
            $subscriptionId = $data['plan'];

            // دریافت اطلاعات اشتراک
            $subscription = $this->db->selectOne('SELECT * FROM subscriptions WHERE id = ?', [$subscriptionId]);

            if ($subscription) {
                // محاسبه تاریخ شروع و پایان اشتراک
                $startDate = date('Y-m-d H:i:s');
                $endDate = date('Y-m-d H:i:s', strtotime("+{$subscription['duration']} days"));

                // ایجاد اشتراک کاربر
                $this->db->insert('user_subscriptions', [
                    'user_id' => $userId,
                    'subscription_id' => $subscriptionId,
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                    'status' => 'active'
                ]);

                // ایجاد پرداخت برای این اشتراک (در اینجا به صورت مستقیم موفق در نظر گرفته شده)
                $paymentId = $this->db->insert('payments', [
                    'user_id' => $userId,
                    'subscription_id' => $subscriptionId,
                    'amount' => $subscription['price'],
                    'payment_method' => 'online',
                    'status' => 'success'
                ]);

                // بروزرسانی اشتراک کاربر با شناسه پرداخت
                if ($paymentId) {
                    $this->db->update('user_subscriptions', ['payment_id' => $paymentId], ['user_id' => $userId]);
                }
            }

            // لاگین کردن کاربر پس از ثبت نام
            $this->auth->loginById($userId);

            // ریدایرکت به صفحه داشبورد
            Response::redirect('/dashboard');
        } else {
            // اگر ثبت نام ناموفق بود، برگرداندن به صفحه ثبت نام با پیام خطا
            $_SESSION['errors'] = ['register' => 'خطایی در ثبت نام رخ داده است. لطفا مجددا تلاش کنید.'];
            $_SESSION['old_input'] = $request->getBody();
            Response::redirect('/register');
        }
    }

    public function logout()
    {
        $this->auth->logout();
        Response::redirect('/login');
    }

    public function forgotPassword()
    {
        return $this->view('auth/forgot-password');
    }

    public function processForgotPassword()
    {
        $request = new Request();

        // بررسی اعتبار درخواست
        $validation = $this->validate($request->getBody(), [
            'email' => ['required', 'email', 'exists:users,email']
        ]);

        if (!$validation['valid']) {
            $_SESSION['errors'] = $validation['errors'];
            Response::redirect('/forgot-password');
            return;
        }

        $email = $request->getBody()['email'];

        // ایجاد توکن بازیابی رمز عبور
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // ذخیره توکن در دیتابیس
        $this->db->update('users', [
            'reset_token' => $token,
            'reset_token_expires' => $expires
        ], ['email' => $email]);

        // ارسال ایمیل بازیابی رمز عبور (در اینجا فقط شبیه‌سازی شده)
        // در یک محیط واقعی، اینجا کد ارسال ایمیل قرار می‌گیرد

        $_SESSION['success'] = 'لینک بازیابی رمز عبور به ایمیل شما ارسال شد.';
        Response::redirect('/login');
    }

    private function validate($data, $rules)
    {
        $errors = [];
        $valid = true;

        foreach ($rules as $field => $fieldRules) {
            foreach ($fieldRules as $rule) {
                // بررسی قوانین مختلف اعتبارسنجی
                if ($rule === 'required' && (!isset($data[$field]) || empty($data[$field]))) {
                    $errors[$field] = 'این فیلد اجباری است';
                    $valid = false;
                    break;
                }

                if (isset($data[$field]) && !empty($data[$field])) {
                    if ($rule === 'email' && !filter_var($data[$field], FILTER_VALIDATE_EMAIL)) {
                        $errors[$field] = 'ایمیل وارد شده معتبر نیست';
                        $valid = false;
                        break;
                    }

                    if (strpos($rule, 'min:') === 0) {
                        $min = substr($rule, 4);
                        if (strlen($data[$field]) < $min) {
                            $errors[$field] = "این فیلد باید حداقل $min کاراکتر باشد";
                            $valid = false;
                            break;
                        }
                    }

                    if ($rule === 'alphanumeric' && !ctype_alnum($data[$field])) {
                        $errors[$field] = 'این فیلد فقط می‌تواند شامل حروف و اعداد باشد';
                        $valid = false;
                        break;
                    }

                    if (strpos($rule, 'match:') === 0) {
                        $matchField = substr($rule, 6);
                        if (!isset($data[$matchField]) || $data[$field] !== $data[$matchField]) {
                            $errors[$field] = 'این فیلد با فیلد مورد نظر مطابقت ندارد';
                            $valid = false;
                            break;
                        }
                    }

                    if (strpos($rule, 'unique:') === 0) {
                        $parts = explode(',', substr($rule, 7));
                        $table = $parts[0];
                        $column = $parts[1];

                        $exists = $this->db->exists("SELECT id FROM $table WHERE $column = ?", [$data[$field]]);
                        if ($exists) {
                            $errors[$field] = 'این مقدار قبلاً استفاده شده است';
                            $valid = false;
                            break;
                        }
                    }

                    if (strpos($rule, 'exists:') === 0) {
                        $parts = explode(',', substr($rule, 7));
                        $table = $parts[0];
                        $column = $parts[1];

                        $exists = $this->db->exists("SELECT id FROM $table WHERE $column = ?", [$data[$field]]);
                        if (!$exists) {
                            $errors[$field] = 'این مقدار در سیستم یافت نشد';
                            $valid = false;
                            break;
                        }
                    }
                }
            }
        }

        return [
            'valid' => $valid,
            'errors' => $errors
        ];
    }
}