<?php
/**
 * View file for login page
 * This file includes the login form and handling error messages
 */
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود - edameye</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        @font-face {
            font-family: 'IRANSans';
            src: url('/public/assets/fonts/IRANSans.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }
        body {
            font-family: 'IRANSans', 'Tahoma', sans-serif;
            background-color: #f8f9fa;
        }
        .gradient-bg {
            background: linear-gradient(90deg, #4776E6 0%, #8E54E9 100%);
        }
        .login-form-container {
            max-width: 450px;
        }
        .input-field:focus {
            border-color: #8E54E9;
            box-shadow: 0 0 0 3px rgba(142, 84, 233, 0.2);
        }
    </style>
</head>
<body class="antialiased min-h-screen flex flex-col">
<!-- Navigation -->
<nav class="bg-white shadow-sm p-4 sticky top-0 z-50">
    <div class="container mx-auto flex justify-between items-center">
        <div class="flex items-center">
            <a href="/" class="text-2xl font-bold text-purple-600">
                <span class="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600">edameye</span>
            </a>
        </div>
        <div class="flex space-x-3 space-x-reverse">
            <a href="/register" class="text-purple-600 hover:text-purple-800 px-4 py-2 rounded-md border border-purple-600 hover:border-purple-800">ثبت نام</a>
        </div>
    </div>
</nav>

<!-- Login Form -->
<div class="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="login-form-container w-full space-y-8 bg-white p-8 rounded-lg shadow-md">
        <div>
            <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                ورود به حساب کاربری
            </h2>
            <p class="mt-2 text-center text-sm text-gray-600">
                یا
                <a href="/register" class="font-medium text-purple-600 hover:text-purple-500">
                    ثبت نام کنید
                </a>
            </p>
        </div>

        <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
            <div class="bg-red-50 border-r-4 border-red-500 p-4 rounded-md">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-circle text-red-500"></i>
                    </div>
                    <div class="mr-3">
                        <p class="text-sm text-red-700">
                            <?php foreach ($_SESSION['errors'] as $error): ?>
                                <?php echo $error; ?><br>
                            <?php endforeach; ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php unset($_SESSION['errors']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-50 border-r-4 border-green-500 p-4 rounded-md">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fas fa-check-circle text-green-500"></i>
                    </div>
                    <div class="mr-3">
                        <p class="text-sm text-green-700">
                            <?php echo $_SESSION['success']; ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <form class="mt-8 space-y-6" action="/login" method="POST">
            <input type="hidden" name="action" value="login">
            <div class="rounded-md shadow-sm -space-y-px">
                <div>
                    <label for="email" class="sr-only">ایمیل یا نام کاربری</label>
                    <input id="email" name="email" type="text" required class="input-field appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm" placeholder="ایمیل یا نام کاربری" value="<?php echo isset($_SESSION['old_input']['email']) ? $_SESSION['old_input']['email'] : ''; ?>">
                </div>
                <div class="relative">
                    <label for="password" class="sr-only">رمز عبور</label>
                    <input id="password" name="password" type="password" required class="input-field appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm" placeholder="رمز عبور">
                    <button type="button" id="togglePassword" class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 cursor-pointer">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <input id="remember-me" name="remember-me" type="checkbox" class="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded" <?php echo isset($_SESSION['old_input']['remember-me']) ? 'checked' : ''; ?>>
                    <label for="remember-me" class="mr-2 block text-sm text-gray-900">
                        مرا به خاطر بسپار
                    </label>
                </div>

                <div class="text-sm">
                    <a href="/forgot-password" class="font-medium text-purple-600 hover:text-purple-500">
                        فراموشی رمز عبور؟
                    </a>
                </div>
            </div>

            <div>
                <button type="submit" class="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-300">
                        <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                            <i class="fas fa-sign-in-alt"></i>
                        </span>
                    ورود
                </button>
            </div>
        </form>

        <?php unset($_SESSION['old_input']); ?>

        <!-- Social Login -->
        <div class="mt-6">
            <div class="relative">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-gray-300"></div>
                </div>
                <div class="relative flex justify-center text-sm">
                        <span class="px-2 bg-white text-gray-500">
                            ورود با
                        </span>
                </div>
            </div>

            <div class="mt-6 grid grid-cols-2 gap-3">
                <div>
                    <a href="/auth/google" class="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors duration-300">
                        <span class="sr-only">ورود با Google</span>
                        <i class="fab fa-google text-red-500"></i>
                    </a>
                </div>
                <div>
                    <a href="/auth/linkedin" class="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors duration-300">
                        <span class="sr-only">ورود با LinkedIn</span>
                        <i class="fab fa-linkedin text-blue-500"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-white border-t border-gray-200 py-4">
    <div class="container mx-auto px-4 text-center text-gray-600 text-sm">
        &copy; ۱۴۰۴ edameye - تمامی حقوق محفوظ است.
    </div>
</footer>

<!-- Scripts -->
<script>
    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const password = document.getElementById('password');
        const icon = this.querySelector('i');

        if (password.type === 'password') {
            password.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            password.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
</script>
</body>
</html>