<?php
/**
 * reports/create.php
 *
 * قالب ایجاد گزارش جدید برای رصد، پایش و تحلیل شبکه‌های اجتماعی
 */

// دسترسی به متغیرهای ارسالی از کنترلر
/* @var $title string */
/* @var $platforms array */
/* @var $keywords array */
/* @var $page string */
/* @var $errors array */

// تنظیم متغیرهای پیش‌فرض
$currentLang = \App\Core\Language::getCurrentLang();
$isRtl = $currentLang === 'fa';
$dir = $isRtl ? 'rtl' : 'ltr';
?>

<!DOCTYPE html>
<html lang="<?= $currentLang ?>" dir="<?= $dir ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Vazirmatn Font (برای فارسی) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            font-family: <?= $isRtl ? "'Vazirmatn'" : "'Inter'" ?>, system-ui, sans-serif;
        }

        .socialkoch-gradient {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
        }

        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .loading-spinner {
            display: inline-block;
            width: 50px;
            height: 50px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* تنظیمات مخصوص RTL برای فرم‌ها */
        input, select, textarea {
            direction: <?= $isRtl ? 'rtl' : 'ltr' ?>;
        }
    </style>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            200: '#c7d2fe',
                            300: '#a5b4fc',
                            400: '#818cf8',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            800: '#3730a3',
                            900: '#312e81',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 min-h-screen">
<!-- Header -->
<header class="socialkoch-gradient text-white shadow-md">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <div class="flex items-center">
            <h1 class="text-2xl font-bold">SOCIALKOCH.CO</h1>
            <p class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm opacity-90">رصد، پایش و تحلیل شبکه‌های اجتماعی</p>
        </div>
        <div class="flex items-center space-x-4 <?= $isRtl ? 'space-x-reverse' : '' ?>">
            <div class="relative">
                <button class="text-white focus:outline-none">
                    <i class="fas fa-bell text-lg"></i>
                    <span class="absolute -top-1 <?= $isRtl ? 'left-0' : 'right-0' ?> bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">3</span>
                </button>
            </div>
            <div class="flex items-center">
                <img src="<?= asset('images/avatar.png') ?>" alt="User" class="w-8 h-8 rounded-full">
                <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">کاربر گرامی</span>
            </div>
        </div>
    </div>
</header>

<!-- Main Content -->
<div class="container mx-auto px-4 py-8 flex flex-wrap md:flex-nowrap">
    <!-- Sidebar -->
    <aside class="w-full md:w-1/4 md:<?= $isRtl ? 'ml-6' : 'mr-6' ?> mb-6 md:mb-0">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center mb-6">
                <img src="<?= asset('images/avatar.png') ?>" alt="User" class="w-12 h-12 rounded-full">
                <div class="<?= $isRtl ? 'mr-3' : 'ml-3' ?>">
                    <p class="font-semibold">کاربر گرامی</p>
                    <p class="text-sm text-gray-600">اشتراک ویژه</p>
                </div>
            </div>

            <div class="mb-4">
                <h3 class="font-semibold text-gray-700 mb-2">وضعیت اشتراک</h3>
                <div class="bg-primary-50 p-3 rounded-lg">
                    <div class="flex justify-between mb-1">
                        <span class="text-sm">اشتراک ویژه</span>
                        <span class="text-sm text-primary-700">فعال</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm">تاریخ انقضا</span>
                        <span class="text-sm">۱۴۰۴/۰۲/۱۵</span>
                    </div>
                    <div class="mt-2">
                        <div class="w-full bg-gray-200 h-2 rounded-full">
                            <div class="bg-primary-600 h-2 rounded-full" style="width: 75%"></div>
                        </div>
                        <p class="text-xs text-center mt-1">۲۳ روز باقی‌مانده</p>
                    </div>
                </div>
            </div>

            <nav>
                <ul class="space-y-1">
                    <li>
                        <a href="/dashboard" class="flex items-center p-2 rounded-lg <?= $page === 'dashboard' ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-100' ?>">
                            <i class="fas fa-home w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">داشبورد</span>
                        </a>
                    </li>
                    <li>
                        <a href="/reports" class="flex items-center p-2 rounded-lg <?= $page === 'reports' ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-100' ?>">
                            <i class="fas fa-chart-bar w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">گزارش‌های آنالیز</span>
                        </a>
                    </li>
                    <li>
                        <a href="/instagram" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fab fa-instagram w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پیج‌های اینستاگرام</span>
                        </a>
                    </li>
                    <li>
                        <a href="/content" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-layer-group w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">محتوای آموزشی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/subscription" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-gem w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">اشتراک ویژه</span>
                        </a>
                    </li>
                    <li>
                        <a href="/support" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-headset w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پشتیبانی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/invoices" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-file-invoice w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">صورت حساب‌ها</span>
                        </a>
                    </li>
                    <li>
                        <a href="/saves" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-bookmark w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">ذخیره شده‌ها</span>
                        </a>
                    </li>
                    <li>
                        <a href="/faq" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-question-circle w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پرسش‌های شما</span>
                        </a>
                    </li>
                    <li>
                        <a href="/terms" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-file-contract w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">شرایط و قوانین</span>
                        </a>
                    </li>
                    <li>
                        <a href="/privacy" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-shield-alt w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">حریم خصوصی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/auth/logout" class="flex items-center p-2 rounded-lg hover:bg-gray-100 text-red-600">
                            <i class="fas fa-sign-out-alt w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">خروج از حساب کاربری</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="w-full md:w-3/4">
        <div class="bg-white rounded-lg shadow-sm p-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold">ایجاد گزارش جدید</h2>
                <a href="/reports" class="text-primary-600 hover:text-primary-800">
                    <i class="fas fa-arrow-<?= $isRtl ? 'left' : 'right' ?>"></i>
                    <span class="<?= $isRtl ? 'mr-1' : 'ml-1' ?>">بازگشت به گزارش‌ها</span>
                </a>
            </div>

            <!-- نمایش خطاها -->
            <?php if (isset($errors) && !empty($errors)): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                    <div class="font-semibold mb-1">لطفاً خطاهای زیر را برطرف کنید:</div>
                    <ul class="list-disc list-inside text-sm">
                        <?php foreach ($errors as $field => $fieldErrors): ?>
                            <?php foreach ($fieldErrors as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- فرم ایجاد گزارش -->
            <form id="create-report-form" action="/reports/create" method="post" class="space-y-6">
                <div class="bg-primary-50 rounded-lg p-4 mb-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 rounded-full bg-primary-200 flex items-center justify-center">
                            <i class="fab fa-instagram text-primary-700"></i>
                        </div>
                        <div class="<?= $isRtl ? 'mr-3' : 'ml-3' ?>">
                            <h3 class="font-semibold">آنالیز پیج اینستاگرام</h3>
                            <p class="text-sm text-gray-600">جزئیات پیج خود را وارد کنید تا آنالیز کامل دریافت نمایید</p>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="instagram_id" class="block text-sm font-medium text-gray-700 mb-1">آیدی پیج اینستاگرام *</label>
                        <div class="relative">
                                <span class="absolute inset-y-0 <?= $isRtl ? 'right-0 pr-3' : 'left-0 pl-3' ?> flex items-center text-gray-500">
                                    <i class="fab fa-instagram"></i>
                                </span>
                            <input type="text" id="instagram_id" name="instagram_id" placeholder="بدون @ وارد کنید، مثال: socialkoch.co" class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 pl-10 <?= $isRtl ? 'pr-10 text-right' : 'pl-10 text-left' ?>" required>
                        </div>
                    </div>

                    <div>
                        <label for="category" class="block text-sm font-medium text-gray-700 mb-1">حوزه کاری *</label>
                        <select id="category" name="category" class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500" required>
                            <option value="">انتخاب کنید</option>
                            <option value="business">کسب و کار</option>
                            <option value="personal">شخصی</option>
                            <option value="education">آموزشی</option>
                            <option value="health">سلامت و زیبایی</option>
                            <option value="food">غذا و نوشیدنی</option>
                            <option value="fashion">مد و لباس</option>
                            <option value="technology">تکنولوژی</option>
                            <option value="art">هنر و سرگرمی</option>
                            <option value="travel">سفر و گردشگری</option>
                            <option value="sports">ورزشی</option>
                            <option value="other">سایر</option>
                        </select>
                    </div>

                    <div>
                        <label for="subcategory" class="block text-sm font-medium text-gray-700 mb-1">دسته‌بندی تخصصی</label>
                        <select id="subcategory" name="subcategory" class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500">
                            <option value="">انتخاب کنید</option>
                            <option value="influencer">اینفلوئنسر</option>
                            <option value="brand">برند</option>
                            <option value="shop">فروشگاه</option>
                            <option value="service">خدمات</option>
                            <option value="informational">اطلاع‌رسانی</option>
                            <option value="educational">آموزشی</option>
                            <option value="entertainment">سرگرمی</option>
                            <option value="ngo">سازمان غیرانتفاعی</option>
                            <option value="other">سایر</option>
                        </select>
                    </div>

                    <div>
                        <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1">تاریخ شروع آنالیز</label>
                        <input type="date" id="start_date" name="start_date" class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500">
                        <p class="text-xs text-gray-500 mt-1">در صورت عدم انتخاب، از امروز شروع می‌شود</p>
                    </div>
                </div>

                <div>
                    <label for="description" class="block text-sm font-medium text-gray-700 mb-1">توضیحات فعالیت پیج</label>
                    <textarea id="description" name="description" rows="4" placeholder="توضیحات مختصری درباره محتوا و هدف پیج خود بنویسید..." class="block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"></textarea>
                </div>

                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-lg">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-info-circle text-yellow-400"></i>
                        </div>
                        <div class="<?= $isRtl ? 'mr-3' : 'ml-3' ?>">
                            <p class="text-sm text-yellow-700">
                                با ثبت این فرم، سیستم شروع به جمع‌آوری و تحلیل داده‌های پیج اینستاگرام شما می‌کند. این فرآیند ممکن است چند دقیقه طول بکشد.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="button" onclick="submitForm()" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg transition-all inline-flex items-center">
                        <i class="fas fa-chart-line"></i>
                        <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">شروع آنالیز</span>
                    </button>
                </div>
            </form>

            <div class="border-t mt-8 pt-6">
                <h3 class="text-lg font-semibold mb-4">با آنالیز پیج اینستاگرام چه چیزهایی دریافت می‌کنید؟</h3>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="text-primary-600 mb-2">
                            <i class="fas fa-chart-pie text-xl"></i>
                        </div>
                        <h4 class="font-semibold mb-1">آمار تعاملات</h4>
                        <p class="text-sm text-gray-600">ایمپرشن، اینگیجمنت، میانگین لایک و کامنت به همراه درصد رشد</p>
                    </div>

                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="text-primary-600 mb-2">
                            <i class="fas fa-users text-xl"></i>
                        </div>
                        <h4 class="font-semibold mb-1">تحلیل فالوورها</h4>
                        <p class="text-sm text-gray-600">نمودار تغییرات فالوورها و پتانسیل رشد پیج شما</p>
                    </div>

                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="text-primary-600 mb-2">
                            <i class="fas fa-lightbulb text-xl"></i>
                        </div>
                        <h4 class="font-semibold mb-1">استراتژی رشد</h4>
                        <p class="text-sm text-gray-600">مراحل پیشنهادی برای بهبود عملکرد و ارتقاء پیج شما</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Footer -->
<footer class="bg-white border-t mt-8 py-6">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row justify-between items-center">
            <div class="mb-4 md:mb-0">
                <p class="text-gray-600 text-sm">© <?= date('Y') ?> SOCIALKOCH.CO - تمامی حقوق محفوظ است</p>
            </div>
            <div class="flex space-x-4 <?= $isRtl ? 'space-x-reverse' : '' ?>">
                <a href="/terms" class="text-gray-600 hover:text-primary-600 text-sm">شرایط و قوانین</a>
                <a href="/privacy" class="text-gray-600 hover:text-primary-600 text-sm">حریم خصوصی</a>
                <a href="/contact" class="text-gray-600 hover:text-primary-600 text-sm">تماس با ما</a>
            </div>
        </div>
    </div>
</footer>

<!-- Loading Modal -->
<div id="loading-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
    <div class="bg-white rounded-lg p-8 max-w-sm w-full text-center">
        <div class="flex justify-center mb-4">
            <div class="loading-spinner"></div>
        </div>
        <h3 class="text-xl font-semibold mb-2">در حال آنالیز پیج</h3>
        <p class="text-gray-600">لطفاً کمی صبر کنید، این فرآیند ممکن است چند دقیقه طول بکشد...</p>
    </div>
</div>

<script>
    // نمایش Loading Modal
    function showLoading() {
        document.getElementById('loading-modal').classList.remove('hidden');
    }

    // مخفی کردن Loading Modal
    function hideLoading() {
        document.getElementById('loading-modal').classList.add('hidden');
    }

    // ارسال فرم با نمایش لودینگ
    function submitForm() {
        // بررسی اعتبارسنجی فرم
        const form = document.getElementById('create-report-form');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        // نمایش لودینگ
        showLoading();

        // ارسال فرم
        form.submit();
    }

    // تغییر دسته‌بندی تخصصی بر اساس حوزه کاری
    document.getElementById('category').addEventListener('change', function() {
        const category = this.value;
        const subcategory = document.getElementById('subcategory');

        // پاک کردن گزینه‌های فعلی
        subcategory.innerHTML = '<option value="">انتخاب کنید</option>';

        // افزودن گزینه‌های جدید بر اساس دسته‌بندی انتخاب شده
        if (category === 'business') {
            const options = [
                {value: 'retail', label: 'خرده‌فروشی'},
                {value: 'service', label: 'خدمات'},
                {value: 'manufacturing', label: 'تولیدی'},
                {value: 'consulting', label: 'مشاوره'},
                {value: 'marketing', label: 'بازاریابی'},
                {value: 'finance', label: 'مالی'},
                {value: 'real_estate', label: 'املاک'},
                {value: 'other', label: 'سایر'}
            ];

            options.forEach(option => {
                const optionElement = document.createElement('option');
                optionElement.value = option.value;
                optionElement.textContent = option.label;
                subcategory.appendChild(optionElement);
            });
        } else if (category === 'education') {
            const options = [
                {value: 'university', label: 'دانشگاه'},
                {value: 'school', label: 'مدرسه'},
                {value: 'training', label: 'آموزشگاه'},
                {value: 'online_courses', label: 'دوره‌های آنلاین'},
                {value: 'language', label: 'زبان'},
                {value: 'skills', label: 'مهارت‌های تخصصی'},
                {value: 'other', label: 'سایر'}
            ];

            options.forEach(option => {
                const optionElement = document.createElement('option');
                optionElement.value = option.value;
                optionElement.textContent = option.label;
                subcategory.appendChild(optionElement);
            });
        }
        // سایر دسته‌بندی‌ها به همین ترتیب
    });
</script>
</body>
</html>