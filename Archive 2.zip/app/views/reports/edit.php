<?php
/**
 * reports/edit.php
 *
 * قالب ویرایش گزارش برای رصد، پایش و تحلیل شبکه‌های اجتماعی
 */

// دسترسی به متغیرهای ارسالی از کنترلر
/* @var $title string */
/* @var $report array */
/* @var $platforms array */
/* @var $keywords array */
/* @var $page string */
/* @var $errors array */

// تنظیم متغیرهای پیش‌فرض
$currentLang = \App\Core\Language::getCurrentLang();
$isRtl = $currentLang === 'fa';
$dir = $isRtl ? 'rtl' : 'ltr';
?>

<!DOCTYPE html>
<html lang="<?= $currentLang ?>" dir="<?= $dir ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Vazirmatn Font (برای فارسی) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            font-family: <?= $isRtl ? "'Vazirmatn'" : "'Inter'" ?>, system-ui, sans-serif;
        }

        .socialkoch-gradient {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
        }

        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .loading-spinner {
            display: inline-block;
            width: 50px;
            height: 50px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* تنظیمات مخصوص RTL برای فرم‌ها */
        input, select, textarea {
            direction: <?= $isRtl ? 'rtl' : 'ltr' ?>;
        }
    </style>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            200: '#c7d2fe',
                            300: '#a5b4fc',
                            400: '#818cf8',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            800: '#3730a3',
                            900: '#312e81',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 min-h-screen">
<!-- Header -->
<header class="socialkoch-gradient text-white shadow-md">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <div class="flex items-center">
            <h1 class="text-2xl font-bold">SOCIALKOCH.CO</h1>
            <p class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm opacity-90">رصد، پایش و تحلیل شبکه‌های اجتماعی</p>
        </div>
        <div class="flex items-center space-x-4 <?= $isRtl ? 'space-x-reverse' : '' ?>">
            <div class="relative">
                <button class="text-white focus:outline-none">
                    <i class="fas fa-bell text-lg"></i>
                    <span class="absolute -top-1 <?= $isRtl ? 'left-0' : 'right-0' ?> bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">3</span>
                </button>
            </div>
            <div class="flex items-center">
                <img src="<?= asset('images/avatar.png') ?>" alt="User" class="w-8 h-8 rounded-full">
                <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">کاربر گرامی</span>
            </div>
        </div>
    </div>
</header>

<!-- Main Content -->
<div class="container mx-auto px-4 py-8 flex flex-wrap md:flex-nowrap">
    <!-- Sidebar -->
    <aside class="w-full md:w-1/4 md:<?= $isRtl ? 'ml-6' : 'mr-6' ?> mb-6 md:mb-0">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center mb-6">
                <img src="<?= asset('images/avatar.png') ?>" alt="User" class="w-12 h-12 rounded-full">
                <div class="<?= $isRtl ? 'mr-3' : 'ml-3' ?>">
                    <p class="font-semibold">کاربر گرامی</p>
                    <p class="text-sm text-gray-600">اشتراک ویژه</p>
                </div>
            </div>

            <div class="mb-4">
                <h3 class="font-semibold text-gray-700 mb-2">وضعیت اشتراک</h3>
                <div class="bg-primary-50 p-3 rounded-lg">
                    <div class="flex justify-between mb-1">
                        <span class="text-sm">اشتراک ویژه</span>
                        <span class="text-sm text-primary-700">فعال</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm">تاریخ انقضا</span>
                        <span class="text-sm">۱۴۰۴/۰۲/۱۵</span>
                    </div>
                    <div class="mt-2">
                        <div class="w-full bg-gray-200 h-2 rounded-full">
                            <div class="bg-primary-600 h-2 rounded-full" style="width: 75%"></div>
                        </div>
                        <p class="text-xs text-center mt-1">۲۳ روز باقی‌مانده</p>
                    </div>
                </div>
            </div>

            <nav>
                <ul class="space-y-1">
                    <li>
                        <a href="/dashboard" class="flex items-center p-2 rounded-lg <?= $page === 'dashboard' ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-100' ?>">
                            <i class="fas fa-home w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">داشبورد</span>
                        </a>
                    </li>
                    <li>
                        <a href="/reports" class="flex items-center p-2 rounded-lg <?= $page === 'reports' ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-100' ?>">
                            <i class="fas fa-chart-bar w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">گزارش‌های آنالیز</span>
                        </a>
                    </li>
                    <li>
                        <a href="/instagram" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fab fa-instagram w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پیج‌های اینستاگرام</span>
                        </a>
                    </li>
                    <li>
                        <a href="/content" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-layer-group w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">محتوای آموزشی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/subscription" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-gem w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">اشتراک</span>
                        </a>
                    </li>
                    <li>
                        <a href="/support" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-headset w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پشتیبانی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/settings" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-cog w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">تنظیمات</span>
                        </a>
                    </li>
                    <li>
                        <a href="/logout" class="flex items-center p-2 rounded-lg text-red-600 hover:bg-red-50">
                            <i class="fas fa-sign-out-alt w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">خروج</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="w-full md:w-3/4">
        <!-- برگشت به صفحه گزارش‌ها -->
        <div class="mb-6">
            <a href="/reports" class="inline-flex items-center text-primary-600 hover:text-primary-800">
                <i class="fas fa-<?= $isRtl ? 'arrow-right' : 'arrow-left' ?> <?= $isRtl ? 'ml-2' : 'mr-2' ?>"></i>
                <span>بازگشت به لیست گزارش‌ها</span>
            </a>
        </div>

        <!-- فرم ویرایش گزارش -->
        <div class="bg-white rounded-lg shadow-sm p-6">
            <h2 class="text-2xl font-bold mb-6"><?= isset($report['id']) ? 'ویرایش گزارش' : 'ایجاد گزارش جدید' ?></h2>

            <!-- نمایش خطاها -->
            <?php if (!empty($errors)): ?>
                <div class="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 mb-6">
                    <h3 class="font-semibold mb-2">لطفاً خطاهای زیر را برطرف کنید:</h3>
                    <ul class="list-disc <?= $isRtl ? 'mr-5' : 'ml-5' ?>">
                        <?php foreach ($errors as $error): ?>
                            <li><?= $error ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="/reports/<?= isset($report['id']) ? 'update/' . $report['id'] : 'create' ?>" method="POST" id="reportForm">
                <!-- بخش اطلاعات کلی -->
                <div class="mb-8">
                    <h3 class="text-lg font-semibold mb-4 pb-2 border-b">اطلاعات کلی گزارش</h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="report_title" class="block text-sm font-medium text-gray-700 mb-1">عنوان گزارش</label>
                            <input type="text" id="report_title" name="report_title"
                                   value="<?= isset($report['title']) ? htmlspecialchars($report['title']) : '' ?>"
                                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                                   placeholder="مثال: تحلیل بازار لوازم آرایشی در اینستاگرام" required>
                        </div>

                        <div>
                            <label for="report_type" class="block text-sm font-medium text-gray-700 mb-1">نوع گزارش</label>
                            <select id="report_type" name="report_type"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <option value="trend_analysis" <?= (isset($report['type']) && $report['type'] === 'trend_analysis') ? 'selected' : '' ?>>تحلیل روند</option>
                                <option value="competitor_analysis" <?= (isset($report['type']) && $report['type'] === 'competitor_analysis') ? 'selected' : '' ?>>تحلیل رقبا</option>
                                <option value="hashtag_analysis" <?= (isset($report['type']) && $report['type'] === 'hashtag_analysis') ? 'selected' : '' ?>>تحلیل هشتگ</option>
                                <option value="sentiment_analysis" <?= (isset($report['type']) && $report['type'] === 'sentiment_analysis') ? 'selected' : '' ?>>تحلیل احساسات</option>
                                <option value="audience_analysis" <?= (isset($report['type']) && $report['type'] === 'audience_analysis') ? 'selected' : '' ?>>تحلیل مخاطبان</option>
                            </select>
                        </div>
                    </div>

                    <div class="mt-4">
                        <label for="report_description" class="block text-sm font-medium text-gray-700 mb-1">توضیحات گزارش</label>
                        <textarea id="report_description" name="report_description" rows="3"
                                  class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                                  placeholder="توضیحات مختصر درباره هدف از تهیه این گزارش..."><?= isset($report['description']) ? htmlspecialchars($report['description']) : '' ?></textarea>
                    </div>
                </div>

                <!-- بخش تنظیمات منابع -->
                <div class="mb-8">
                    <h3 class="text-lg font-semibold mb-4 pb-2 border-b">تنظیمات منابع و پلتفرم‌ها</h3>

                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700 mb-2">پلتفرم‌های مورد نظر</label>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <?php foreach ($platforms as $key => $platform): ?>
                                <div class="flex items-center">
                                    <input type="checkbox" id="platform_<?= $key ?>" name="platforms[]" value="<?= $key ?>"
                                        <?= (isset($report['platforms']) && in_array($key, $report['platforms'])) ? 'checked' : '' ?>
                                           class="rounded border-gray-300 text-primary-600 focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                    <label for="platform_<?= $key ?>" class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm text-gray-700">
                                        <i class="fab fa-<?= $platform['icon'] ?> <?= $isRtl ? 'ml-1' : 'mr-1' ?>"></i>
                                        <?= $platform['name'] ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="date_range" class="block text-sm font-medium text-gray-700 mb-1">بازه زمانی</label>
                            <select id="date_range" name="date_range"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <option value="last_day" <?= (isset($report['date_range']) && $report['date_range'] === 'last_day') ? 'selected' : '' ?>>۲۴ ساعت گذشته</option>
                                <option value="last_week" <?= (isset($report['date_range']) && $report['date_range'] === 'last_week') ? 'selected' : '' ?>>هفته گذشته</option>
                                <option value="last_month" <?= (isset($report['date_range']) && $report['date_range'] === 'last_month') ? 'selected' : '' ?>>ماه گذشته</option>
                                <option value="last_3_months" <?= (isset($report['date_range']) && $report['date_range'] === 'last_3_months') ? 'selected' : '' ?>>سه ماه گذشته</option>
                                <option value="custom" <?= (isset($report['date_range']) && $report['date_range'] === 'custom') ? 'selected' : '' ?>>بازه سفارشی</option>
                            </select>
                        </div>

                        <div id="custom_date_container" class="<?= (isset($report['date_range']) && $report['date_range'] === 'custom') ? '' : 'hidden' ?> grid grid-cols-2 gap-4">
                            <div>
                                <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1">تاریخ شروع</label>
                                <input type="date" id="start_date" name="start_date"
                                       value="<?= isset($report['start_date']) ? $report['start_date'] : '' ?>"
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                            </div>
                            <div>
                                <label for="end_date" class="block text-sm font-medium text-gray-700 mb-1">تاریخ پایان</label>
                                <input type="date" id="end_date" name="end_date"
                                       value="<?= isset($report['end_date']) ? $report['end_date'] : '' ?>"
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- بخش کلمات کلیدی و فیلترها -->
                <div class="mb-8">
                    <h3 class="text-lg font-semibold mb-4 pb-2 border-b">کلمات کلیدی و فیلترها</h3>

                    <div id="keywords_container">
                        <?php if (!empty($report['keywords'])): ?>
                            <?php foreach ($report['keywords'] as $index => $keyword): ?>
                                <div class="keyword-item mb-3 flex items-center gap-2">
                                    <input type="text" name="keywords[]" value="<?= htmlspecialchars($keyword) ?>"
                                           class="flex-grow rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                                           placeholder="کلمه کلیدی یا عبارت...">
                                    <button type="button" class="remove-keyword p-2 text-red-500 hover:text-red-700 focus:outline-none">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="keyword-item mb-3 flex items-center gap-2">
                                <input type="text" name="keywords[]"
                                       class="flex-grow rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                                       placeholder="کلمه کلیدی یا عبارت...">
                                <button type="button" class="remove-keyword p-2 text-red-500 hover:text-red-700 focus:outline-none">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <button type="button" id="add_keyword" class="mt-2 flex items-center text-primary-600 hover:text-primary-800 focus:outline-none">
                        <i class="fas fa-plus <?= $isRtl ? 'ml-1' : 'mr-1' ?>"></i>
                        <span>افزودن کلمه کلیدی</span>
                    </button>

                    <div class="mt-6">
                        <label for="filter_language" class="block text-sm font-medium text-gray-700 mb-1">فیلتر زبان</label>
                        <select id="filter_language" name="filter_language"
                                class="mt-1 block w-full max-w-xs rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                            <option value="all" <?= (isset($report['filter_language']) && $report['filter_language'] === 'all') ? 'selected' : '' ?>>همه زبان‌ها</option>
                            <option value="fa" <?= (isset($report['filter_language']) && $report['filter_language'] === 'fa') ? 'selected' : '' ?>>فارسی</option>
                            <option value="en" <?= (isset($report['filter_language']) && $report['filter_language'] === 'en') ? 'selected' : '' ?>>انگلیسی</option>
                            <option value="ar" <?= (isset($report['filter_language']) && $report['filter_language'] === 'ar') ? 'selected' : '' ?>>عربی</option>
                            <option value="tr" <?= (isset($report['filter_language']) && $report['filter_language'] === 'tr') ? 'selected' : '' ?>>ترکی</option>
                        </select>
                    </div>

                    <div class="mt-4">
                        <label for="exclude_words" class="block text-sm font-medium text-gray-700 mb-1">کلمات استثنا (با کاما جدا کنید)</label>
                        <input type="text" id="exclude_words" name="exclude_words"
                               value="<?= isset($report['exclude_words']) ? htmlspecialchars($report['exclude_words']) : '' ?>"
                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                               placeholder="مثلا: تبلیغ، اسپانسر، آگهی">
                        <p class="mt-1 text-sm text-gray-500">پست‌هایی که این کلمات را دارند، از نتایج حذف می‌شوند.</p>
                    </div>
                </div>

                <!-- تنظیمات گزارش -->
                <div class="mb-8">
                    <h3 class="text-lg font-semibold mb-4 pb-2 border-b">تنظیمات گزارش</h3>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">بخش‌های مورد نظر در گزارش</label>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div class="flex items-center">
                                <input type="checkbox" id="section_trend" name="report_sections[]" value="trend"
                                    <?= (isset($report['sections']) && in_array('trend', $report['sections'])) ? 'checked' : '' ?>
                                       class="rounded border-gray-300 text-primary-600 focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <label for="section_trend" class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm text-gray-700">
                                    تحلیل روند
                                </label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="section_mentions" name="report_sections[]" value="mentions"
                                    <?= (isset($report['sections']) && in_array('mentions', $report['sections'])) ? 'checked' : '' ?>
                                       class="rounded border-gray-300 text-primary-600 focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <label for="section_mentions" class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm text-gray-700">
                                    منشن‌ها و ارجاعات
                                </label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="section_sentiment" name="report_sections[]" value="sentiment"
                                    <?= (isset($report['sections']) && in_array('sentiment', $report['sections'])) ? 'checked' : '' ?>
                                       class="rounded border-gray-300 text-primary-600 focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <label for="section_sentiment" class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm text-gray-700">
                                    تحلیل احساسات
                                </label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="section_hashtags" name="report_sections[]" value="hashtags"
                                    <?= (isset($report['sections']) && in_array('hashtags', $report['sections'])) ? 'checked' : '' ?>
                                       class="rounded border-gray-300 text-primary-600 focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <label for="section_hashtags" class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm text-gray-700">
                                    تحلیل هشتگ‌ها
                                </label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="section_engagement" name="report_sections[]" value="engagement"
                                    <?= (isset($report['sections']) && in_array('engagement', $report['sections'])) ? 'checked' : '' ?>
                                       class="rounded border-gray-300 text-primary-600 focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <label for="section_engagement" class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm text-gray-700">
                                    تعامل و مشارکت
                                </label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="section_demographics" name="report_sections[]" value="demographics"
                                    <?= (isset($report['sections']) && in_array('demographics', $report['sections'])) ? 'checked' : '' ?>
                                       class="rounded border-gray-300 text-primary-600 focus:border-primary-300 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                                <label for="section_demographics" class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm text-gray-700">
                                    تحلیل جمعیت‌شناختی
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="mt-6">
                        <label for="report_schedule" class="block text-sm font-medium text-gray-700 mb-1">زمان‌بندی اجرای خودکار</label>
                        <select id="report_schedule" name="report_schedule"
                                class="mt-1 block w-full max-w-xs rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50">
                            <option value="none" <?= (isset($report['schedule']) && $report['schedule'] === 'none') ? 'selected' : '' ?>>بدون زمان‌بندی (اجرای دستی)</option>
                            <option value="daily" <?= (isset($report['schedule']) && $report['schedule'] === 'daily') ? 'selected' : '' ?>>روزانه</option>
                            <option value="weekly" <?= (isset($report['schedule']) && $report['schedule'] === 'weekly') ? 'selected' : '' ?>>هفتگی</option>
                            <option value="monthly" <?= (isset($report['schedule']) && $report['schedule'] === 'monthly') ? 'selected' : '' ?>>ماهانه</option>
                        </select>
                    </div>

                    <div class="mt-6">
                        <label for="notification_email" class="block text-sm font-medium text-gray-700 mb-1">ایمیل اطلاع‌رسانی (اختیاری)</label>
                        <input type="email" id="notification_email" name="notification_email"
                               value="<?= isset($report['notification_email']) ? htmlspecialchars($report['notification_email']) : '' ?>"
                               class="mt-1 block w-full max-w-md rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                               placeholder="example@domain.com">
                        <p class="mt-1 text-sm text-gray-500">گزارش‌های تولید شده به این ایمیل ارسال خواهد شد.</p>
                    </div>
                </div>

                <!-- دکمه‌های فرم -->
                <div class="flex items-center justify-end space-x-4 <?= $isRtl ? 'space-x-reverse' : '' ?> pt-6 border-t">
                    <button type="button" id="save_draft" class="px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-300">
                        ذخیره پیش‌نویس
                    </button>
                    <button type="button" id="preview_report" class="px-4 py-2 bg-primary-50 text-primary-700 rounded-md hover:bg-primary-100 focus:outline-none focus:ring-2 focus:ring-primary-300">
                        پیش‌نمایش گزارش
                    </button>
                    <button type="submit" class="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500">
                        <?= isset($report['id']) ? 'به‌روزرسانی گزارش' : 'ایجاد گزارش' ?>
                    </button>
                </div>
            </form>
        </div>
    </main>
</div>

<!-- Loading Overlay -->
<div id="loading_overlay" class="fixed inset-0 bg-black bg-opacity-50 items-center justify-center z-50 hidden">
    <div class="bg-white rounded-lg p-8 max-w-md mx-auto text-center">
        <div class="loading-spinner mb-4"></div>
        <p class="text-lg font-semibold" id="loading_message">در حال پردازش اطلاعات...</p>
        <p class="text-sm text-gray-600 mt-2">لطفاً شکیبا باشید.</p>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // نمایش/مخفی کردن گزینه‌های تاریخ سفارشی
        document.getElementById('date_range').addEventListener('change', function() {
            const customDateContainer = document.getElementById('custom_date_container');
            if (this.value === 'custom') {
                customDateContainer.classList.remove('hidden');
            } else {
                customDateContainer.classList.add('hidden');
            }
        });

        // افزودن کلمه کلیدی جدید
        document.getElementById('add_keyword').addEventListener('click', function() {
            const keywordsContainer = document.getElementById('keywords_container');
            const newKeywordItem = document.createElement('div');
            newKeywordItem.className = 'keyword-item mb-3 flex items-center gap-2';
            newKeywordItem.innerHTML = `
                    <input type="text" name="keywords[]"
                           class="flex-grow rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                           placeholder="کلمه کلیدی یا عبارت...">
                    <button type="button" class="remove-keyword p-2 text-red-500 hover:text-red-700 focus:outline-none">
                        <i class="fas fa-times"></i>
                    </button>
                `;
            keywordsContainer.appendChild(newKeywordItem);

            // اضافه کردن رویداد حذف به دکمه جدید
            newKeywordItem.querySelector('.remove-keyword').addEventListener('click', function() {
                if (document.querySelectorAll('.keyword-item').length > 1) {
                    newKeywordItem.remove();
                } else {
                    newKeywordItem.querySelector('input').value = '';
                    Swal.fire({
                        icon: 'info',
                        title: 'توجه',
                        text: 'حداقل یک کلمه کلیدی لازم است.',
                        confirmButtonText: 'تایید'
                    });
                }
            });
        });

        // حذف کلمه کلیدی
        document.querySelectorAll('.remove-keyword').forEach(button => {
            button.addEventListener('click', function() {
                if (document.querySelectorAll('.keyword-item').length > 1) {
                    this.closest('.keyword-item').remove();
                } else {
                    this.closest('.keyword-item').querySelector('input').value = '';
                    Swal.fire({
                        icon: 'info',
                        title: 'توجه',
                        text: 'حداقل یک کلمه کلیدی لازم است.',
                        confirmButtonText: 'تایید'
                    });
                }
            });
        });

        // ذخیره پیش‌نویس
        document.getElementById('save_draft').addEventListener('click', function() {
            const formData = new FormData(document.getElementById('reportForm'));
            formData.append('is_draft', '1');

            showLoading('در حال ذخیره پیش‌نویس...');

            // ارسال فرم با AJAX
            fetch(document.getElementById('reportForm').action, {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'موفقیت',
                            text: 'پیش‌نویس گزارش با موفقیت ذخیره شد.',
                            confirmButtonText: 'تایید'
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'خطا',
                            text: data.message || 'خطایی در ذخیره گزارش رخ داد.',
                            confirmButtonText: 'تایید'
                        });
                    }
                })
                .catch(error => {
                    hideLoading();
                    Swal.fire({
                        icon: 'error',
                        title: 'خطا',
                        text: 'خطایی در ارتباط با سرور رخ داد.',
                        confirmButtonText: 'تایید'
                    });
                });
        });

        // پیش‌نمایش گزارش
        document.getElementById('preview_report').addEventListener('click', function() {
            const formData = new FormData(document.getElementById('reportForm'));
            formData.append('preview', '1');

            showLoading('در حال ایجاد پیش‌نمایش گزارش...');

            // ارسال فرم با AJAX
            fetch('/reports/preview', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    if (data.success) {
                        // باز کردن صفحه پیش‌نمایش در تب جدید
                        window.open(data.preview_url, '_blank');
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'خطا',
                            text: data.message || 'خطایی در ایجاد پیش‌نمایش رخ داد.',
                            confirmButtonText: 'تایید'
                        });
                    }
                })
                .catch(error => {
                    hideLoading();
                    Swal.fire({
                        icon: 'error',
                        title: 'خطا',
                        text: 'خطایی در ارتباط با سرور رخ داد.',
                        confirmButtonText: 'تایید'
                    });
                });
        });

        // نمایش/مخفی کردن صفحه درحال بارگذاری
        function showLoading(message) {
            document.getElementById('loading_message').textContent = message || 'در حال پردازش اطلاعات...';
            document.getElementById('loading_overlay').style.display = 'flex';
        }

        function hideLoading() {
            document.getElementById('loading_overlay').style.display = 'none';
        }

        // ارسال فرم
        document.getElementById('reportForm').addEventListener('submit', function(e) {
            e.preventDefault();

            // بررسی معتبر بودن فرم
            const title = document.getElementById('report_title').value.trim();
            const selectedPlatforms = document.querySelectorAll('input[name="platforms[]"]:checked');
            const keywords = Array.from(document.querySelectorAll('input[name="keywords[]"]'))
                .map(input => input.value.trim())
                .filter(value => value !== '');

            let isValid = true;
            let errorMessage = '';

            if (!title) {
                isValid = false;
                errorMessage = 'لطفاً عنوان گزارش را وارد کنید.';
            } else if (selectedPlatforms.length === 0) {
                isValid = false;
                errorMessage = 'لطفاً حداقل یک پلتفرم را انتخاب کنید.';
            } else if (keywords.length === 0) {
                isValid = false;
                errorMessage = 'لطفاً حداقل یک کلمه کلیدی وارد کنید.';
            }

            if (!isValid) {
                Swal.fire({
                    icon: 'warning',
                    title: 'خطا در اطلاعات',
                    text: errorMessage,
                    confirmButtonText: 'تایید'
                });
                return;
            }

            // اگر بازه زمانی سفارشی انتخاب شده، تاریخ‌ها را بررسی کنید
            if (document.getElementById('date_range').value === 'custom') {
                const startDate = document.getElementById('start_date').value;
                const endDate = document.getElementById('end_date').value;

                if (!startDate || !endDate) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'خطا در اطلاعات',
                        text: 'لطفاً تاریخ شروع و پایان را مشخص کنید.',
                        confirmButtonText: 'تایید'
                    });
                    return;
                }

                if (new Date(startDate) > new Date(endDate)) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'خطا در اطلاعات',
                        text: 'تاریخ شروع نمی‌تواند بعد از تاریخ پایان باشد.',
                        confirmButtonText: 'تایید'
                    });
                    return;
                }
            }

            // نمایش پیام در حال بارگذاری
            showLoading('در حال ثبت گزارش...');

            // ارسال فرم
            this.submit();
        });
    });
</script>

<!-- Footer -->
<footer class="bg-gray-800 text-white py-6 mt-12">
    <div class="container mx-auto px-4">
        <div class="flex flex-wrap justify-between items-center">
            <div class="w-full md:w-1/2 mb-4 md:mb-0">
                <h2 class="text-xl font-bold mb-2">SOCIALKOCH.CO</h2>
                <p class="text-gray-400">سامانه هوشمند رصد، پایش و تحلیل شبکه‌های اجتماعی</p>
            </div>
            <div class="w-full md:w-1/2">
                <div class="flex flex-wrap justify-end">
                    <div class="w-full md:w-auto mb-4 md:mb-0 md:<?= $isRtl ? 'ml-12' : 'mr-12' ?>">
                        <h3 class="text-lg font-semibold mb-2">دسترسی سریع</h3>
                        <ul class="space-y-1">
                            <li><a href="/dashboard" class="text-gray-400 hover:text-white">داشبورد</a></li>
                            <li><a href="/reports" class="text-gray-400 hover:text-white">گزارش‌ها</a></li>
                            <li><a href="/subscription" class="text-gray-400 hover:text-white">اشتراک</a></li>
                        </ul>
                    </div>
                    <div class="w-full md:w-auto">
                        <h3 class="text-lg font-semibold mb-2">پشتیبانی</h3>
                        <ul class="space-y-1">
                            <li><a href="/support" class="text-gray-400 hover:text-white">تماس با ما</a></li>
                            <li><a href="/faq" class="text-gray-400 hover:text-white">سوالات متداول</a></li>
                            <li><a href="/terms" class="text-gray-400 hover:text-white">قوانین و مقررات</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="border-t border-gray-700 mt-6 pt-6 text-center text-gray-400">
            <p>تمامی حقوق این سامانه متعلق به SOCIALKOCH.CO می‌باشد. &copy; <?= date('Y') ?></p>
        </div>
    </div>
</footer>
</body>
</html>