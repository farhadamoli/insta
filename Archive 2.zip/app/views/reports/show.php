<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edameye - سیستم جامع رصد، پایش و تحلیل شبکه‌های اجتماعی</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        @font-face {
            font-family: 'IRANSans';
            src: url('fonts/IRANSans.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }
        body {
            font-family: 'IRANSans', 'Tahoma', sans-serif;
            background-color: #f8f9fa;
        }
        .gradient-bg {
            background: linear-gradient(90deg, #4776E6 0%, #8E54E9 100%);
        }
        .feature-card {
            transition: all 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .custom-shadow {
            box-shadow: 0 4px 6px rgba(50, 50, 93, 0.11), 0 1px 3px rgba(0, 0, 0, 0.08);
        }
        .price-card {
            transition: all 0.3s ease;
        }
        .price-card:hover {
            transform: scale(1.03);
        }
        .popular-plan {
            transform: scale(1.05);
        }
    </style>
</head>
<body class="antialiased">
<!-- Navigation -->
<nav class="bg-white shadow-sm p-4 sticky top-0 z-50">
    <div class="container mx-auto flex justify-between items-center">
        <div class="flex items-center">
            <a href="#" class="text-2xl font-bold text-purple-600">
                <span class="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600">edameye</span>
            </a>
        </div>
        <div class="hidden md:flex space-x-6 space-x-reverse">
            <a href="#features" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md">ویژگی‌ها</a>
            <a href="#pricing" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md">تعرفه‌ها</a>
            <a href="#contact" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md">تماس با ما</a>
            <a href="#blog" class="text-gray-700 hover:text-purple-600 px-3 py-2 rounded-md">وبلاگ</a>
        </div>
        <div class="flex space-x-3 space-x-reverse">
            <a href="/login" class="text-purple-600 hover:text-purple-800 px-4 py-2 rounded-md border border-purple-600 hover:border-purple-800">ورود</a>
            <a href="/register" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md transition-colors duration-300">ثبت نام</a>
        </div>
        <button class="md:hidden flex items-center">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
        </button>
    </div>
</nav>

<!-- Hero Section -->
<section class="gradient-bg text-white py-20">
    <div class="container mx-auto px-4 flex flex-col lg:flex-row items-center">
        <div class="lg:w-1/2 mb-10 lg:mb-0">
            <h1 class="text-4xl md:text-5xl font-bold mb-6">سیستم جامع رصد، پایش و تحلیل شبکه‌های اجتماعی</h1>
            <p class="text-xl mb-8">با edameye به راحتی پیج‌های اجتماعی خود را مدیریت کنید، تحلیل‌های دقیق دریافت کنید و استراتژی محتوایی هوشمند طراحی کنید.</p>
            <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 sm:space-x-reverse">
                <a href="/register" class="bg-white text-purple-700 hover:bg-gray-100 font-bold px-6 py-3 rounded-lg text-center">شروع رایگان</a>
                <a href="#demo" class="bg-transparent border-2 border-white hover:bg-white hover:text-purple-700 text-white font-bold px-6 py-3 rounded-lg transition-colors duration-300 text-center">نمایش دمو</a>
            </div>
        </div>
        <div class="lg:w-1/2">
            <img src="/api/placeholder/600/400" alt="داشبورد edameye" class="rounded-lg shadow-xl">
        </div>
    </div>
</section>

<!-- Stats -->
<section class="py-10 bg-white">
    <div class="container mx-auto px-4">
        <div class="flex flex-wrap -mx-4 text-center">
            <div class="w-full md:w-1/3 px-4 mb-6 md:mb-0">
                <div class="p-6 bg-gray-50 rounded-lg custom-shadow h-full">
                    <i class="fas fa-chart-line text-4xl text-purple-600 mb-4"></i>
                    <h3 class="text-2xl font-bold mb-2">+۵۰٪</h3>
                    <p class="text-gray-600">افزایش تعامل در شبکه‌های اجتماعی</p>
                </div>
            </div>
            <div class="w-full md:w-1/3 px-4 mb-6 md:mb-0">
                <div class="p-6 bg-gray-50 rounded-lg custom-shadow h-full">
                    <i class="fas fa-users text-4xl text-purple-600 mb-4"></i>
                    <h3 class="text-2xl font-bold mb-2">۱۰,۰۰۰+</h3>
                    <p class="text-gray-600">کاربر فعال در پلتفرم</p>
                </div>
            </div>
            <div class="w-full md:w-1/3 px-4">
                <div class="p-6 bg-gray-50 rounded-lg custom-shadow h-full">
                    <i class="fas fa-clock text-4xl text-purple-600 mb-4"></i>
                    <h3 class="text-2xl font-bold mb-2">۷۰٪</h3>
                    <p class="text-gray-600">صرفه‌جویی در زمان مدیریت شبکه‌های اجتماعی</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features -->
<section id="features" class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold mb-4">ویژگی‌های پیشرفته edameye</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">مجموعه کاملی از ابزارهای مدیریت و تحلیل شبکه‌های اجتماعی برای رشد حرفه‌ای کسب و کار شما</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!-- Feature 1 -->
            <div class="feature-card bg-white rounded-lg p-6 custom-shadow">
                <div class="w-14 h-14 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-chart-pie text-2xl text-purple-600"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">تحلیل پیشرفته اینستاگرام</h3>
                <p class="text-gray-600">گزارش‌های دقیق از روند رشد، تعامل کاربران، لایک‌ها، کامنت‌ها و بهترین زمان پست گذاری</p>
            </div>

            <!-- Feature 2 -->
            <div class="feature-card bg-white rounded-lg p-6 custom-shadow">
                <div class="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-robot text-2xl text-blue-600"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">تولید محتوا با هوش مصنوعی</h3>
                <p class="text-gray-600">ایده‌های محتوایی خلاقانه، کپشن‌ها و تصاویر منحصر به فرد با استفاده از هوش مصنوعی</p>
            </div>

            <!-- Feature 3 -->
            <div class="feature-card bg-white rounded-lg p-6 custom-shadow">
                <div class="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-calendar-alt text-2xl text-green-600"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">برنامه‌ریزی محتوایی</h3>
                <p class="text-gray-600">زمان‌بندی پست‌ها، استوری‌ها و محتوای ویدئویی به صورت هوشمند و خودکار</p>
            </div>

            <!-- Feature 4 -->
            <div class="feature-card bg-white rounded-lg p-6 custom-shadow">
                <div class="w-14 h-14 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-bullseye text-2xl text-yellow-600"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">استراتژی‌های رشد</h3>
                <p class="text-gray-600">راهکارهای تخصصی و برنامه‌های اختصاصی برای افزایش فالوور و تعامل</p>
            </div>

            <!-- Feature 5 -->
            <div class="feature-card bg-white rounded-lg p-6 custom-shadow">
                <div class="w-14 h-14 bg-red-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-lightbulb text-2xl text-red-600"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">ایده‌های خلاقانه</h3>
                <p class="text-gray-600">پیشنهادات نوآورانه برای محتوا، کمپین‌های تبلیغاتی و نام‌گذاری برند</p>
            </div>

            <!-- Feature 6 -->
            <div class="feature-card bg-white rounded-lg p-6 custom-shadow">
                <div class="w-14 h-14 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-users-cog text-2xl text-indigo-600"></i>
                </div>
                <h3 class="text-xl font-bold mb-3">مدیریت CRM</h3>
                <p class="text-gray-600">مدیریت ارتباط با مشتریان و مخاطبان به صورت یکپارچه با شبکه‌های اجتماعی</p>
            </div>
        </div>

        <div class="mt-16 text-center">
            <a href="/features" class="text-purple-600 hover:text-purple-800 font-bold text-lg">
                مشاهده تمامی ویژگی‌ها
                <i class="fas fa-arrow-left mr-2"></i>
            </a>
        </div>
    </div>
</section>

<!-- How it works -->
<section class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold mb-4">چگونه edameye کار می‌کند؟</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">در سه مرحله ساده، مدیریت شبکه‌های اجتماعی خود را متحول کنید</p>
        </div>

        <div class="flex flex-col md:flex-row items-center justify-between">
            <!-- Step 1 -->
            <div class="w-full md:w-1/3 px-4 mb-10 md:mb-0 text-center">
                <div class="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <span class="text-2xl font-bold text-purple-600">1</span>
                </div>
                <h3 class="text-xl font-bold mb-3">ثبت پیج</h3>
                <p class="text-gray-600">پیج اینستاگرام خود را در سیستم ثبت کنید و اطلاعات پایه را وارد نمایید.</p>
            </div>

            <!-- Step 2 -->
            <div class="w-full md:w-1/3 px-4 mb-10 md:mb-0 text-center">
                <div class="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <span class="text-2xl font-bold text-purple-600">2</span>
                </div>
                <h3 class="text-xl font-bold mb-3">دریافت تحلیل</h3>
                <p class="text-gray-600">گزارش‌های دقیق و تحلیل‌های پیشرفته از عملکرد پیج خود را مشاهده کنید.</p>
            </div>

            <!-- Step 3 -->
            <div class="w-full md:w-1/3 px-4 text-center">
                <div class="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <span class="text-2xl font-bold text-purple-600">3</span>
                </div>
                <h3 class="text-xl font-bold mb-3">رشد و توسعه</h3>
                <p class="text-gray-600">با استفاده از ابزارهای هوشمند و برنامه‌ریزی محتوایی، پیج خود را رشد دهید.</p>
            </div>
        </div>
    </div>
</section>

<!-- Pricing -->
<section id="pricing" class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold mb-4">تعرفه‌های اشتراک</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">پلن مناسب کسب و کار خود را انتخاب کنید</p>
        </div>

        <div class="flex flex-col lg:flex-row justify-center gap-8">
            <!-- Plan 1 -->
            <div class="price-card bg-white rounded-lg overflow-hidden custom-shadow lg:w-1/3">
                <div class="p-6 border-b">
                    <h3 class="text-2xl font-bold mb-2">اشتراک یک ماهه</h3>
                    <div class="flex items-end mb-4">
                        <span class="text-4xl font-bold">۱۰۰,۰۰۰</span>
                        <span class="text-gray-600 mr-1">تومان</span>
                    </div>
                    <p class="text-gray-600">مناسب برای کاربران تازه‌کار</p>
                </div>
                <div class="p-6">
                    <ul class="space-y-3 mb-6">
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۳ پیج اینستاگرام</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۵ پست در روز</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۵۰ تولید محتوا با هوش مصنوعی</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>تحلیل‌های پایه</span>
                        </li>
                        <li class="flex items-center text-gray-400">
                            <i class="fas fa-times text-red-500 ml-2"></i>
                            <span>مدیریت CRM</span>
                        </li>
                    </ul>
                    <a href="/register?plan=monthly" class="block w-full text-center bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-lg transition-colors duration-300">انتخاب پلن</a>
                </div>
            </div>

            <!-- Plan 2 - Popular -->
            <div class="price-card popular-plan bg-white rounded-lg overflow-hidden custom-shadow lg:w-1/3 relative">
                <div class="absolute top-0 left-0 right-0 bg-yellow-500 text-white py-1 text-center font-bold">
                    پرطرفدارترین
                </div>
                <div class="p-6 border-b">
                    <h3 class="text-2xl font-bold mb-2">اشتراک سه ماهه</h3>
                    <div class="flex items-end mb-4">
                        <span class="text-4xl font-bold">۵۰۰,۰۰۰</span>
                        <span class="text-gray-600 mr-1">تومان</span>
                    </div>
                    <p class="text-gray-600">مناسب برای کسب و کارهای در حال رشد</p>
                </div>
                <div class="p-6">
                    <ul class="space-y-3 mb-6">
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۵ پیج اینستاگرام</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۱۰ پست در روز</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۲۰۰ تولید محتوا با هوش مصنوعی</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>تحلیل‌های پیشرفته</span>
                        </li>
                        <li class="flex items-center text-gray-400">
                            <i class="fas fa-times text-red-500 ml-2"></i>
                            <span>مدیریت CRM</span>
                        </li>
                    </ul>
                    <a href="/register?plan=quarterly" class="block w-full text-center bg-yellow-500 hover:bg-yellow-600 text-white py-3 rounded-lg transition-colors duration-300">انتخاب پلن</a>
                </div>
            </div>

            <!-- Plan 3 -->
            <div class="price-card bg-white rounded-lg overflow-hidden custom-shadow lg:w-1/3">
                <div class="p-6 border-b">
                    <h3 class="text-2xl font-bold mb-2">اشتراک یک ساله</h3>
                    <div class="flex items-end mb-4">
                        <span class="text-4xl font-bold">۲,۰۰۰,۰۰۰</span>
                        <span class="text-gray-600 mr-1">تومان</span>
                    </div>
                    <p class="text-gray-600">مناسب برای کسب و کارهای حرفه‌ای</p>
                </div>
                <div class="p-6">
                    <ul class="space-y-3 mb-6">
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۱۰ پیج اینستاگرام</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۲۰ پست در روز</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>۱۰۰۰ تولید محتوا با هوش مصنوعی</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>تحلیل‌های پیشرفته و تخصصی</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check text-green-500 ml-2"></i>
                            <span>مدیریت CRM</span>
                        </li>
                    </ul>
                    <a href="/register?plan=yearly" class="block w-full text-center bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-lg transition-colors duration-300">انتخاب پلن</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold mb-4">نظرات مشتریان</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">آنچه کاربران ما درباره edameye می‌گویند</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Testimonial 1 -->
            <div class="bg-gray-50 p-6 rounded-lg custom-shadow">
                <div class="flex items-center mb-4">
                    <img src="/api/placeholder/60/60" alt="تصویر کاربر" class="w-12 h-12 rounded-full">
                    <div class="mr-3">
                        <h4 class="font-bold">علی محمدی</h4>
                        <p class="text-sm text-gray-600">مدیر شبکه‌های اجتماعی</p>
                    </div>
                </div>
                <p class="text-gray-700">«با استفاده از edameye توانستیم در مدت ۳ ماه فالوورهای پیج خود را دو برابر کنیم. تحلیل‌های دقیق و ایده‌های محتوایی عالی!»</p>
                <div class="mt-4 flex">
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                </div>
            </div>

            <!-- Testimonial 2 -->
            <div class="bg-gray-50 p-6 rounded-lg custom-shadow">
                <div class="flex items-center mb-4">
                    <img src="/api/placeholder/60/60" alt="تصویر کاربر" class="w-12 h-12 rounded-full">
                    <div class="mr-3">
                        <h4 class="font-bold">مریم حسینی</h4>
                        <p class="text-sm text-gray-600">صاحب فروشگاه آنلاین</p>
                    </div>
                </div>
                <p class="text-gray-700">«زمان زیادی برای مدیریت اینستاگرام نداشتم. با edameye همه چیز خودکار شد و میزان فروش ما از طریق اینستاگرام ۴۰٪ افزایش یافت.»</p>
                <div class="mt-4 flex">
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star-half-alt text-yellow-500"></i>
                </div>
            </div>

            <!-- Testimonial 3 -->
            <div class="bg-gray-50 p-6 rounded-lg custom-shadow">
                <div class="flex items-center mb-4">
                    <img src="/api/placeholder/60/60" alt="تصویر کاربر" class="w-12 h-12 rounded-full">
                    <div class="mr-3">
                        <h4 class="font-bold">رضا کریمی</h4>
                        <p class="text-sm text-gray-600">اینفلوئنسر دیجیتال مارکتینگ</p>
                    </div>
                </div>
                <p class="text-gray-700">«به عنوان یک اینفلوئنسر، edameye به من کمک کرد تا محتوای با کیفیت‌تری تولید کنم و تعامل فالوورهایم را افزایش دهم.»</p>
                <div class="mt-4 flex">
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                    <i class="fas fa-star text-yellow-500"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="py-20 gradient-bg text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl md:text-4xl font-bold mb-6">آماده شروع هستید؟</h2>
        <p class="text-xl mb-8 max-w-3xl mx-auto">امروز به edameye بپیوندید و تحولی در شبکه‌های اجتماعی خود ایجاد کنید.</p>
        <a href="/register" class="bg-white text-purple-700 hover:bg-gray-100 font-bold px-8 py-4 rounded-lg inline-block text-lg transition-colors duration-300">
            ثبت نام رایگان
            <i class="fas fa-arrow-left mr-2"></i>
        </a>
    </div>
</section>

<!-- Footer -->
<footer class="bg-gray-800 text-white py-12">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
                <h3 class="text-xl font-bold mb-4">edameye</h3>
                <p class="mb-4">سیستم جامع رصد، پایش و تحلیل شبکه‌های اجتماعی</p>
                <div class="flex space-x-4 space-x-reverse">
                    <a href="#" class="text-gray-300 hover:text-white">
                        <i class="fab fa-instagram text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-300 hover:text-white">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-300 hover:text-white">
                        <i class="fab fa-linkedin text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-300 hover:text-white">
                        <i class="fab fa-telegram text-xl"></i>
                    </a>
                </div>
            </div>
            <div>
                <h3 class="text-xl font-bold mb-4">دسترسی سریع</h3>
                <ul class="space-y-2">
                    <li><a href="#" class="text-gray-300 hover:text-white">صفحه اصلی</a></li>
                    <li><a href="#features" class="text-gray-300 hover:text-white">ویژگی‌ها</a></li>
                    <li><a href="#pricing" class="text-gray-300 hover:text-white">تعرفه‌ها</a></li>
                    <li><a href="/login" class="text-gray-300 hover:text-white">ورود</a></li>
                    <li><a href="/register" class="text-gray-300 hover:text-white">ثبت نام</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-xl font-bold mb-4">خدمات ما</h3>
                <ul class="space-y-2">
                    <li><a href="#" class="text-gray-300 hover:text-white">تحلیل اینستاگرام</a></li>
                    <li><a href="#" class="text-gray-300 hover:text-white">تولید محتوا با هوش مصنوعی</a></li>
                    <li><a href="#" class="text-gray-300 hover:text-white">طراحی لوگو</a></li>
                    <li><a href="#" class="text-gray-300 hover:text-white">خدمات برندینگ</a></li>
                    <li><a href="#" class="text-gray-300 hover:text-white">مدیریت CRM</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-xl font-bold mb-4">تماس با ما</h3>
                <ul class="space-y-2">
                    <li class="flex items-center">
                        <i class="fas fa-envelope ml-2 text-purple-400"></i>
                        <span>info@edameye.com</span>
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-phone ml-2 text-purple-400"></i>
                        <span>۰۲۱-۸۸۲۲۵۵۴۴</span>
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-map-marker-alt ml-2 text-purple-400"></i>
                        <span>تهران، خیابان ولیعصر، برج نگین</span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="border-t border-gray-700 mt-8 pt-8 text-center">
            <p>&copy; ۱۴۰۴ edameye - تمامی حقوق محفوظ است.</p>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.0.18/sweetalert2.min.js"></script>
<script>
    // Mobile menu toggle
    document.querySelector('button.md\\:hidden').addEventListener('click', function() {
        const menu = document.querySelector('.md\\:flex.space-x-6');
        menu.classList.toggle('hidden');
        menu.classList.toggle('flex');
        menu.classList.toggle('flex-col');
        menu.classList.toggle('absolute');
        menu.classList.toggle('top-16');
        menu.classList.toggle('right-0');
        menu.classList.toggle('w-full');
        menu.classList.toggle('bg-white');
        menu.classList.toggle('p-4');
        menu.classList.toggle('shadow-md');
    });

    // Demo button click
    document.querySelector('a[href="#demo"]').addEventListener('click', function(e) {
        e.preventDefault();
        Swal.fire({
            title: 'نمایش دمو',
            html: '<iframe width="100%" height="400" src="/api/placeholder/800/400" frameborder="0" allowfullscreen></iframe>',
            width: '80%',
            confirmButtonText: 'بستن',
            confirmButtonColor: '#8E54E9',
        });
    });
</script>
</body>
</html>