<?php
/**
 * reports/index.php
 *
 * قالب نمایش لیست گزارش‌های رصد، پایش و تحلیل شبکه‌های اجتماعی
 */

// دسترسی به متغیرهای ارسالی از کنترلر
/* @var $title string */
/* @var $reports array */
/* @var $page string */

// تنظیم متغیرهای پیش‌فرض
$currentLang = \App\Core\Language::getCurrentLang();
$isRtl = $currentLang === 'fa';
$dir = $isRtl ? 'rtl' : 'ltr';
?>

<!DOCTYPE html>
<html lang="<?= $currentLang ?>" dir="<?= $dir ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Vazirmatn Font (برای فارسی) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            font-family: <?= $isRtl ? "'Vazirmatn'" : "'Inter'" ?>, system-ui, sans-serif;
        }

        .socialkoch-gradient {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
        }

        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .loading-spinner {
            display: inline-block;
            width: 50px;
            height: 50px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
    </style>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            200: '#c7d2fe',
                            300: '#a5b4fc',
                            400: '#818cf8',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            800: '#3730a3',
                            900: '#312e81',
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 min-h-screen">
<!-- Header -->
<header class="socialkoch-gradient text-white shadow-md">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <div class="flex items-center">
            <h1 class="text-2xl font-bold">SOCIALKOCH.CO</h1>
            <p class="<?= $isRtl ? 'mr-2' : 'ml-2' ?> text-sm opacity-90">رصد، پایش و تحلیل شبکه‌های اجتماعی</p>
        </div>
        <div class="flex items-center space-x-4 <?= $isRtl ? 'space-x-reverse' : '' ?>">
            <div class="relative">
                <button class="text-white focus:outline-none">
                    <i class="fas fa-bell text-lg"></i>
                    <span class="absolute -top-1 <?= $isRtl ? 'left-0' : 'right-0' ?> bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">3</span>
                </button>
            </div>
            <div class="flex items-center">
                <img src="<?= asset('images/avatar.png') ?>" alt="User" class="w-8 h-8 rounded-full">
                <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">کاربر گرامی</span>
            </div>
        </div>
    </div>
</header>

<!-- Main Content -->
<div class="container mx-auto px-4 py-8 flex flex-wrap md:flex-nowrap">
    <!-- Sidebar -->
    <aside class="w-full md:w-1/4 md:<?= $isRtl ? 'ml-6' : 'mr-6' ?> mb-6 md:mb-0">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <div class="flex items-center mb-6">
                <img src="<?= asset('images/avatar.png') ?>" alt="User" class="w-12 h-12 rounded-full">
                <div class="<?= $isRtl ? 'mr-3' : 'ml-3' ?>">
                    <p class="font-semibold">کاربر گرامی</p>
                    <p class="text-sm text-gray-600">اشتراک ویژه</p>
                </div>
            </div>

            <div class="mb-4">
                <h3 class="font-semibold text-gray-700 mb-2">وضعیت اشتراک</h3>
                <div class="bg-primary-50 p-3 rounded-lg">
                    <div class="flex justify-between mb-1">
                        <span class="text-sm">اشتراک ویژه</span>
                        <span class="text-sm text-primary-700">فعال</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm">تاریخ انقضا</span>
                        <span class="text-sm">۱۴۰۴/۰۲/۱۵</span>
                    </div>
                    <div class="mt-2">
                        <div class="w-full bg-gray-200 h-2 rounded-full">
                            <div class="bg-primary-600 h-2 rounded-full" style="width: 75%"></div>
                        </div>
                        <p class="text-xs text-center mt-1">۲۳ روز باقی‌مانده</p>
                    </div>
                </div>
            </div>

            <nav>
                <ul class="space-y-1">
                    <li>
                        <a href="/dashboard" class="flex items-center p-2 rounded-lg <?= $page === 'dashboard' ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-100' ?>">
                            <i class="fas fa-home w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">داشبورد</span>
                        </a>
                    </li>
                    <li>
                        <a href="/reports" class="flex items-center p-2 rounded-lg <?= $page === 'reports' ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-100' ?>">
                            <i class="fas fa-chart-bar w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">گزارش‌های آنالیز</span>
                        </a>
                    </li>
                    <li>
                        <a href="/instagram" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fab fa-instagram w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پیج‌های اینستاگرام</span>
                        </a>
                    </li>
                    <li>
                        <a href="/content" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-layer-group w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">محتوای آموزشی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/subscription" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-gem w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">اشتراک ویژه</span>
                        </a>
                    </li>
                    <li>
                        <a href="/support" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-headset w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پشتیبانی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/invoices" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-file-invoice w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">صورت حساب‌ها</span>
                        </a>
                    </li>
                    <li>
                        <a href="/saves" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-bookmark w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">ذخیره شده‌ها</span>
                        </a>
                    </li>
                    <li>
                        <a href="/faq" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-question-circle w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">پرسش‌های شما</span>
                        </a>
                    </li>
                    <li>
                        <a href="/terms" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-file-contract w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">شرایط و قوانین</span>
                        </a>
                    </li>
                    <li>
                        <a href="/privacy" class="flex items-center p-2 rounded-lg hover:bg-gray-100">
                            <i class="fas fa-shield-alt w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">حریم خصوصی</span>
                        </a>
                    </li>
                    <li>
                        <a href="/auth/logout" class="flex items-center p-2 rounded-lg hover:bg-gray-100 text-red-600">
                            <i class="fas fa-sign-out-alt w-5 text-center"></i>
                            <span class="<?= $isRtl ? 'mr-2' : 'ml-2' ?>">خروج از حساب کاربری</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="w-full md:w-3/4">
        <div class="bg-white rounded-lg shadow-sm p-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold">گزارش‌های آنالیز</h2>
                <a href="/reports/create" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition-all">
                    <i class="fas fa-plus"></i>
                    <span class="<?= $isRtl ? 'mr-1' : 'ml-1' ?>">گزارش جدید</span>
                </a>
            </div>

            <?php if (empty($reports)): ?>
                <div class="text-center py-12">
                    <div class="mb-6">
                        <i class="fas fa-chart-line text-6xl text-gray-300"></i>
                    </div>
                    <h3 class="text-lg text-gray-500 mb-4">هنوز هیچ گزارشی ثبت نکرده‌اید</h3>
                    <p class="text-gray-400 max-w-md mx-auto mb-8">
                        با ایجاد گزارش‌های آنالیز می‌توانید عملکرد پیج‌های اینستاگرام خود را بررسی کنید و استراتژی‌های بهبود را دریافت نمایید.
                    </p>
                    <a href="/reports/create" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg transition-all inline-block">
                        <i class="fas fa-plus"></i>
                        <span class="<?= $isRtl ? 'mr-1' : 'ml-1' ?>">ایجاد گزارش جدید</span>
                    </a>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php foreach ($reports as $report): ?>
                        <div class="border border-gray-200 rounded-lg overflow-hidden shadow-sm transition-all duration-300 card-hover">
                            <div class="socialkoch-gradient text-white p-4">
                                <h3 class="font-semibold text-lg"><?= htmlspecialchars($report['title']) ?></h3>
                                <p class="text-sm opacity-90"><?= htmlspecialchars($report['instagram_id']) ?></p>
                            </div>
                            <div class="p-4">
                                <div class="mb-4">
                                    <div class="flex justify-between mb-1">
                                        <span class="text-sm">فالوورها</span>
                                        <span class="text-sm font-semibold"><?= number_format($report['followers_count']) ?></span>
                                    </div>
                                    <div class="flex justify-between mb-1">
                                        <span class="text-sm">نرخ تعامل</span>
                                        <span class="text-sm font-semibold"><?= number_format($report['engagement_rate'], 2) ?>%</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-sm">تاریخ ایجاد</span>
                                        <span class="text-sm"><?= $report['created_at'] ?></span>
                                    </div>
                                </div>
                                <div class="flex justify-between">
                                    <a href="/reports/<?= $report['id'] ?>" class="text-primary-600 hover:text-primary-800 text-sm">
                                        <i class="fas fa-eye"></i>
                                        <span class="<?= $isRtl ? 'mr-1' : 'ml-1' ?>">مشاهده جزئیات</span>
                                    </a>
                                    <a href="/reports/<?= $report['id'] ?>/export/pdf" class="text-gray-600 hover:text-gray-800 text-sm">
                                        <i class="fas fa-download"></i>
                                        <span class="<?= $isRtl ? 'mr-1' : 'ml-1' ?>">دانلود PDF</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- Footer -->
<footer class="bg-white border-t mt-8 py-6">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row justify-between items-center">
            <div class="mb-4 md:mb-0">
                <p class="text-gray-600 text-sm">© <?= date('Y') ?> SOCIALKOCH.CO - تمامی حقوق محفوظ است</p>
            </div>
            <div class="flex space-x-4 <?= $isRtl ? 'space-x-reverse' : '' ?>">
                <a href="/terms" class="text-gray-600 hover:text-primary-600 text-sm">شرایط و قوانین</a>
                <a href="/privacy" class="text-gray-600 hover:text-primary-600 text-sm">حریم خصوصی</a>
                <a href="/contact" class="text-gray-600 hover:text-primary-600 text-sm">تماس با ما</a>
            </div>
        </div>
    </div>
</footer>

<!-- Loading Modal -->
<div id="loading-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center hidden">
    <div class="bg-white rounded-lg p-8 max-w-sm w-full text-center">
        <div class="flex justify-center mb-4">
            <div class="loading-spinner"></div>
        </div>
        <h3 class="text-xl font-semibold mb-2">در حال پردازش</h3>
        <p class="text-gray-600">لطفاً کمی صبر کنید...</p>
    </div>
</div>

<script>
    // نمایش Loading Modal
    function showLoading() {
        document.getElementById('loading-modal').classList.remove('hidden');
    }

    // مخفی کردن Loading Modal
    function hideLoading() {
        document.getElementById('loading-modal').classList.add('hidden');
    }

    // مثال استفاده از SweetAlert2
    function showAlert(type, title, text) {
        Swal.fire({
            icon: type,
            title: title,
            text: text,
            confirmButtonColor: '#4f46e5'
        });
    }
</script>
</body>
</html>