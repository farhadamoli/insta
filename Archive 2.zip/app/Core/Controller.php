<?php

/**
 * Controller.php
 *
 * کلاس پایه برای تمام کنترلرهای پروژه ادامه‌ای
 */

namespace App\Core;

use App\Core\Request;
use App\Core\Response;

abstract class Controller {
    /**
     * شیء درخواست
     *
     * @var Request
     */
    protected $request;

    /**
     * شیء پاسخ
     *
     * @var Response
     */
    protected $response;

    /**
     * پارامترهای قالب
     *
     * @var array
     */
    protected $viewData = [];

    /**
     * میان‌افزارهای کنترلر
     *
     * @var array
     */
    protected $middleware = [];

    /**
     * سازنده کلاس
     */
    public function __construct() {
        $this->request = new Request();
        $this->response = new Response();
    }

    /**
     * تنظیم میان‌افزارها
     *
     * @param string|array $middleware نام یا آرایه‌ای از نام‌های میان‌افزارها
     * @param array $except آرایه‌ای از متدهای مستثنی (اختیاری)
     * @return void
     */
    protected function middleware($middleware, array $except = []) {
        if (is_string($middleware)) {
            $middleware = [$middleware];
        }

        foreach ($middleware as $m) {
            $this->middleware[] = [
                'name' => $m,
                'except' => $except
            ];
        }
    }

    /**
     * بررسی اجرای میان‌افزار برای متد
     *
     * @param string $middleware نام میان‌افزار
     * @param string $method نام متد
     * @return bool نتیجه بررسی
     */
    protected function shouldRunMiddleware($middleware, $method) {
        foreach ($this->middleware as $m) {
            if ($m['name'] === $middleware && in_array($method, $m['except'])) {
                return false;
            }
        }

        return true;
    }

    /**
     * بارگذاری مدل
     *
     * @param string $model نام مدل
     * @return object نمونه مدل
     */
    protected function loadModel($model) {
        $modelClass = "\\App\\Models\\{$model}";

        if (class_exists($modelClass)) {
            return new $modelClass();
        }

        throw new \Exception("Model {$model} not found");
    }

    /**
     * نمایش قالب
     *
     * @param string $view مسیر قالب
     * @param array $data داده‌های قالب (اختیاری)
     * @return string محتوای نمایش داده شده
     */
    protected function render($view, $data = []) {
        // ترکیب داده‌های جدید با داده‌های قبلی
        $data = array_merge($this->viewData, $data);

        // استخراج داده‌ها برای استفاده در قالب
        extract($data);

        // مسیر کامل فایل قالب
        $viewPath = VIEWS_PATH . '/' . $view . '.php';

        if (!file_exists($viewPath)) {
            throw new \Exception("View {$view} not found");
        }

        // شروع بافر خروجی
        ob_start();

        // شامل‌سازی فایل قالب
        include $viewPath;

        // دریافت محتوای بافر
        $content = ob_get_clean();

        // ارسال محتوا به پاسخ
        $this->response->setContent($content);
        $this->response->send();

        return $content;
    }

    /**
     * تنظیم داده‌های قالب
     *
     * @param string $key کلید
     * @param mixed $value مقدار
     * @return Controller برای زنجیره‌ای کردن متدها
     */
    protected function set($key, $value) {
        $this->viewData[$key] = $value;
        return $this;
    }

    /**
     * تغییر مسیر به URL دیگر
     *
     * @param string $url آدرس مقصد
     * @param array $flashMessage پیام فلش (اختیاری)
     * @return void
     */
    protected function redirect($url, $flashMessage = null) {
        if ($flashMessage) {
            $type = key($flashMessage);
            $message = $flashMessage[$type];
            $this->flash($type, $message);
        }

        $this->response->redirect($url);
    }

    /**
     * ارسال پاسخ JSON
     *
     * @param mixed $data داده
     * @param int $statusCode کد وضعیت (اختیاری)
     * @return void
     */
    protected function json($data, $statusCode = 200) {
        $this->response->json($data, $statusCode);
    }

    /**
     * ذخیره پیام فلش در نشست
     *
     * @param string $type نوع پیام (success, error, warning, info)
     * @param string $message متن پیام
     * @param string $title عنوان پیام (اختیاری)
     * @return void
     */
    protected function flash($type, $message, $title = null) {
        AlertHelper::flash($type, $message, $title);
    }

    /**
     * اعتبارسنجی داده‌های ورودی
     *
     * @param array $data داده‌ها
     * @param array $rules قوانین
     * @return array|bool آرایه خطاها یا true در صورت موفقیت
     */
    protected function validate($data, $rules) {
        $errors = [];

        foreach ($rules as $field => $rule) {
            $fieldRules = explode('|', $rule);

            foreach ($fieldRules as $fieldRule) {
                // بررسی قانون با پارامتر
                if (strpos($fieldRule, ':') !== false) {
                    list($ruleName, $ruleValue) = explode(':', $fieldRule);
                } else {
                    $ruleName = $fieldRule;
                    $ruleValue = null;
                }

                // اعتبارسنجی براساس نوع قانون
                switch ($ruleName) {
                    case 'required':
                        if (!isset($data[$field]) || $data[$field] === '') {
                            $errors[$field][] = 'The ' . $field . ' field is required.';
                        }
                        break;

                    case 'email':
                        if (isset($data[$field]) && $data[$field] !== '' && !filter_var($data[$field], FILTER_VALIDATE_EMAIL)) {
                            $errors[$field][] = 'The ' . $field . ' must be a valid email address.';
                        }
                        break;

                    case 'min':
                        if (isset($data[$field]) && strlen($data[$field]) < $ruleValue) {
                            $errors[$field][] = 'The ' . $field . ' must be at least ' . $ruleValue . ' characters.';
                        }
                        break;

                    case 'max':
                        if (isset($data[$field]) && strlen($data[$field]) > $ruleValue) {
                            $errors[$field][] = 'The ' . $field . ' may not be greater than ' . $ruleValue . ' characters.';
                        }
                        break;

                    case 'numeric':
                        if (isset($data[$field]) && $data[$field] !== '' && !is_numeric($data[$field])) {
                            $errors[$field][] = 'The ' . $field . ' must be a number.';
                        }
                        break;

                    case 'alpha':
                        if (isset($data[$field]) && $data[$field] !== '' && !ctype_alpha($data[$field])) {
                            $errors[$field][] = 'The ' . $field . ' may only contain letters.';
                        }
                        break;

                    case 'alphanumeric':
                        if (isset($data[$field]) && $data[$field] !== '' && !ctype_alnum($data[$field])) {
                            $errors[$field][] = 'The ' . $field . ' may only contain letters and numbers.';
                        }
                        break;

                    case 'url':
                        if (isset($data[$field]) && $data[$field] !== '' && !filter_var($data[$field], FILTER_VALIDATE_URL)) {
                            $errors[$field][] = 'The ' . $field . ' must be a valid URL.';
                        }
                        break;

                    case 'date':
                        if (isset($data[$field]) && $data[$field] !== '' && !strtotime($data[$field])) {
                            $errors[$field][] = 'The ' . $field . ' must be a valid date.';
                        }
                        break;

                    case 'matches':
                        if (isset($data[$field]) && isset($data[$ruleValue]) && $data[$field] !== $data[$ruleValue]) {
                            $errors[$field][] = 'The ' . $field . ' and ' . $ruleValue . ' must match.';
                        }
                        break;
                }
            }
        }

        return empty($errors) ? true : $errors;
    }

    /**
     * آماده‌سازی پاسخ خطای اعتبارسنجی
     *
     * @param array $errors خطاها
     * @param bool $jsonResponse آیا پاسخ JSON باشد؟
     * @return mixed پاسخ
     */
    protected function validationErrors($errors, $jsonResponse = false) {
        if ($jsonResponse) {
            return $this->json([
                'success' => false,
                'errors' => $errors
            ], 422);
        }

        $this->set('errors', $errors);
        return false;
    }

    /**
     * بررسی اعتبار توکن CSRF
     *
     * @param string $token توکن CSRF
     * @return bool نتیجه بررسی
     */
    protected function verifyCsrfToken($token) {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_expire'])) {
            return false;
        }

        if ($_SESSION['csrf_token_expire'] < time()) {
            return false;
        }

        return hash_equals($_SESSION['csrf_token'], $token);
    }

    /**
     * تولید توکن CSRF جدید
     *
     * @return string توکن CSRF
     */
    protected function generateCsrfToken() {
        $token = bin2hex(random_bytes(32));
        $_SESSION['csrf_token'] = $token;
        $_SESSION['csrf_token_expire'] = time() + CSRF_TOKEN_EXPIRE;

        return $token;
    }

    /**
     * دریافت توکن CSRF فعلی
     *
     * @return string توکن CSRF
     */
    protected function getCsrfToken() {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_expire']) || $_SESSION['csrf_token_expire'] < time()) {
            return $this->generateCsrfToken();
        }

        return $_SESSION['csrf_token'];
    }

    /**
     * تولید فیلد CSRF برای استفاده در فرم‌ها
     *
     * @return string فیلد HTML
     */
    protected function csrfField() {
        $token = $this->getCsrfToken();
        return '<input type="hidden" name="csrf_token" value="' . $token . '">';
    }
}