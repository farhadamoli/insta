<?php

/**
 * FileManager.php
 *
 * کلاس مدیریت فایل برای پروژه ادامه‌ای
 * مدیریت آپلود، ذخیره‌سازی و دسترسی به فایل‌های کاربران
 */

namespace App\Core;

use Exception;

class FileManager {
    // مسیرهای اصلی
    const UPLOAD_DIR = 'uploads';
    const PROFILES_DIR = 'uploads/profiles';
    const GENERATED_DIR = 'uploads/generated';
    const TEMP_DIR = 'uploads/temp';

    // تنظیمات پیش‌فرض
    private $allowedImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    private $allowedFileTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain', 'text/csv'];
    private $maxFileSize = 5242880; // 5 مگابایت
    private $maxImageSize = 2097152; // 2 مگابایت

    /**
     * سازنده کلاس - بررسی وجود پوشه‌های لازم
     */
    public function __construct() {
        $this->checkDirectories();
    }

    /**
     * بررسی وجود پوشه‌های لازم و ایجاد آنها در صورت نیاز
     */
    private function checkDirectories() {
        $directories = [
            self::UPLOAD_DIR,
            self::PROFILES_DIR,
            self::GENERATED_DIR,
            self::TEMP_DIR
        ];

        foreach ($directories as $dir) {
            if (!file_exists($dir)) {
                if (!mkdir($dir, 0755, true)) {
                    throw new Exception("مشکل در ایجاد پوشه {$dir}");
                }
            }
        }
    }

    /**
     * تنظیم نوع فایل‌های تصویری مجاز
     *
     * @param array $types آرایه‌ای از MIME type های مجاز
     * @return FileManager برای زنجیره‌ای کردن متدها
     */
    public function setAllowedImageTypes(array $types) {
        $this->allowedImageTypes = $types;
        return $this;
    }

    /**
     * تنظیم نوع فایل‌های مجاز
     *
     * @param array $types آرایه‌ای از MIME type های مجاز
     * @return FileManager برای زنجیره‌ای کردن متدها
     */
    public function setAllowedFileTypes(array $types) {
        $this->allowedFileTypes = $types;
        return $this;
    }

    /**
     * تنظیم حداکثر حجم فایل مجاز
     *
     * @param int $size حجم به بایت
     * @return FileManager برای زنجیره‌ای کردن متدها
     */
    public function setMaxFileSize(int $size) {
        $this->maxFileSize = $size;
        return $this;
    }

    /**
     * تنظیم حداکثر حجم تصویر مجاز
     *
     * @param int $size حجم به بایت
     * @return FileManager برای زنجیره‌ای کردن متدها
     */
    public function setMaxImageSize(int $size) {
        $this->maxImageSize = $size;
        return $this;
    }

    /**
     * آپلود تصویر پروفایل
     *
     * @param array $file آرایه فایل آپلود شده ($_FILES)
     * @param int $user_id شناسه کاربر
     * @return array|false مسیر فایل آپلود شده یا false در صورت خطا
     */
    public function uploadProfileImage(array $file, int $user_id) {
        // بررسی خطاهای آپلود
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception($this->getUploadErrorMessage($file['error']));
        }

        // بررسی نوع فایل
        if (!in_array($file['type'], $this->allowedImageTypes)) {
            throw new Exception('نوع فایل مجاز نیست. فقط تصاویر JPEG، PNG، GIF و WebP پذیرفته می‌شوند.');
        }

        // بررسی حجم فایل
        if ($file['size'] > $this->maxImageSize) {
            throw new Exception('حجم فایل بیشتر از حد مجاز است. حداکثر حجم مجاز: ' . $this->formatFileSize($this->maxImageSize));
        }

        // تعیین پسوند فایل
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);

        // ایجاد نام جدید برای فایل
        $newFileName = 'profile_' . $user_id . '_' . time() . '.' . $extension;

        // مسیر کامل فایل
        $destination = self::PROFILES_DIR . '/' . $newFileName;

        // حذف فایل قبلی کاربر (اگر وجود داشته باشد)
        $this->removeUserProfileImage($user_id);

        // آپلود فایل
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new Exception('خطا در آپلود فایل.');
        }

        // برای تصاویر، تصویر بندانگشتی ایجاد می‌کنیم
        $thumbnailPath = $this->createThumbnail($destination, $extension);

        return [
            'path' => $destination,
            'url' => $this->getFileUrl($destination),
            'thumbnail' => $thumbnailPath,
            'thumbnail_url' => $this->getFileUrl($thumbnailPath),
            'type' => $file['type'],
            'size' => $file['size'],
            'name' => $newFileName
        ];
    }

    /**
     * حذف تصویر پروفایل کاربر
     *
     * @param int $user_id شناسه کاربر
     * @return bool موفقیت یا عدم موفقیت حذف
     */
    public function removeUserProfileImage($user_id) {
        $pattern = self::PROFILES_DIR . '/profile_' . $user_id . '_*';
        $files = glob($pattern);

        foreach ($files as $file) {
            unlink($file);

            // حذف تصویر بندانگشتی
            $thumbnailPath = dirname($file) . '/thumbnails/' . basename($file);
            if (file_exists($thumbnailPath)) {
                unlink($thumbnailPath);
            }
        }

        return true;
    }

    /**
     * آپلود فایل در پوشه محتوای تولید شده
     *
     * @param array $file آرایه فایل آپلود شده ($_FILES)
     * @param int $user_id شناسه کاربر
     * @param string $prefix پیشوند نام فایل
     * @return array|false مسیر فایل آپلود شده یا false در صورت خطا
     */
    public function uploadGeneratedFile(array $file, int $user_id, string $prefix = 'generated') {
        // بررسی خطاهای آپلود
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception($this->getUploadErrorMessage($file['error']));
        }

        // بررسی نوع فایل
        $validType = false;

        // بررسی حجم فایل
        if (in_array($file['type'], $this->allowedImageTypes)) {
            if ($file['size'] > $this->maxImageSize) {
                throw new Exception('حجم تصویر بیشتر از حد مجاز است. حداکثر حجم مجاز: ' . $this->formatFileSize($this->maxImageSize));
            }
            $validType = true;
        } else if (in_array($file['type'], $this->allowedFileTypes)) {
            if ($file['size'] > $this->maxFileSize) {
                throw new Exception('حجم فایل بیشتر از حد مجاز است. حداکثر حجم مجاز: ' . $this->formatFileSize($this->maxFileSize));
            }
            $validType = true;
        }

        if (!$validType) {
            throw new Exception('نوع فایل مجاز نیست.');
        }

        // تعیین پسوند فایل
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);

        // ایجاد نام جدید برای فایل
        $newFileName = $prefix . '_' . $user_id . '_' . time() . '.' . $extension;

        // مسیر کامل فایل
        $destination = self::GENERATED_DIR . '/' . $newFileName;

        // آپلود فایل
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new Exception('خطا در آپلود فایل.');
        }

        $thumbnailPath = null;

        // اگر فایل تصویر است، تصویر بندانگشتی ایجاد می‌کنیم
        if (in_array($file['type'], $this->allowedImageTypes)) {
            $thumbnailPath = $this->createThumbnail($destination, $extension);
        }

        return [
            'path' => $destination,
            'url' => $this->getFileUrl($destination),
            'thumbnail' => $thumbnailPath,
            'thumbnail_url' => $thumbnailPath ? $this->getFileUrl($thumbnailPath) : null,
            'type' => $file['type'],
            'size' => $file['size'],
            'name' => $newFileName
        ];
    }

    /**
     * آپلود فایل موقت
     *
     * @param array $file آرایه فایل آپلود شده ($_FILES)
     * @param int $user_id شناسه کاربر
     * @return array|false مسیر فایل آپلود شده یا false در صورت خطا
     */
    public function uploadTempFile(array $file, int $user_id) {
        // بررسی خطاهای آپلود
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception($this->getUploadErrorMessage($file['error']));
        }

        // بررسی نوع فایل (برای فایل‌های موقت محدودیت کمتری اعمال می‌کنیم)
        $validType = in_array($file['type'], array_merge($this->allowedImageTypes, $this->allowedFileTypes));

        if (!$validType) {
            throw new Exception('نوع فایل مجاز نیست.');
        }

        // بررسی حجم فایل
        if ($file['size'] > $this->maxFileSize) {
            throw new Exception('حجم فایل بیشتر از حد مجاز است. حداکثر حجم مجاز: ' . $this->formatFileSize($this->maxFileSize));
        }

        // تعیین پسوند فایل
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);

        // ایجاد نام جدید برای فایل
        $newFileName = 'temp_' . $user_id . '_' . time() . '.' . $extension;

        // مسیر کامل فایل
        $destination = self::TEMP_DIR . '/' . $newFileName;

        // آپلود فایل
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new Exception('خطا در آپلود فایل.');
        }

        return [
            'path' => $destination,
            'url' => $this->getFileUrl($destination),
            'type' => $file['type'],
            'size' => $file['size'],
            'name' => $newFileName,
            'original_name' => $file['name']
        ];
    }

    /**
     * انتقال فایل از پوشه موقت به پوشه دائمی
     *
     * @param string $tempPath مسیر فایل موقت
     * @param string $destDir پوشه مقصد
     * @param string $newFileName نام جدید فایل (اختیاری)
     * @return array|false اطلاعات فایل منتقل شده یا false در صورت خطا
     */
    public function moveFromTemp($tempPath, $destDir, $newFileName = null) {
        if (!file_exists($tempPath)) {
            throw new Exception('فایل موقت یافت نشد.');
        }

        if (!is_dir($destDir)) {
            throw new Exception('پوشه مقصد معتبر نیست.');
        }

        if ($newFileName === null) {
            $newFileName = basename($tempPath);
        }

        $destination = $destDir . '/' . $newFileName;

        if (!rename($tempPath, $destination)) {
            throw new Exception('خطا در انتقال فایل.');
        }

        $mimeType = mime_content_type($destination);
        $extension = pathinfo($destination, PATHINFO_EXTENSION);
        $thumbnailPath = null;

        // اگر فایل تصویر است، تصویر بندانگشتی ایجاد می‌کنیم
        if (in_array($mimeType, $this->allowedImageTypes)) {
            $thumbnailPath = $this->createThumbnail($destination, $extension);
        }

        return [
            'path' => $destination,
            'url' => $this->getFileUrl($destination),
            'thumbnail' => $thumbnailPath,
            'thumbnail_url' => $thumbnailPath ? $this->getFileUrl($thumbnailPath) : null,
            'type' => $mimeType,
            'size' => filesize($destination),
            'name' => $newFileName
        ];
    }

    /**
     * پاکسازی فایل‌های موقت قدیمی
     *
     * @param int $olderThan زمان به ثانیه (پیش‌فرض: 24 ساعت)
     * @return int تعداد فایل‌های حذف شده
     */
    public function cleanupTempFiles($olderThan = 86400) {
        $files = glob(self::TEMP_DIR . '/*');
        $now = time();
        $count = 0;

        foreach ($files as $file) {
            if (is_file($file)) {
                $fileTime = filemtime($file);
                if (($now - $fileTime) > $olderThan) {
                    unlink($file);
                    $count++;
                }
            }
        }

        return $count;
    }

    /**
     * حذف یک فایل
     *
     * @param string $path مسیر فایل
     * @return bool موفقیت یا عدم موفقیت حذف
     */
    public function deleteFile($path) {
        if (!file_exists($path)) {
            return false;
        }

        // حذف تصویر بندانگشتی اگر وجود داشته باشد
        $extension = pathinfo($path, PATHINFO_EXTENSION);
        $thumbDir = dirname($path) . '/thumbnails';
        $thumbPath = $thumbDir . '/' . basename($path);

        if (file_exists($thumbPath)) {
            unlink($thumbPath);
        }

        return unlink($path);
    }

    /**
     * ایجاد تصویر بندانگشتی
     *
     * @param string $imagePath مسیر تصویر اصلی
     * @param string $extension پسوند فایل
     * @return string|false مسیر تصویر بندانگشتی یا false در صورت خطا
     */
    private function createThumbnail($imagePath, $extension) {
        $thumbDir = dirname($imagePath) . '/thumbnails';

        // ایجاد پوشه thumbnails اگر وجود نداشته باشد
        if (!file_exists($thumbDir)) {
            mkdir($thumbDir, 0755, true);
        }

        $thumbPath = $thumbDir . '/' . basename($imagePath);

        // تعیین ابعاد تصویر بندانگشتی
        $thumbWidth = 150;
        $thumbHeight = 150;

        // ایجاد تصویر بندانگشتی با استفاده از GD
        $sourceImage = null;

        switch (strtolower($extension)) {
            case 'jpg':
            case 'jpeg':
                $sourceImage = imagecreatefromjpeg($imagePath);
                break;
            case 'png':
                $sourceImage = imagecreatefrompng($imagePath);
                break;
            case 'gif':
                $sourceImage = imagecreatefromgif($imagePath);
                break;
            case 'webp':
                $sourceImage = imagecreatefromwebp($imagePath);
                break;
            default:
                return false;
        }

        if (!$sourceImage) {
            return false;
        }

        // ابعاد تصویر اصلی
        $srcWidth = imagesx($sourceImage);
        $srcHeight = imagesy($sourceImage);

        // محاسبه نسبت ابعاد جدید
        $ratio = min($thumbWidth / $srcWidth, $thumbHeight / $srcHeight);

        $newWidth = $srcWidth * $ratio;
        $newHeight = $srcHeight * $ratio;

        // ایجاد تصویر جدید
        $thumbImage = imagecreatetruecolor($newWidth, $newHeight);

        // حفظ شفافیت برای تصاویر PNG و GIF
        if ($extension == 'png' || $extension == 'gif' || $extension == 'webp') {
            imagealphablending($thumbImage, false);
            imagesavealpha($thumbImage, true);
            $transparent = imagecolorallocatealpha($thumbImage, 255, 255, 255, 127);
            imagefilledrectangle($thumbImage, 0, 0, $newWidth, $newHeight, $transparent);
        }

        // تغییر اندازه تصویر
        imagecopyresampled($thumbImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $srcWidth, $srcHeight);

        // ذخیره تصویر بندانگشتی
        $result = false;

        switch (strtolower($extension)) {
            case 'jpg':
            case 'jpeg':
                $result = imagejpeg($thumbImage, $thumbPath, 90);
                break;
            case 'png':
                $result = imagepng($thumbImage, $thumbPath, 9);
                break;
            case 'gif':
                $result = imagegif($thumbImage, $thumbPath);
                break;
            case 'webp':
                $result = imagewebp($thumbImage, $thumbPath, 90);
                break;
        }

        // آزادسازی حافظه
        imagedestroy($sourceImage);
        imagedestroy($thumbImage);

        return $result ? $thumbPath : false;
    }

    /**
     * دریافت آدرس URL فایل
     *
     * @param string $path مسیر فایل
     * @return string آدرس URL فایل
     */
    public function getFileUrl($path) {
        $baseUrl = $this->getBaseUrl();
        $relativePath = str_replace(DIRECTORY_SEPARATOR, '/', $path);

        return $baseUrl . '/' . $relativePath;
    }

    /**
     * دریافت آدرس پایه وب‌سایت
     *
     * @return string آدرس پایه وب‌سایت
     */
    private function getBaseUrl() {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $domainName = $_SERVER['HTTP_HOST'];

        return $protocol . $domainName;
    }

    /**
     * قالب‌بندی حجم فایل به فرمت خوانا
     *
     * @param int $bytes حجم به بایت
     * @return string حجم به فرمت خوانا
     */
    private function formatFileSize($bytes) {
        $units = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت', 'ترابایت'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);

        $bytes /= pow(1024, $pow);

        return round($bytes, 2) . ' ' . $units[$pow];
    }

    /**
     * دریافت پیام خطای آپلود
     *
     * @param int $error کد خطای آپلود
     * @return string پیام خطا
     */
    private function getUploadErrorMessage($error) {
        switch ($error) {
            case UPLOAD_ERR_INI_SIZE:
                return 'حجم فایل آپلود شده از حداکثر مجاز در php.ini بیشتر است.';
            case UPLOAD_ERR_FORM_SIZE:
                return 'حجم فایل آپلود شده از حداکثر مجاز در فرم HTML بیشتر است.';
            case UPLOAD_ERR_PARTIAL:
                return 'فایل فقط به صورت جزئی آپلود شده است.';
            case UPLOAD_ERR_NO_FILE:
                return 'هیچ فایلی آپلود نشده است.';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'پوشه موقت برای آپلود وجود ندارد.';
            case UPLOAD_ERR_CANT_WRITE:
                return 'نوشتن فایل در دیسک با مشکل مواجه شد.';
            case UPLOAD_ERR_EXTENSION:
                return 'یک افزونه PHP آپلود فایل را متوقف کرد.';
            default:
                return 'خطای ناشناخته در آپلود فایل.';
        }
    }

    /**
     * بررسی مجاز بودن پسوند فایل
     *
     * @param string $filename نام فایل
     * @param array $allowedExtensions آرایه‌ای از پسوندهای مجاز
     * @return bool مجاز بودن یا نبودن
     */
    public function isExtensionAllowed($filename, array $allowedExtensions) {
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return in_array($extension, $allowedExtensions);
    }
}