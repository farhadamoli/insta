<?php

/**
 * Request.php
 *
 * کلاس مدیریت درخواست‌های HTTP در پروژه ادامه‌ای
 */

namespace App\Core;

class Request {
    /**
     * داده‌های GET
     *
     * @var array
     */
    private $get = [];

    /**
     * داده‌های POST
     *
     * @var array
     */
    private $post = [];

    /**
     * داده‌های FILES
     *
     * @var array
     */
    private $files = [];

    /**
     * داده‌های COOKIE
     *
     * @var array
     */
    private $cookies = [];

    /**
     * داده‌های SERVER
     *
     * @var array
     */
    private $server = [];

    /**
     * پارامترهای مسیر
     *
     * @var array
     */
    private $params = [];

    /**
     * سازنده کلاس
     */
    public function __construct() {
        $this->get = $_GET;
        $this->post = $_POST;
        $this->files = $_FILES;
        $this->cookies = $_COOKIE;
        $this->server = $_SERVER;

        // تمیز کردن داده‌های ورودی
        $this->sanitize();
    }

    /**
     * تمیز کردن داده‌های ورودی
     */
    private function sanitize() {
        $this->get = $this->sanitizeData($this->get);
        $this->post = $this->sanitizeData($this->post);
    }

    /**
     * تمیز کردن آرایه داده
     *
     * @param array $data آرایه داده
     * @return array آرایه تمیز شده
     */
    private function sanitizeData($data) {
        $sanitized = [];

        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = $this->sanitizeData($value);
            } else {
                $sanitized[$key] = $this->sanitizeInput($value);
            }
        }

        return $sanitized;
    }

    /**
     * تمیز کردن یک مقدار ورودی
     *
     * @param mixed $input مقدار ورودی
     * @return mixed مقدار تمیز شده
     */
    private function sanitizeInput($input) {
        if (is_string($input)) {
            return clean_input($input);
        }

        return $input;
    }

    /**
     * دریافت مقدار از داده‌های GET
     *
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض در صورت عدم وجود
     * @return mixed مقدار
     */
    public function getParam($key, $default = null) {
        return isset($this->get[$key]) ? $this->get[$key] : $default;
    }

    /**
     * دریافت مقدار از داده‌های POST
     *
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض در صورت عدم وجود
     * @return mixed مقدار
     */
    public function getPost($key, $default = null) {
        return isset($this->post[$key]) ? $this->post[$key] : $default;
    }

    /**
     * دریافت مقدار از داده‌های FILES
     *
     * @param string $key کلید
     * @return array|null مقدار
     */
    public function getFile($key) {
        return isset($this->files[$key]) ? $this->files[$key] : null;
    }

    /**
     * دریافت مقدار از داده‌های COOKIE
     *
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض در صورت عدم وجود
     * @return mixed مقدار
     */
    public function getCookie($key, $default = null) {
        return isset($this->cookies[$key]) ? $this->cookies[$key] : $default;
    }

    /**
     * دریافت مقدار از داده‌های SERVER
     *
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض در صورت عدم وجود
     * @return mixed مقدار
     */
    public function getServer($key, $default = null) {
        return isset($this->server[$key]) ? $this->server[$key] : $default;
    }

    /**
     * دریافت متد HTTP
     *
     * @return string متد HTTP
     */
    public function getMethod() {
        return strtoupper($this->getServer('REQUEST_METHOD', 'GET'));
    }

    /**
     * دریافت URI درخواست
     *
     * @return string URI
     */
    public function getUri() {
        $uri = $this->getParam('url', '');

        if (empty($uri)) {
            $uri = trim($this->getServer('REQUEST_URI', ''), '/');

            // حذف query string
            if (($pos = strpos($uri, '?')) !== false) {
                $uri = substr($uri, 0, $pos);
            }
        }

        return '/' . trim($uri, '/');
    }

    /**
     * دریافت URL کامل
     *
     * @return string URL کامل
     */
    public function getFullUrl() {
        $protocol = $this->isSecure() ? 'https://' : 'http://';
        $host = $this->getServer('HTTP_HOST', '');
        $uri = $this->getServer('REQUEST_URI', '');

        return $protocol . $host . $uri;
    }

    /**
     * بررسی امن بودن اتصال (HTTPS)
     *
     * @return bool نتیجه بررسی
     */
    public function isSecure() {
        if ($this->getServer('HTTPS') == 'on' || $this->getServer('HTTPS') == 1) {
            return true;
        }

        if ($this->getServer('SERVER_PORT') == 443) {
            return true;
        }

        if ($this->getServer('HTTP_X_FORWARDED_PROTO') == 'https') {
            return true;
        }

        return false;
    }

    /**
     * بررسی درخواست AJAX
     *
     * @return bool نتیجه بررسی
     */
    public function isAjax() {
        return !empty($this->getServer('HTTP_X_REQUESTED_WITH')) &&
            strtolower($this->getServer('HTTP_X_REQUESTED_WITH')) === 'xmlhttprequest';
    }

    /**
     * دریافت آدرس IP کاربر
     *
     * @return string آدرس IP
     */
    public function getIp() {
        // بررسی سرآیندهای مختلف برای دریافت IP واقعی
        $ip_keys = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];

        foreach ($ip_keys as $key) {
            if ($this->getServer($key)) {
                $ip = $this->getServer($key);

                // اگر فهرستی از IP ها باشد، اولین را انتخاب می‌کنیم
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }

                // اعتبارسنجی IP
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    /**
     * دریافت کاربرگزار (User Agent)
     *
     * @return string کاربرگزار
     */
    public function getUserAgent() {
        return $this->getServer('HTTP_USER_AGENT', '');
    }

    /**
     * دریافت زبان مرورگر کاربر
     *
     * @return string زبان
     */
    public function getBrowserLanguage() {
        $http_accept_language = $this->getServer('HTTP_ACCEPT_LANGUAGE', '');

        if (!empty($http_accept_language)) {
            $langs = explode(',', $http_accept_language);

            if (!empty($langs[0])) {
                $lang = substr($langs[0], 0, 2);
                return strtolower($lang);
            }
        }

        return DEFAULT_LANG;
    }

    /**
     * دریافت مقدار سرآیند (Header)
     *
     * @param string $header نام سرآیند
     * @return string|null مقدار سرآیند
     */
    public function getHeader($header) {
        $header = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
        return $this->getServer($header);
    }

    /**
     * دریافت نوع محتوای درخواست
     *
     * @return string نوع محتوا
     */
    public function getContentType() {
        return $this->getServer('CONTENT_TYPE', '');
    }

    /**
     * دریافت داده‌های JSON
     *
     * @return array|null داده‌های JSON
     */
    public function getJson() {
        if (strpos($this->getContentType(), 'application/json') !== false) {
            $json = file_get_contents('php://input');
            return json_decode($json, true);
        }

        return null;
    }

    /**
     * تنظیم پارامترهای مسیر
     *
     * @param array $params پارامترها
     */
    public function setParams($params) {
        $this->params = $params;
    }

    /**
     * دریافت پارامترهای مسیر
     *
     * @return array پارامترها
     */
    public function getParams() {
        return $this->params;
    }

    /**
     * دریافت پارامتر مسیر
     *
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض
     * @return mixed مقدار
     */
    public function getRouteParam($key, $default = null) {
        return isset($this->params[$key]) ? $this->params[$key] : $default;
    }

    /**
     * دریافت تمام داده‌های GET
     *
     * @return array داده‌های GET
     */
    public function getAllParams() {
        return $this->get;
    }

    /**
     * دریافت تمام داده‌های POST
     *
     * @return array داده‌های POST
     */
    public function getAllPost() {
        return $this->post;
    }

    /**
     * بررسی نوع درخواست (GET, POST, PUT, DELETE)
     *
     * @param string $method متد مورد نظر
     * @return bool نتیجه بررسی
     */
    public function is($method) {
        return $this->getMethod() === strtoupper($method);
    }

    /**
     * بررسی وجود پارامتر در GET یا POST
     *
     * @param string $key کلید
     * @return bool نتیجه بررسی
     */
    public function has($key) {
        return isset($this->get[$key]) || isset($this->post[$key]);
    }

    /**
     * دریافت مقدار از GET یا POST
     *
     * @param string $key کلید
     * @param mixed $default مقدار پیش‌فرض
     * @return mixed مقدار
     */
    public function input($key, $default = null) {
        if (isset($this->post[$key])) {
            return $this->post[$key];
        }

        if (isset($this->get[$key])) {
            return $this->get[$key];
        }

        return $default;
    }
}