<?php

/**
 * DateHelper.php
 *
 * کلاس کمکی برای کار با تاریخ و زمان در پروژه ادامه‌ای
 * این کلاس از کتابخانه jdf.php برای تبدیل تاریخ میلادی به شمسی استفاده می‌کند
 */

namespace App\Core;

class DateHelper {
    /**
     * تنظیمات پیش‌فرض
     */
    private static $defaultFormat = 'Y/m/d';
    private static $defaultTimeFormat = 'H:i';
    private static $defaultDatetimeFormat = 'Y/m/d H:i';
    private static $useFaNumbers = true;

    /**
     * زبان فعلی برای نمایش تاریخ
     */
    private static $lang = 'fa';

    /**
     * تنظیم زبان برای نمایش تاریخ
     *
     * @param string $lang کد زبان ('fa' یا 'en')
     */
    public static function setLang($lang) {
        self::$lang = ($lang === 'fa' || $lang === 'en') ? $lang : 'fa';
    }

    /**
     * تنظیم استفاده از اعداد فارسی
     *
     * @param bool $use استفاده از اعداد فارسی
     */
    public static function setUseFaNumbers($use) {
        self::$useFaNumbers = (bool) $use;
    }

    /**
     * تنظیم فرمت پیش‌فرض تاریخ
     *
     * @param string $format فرمت جدید
     */
    public static function setDefaultFormat($format) {
        self::$defaultFormat = $format;
    }

    /**
     * تبدیل تاریخ میلادی به شمسی یا بالعکس براساس زبان فعلی
     *
     * @param string $date تاریخ ورودی
     * @param string $format فرمت خروجی
     * @return string تاریخ تبدیل شده
     */
    public static function formatDate($date, $format = null) {
        if ($format === null) {
            $format = self::$defaultFormat;
        }

        // اگر تاریخ به صورت timestamp باشد
        if (is_numeric($date) && strlen($date) > 6) {
            if (self::$lang === 'fa') {
                return jdate($format, $date, self::$useFaNumbers);
            } else {
                return date($format, $date);
            }
        }

        // اگر تاریخ به صورت رشته باشد
        if (self::$lang === 'fa') {
            // تشخیص نوع تاریخ (میلادی یا شمسی)
            if (preg_match('/^\d{4}[-\/]\d{1,2}[-\/]\d{1,2}$/', $date)) {
                // احتمالاً تاریخ میلادی است
                return gregorian_to_jalali($date, $format);
            } else {
                // احتمالاً تاریخ شمسی است یا فرمت نامعتبر
                if (jdate_is_valid($date)) {
                    // فرمت‌بندی مجدد تاریخ شمسی
                    $parts = preg_split('/[-\/\\\.]/', $date);
                    if (count($parts) === 3) {
                        $formatted = str_replace(['Y', 'y', 'm', 'n', 'd', 'j'], [
                            $parts[0],
                            substr($parts[0], 2),
                            str_pad($parts[1], 2, '0', STR_PAD_LEFT),
                            $parts[1],
                            str_pad($parts[2], 2, '0', STR_PAD_LEFT),
                            $parts[2]
                        ], $format);

                        return self::$useFaNumbers ? en_to_fa_numbers($formatted) : $formatted;
                    }
                }

                // اگر نتوانستیم تشخیص دهیم، تاریخ اصلی را برگردانیم
                return $date;
            }
        } else {
            // زبان انگلیسی
            // تشخیص نوع تاریخ (میلادی یا شمسی)
            if (preg_match('/^\d{4}[-\/]\d{1,2}[-\/]\d{1,2}$/', $date)) {
                // احتمالاً تاریخ میلادی است
                $timestamp = strtotime($date);
                return date($format, $timestamp);
            } else {
                // احتمالاً تاریخ شمسی است
                if (jdate_is_valid($date)) {
                    // تبدیل تاریخ شمسی به میلادی
                    $gregorian = jalali_to_gregorian($date, 'Y-m-d');
                    $timestamp = strtotime($gregorian);
                    return date($format, $timestamp);
                }

                // اگر نتوانستیم تشخیص دهیم، تاریخ اصلی را برگردانیم
                return $date;
            }
        }
    }

    /**
     * نمایش تاریخ و زمان به صورت نسبی (مثلاً "چند دقیقه پیش")
     *
     * @param int|string $timestamp زمان یونیکس یا تاریخ
     * @return string زمان نسبی
     */
    public static function timeAgo($timestamp) {
        if (!is_numeric($timestamp)) {
            $timestamp = strtotime($timestamp);
        }

        $diff = time() - $timestamp;

        if (self::$lang === 'fa') {
            return jdate_ago($timestamp, self::$useFaNumbers);
        } else {
            // نسخه انگلیسی
            if ($diff < 60) {
                return 'moments ago';
            } elseif ($diff < 3600) {
                $mins = floor($diff / 60);
                return $mins . ' minute' . ($mins > 1 ? 's' : '') . ' ago';
            } elseif ($diff < 86400) {
                $hours = floor($diff / 3600);
                return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
            } elseif ($diff < 2592000) {
                $days = floor($diff / 86400);
                if ($days == 1) {
                    return 'yesterday';
                } else {
                    return $days . ' days ago';
                }
            } elseif ($diff < 31536000) {
                $months = floor($diff / 2592000);
                return $months . ' month' . ($months > 1 ? 's' : '') . ' ago';
            } else {
                $years = floor($diff / 31536000);
                return $years . ' year' . ($years > 1 ? 's' : '') . ' ago';
            }
        }
    }

    /**
     * تبدیل تاریخ به فرمت مناسب برای نمایش در رابط کاربری
     *
     * @param string|int $date تاریخ یا timestamp
     * @param bool $includeTime شامل زمان هم باشد
     * @return string تاریخ فرمت‌بندی شده
     */
    public static function formatForDisplay($date, $includeTime = false) {
        if (empty($date)) {
            return '';
        }

        if (!is_numeric($date)) {
            $date = strtotime($date);
        }

        $format = $includeTime ? self::$defaultDatetimeFormat : self::$defaultFormat;

        if (self::$lang === 'fa') {
            return jdate($format, $date, self::$useFaNumbers);
        } else {
            return date($format, $date);
        }
    }

    /**
     * تبدیل تاریخ به فرمت مناسب برای ذخیره در دیتابیس (همیشه میلادی)
     *
     * @param string $date تاریخ (شمسی یا میلادی براساس زبان فعلی)
     * @return string تاریخ میلادی با فرمت Y-m-d
     */
    public static function formatForDatabase($date) {
        if (empty($date)) {
            return null;
        }

        if (self::$lang === 'fa') {
            // تبدیل تاریخ شمسی به میلادی
            if (jdate_is_valid($date)) {
                return jalali_to_gregorian($date, 'Y-m-d');
            } else {
                // اگر فرمت تاریخ شمسی نامعتبر باشد، تاریخ جاری را برمی‌گردانیم
                return date('Y-m-d');
            }
        } else {
            // فرمت‌بندی تاریخ میلادی
            $timestamp = strtotime($date);
            return date('Y-m-d', $timestamp);
        }
    }

    /**
     * محاسبه سن براساس تاریخ تولد
     *
     * @param string $birthDate تاریخ تولد
     * @return int سن
     */
    public static function calculateAge($birthDate) {
        if (empty($birthDate)) {
            return 0;
        }

        if (self::$lang === 'fa') {
            // اگر تاریخ تولد شمسی باشد
            if (jdate_is_valid($birthDate)) {
                return jdate_calculate_age($birthDate);
            }
        }

        // تاریخ تولد میلادی
        $birthDate = new \DateTime($birthDate);
        $today = new \DateTime('today');
        $age = $birthDate->diff($today)->y;

        return $age;
    }

    /**
     * دریافت تاریخ فعلی براساس زبان
     *
     * @param string $format فرمت خروجی
     * @return string تاریخ فعلی
     */
    public static function now($format = null) {
        if ($format === null) {
            $format = self::$defaultFormat;
        }

        if (self::$lang === 'fa') {
            return jdate($format, time(), self::$useFaNumbers);
        } else {
            return date($format);
        }
    }

    /**
     * دریافت تاریخ و زمان فعلی براساس زبان
     *
     * @param string $format فرمت خروجی
     * @return string تاریخ و زمان فعلی
     */
    public static function nowWithTime($format = null) {
        if ($format === null) {
            $format = self::$defaultDatetimeFormat;
        }

        if (self::$lang === 'fa') {
            return jdate($format, time(), self::$useFaNumbers);
        } else {
            return date($format);
        }
    }

    /**
     * دریافت نام روز هفته
     *
     * @param string|int $date تاریخ یا timestamp
     * @return string نام روز هفته
     */
    public static function getDayName($date = null) {
        if ($date === null) {
            $timestamp = time();
        } elseif (is_numeric($date)) {
            $timestamp = $date;
        } else {
            $timestamp = strtotime($date);
        }

        $w = date('w', $timestamp);

        if (self::$lang === 'fa') {
            $days = [
                0 => 'یکشنبه',
                1 => 'دوشنبه',
                2 => 'سه‌شنبه',
                3 => 'چهارشنبه',
                4 => 'پنج‌شنبه',
                5 => 'جمعه',
                6 => 'شنبه'
            ];
        } else {
            $days = [
                0 => 'Sunday',
                1 => 'Monday',
                2 => 'Tuesday',
                3 => 'Wednesday',
                4 => 'Thursday',
                5 => 'Friday',
                6 => 'Saturday'
            ];
        }

        return $days[$w];
    }

    /**
     * دریافت نام ماه
     *
     * @param int $month شماره ماه (1-12)
     * @return string نام ماه
     */
    public static function getMonthName($month) {
        if (self::$lang === 'fa') {
            $months = [
                1 => 'فروردین',
                2 => 'اردیبهشت',
                3 => 'خرداد',
                4 => 'تیر',
                5 => 'مرداد',
                6 => 'شهریور',
                7 => 'مهر',
                8 => 'آبان',
                9 => 'آذر',
                10 => 'دی',
                11 => 'بهمن',
                12 => 'اسفند'
            ];
        } else {
            $months = [
                1 => 'January',
                2 => 'February',
                3 => 'March',
                4 => 'April',
                5 => 'May',
                6 => 'June',
                7 => 'July',
                8 => 'August',
                9 => 'September',
                10 => 'October',
                11 => 'November',
                12 => 'December'
            ];
        }

        return $months[(int) $month] ?? '';
    }

    /**
     * تبدیل اعداد انگلیسی به فارسی یا بالعکس
     *
     * @param string $text متن حاوی اعداد
     * @param string $to جهت تبدیل ('fa' یا 'en')
     * @return string متن تبدیل شده
     */
    public static function convertNumbers($text, $to = 'fa') {
        if ($to === 'fa') {
            return en_to_fa_numbers($text);
        } else {
            return fa_to_en_numbers($text);
        }
    }
}