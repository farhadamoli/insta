<?php

namespace App\Core;

/**
 * Router Class
 *
 * کلاس مسیریابی که درخواست‌ها را به کنترلرها و اکشن‌های مناسب هدایت می‌کند
 */
class Router
{
    private $routes = [
        'GET' => [],
        'POST' => [],
        'PUT' => [],
        'DELETE' => []
    ];

    private $notFoundHandler;
    private $errorHandler;

    /**
     * افزودن مسیر GET
     *
     * @param string $uri مسیر URI
     * @param array|string $handler کنترلر و اکشن یا callback
     * @return self
     */
    public function get($uri, $handler)
    {
        $this->addRoute('GET', $uri, $handler);
        return $this;
    }

    /**
     * افزودن مسیر POST
     *
     * @param string $uri مسیر URI
     * @param array|string $handler کنترلر و اکشن یا callback
     * @return self
     */
    public function post($uri, $handler)
    {
        $this->addRoute('POST', $uri, $handler);
        return $this;
    }

    /**
     * افزودن مسیر PUT
     *
     * @param string $uri مسیر URI
     * @param array|string $handler کنترلر و اکشن یا callback
     * @return self
     */
    public function put($uri, $handler)
    {
        $this->addRoute('PUT', $uri, $handler);
        return $this;
    }

    /**
     * افزودن مسیر DELETE
     *
     * @param string $uri مسیر URI
     * @param array|string $handler کنترلر و اکشن یا callback
     * @return self
     */
    public function delete($uri, $handler)
    {
        $this->addRoute('DELETE', $uri, $handler);
        return $this;
    }

    /**
     * تنظیم handler برای 404 Not Found
     *
     * @param callable $handler
     * @return self
     */
    public function setNotFoundHandler($handler)
    {
        $this->notFoundHandler = $handler;
        return $this;
    }

    /**
     * تنظیم handler برای خطاها
     *
     * @param callable $handler
     * @return self
     */
    public function setErrorHandler($handler)
    {
        $this->errorHandler = $handler;
        return $this;
    }

    /**
     * افزودن گروهی از مسیرها با پیشوند مشترک
     *
     * @param string $prefix پیشوند مسیر
     * @param callable $callback تابعی که مسیرها را تعریف می‌کند
     * @return self
     */
    public function group($prefix, $callback)
    {
        $previousGroupPrefix = $this->getGroupPrefix();
        $this->setGroupPrefix($previousGroupPrefix . $prefix);

        call_user_func($callback, $this);

        $this->setGroupPrefix($previousGroupPrefix);

        return $this;
    }

    /**
     * اجرای مسیریابی برای درخواست فعلی
     *
     * @return mixed نتیجه اجرای handler
     */
    public function dispatch()
    {
        $request = new Request();
        $method = $request->getMethod();
        $uri = $request->getUri();

        // حذف / از انتهای URI
        $uri = rtrim($uri, '/');

        // اضافه کردن / به ابتدای URI اگر خالی باشد
        if (empty($uri)) {
            $uri = '/';
        }

        // پشتیبانی از متدهای PUT و DELETE با استفاده از _method در POST
        if ($method === 'POST' && isset($_POST['_method'])) {
            $method = strtoupper($_POST['_method']);
            if (!in_array($method, ['GET', 'POST', 'PUT', 'DELETE'])) {
                $method = 'POST';
            }
        }

        try {
            // بررسی وجود مسیر در روش HTTP موردنظر
            if (isset($this->routes[$method])) {
                foreach ($this->routes[$method] as $route) {
                    $pattern = $this->buildPatternFromRoute($route['uri']);

                    if (preg_match($pattern, $uri, $matches)) {
                        // حذف مطابقت کامل از آرایه
                        array_shift($matches);

                        // استخراج پارامترهای مسیر از نام‌های کلیدها
                        $params = [];
                        preg_match_all('/\{([a-zA-Z0-9_]+)\}/', $route['uri'], $paramNames);

                        if (isset($paramNames[1]) && !empty($paramNames[1])) {
                            foreach ($paramNames[1] as $index => $name) {
                                $params[$name] = $matches[$index] ?? null;
                            }
                        }

                        // اجرای handler با پارامترهای مسیر
                        return $this->callRouteHandler($route['handler'], $params);
                    }
                }
            }

            // مسیر پیدا نشد
            return $this->handleNotFound();

        } catch (\Exception $e) {
            // خطایی رخ داده است
            return $this->handleError($e);
        }
    }

    /**
     * بارگذاری مسیرها از فایل
     *
     * @param string $file مسیر فایل
     * @return self
     */
    public function loadRoutesFromFile($file)
    {
        if (file_exists($file)) {
            require $file;
        }

        return $this;
    }

    /**
     * افزودن مسیر به آرایه مسیرها
     *
     * @param string $method روش HTTP
     * @param string $uri مسیر URI
     * @param array|string $handler کنترلر و اکشن یا callback
     */
    private function addRoute($method, $uri, $handler)
    {
        // افزودن پیشوند گروه به URI
        $groupPrefix = $this->getGroupPrefix();
        $uri = $groupPrefix . $uri;

        // استاندارد‌سازی URI
        $uri = $this->normalizeUri($uri);

        $this->routes[$method][] = [
            'uri' => $uri,
            'handler' => $handler
        ];
    }

    /**
     * استاندارد‌سازی URI
     *
     * @param string $uri مسیر URI
     * @return string URI استاندارد شده
     */
    private function normalizeUri($uri)
    {
        // حذف /‌های تکراری
        $uri = preg_replace('/\/+/', '/', $uri);

        // تبدیل URI خالی به /
        if (empty($uri)) {
            return '/';
        }

        return $uri;
    }

    /**
     * ایجاد الگوی regex از مسیر URI
     *
     * @param string $route مسیر URI
     * @return string الگوی regex
     */
    private function buildPatternFromRoute($route)
    {
        // تبدیل پارامترها به گروه‌های regex
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '([^/]+)', $route);

        // افزودن ابتدا و انتهای الگو
        $pattern = '#^' . $pattern . '$#';

        return $pattern;
    }

    /**
     * اجرای handler مسیر
     *
     * @param mixed $handler کنترلر و اکشن یا callback
     * @param array $params پارامترهای مسیر
     * @return mixed نتیجه اجرای handler
     */
    private function callRouteHandler($handler, $params = [])
    {
        if (is_callable($handler)) {
            // اگر handler یک callback باشد
            return call_user_func_array($handler, $params);
        } elseif (is_string($handler)) {
            // اگر handler به صورت Controller@method باشد
            $segments = explode('@', $handler);
            if (count($segments) === 2) {
                $controllerName = $segments[0];
                $methodName = $segments[1];

                // اضافه کردن namespace به کنترلر
                $controllerClass = 'App\\Controllers\\' . $controllerName;

                if (class_exists($controllerClass)) {
                    $controller = new $controllerClass();

                    if (method_exists($controller, $methodName)) {
                        return call_user_func_array([$controller, $methodName], $params);
                    }
                }
            }
        } elseif (is_array($handler) && count($handler) === 2) {
            // اگر handler به صورت [Controller, method] باشد
            list($controllerName, $methodName) = $handler;

            // اگر کنترلر به صورت نمونه یا نام کلاس باشد
            $controller = is_string($controllerName) ? new $controllerName() : $controllerName;

            if (method_exists($controller, $methodName)) {
                return call_user_func_array([$controller, $methodName], $params);
            }
        }

        // اگر handler نامعتبر باشد
        throw new \Exception("Invalid route handler");
    }

    /**
     * اجرای handler برای 404 Not Found
     *
     * @return mixed نتیجه اجرای handler
     */
    private function handleNotFound()
    {
        if ($this->notFoundHandler !== null && is_callable($this->notFoundHandler)) {
            return call_user_func($this->notFoundHandler);
        }

        // پیش‌فرض برای 404
        Response::setStatusCode(404);
        echo "404 - Page Not Found";
        exit;
    }

    /**
     * اجرای handler برای خطاها
     *
     * @param \Exception $exception خطای رخ داده
     * @return mixed نتیجه اجرای handler
     */
    private function handleError($exception)
    {
        if ($this->errorHandler !== null && is_callable($this->errorHandler)) {
            return call_user_func($this->errorHandler, $exception);
        }

        // پیش‌فرض برای خطا
        Response::setStatusCode(500);
        $config = require_once __DIR__ . '/../config/config.php';

        if ($config['app']['debug']) {
            echo "500 - Server Error: " . $exception->getMessage();
            echo "<pre>" . $exception->getTraceAsString() . "</pre>";
        } else {
            echo "500 - Server Error. Please try again later.";
        }

        exit;
    }

    /**
     * دریافت پیشوند گروه فعلی
     *
     * @return string پیشوند گروه
     */
    private function getGroupPrefix()
    {
        return isset($GLOBALS['route_group_prefix']) ? $GLOBALS['route_group_prefix'] : '';
    }

    /**
     * تنظیم پیشوند گروه فعلی
     *
     * @param string $prefix پیشوند گروه
     */
    private function setGroupPrefix($prefix)
    {
        $GLOBALS['route_group_prefix'] = $prefix;
    }
}