<?php

namespace App\Core;

/**
 * Database Class
 *
 * Handles all database operations with PDO
 */
class Database
{
    private $host;
    private $user;
    private $pass;
    private $dbname;
    private $charset;

    private $pdo;
    private $stmt;
    private $error;

    public function __construct()
    {
        // بارگذاری تنظیمات دیتابیس از فایل کانفیگ
        $config = require_once __DIR__ . '/../config/config.php';

        $this->host = $config['db']['host'];
        $this->user = $config['db']['user'];
        $this->pass = $config['db']['pass'];
        $this->dbname = $config['db']['dbname'];
        $this->charset = $config['db']['charset'];

        $this->connect();
    }

    /**
     * ایجاد اتصال به دیتابیس
     */
    private function connect()
    {
        // تنظیم DSN
        $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset={$this->charset}";

        // تنظیم گزینه‌های PDO
        $options = [
            \PDO::ATTR_PERSISTENT => true,
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES => false,
        ];

        // ایجاد نمونه PDO
        try {
            $this->pdo = new \PDO($dsn, $this->user, $this->pass, $options);
        } catch (\PDOException $e) {
            $this->error = $e->getMessage();
            error_log("Database connection error: {$this->error}");
            die("خطا در اتصال به پایگاه داده. لطفاً با مدیر سیستم تماس بگیرید.");
        }
    }

    /**
     * آماده‌سازی statement برای اجرا
     *
     * @param string $sql کوئری SQL
     * @return void
     */
    public function query($sql)
    {
        $this->stmt = $this->pdo->prepare($sql);
    }

    /**
     * بایند کردن پارامترها به statement
     *
     * @param array $params آرایه پارامترها
     * @return void
     */
    public function bind($params)
    {
        if ($params) {
            $i = 1;
            foreach ($params as $param) {
                $type = match(true) {
                    is_int($param) => \PDO::PARAM_INT,
                    is_bool($param) => \PDO::PARAM_BOOL,
                    is_null($param) => \PDO::PARAM_NULL,
                    default => \PDO::PARAM_STR
                };

                $this->stmt->bindValue($i++, $param, $type);
            }
        }
    }

    /**
     * اجرای statement
     *
     * @return bool موفقیت یا عدم موفقیت در اجرا
     */
    public function execute()
    {
        try {
            return $this->stmt->execute();
        } catch (\PDOException $e) {
            $this->error = $e->getMessage();
            error_log("Database query error: {$this->error}");
            return false;
        }
    }

    /**
     * دریافت چندین رکورد
     *
     * @param string $sql کوئری SQL
     * @param array $params پارامترهای کوئری
     * @return array آرایه رکوردها
     */
    public function select($sql, $params = [])
    {
        $this->query($sql);
        $this->bind($params);

        if ($this->execute()) {
            return $this->stmt->fetchAll();
        }

        return [];
    }

    /**
     * دریافت یک رکورد
     *
     * @param string $sql کوئری SQL
     * @param array $params پارامترهای کوئری
     * @return array|null رکورد یا null در صورت عدم وجود
     */
    public function selectOne($sql, $params = [])
    {
        $this->query($sql);
        $this->bind($params);

        if ($this->execute()) {
            return $this->stmt->fetch() ?: null;
        }

        return null;
    }

    /**
     * بررسی وجود یک رکورد
     *
     * @param string $sql کوئری SQL
     * @param array $params پارامترهای کوئری
     * @return bool آیا رکورد وجود دارد
     */
    public function exists($sql, $params = [])
    {
        $this->query($sql);
        $this->bind($params);

        if ($this->execute()) {
            return $this->stmt->rowCount() > 0;
        }

        return false;
    }

    /**
     * افزودن رکورد جدید
     *
     * @param string $table نام جدول
     * @param array $data داده‌های رکورد
     * @return int|bool شناسه رکورد جدید یا false در صورت خطا
     */
    public function insert($table, $data)
    {
        // ساخت کوئری
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));

        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";

        $this->query($sql);
        $this->bind(array_values($data));

        if ($this->execute()) {
            return $this->pdo->lastInsertId();
        }

        return false;
    }

    /**
     * بروزرسانی رکورد
     *
     * @param string $table نام جدول
     * @param array $data داده‌های به‌روزرسانی
     * @param array $where شرط‌های به‌روزرسانی (کلید: نام فیلد، مقدار: مقدار فیلد)
     * @return int تعداد رکوردهای به‌روزرسانی شده
     */
    public function update($table, $data, $where)
    {
        // ساخت بخش SET کوئری
        $set = implode(' = ?, ', array_keys($data)) . ' = ?';

        // ساخت بخش WHERE کوئری
        $whereClause = implode(' = ? AND ', array_keys($where)) . ' = ?';

        $sql = "UPDATE {$table} SET {$set} WHERE {$whereClause}";

        $this->query($sql);

        // ترکیب پارامترها
        $params = array_merge(array_values($data), array_values($where));
        $this->bind($params);

        if ($this->execute()) {
            return $this->stmt->rowCount();
        }

        return 0;
    }

    /**
     * حذف رکورد
     *
     * @param string $table نام جدول
     * @param array $where شرط‌های حذف (کلید: نام فیلد، مقدار: مقدار فیلد)
     * @return int تعداد رکوردهای حذف شده
     */
    public function delete($table, $where)
    {
        // ساخت بخش WHERE کوئری
        $whereClause = implode(' = ? AND ', array_keys($where)) . ' = ?';

        $sql = "DELETE FROM {$table} WHERE {$whereClause}";

        $this->query($sql);
        $this->bind(array_values($where));

        if ($this->execute()) {
            return $this->stmt->rowCount();
        }

        return 0;
    }

    /**
     * شروع تراکنش
     */
    public function beginTransaction()
    {
        return $this->pdo->beginTransaction();
    }

    /**
     * تایید تراکنش
     */
    public function commit()
    {
        return $this->pdo->commit();
    }

    /**
     * برگرداندن تراکنش
     */
    public function rollBack()
    {
        return $this->pdo->rollBack();
    }

    /**
     * دریافت خطای اخیر
     *
     * @return string پیام خطا
     */
    public function getError()
    {
        return $this->error;
    }

    /**
     * دریافت تعداد رکوردهای تحت تاثیر قرار گرفته در آخرین عملیات
     *
     * @return int تعداد رکوردها
     */
    public function rowCount()
    {
        return $this->stmt->rowCount();
    }
}