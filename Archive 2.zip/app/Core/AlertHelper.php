<?php

/**
 * AlertHelper.php
 *
 * کلاس کمکی برای کار با SweetAlert2 در پروژه ادامه‌ای
 */

namespace App\Core;

class AlertHelper {
    /**
     * ایجاد کد JavaScript برای نمایش هشدار موفقیت
     *
     * @param string $message متن پیام
     * @param string $title عنوان (اختیاری)
     * @param int $timer زمان نمایش به میلی‌ثانیه (اختیاری)
     * @return string کد JavaScript
     */
    public static function success($message, $title = null, $timer = 3000) {
        return self::alert([
            'icon' => 'success',
            'title' => $title,
            'text' => $message,
            'timer' => $timer,
            'timerProgressBar' => true
        ]);
    }

    /**
     * ایجاد کد JavaScript برای نمایش هشدار خطا
     *
     * @param string $message متن پیام
     * @param string $title عنوان (اختیاری)
     * @return string کد JavaScript
     */
    public static function error($message, $title = null) {
        return self::alert([
            'icon' => 'error',
            'title' => $title,
            'text' => $message
        ]);
    }

    /**
     * ایجاد کد JavaScript برای نمایش هشدار اطلاعات
     *
     * @param string $message متن پیام
     * @param string $title عنوان (اختیاری)
     * @return string کد JavaScript
     */
    public static function info($message, $title = null) {
        return self::alert([
            'icon' => 'info',
            'title' => $title,
            'text' => $message
        ]);
    }

    /**
     * ایجاد کد JavaScript برای نمایش هشدار اخطار
     *
     * @param string $message متن پیام
     * @param string $title عنوان (اختیاری)
     * @return string کد JavaScript
     */
    public static function warning($message, $title = null) {
        return self::alert([
            'icon' => 'warning',
            'title' => $title,
            'text' => $message
        ]);
    }

    /**
     * ایجاد کد JavaScript برای نمایش پرسش تأیید یا رد
     *
     * @param string $message متن پیام
     * @param string $title عنوان (اختیاری)
     * @param string $confirmButtonText متن دکمه تأیید
     * @param string $cancelButtonText متن دکمه لغو
     * @param string $confirmCallback تابع JavaScript که در صورت تأیید اجرا می‌شود
     * @param string $cancelCallback تابع JavaScript که در صورت لغو اجرا می‌شود (اختیاری)
     * @return string کد JavaScript
     */
    public static function confirm($message, $title = null, $confirmButtonText = 'بله', $cancelButtonText = 'خیر', $confirmCallback = '', $cancelCallback = '') {
        $options = [
            'icon' => 'question',
            'title' => $title,
            'text' => $message,
            'showCancelButton' => true,
            'confirmButtonColor' => '#3085d6',
            'cancelButtonColor' => '#d33',
            'confirmButtonText' => $confirmButtonText,
            'cancelButtonText' => $cancelButtonText,
            'reverseButtons' => Language::getCurrentLang() === 'fa'
        ];

        if (!empty($confirmCallback) || !empty($cancelCallback)) {
            return "Swal.fire(" . json_encode($options, JSON_UNESCAPED_UNICODE) . ").then((result) => {
                if (result.isConfirmed) {
                    {$confirmCallback}
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    {$cancelCallback}
                }
            });";
        } else {
            return "Swal.fire(" . json_encode($options, JSON_UNESCAPED_UNICODE) . ");";
        }
    }

    /**
     * ایجاد کد JavaScript برای نمایش فرم ورودی
     *
     * @param string $message متن پیام
     * @param string $title عنوان (اختیاری)
     * @param string $inputPlaceholder متن توضیحی فیلد ورودی
     * @param string $confirmButtonText متن دکمه تأیید
     * @param string $cancelButtonText متن دکمه لغو
     * @param string $callback تابع JavaScript که در صورت تأیید اجرا می‌شود
     * @return string کد JavaScript
     */
    public static function prompt($message, $title = null, $inputPlaceholder = '', $confirmButtonText = 'تأیید', $cancelButtonText = 'لغو', $callback = '') {
        $options = [
            'icon' => 'question',
            'title' => $title,
            'text' => $message,
            'input' => 'text',
            'inputPlaceholder' => $inputPlaceholder,
            'showCancelButton' => true,
            'confirmButtonColor' => '#3085d6',
            'cancelButtonColor' => '#d33',
            'confirmButtonText' => $confirmButtonText,
            'cancelButtonText' => $cancelButtonText,
            'reverseButtons' => Language::getCurrentLang() === 'fa'
        ];

        if (!empty($callback)) {
            return "Swal.fire(" . json_encode($options, JSON_UNESCAPED_UNICODE) . ").then((result) => {
                if (result.isConfirmed) {
                    {$callback}(result.value);
                }
            });";
        } else {
            return "Swal.fire(" . json_encode($options, JSON_UNESCAPED_UNICODE) . ");";
        }
    }

    /**
     * ایجاد کد JavaScript برای نمایش هشدار با پارامترهای سفارشی
     *
     * @param array $options پارامترهای هشدار
     * @return string کد JavaScript
     */
    public static function alert($options) {
        // تنظیم عنوان به متن پیام اگر عنوان خالی باشد
        if (isset($options['text']) && !isset($options['title'])) {
            $options['title'] = null;
        }

        // تنظیم رنگ دکمه‌ها
        if (!isset($options['confirmButtonColor'])) {
            $options['confirmButtonColor'] = '#3085d6';
        }

        // تنظیم جهت دکمه‌ها براساس زبان
        if (isset($options['showCancelButton']) && $options['showCancelButton']) {
            $options['reverseButtons'] = Language::getCurrentLang() === 'fa';
        }

        return "Swal.fire(" . json_encode($options, JSON_UNESCAPED_UNICODE) . ");";
    }

    /**
     * ایجاد تگ اسکریپت کامل برای نمایش هشدار
     *
     * @param string $alertCode کد جاوااسکریپت هشدار
     * @return string تگ اسکریپت کامل
     */
    public static function toScript($alertCode) {
        return "<script>document.addEventListener('DOMContentLoaded', function() { {$alertCode} });</script>";
    }

    /**
     * افزودن هشدار به سشن برای نمایش در صفحه بعدی
     *
     * @param string $type نوع هشدار (success, error, warning, info)
     * @param string $message متن پیام
     * @param string $title عنوان (اختیاری)
     */
    public static function flash($type, $message, $title = null) {
        if (!isset($_SESSION)) {
            session_start();
        }

        $_SESSION['flash_message'] = [
            'type' => $type,
            'message' => $message,
            'title' => $title
        ];
    }

    /**
     * بررسی وجود هشدار فلش در سشن و نمایش آن
     *
     * @return string|null کد جاوااسکریپت هشدار یا null
     */
    public static function displayFlash() {
        if (!isset($_SESSION)) {
            session_start();
        }

        if (isset($_SESSION['flash_message'])) {
            $flash = $_SESSION['flash_message'];
            unset($_SESSION['flash_message']);

            $type = $flash['type'];
            $message = $flash['message'];
            $title = $flash['title'];

            switch ($type) {
                case 'success':
                    return self::toScript(self::success($message, $title));
                case 'error':
                    return self::toScript(self::error($message, $title));
                case 'warning':
                    return self::toScript(self::warning($message, $title));
                case 'info':
                    return self::toScript(self::info($message, $title));
                default:
                    return null;
            }
        }

        return null;
    }
}