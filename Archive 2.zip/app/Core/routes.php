<?php

/**
 * تعریف مسیرهای برنامه
 *
 * در این فایل، تمام مسیرهای برنامه و کنترلرهای مرتبط با آنها تعریف می‌شوند
 */

use App\Core\Router;
use App\Core\Response;

// دریافت نمونه روتر
$router = $router ?? new Router();

// ثبت میدلورها
$router->registerMiddleware('auth', \App\Middlewares\AuthMiddleware::class);
$router->registerMiddleware('admin', \App\Middlewares\AdminMiddleware::class);

// صفحات عمومی
$router->get('/', 'HomeController@index');
$router->get('/about', 'HomeController@about');
$router->get('/contact', 'HomeController@contact');
$router->post('/contact', 'HomeController@submitContact');

// مسیرهای احراز هویت
$router->get('/login', 'AuthController@showLoginForm');
$router->post('/login', 'AuthController@login');
$router->get('/register', 'AuthController@showRegisterForm');
$router->post('/register', 'AuthController@register');
$router->get('/forgot-password', 'AuthController@forgotPassword');
$router->post('/forgot-password', 'AuthController@processForgotPassword');
$router->get('/logout', 'AuthController@logout');

// مسیرهای داشبورد کاربر
$router->group('/dashboard', function ($router) {
    $router->get('', 'DashboardController@index');
    $router->get('/profile', 'ProfileController@index');
    $router->post('/profile', 'ProfileController@update');
}, ['auth']);

// مسیرهای داشبورد ادمین
$router->group('/admin', function ($router) {
    $router->get('/dashboard', 'AdminController@index');
    $router->get('/users', 'AdminController@users');
    $router->get('/settings', 'AdminController@settings');
}, ['admin']);

// تعریف handler برای صفحه 404
$router->setNotFoundHandler(function () {
    return Response::html("<h1>404 - صفحه مورد نظر پیدا نشد</h1>", 404);
});

// تعریف handler برای خطاها
$router->setErrorHandler(function ($exception) {
    $config = require_once __DIR__ . '/config.php';

    if ($config['app']['debug']) {
        // در حالت debug، نمایش جزئیات خطا
        return Response::html(
            "<h1>خطای سیستم</h1>" .
            "<p>" . $exception->getMessage() . "</p>" .
            "<pre>" . $exception->getTraceAsString() . "</pre>",
            500
        );
    } else {
        // در حالت production، نمایش صفحه خطای عمومی
        return Response::html("<h1>خطای سیستم</h1><p>متأسفانه خطایی رخ داده است. لطفاً بعداً مجدداً تلاش کنید.</p>", 500);
    }
});

return $router;