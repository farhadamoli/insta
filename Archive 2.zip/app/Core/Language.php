<?php

/**
 * Language.php
 *
 * کلاس مدیریت زبان‌ها و پشتیبانی چندزبانه در پروژه ادامه‌ای
 */

namespace App\Core;

use Exception;

class Language {
    // زبان پیش‌فرض سیستم
    private static $defaultLang = 'fa';

    // زبان فعلی
    private static $currentLang = 'fa';

    // مسیر پوشه‌های زبان
    private static $langPath = 'lang';

    // آرایه نگهداری ترجمه‌ها
    private static $translations = [];

    // زبان‌های پشتیبانی شده
    private static $supportedLangs = [
        'fa' => 'فارسی',
        'en' => 'English'
    ];

    /**
     * بارگذاری زبان
     *
     * @param string $lang کد زبان
     * @return bool موفقیت یا عدم موفقیت بارگذاری
     */
    public static function load($lang = null) {
        // اگر زبان مشخص نشده باشد، از زبان پیش‌فرض استفاده می‌کنیم
        if ($lang === null) {
            $lang = self::$defaultLang;
        }

        // بررسی پشتیبانی از زبان
        if (!self::isSupported($lang)) {
            $lang = self::$defaultLang;
        }

        // تنظیم زبان فعلی
        self::$currentLang = $lang;

        // مسیر پوشه زبان
        $langDir = self::$langPath . '/' . $lang;

        // بررسی وجود پوشه زبان
        if (!is_dir($langDir)) {
            throw new Exception("Language directory not found: {$langDir}");
        }

        // خواندن همه فایل‌های زبان
        $langFiles = glob($langDir . '/*.php');

        if (empty($langFiles)) {
            throw new Exception("No language files found in: {$langDir}");
        }

        // بارگذاری همه فایل‌های زبان
        foreach ($langFiles as $file) {
            $section = basename($file, '.php');
            self::$translations[$section] = include($file);
        }

        return true;
    }

    /**
     * دریافت ترجمه یک کلید
     *
     * @param string $key کلید ترجمه (به صورت section.key)
     * @param array $params پارامترهای جایگزینی در متن
     * @param string $default مقدار پیش‌فرض در صورت عدم وجود ترجمه
     * @return string متن ترجمه شده
     */
    public static function get($key, $params = [], $default = null) {
        // اگر ترجمه‌ها بارگذاری نشده‌اند، آنها را بارگذاری می‌کنیم
        if (empty(self::$translations)) {
            self::load();
        }

        // تجزیه کلید به بخش و کلید
        $parts = explode('.', $key);

        if (count($parts) !== 2) {
            return $default !== null ? $default : $key;
        }

        list($section, $textKey) = $parts;

        // بررسی وجود ترجمه
        if (isset(self::$translations[$section][$textKey])) {
            $text = self::$translations[$section][$textKey];

            // جایگزینی پارامترها در متن
            if (!empty($params)) {
                foreach ($params as $paramKey => $paramValue) {
                    $text = str_replace(':' . $paramKey, $paramValue, $text);
                }
            }

            return $text;
        }

        // در صورت عدم وجود ترجمه، مقدار پیش‌فرض یا خود کلید را برمی‌گردانیم
        return $default !== null ? $default : $key;
    }

    /**
     * دریافت زبان فعلی
     *
     * @return string کد زبان فعلی
     */
    public static function getCurrentLang() {
        return self::$currentLang;
    }

    /**
     * دریافت نام زبان فعلی
     *
     * @return string نام زبان فعلی
     */
    public static function getCurrentLangName() {
        return self::$supportedLangs[self::$currentLang] ?? self::$currentLang;
    }

    /**
     * تغییر زبان فعلی
     *
     * @param string $lang کد زبان
     * @return bool موفقیت یا عدم موفقیت تغییر زبان
     */
    public static function setLang($lang) {
        if (!self::isSupported($lang)) {
            return false;
        }

        return self::load($lang);
    }

    /**
     * تنظیم زبان پیش‌فرض
     *
     * @param string $lang کد زبان
     * @return bool موفقیت یا عدم موفقیت تنظیم زبان پیش‌فرض
     */
    public static function setDefaultLang($lang) {
        if (!self::isSupported($lang)) {
            return false;
        }

        self::$defaultLang = $lang;
        return true;
    }

    /**
     * بررسی پشتیبانی از یک زبان
     *
     * @param string $lang کد زبان
     * @return bool نتیجه بررسی
     */
    public static function isSupported($lang) {
        return isset(self::$supportedLangs[$lang]);
    }

    /**
     * دریافت لیست زبان‌های پشتیبانی شده
     *
     * @return array لیست زبان‌های پشتیبانی شده
     */
    public static function getSupportedLangs() {
        return self::$supportedLangs;
    }

    /**
     * افزودن زبان جدید به لیست زبان‌های پشتیبانی شده
     *
     * @param string $code کد زبان
     * @param string $name نام زبان
     * @return bool موفقیت یا عدم موفقیت افزودن زبان
     */
    public static function addLanguage($code, $name) {
        if (isset(self::$supportedLangs[$code])) {
            return false;
        }

        self::$supportedLangs[$code] = $name;
        return true;
    }

    /**
     * حذف یک زبان از لیست زبان‌های پشتیبانی شده
     *
     * @param string $code کد زبان
     * @return bool موفقیت یا عدم موفقیت حذف زبان
     */
    public static function removeLanguage($code) {
        if ($code === self::$defaultLang) {
            return false;
        }

        if (isset(self::$supportedLangs[$code])) {
            unset(self::$supportedLangs[$code]);
            return true;
        }

        return false;
    }

    /**
     * تشخیص زبان مرورگر کاربر
     *
     * @return string کد زبان
     */
    public static function detectBrowserLanguage() {
        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $browserLangs = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);

            foreach ($browserLangs as $browserLang) {
                $langCode = substr($browserLang, 0, 2);

                if (self::isSupported($langCode)) {
                    return $langCode;
                }
            }
        }

        return self::$defaultLang;
    }

    /**
     * ذخیره زبان انتخابی کاربر در سشن
     *
     * @param string $lang کد زبان
     */
    public static function setSessionLang($lang) {
        if (self::isSupported($lang)) {
            $_SESSION['user_lang'] = $lang;
        }
    }

    /**
     * دریافت زبان ذخیره شده کاربر از سشن
     *
     * @return string|null کد زبان یا null
     */
    public static function getSessionLang() {
        return $_SESSION['user_lang'] ?? null;
    }

    /**
     * ذخیره زبان انتخابی کاربر در کوکی
     *
     * @param string $lang کد زبان
     * @param int $expire مدت زمان انقضا به ثانیه (پیش‌فرض: 30 روز)
     */
    public static function setCookieLang($lang, $expire = 2592000) {
        if (self::isSupported($lang)) {
            setcookie('user_lang', $lang, time() + $expire, '/');
        }
    }

    /**
     * دریافت زبان ذخیره شده کاربر از کوکی
     *
     * @return string|null کد زبان یا null
     */
    public static function getCookieLang() {
        return $_COOKIE['user_lang'] ?? null;
    }

    /**
     * تشخیص زبان کاربر با اولویت: سشن، کوکی، مرورگر، زبان پیش‌فرض
     *
     * @return string کد زبان
     */
    public static function getUserPreferredLang() {
        // بررسی زبان ذخیره شده در سشن
        $sessionLang = self::getSessionLang();
        if ($sessionLang && self::isSupported($sessionLang)) {
            return $sessionLang;
        }

        // بررسی زبان ذخیره شده در کوکی
        $cookieLang = self::getCookieLang();
        if ($cookieLang && self::isSupported($cookieLang)) {
            return $cookieLang;
        }

        // بررسی زبان مرورگر
        $browserLang = self::detectBrowserLanguage();
        if ($browserLang && self::isSupported($browserLang)) {
            return $browserLang;
        }

        // استفاده از زبان پیش‌فرض
        return self::$defaultLang;
    }

    /**
     * ایجاد Helper Function ساده برای دسترسی سریع به ترجمه‌ها
     *
     * نکته: این تابع باید در فایل helpers.php یا مشابه آن تعریف شود
     */
    public static function setupHelperFunction() {
        if (!function_exists('__')) {
            /**
             * دستیار ترجمه
             *
             * @param string $key کلید ترجمه
             * @param array $params پارامترها
             * @param string $default مقدار پیش‌فرض
             * @return string متن ترجمه شده
             */
            function __($key, $params = [], $default = null) {
                return \App\Core\Language::get($key, $params, $default);
            }
        }
    }
}