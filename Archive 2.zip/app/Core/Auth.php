<?php

namespace App\Core;

/**
 * Auth Class
 *
 * Handles authentication functionality including login, logout, and user session management
 */
class Auth
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();

        // اطمینان از شروع نشست
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * تلاش برای ورود کاربر با ایمیل و رمز عبور
     *
     * @param string $email ایمیل یا نام کاربری
     * @param string $password رمز عبور
     * @param bool $remember آیا کاربر را به خاطر بسپاریم
     * @return bool موفقیت یا عدم موفقیت در ورود
     */
    public function login($email, $password, $remember = false)
    {
        // جستجوی کاربر با ایمیل یا نام کاربری
        $user = $this->db->selectOne(
            "SELECT * FROM users WHERE (email = ? OR username = ?) AND status = 'active'",
            [$email, $email]
        );

        if (!$user) {
            return false;
        }

        // بررسی رمز عبور
        if (password_verify($password, $user['password'])) {
            // ذخیره اطلاعات کاربر در نشست
            $this->setUserSession($user);

            // اگر گزینه مرا به خاطر بسپار انتخاب شده باشد
            if ($remember) {
                $this->setRememberMeToken($user['id']);
            }

            // بروزرسانی زمان آخرین ورود
            $this->db->update('users', [
                'last_login' => date('Y-m-d H:i:s')
            ], ['id' => $user['id']]);

            return true;
        }

        return false;
    }

    /**
     * ورود کاربر با شناسه
     *
     * @param int $userId شناسه کاربر
     * @return bool موفقیت یا عدم موفقیت در ورود
     */
    public function loginById($userId)
    {
        $user = $this->db->selectOne(
            "SELECT * FROM users WHERE id = ? AND status = 'active'",
            [$userId]
        );

        if ($user) {
            $this->setUserSession($user);

            // بروزرسانی زمان آخرین ورود
            $this->db->update('users', [
                'last_login' => date('Y-m-d H:i:s')
            ], ['id' => $user['id']]);

            return true;
        }

        return false;
    }

    /**
     * خروج کاربر از سیستم
     */
    public function logout()
    {
        // حذف توکن "مرا به خاطر بسپار" اگر وجود داشته باشد
        if (isset($_SESSION['user_id'])) {
            $this->db->update('users', [
                'remember_token' => null
            ], ['id' => $_SESSION['user_id']]);
        }

        // حذف کوکی‌های مرتبط
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }

        // حذف متغیرهای نشست کاربر
        unset($_SESSION['user_id']);
        unset($_SESSION['user_name']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_role']);

        // تخریب نشست
        session_destroy();
    }

    /**
     * ثبت نام کاربر جدید
     *
     * @param array $userData داده‌های کاربر برای ثبت نام
     * @return int|bool شناسه کاربر جدید یا false در صورت خطا
     */
    public function register($userData)
    {
        return $this->db->insert('users', $userData);
    }

    /**
     * بررسی ورود کاربر
     *
     * @return bool آیا کاربر وارد شده است
     */
    public function isLoggedIn()
    {
        // اگر شناسه کاربر در نشست وجود داشته باشد
        if (isset($_SESSION['user_id'])) {
            return true;
        }

        // بررسی کوکی "مرا به خاطر بسپار"
        if (isset($_COOKIE['remember_token'])) {
            return $this->loginFromRememberToken($_COOKIE['remember_token']);
        }

        return false;
    }

    /**
     * بررسی اینکه آیا کاربر ادمین است
     *
     * @return bool آیا کاربر ادمین است
     */
    public function isAdmin()
    {
        return isset($_SESSION['user_role']) && ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'superadmin');
    }

    /**
     * بررسی اینکه آیا کاربر سوپرادمین است
     *
     * @return bool آیا کاربر سوپرادمین است
     */
    public function isSuperAdmin()
    {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'superadmin';
    }

    /**
     * دریافت اطلاعات کاربر فعلی
     *
     * @return array|null اطلاعات کاربر یا null اگر وارد نشده باشد
     */
    public function getCurrentUser()
    {
        if (!$this->isLoggedIn()) {
            return null;
        }

        return $this->db->selectOne('SELECT * FROM users WHERE id = ?', [$_SESSION['user_id']]);
    }

    /**
     * دریافت اشتراک فعال کاربر
     *
     * @return array|null اطلاعات اشتراک یا null اگر اشتراک فعالی نداشته باشد
     */
    public function getUserActiveSubscription()
    {
        if (!$this->isLoggedIn()) {
            return null;
        }

        $subscription = $this->db->selectOne(
            "SELECT us.*, s.name, s.instagram_pages_limit, s.posts_per_day_limit, s.ai_content_limit, s.has_advanced_analytics, s.has_crm 
            FROM user_subscriptions us 
            JOIN subscriptions s ON us.subscription_id = s.id 
            WHERE us.user_id = ? AND us.status = 'active' AND us.end_date > NOW() 
            ORDER BY us.end_date DESC LIMIT 1",
            [$_SESSION['user_id']]
        );

        return $subscription;
    }

    /**
     * تنظیم اطلاعات کاربر در نشست
     *
     * @param array $user اطلاعات کاربر
     */
    private function setUserSession($user)
    {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['fullname'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
    }

    /**
     * تنظیم توکن "مرا به خاطر بسپار" برای کاربر
     *
     * @param int $userId شناسه کاربر
     */
    private function setRememberMeToken($userId)
    {
        $token = bin2hex(random_bytes(32));

        // ذخیره توکن در دیتابیس
        $this->db->update('users', [
            'remember_token' => $token
        ], ['id' => $userId]);

        // تنظیم کوکی - یک ماه اعتبار
        setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/');
    }

    /**
     * تلاش برای ورود کاربر با استفاده از توکن "مرا به خاطر بسپار"
     *
     * @param string $token توکن "مرا به خاطر بسپار"
     * @return bool موفقیت یا عدم موفقیت در ورود
     */
    private function loginFromRememberToken($token)
    {
        $user = $this->db->selectOne(
            "SELECT * FROM users WHERE remember_token = ? AND status = 'active'",
            [$token]
        );

        if ($user) {
            $this->setUserSession($user);

            // تجدید توکن "مرا به خاطر بسپار"
            $this->setRememberMeToken($user['id']);

            // بروزرسانی زمان آخرین ورود
            $this->db->update('users', [
                'last_login' => date('Y-m-d H:i:s')
            ], ['id' => $user['id']]);

            return true;
        }

        return false;
    }
}