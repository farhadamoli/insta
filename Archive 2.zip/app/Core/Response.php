<?php

/**
 * Response.php
 *
 * کلاس مدیریت پاسخ‌های HTTP در پروژه ادامه‌ای
 */

namespace App\Core;

class Response {
    /**
     * محتوای پاسخ
     *
     * @var string
     */
    private $content = '';

    /**
     * کد وضعیت HTTP
     *
     * @var int
     */
    private $statusCode = 200;

    /**
     * نوع محتوا (Content Type)
     *
     * @var string
     */
    private $contentType = 'text/html';

    /**
     * سرآیندها (Headers)
     *
     * @var array
     */
    private $headers = [];

    /**
     * کوکی‌ها
     *
     * @var array
     */
    private $cookies = [];

    /**
     * تنظیم محتوای پاسخ
     *
     * @param string $content محتوا
     * @return Response برای زنجیره‌ای کردن متدها
     */
    public function setContent($content) {
        $this->content = $content;
        return $this;
    }

    /**
     * تنظیم کد وضعیت HTTP
     *
     * @param int $statusCode کد وضعیت
     * @return Response برای زنجیره‌ای کردن متدها
     */
    public function setStatusCode($statusCode) {
        $this->statusCode = $statusCode;
        return $this;
    }

    /**
     * تنظیم نوع محتوا
     *
     * @param string $contentType نوع محتوا
     * @return Response برای زنجیره‌ای کردن متدها
     */
    public function setContentType($contentType) {
        $this->contentType = $contentType;
        return $this;
    }

    /**
     * افزودن سرآیند
     *
     * @param string $name نام سرآیند
     * @param string $value مقدار سرآیند
     * @return Response برای زنجیره‌ای کردن متدها
     */
    public function addHeader($name, $value) {
        $this->headers[$name] = $value;
        return $this;
    }

    /**
     * افزودن چندین سرآیند
     *
     * @param array $headers آرایه سرآیندها
     * @return Response برای زنجیره‌ای کردن متدها
     */
    public function addHeaders(array $headers) {
        foreach ($headers as $name => $value) {
            $this->addHeader($name, $value);
        }
        return $this;
    }

    /**
     * افزودن کوکی
     *
     * @param string $name نام کوکی
     * @param string $value مقدار کوکی
     * @param int $expire زمان انقضا
     * @param string $path مسیر کوکی
     * @param string $domain دامنه کوکی
     * @param bool $secure کوکی امن
     * @param bool $httpOnly فقط HTTP
     * @return Response برای زنجیره‌ای کردن متدها
     */
    public function addCookie($name, $value, $expire = 0, $path = '/', $domain = '', $secure = false, $httpOnly = true) {
        $this->cookies[] = [
            'name' => $name,
            'value' => $value,
            'expire' => $expire,
            'path' => $path,
            'domain' => $domain,
            'secure' => $secure,
            'httpOnly' => $httpOnly
        ];

        return $this;
    }

    /**
     * حذف کوکی
     *
     * @param string $name نام کوکی
     * @param string $path مسیر کوکی
     * @param string $domain دامنه کوکی
     * @param bool $secure کوکی امن
     * @param bool $httpOnly فقط HTTP
     * @return Response برای زنجیره‌ای کردن متدها
     */
    public function removeCookie($name, $path = '/', $domain = '', $secure = false, $httpOnly = true) {
        return $this->addCookie($name, '', time() - 3600, $path, $domain, $secure, $httpOnly);
    }

    /**
     * تغییر مسیر به URL دیگر
     *
     * @param string $url آدرس مقصد
     * @param int $statusCode کد وضعیت
     * @return void
     */
    public function redirect($url, $statusCode = 302) {
        $this->setStatusCode($statusCode);
        $this->addHeader('Location', $url);
        $this->send();
        exit;
    }

    /**
     * ارسال پاسخ JSON
     *
     * @param mixed $data داده
     * @param int $statusCode کد وضعیت
     * @return void
     */
    public function json($data, $statusCode = 200) {
        $this->setStatusCode($statusCode);
        $this->setContentType('application/json');
        $this->setContent(json_encode($data, JSON_UNESCAPED_UNICODE));
        $this->send();
        exit;
    }

    /**
     * ارسال پاسخ XML
     *
     * @param string $xml محتوای XML
     * @param int $statusCode کد وضعیت
     * @return void
     */
    public function xml($xml, $statusCode = 200) {
        $this->setStatusCode($statusCode);
        $this->setContentType('application/xml');
        $this->setContent($xml);
        $this->send();
        exit;
    }

    /**
     * ارسال فایل
     *
     * @param string $filePath مسیر فایل
     * @param string $fileName نام فایل
     * @param string $contentType نوع محتوا (اختیاری)
     * @return void
     */
    public function download($filePath, $fileName, $contentType = null) {
        if (!file_exists($filePath)) {
            $this->setStatusCode(404);
            $this->setContent('File not found');
            $this->send();
            exit;
        }

        if ($contentType === null) {
            $contentType = $this->getMimeType($filePath);
        }

        $this->setContentType($contentType);
        $this->addHeader('Content-Disposition', 'attachment; filename="' . $fileName . '"');
        $this->addHeader('Content-Length', filesize($filePath));
        $this->send();

        readfile($filePath);
        exit;
    }

    /**
     * تشخیص نوع MIME براساس پسوند فایل
     *
     * @param string $filePath مسیر فایل
     * @return string نوع MIME
     */
    private function getMimeType($filePath) {
        $extension = pathinfo($filePath, PATHINFO_EXTENSION);

        $mimeTypes = [
            'txt' => 'text/plain',
            'html' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            'webp' => 'image/webp',
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'ppt' => 'application/vnd.ms-powerpoint',
            'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'zip' => 'application/zip',
            'rar' => 'application/x-rar-compressed',
            'mp3' => 'audio/mpeg',
            'mp4' => 'video/mp4',
            'wav' => 'audio/wav',
            'ogg' => 'audio/ogg',
            'webm' => 'video/webm'
        ];

        return isset($mimeTypes[$extension]) ? $mimeTypes[$extension] : 'application/octet-stream';
    }

    /**
     * ارسال محتوا به صورت CSV
     *
     * @param array $data داده‌ها
     * @param string $fileName نام فایل
     * @return void
     */
    public function csv(array $data, $fileName = 'export.csv') {
        $this->setContentType('text/csv');
        $this->addHeader('Content-Disposition', 'attachment; filename="' . $fileName . '"');

        ob_start();
        $output = fopen('php://output', 'w');

        // اگر داده‌ها خالی نباشد، سرستون‌ها را از کلیدهای ردیف اول تشخیص می‌دهیم
        if (!empty($data)) {
            fputcsv($output, array_keys(reset($data)));

            foreach ($data as $row) {
                fputcsv($output, $row);
            }
        }

        fclose($output);
        $this->setContent(ob_get_clean());
        $this->send();
        exit;
    }

    /**
     * نمایش خطای HTTP
     *
     * @param int $statusCode کد وضعیت
     * @param string $message پیام خطا (اختیاری)
     * @return void
     */
    public function error($statusCode, $message = null) {
        $this->setStatusCode($statusCode);

        // پیام‌های خطای پیش‌فرض
        $errorMessages = [
            400 => 'Bad Request',
            401 => 'Unauthorized',
            403 => 'Forbidden',
            404 => 'Not Found',
            405 => 'Method Not Allowed',
            429 => 'Too Many Requests',
            500 => 'Internal Server Error',
            503 => 'Service Unavailable'
        ];

        if ($message === null && isset($errorMessages[$statusCode])) {
            $message = $errorMessages[$statusCode];
        }

        // بررسی وجود قالب خطا
        $errorView = VIEWS_PATH . '/errors/' . $statusCode . '.php';

        if (file_exists($errorView)) {
            ob_start();
            include $errorView;
            $this->setContent(ob_get_clean());
        } else {
            // قالب پیش‌فرض خطا
            $this->setContent('
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Error ' . $statusCode . '</title>
                    <style>
                        body { font-family: Arial, sans-serif; background: #f3f3f3; margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; height: 100vh; }
                        .error-container { background: #fff; padding: 30px; border-radius: 5px; box-shadow: 0 3px 10px rgba(0,0,0,0.1); text-align: center; max-width: 500px; }
                        h1 { color: #e74c3c; margin-top: 0; }
                        p { color: #777; margin-bottom: 20px; }
                        a { color: #3498db; text-decoration: none; }
                        a:hover { text-decoration: underline; }
                    </style>
                </head>
                <body>
                    <div class="error-container">
                        <h1>Error ' . $statusCode . '</h1>
                        <p>' . htmlspecialchars($message) . '</p>
                        <a href="' . base_url() . '">Return to Home</a>
                    </div>
                </body>
                </html>
            ');
        }

        $this->send();
        exit;
    }

    /**
     * ارسال پاسخ به مرورگر
     *
     * @return void
     */
    public function send() {
        // تنظیم کد وضعیت
        http_response_code($this->statusCode);

        // تنظیم نوع محتوا
        header('Content-Type: ' . $this->contentType . '; charset=UTF-8');

        // ارسال سرآیندهای سفارشی
        foreach ($this->headers as $name => $value) {
            header($name . ': ' . $value);
        }

        // تنظیم کوکی‌ها
        foreach ($this->cookies as $cookie) {
            setcookie(
                $cookie['name'],
                $cookie['value'],
                $cookie['expire'],
                $cookie['path'],
                $cookie['domain'],
                $cookie['secure'],
                $cookie['httpOnly']
            );
        }

        // ارسال محتوا
        echo $this->content;
    }

    /**
     * نمایش صفحه خطای 404
     *
     * @param string $message پیام خطا (اختیاری)
     * @return void
     */
    public function notFound($message = null) {
        $this->error(404, $message);
    }

    /**
     * نمایش صفحه خطای 403
     *
     * @param string $message پیام خطا (اختیاری)
     * @return void
     */
    public function forbidden($message = null) {
        $this->error(403, $message);
    }

    /**
     * نمایش صفحه خطای 401
     *
     * @param string $message پیام خطا (اختیاری)
     * @return void
     */
    public function unauthorized($message = null) {
        $this->error(401, $message);
    }

    /**
     * نمایش صفحه خطای 500
     *
     * @param string $message پیام خطا (اختیاری)
     * @return void
     */
    public function serverError($message = null) {
        $this->error(500, $message);
    }
}