<?php
/**
 * OpenAI API Integration
 *
 * This file handles all communication with the OpenAI API for
 * content analysis, sentiment analysis, and AI-powered text generation
 * Used for advanced content analysis in the Social Media Monitoring Platform
 *
 * @author Social Monitor Development Team
 * @version 1.2.1
 * @copyright Social Monitor Inc.
 */

namespace Api;

use Core\Helper;
use Core\Config;
use Core\Logger;
use Models\AiAnalysis;

class OpenAI
{
    /**
     * OpenAI API base URL
     */
    const API_BASE_URL = 'https://api.openai.com/v1/';

    /**
     * OpenAI API endpoints
     */
    const ENDPOINT_COMPLETIONS = 'completions';
    const ENDPOINT_CHAT = 'chat/completions';
    const ENDPOINT_EMBEDDINGS = 'embeddings';
    const ENDPOINT_MODERATION = 'moderations';

    /**
     * Default models
     */
    const DEFAULT_TEXT_MODEL = 'gpt-4o';
    const DEFAULT_EMBEDDING_MODEL = 'text-embedding-ada-002';
    const DEFAULT_MODERATION_MODEL = 'text-moderation-latest';

    /**
     * API key for authentication
     */
    private $apiKey;

    /**
     * Current model for text generation
     */
    private $model;

    /**
     * Default temperature for text generation
     */
    private $temperature = 0.7;

    /**
     * Default max tokens for text generation
     */
    private $maxTokens = 1000;

    /**
     * Organization ID (optional)
     */
    private $orgId;

    /**
     * Logger instance
     */
    private $logger;

    /**
     * Constructor
     *
     * @param string $apiKey OpenAI API key
     * @param string $model Model to use
     * @param string $orgId Optional organization ID
     */
    public function __construct($apiKey = null, $model = null, $orgId = null)
    {
        $this->logger = Logger::getInstance();

        if ($apiKey) {
            $this->apiKey = $apiKey;
        } else {
            $this->apiKey = Config::get('openai.api_key');
        }

        if ($model) {
            $this->model = $model;
        } else {
            $this->model = self::DEFAULT_TEXT_MODEL;
        }

        if ($orgId) {
            $this->orgId = $orgId;
        } else {
            $this->orgId = Config::get('openai.org_id');
        }
    }

    /**
     * Set API key
     *
     * @param string $apiKey
     * @return $this
     */
    public function setApiKey($apiKey)
    {
        $this->apiKey = $apiKey;
        return $this;
    }

    /**
     * Set model
     *
     * @param string $model
     * @return $this
     */
    public function setModel($model)
    {
        $this->model = $model;
        return $this;
    }

    /**
     * Set temperature (randomness)
     *
     * @param float $temperature Value between 0 and 1
     * @return $this
     */
    public function setTemperature($temperature)
    {
        $this->temperature = max(0, min(1, (float)$temperature));
        return $this;
    }

    /**
     * Set maximum tokens to generate
     *
     * @param int $maxTokens
     * @return $this
     */
    public function setMaxTokens($maxTokens)
    {
        $this->maxTokens = (int)$maxTokens;
        return $this;
    }

    /**
     * Analyze sentiment of a text using AI
     *
     * @param string $text Text to analyze
     * @return array Analysis results
     */
    public function analyzeSentiment($text)
    {
        $prompt = "Analyze the sentiment of the following social media post. " .
            "Provide a JSON response with the following fields: " .
            "sentiment (positive, negative, neutral), " .
            "confidence (a number between 0 and 1), " .
            "emotion (primary emotion detected), " .
            "key_topics (array of main topics), " .
            "and brief_explanation (1-2 sentences explaining why).\n\n" .
            "Post: \"" . $text . "\"";

        $response = $this->generateText($prompt);

        if (!$response) {
            return [
                'sentiment' => 'neutral',
                'confidence' => 0,
                'emotion' => 'unknown',
                'key_topics' => [],
                'brief_explanation' => 'Analysis failed',
                'error' => true
            ];
        }

        try {
            // Extract JSON from the response
            $jsonStr = trim($response);
            if (substr($jsonStr, 0, 3) === '```' && substr($jsonStr, -3) === '```') {
                $jsonStr = substr($jsonStr, 3, -3);
                if (substr($jsonStr, 0, 4) === 'json') {
                    $jsonStr = substr($jsonStr, 4);
                }
            }
            $jsonStr = trim($jsonStr);

            $analysis = json_decode($jsonStr, true);

            if (!$analysis || !isset($analysis['sentiment'])) {
                throw new \Exception("Failed to parse sentiment analysis JSON");
            }

            $analysis['error'] = false;
            return $analysis;

        } catch (\Exception $e) {
            $this->logger->error('Failed to parse sentiment analysis: ' . $e->getMessage());

            // Try to extract sentiment directly
            if (strpos(strtolower($response), 'positive') !== false) {
                $sentiment = 'positive';
            } elseif (strpos(strtolower($response), 'negative') !== false) {
                $sentiment = 'negative';
            } else {
                $sentiment = 'neutral';
            }

            return [
                'sentiment' => $sentiment,
                'confidence' => 0.5,
                'emotion' => 'unknown',
                'key_topics' => [],
                'brief_explanation' => 'JSON parsing failed, extracted best guess',
                'raw_response' => $response,
                'error' => true
            ];
        }
    }

    /**
     * Categorize a social media post into predefined categories
     *
     * @param string $text Post text
     * @param array $categories List of possible categories
     * @return array Category assignments with confidence scores
     */
    public function categorizePost($text, $categories = [])
    {
        if (empty($categories)) {
            $categories = [
                'promotion', 'customer_service', 'product_feedback',
                'complaint', 'question', 'news', 'announcement',
                'engagement', 'entertainment', 'spam'
            ];
        }

        $categoriesStr = implode(', ', $categories);

        $prompt = "Categorize the following social media post into one or more of these categories: " .
            "$categoriesStr.\n\n" .
            "Provide a JSON response with these fields: " .
            "primary_category (the most relevant single category), " .
            "all_categories (array of applicable categories with confidence scores between 0-1), " .
            "and explanation (brief explanation of the categorization).\n\n" .
            "Post: \"" . $text . "\"";

        $response = $this->generateText($prompt);

        if (!$response) {
            return [
                'primary_category' => 'unknown',
                'all_categories' => [],
                'explanation' => 'Categorization failed',
                'error' => true
            ];
        }

        try {
            // Extract JSON from the response
            $jsonStr = trim($response);
            if (substr($jsonStr, 0, 3) === '```' && substr($jsonStr, -3) === '```') {
                $jsonStr = substr($jsonStr, 3, -3);
                if (substr($jsonStr, 0, 4) === 'json') {
                    $jsonStr = substr($jsonStr, 4);
                }
            }
            $jsonStr = trim($jsonStr);

            $categorization = json_decode($jsonStr, true);

            if (!$categorization || !isset($categorization['primary_category'])) {
                throw new \Exception("Failed to parse categorization JSON");
            }

            $categorization['error'] = false;
            return $categorization;

        } catch (\Exception $e) {
            $this->logger->error('Failed to parse categorization: ' . $e->getMessage());

            // Try to extract primary category directly
            $primaryCategory = 'unknown';
            foreach ($categories as $category) {
                if (strpos(strtolower($response), strtolower($category)) !== false) {
                    $primaryCategory = $category;
                    break;
                }
            }

            return [
                'primary_category' => $primaryCategory,
                'all_categories' => [[$primaryCategory, 0.5]],
                'explanation' => 'JSON parsing failed, extracted best guess',
                'raw_response' => $response,
                'error' => true
            ];
        }
    }

    /**
     * Generate a reply suggestion for a social media comment or message
     *
     * @param string $postText Original post content
     * @param string $comment Comment or message to reply to
     * @param string $tone Tone of the reply (professional, friendly, empathetic, etc.)
     * @param int $maxLength Maximum length of reply in characters
     * @return string Suggested reply
     */
    public function generateReplySuggestion($postText, $comment, $tone = 'professional', $maxLength = 280)
    {
        $prompt = "You're a social media manager for a brand. " .
            "Generate a {$tone} reply to this comment on your post. " .
            "Keep your response under {$maxLength} characters.\n\n" .
            "Original Post: \"{$postText}\"\n\n" .
            "Comment: \"{$comment}\"\n\n" .
            "Your Reply:";

        $response = $this->generateText($prompt);

        if (!$response) {
            return "We appreciate your feedback. Thank you for engaging with us!";
        }

        // Clean up formatting
        $reply = trim($response);
        if (substr($reply, 0, 1) === '"' && substr($reply, -1) === '"') {
            $reply = substr($reply, 1, -1);
        }

        // Ensure length constraints
        if (strlen($reply) > $maxLength) {
            $reply = substr($reply, 0, $maxLength - 3) . '...';
        }

        return $reply;
    }

    /**
     * Detect potentially harmful content in a social media post
     *
     * @param string $text Text to analyze
     * @return array Analysis with flags for harmful content categories
     */
    public function moderateContent($text)
    {
        try {
            $response = $this->apiRequest(self::ENDPOINT_MODERATION, [
                'input' => $text,
                'model' => self::DEFAULT_MODERATION_MODEL
            ]);

            if (!$response || !isset($response['results']) || empty($response['results'])) {
                throw new \Exception('No results in moderation response');
            }

            return [
                'flagged' => $response['results'][0]['flagged'],
                'categories' => $response['results'][0]['categories'],
                'category_scores' => $response['results'][0]['category_scores'],
                'error' => false
            ];

        } catch (\Exception $e) {
            $this->logger->error('Moderation API error: ' . $e->getMessage());

            return [
                'flagged' => false,
                'categories' => [],
                'category_scores' => [],
                'error' => true,
                'error_message' => $e->getMessage()
            ];
        }
    }

    /**
     * Extract hashtag recommendations from post content
     *
     * @param string $text Post text
     * @param int $count Number of hashtags to recommend
     * @return array List of recommended hashtags
     */
    public function recommendHashtags($text, $count = 5)
    {
        $prompt = "Generate {$count} relevant hashtags for the following social media post. " .
            "Provide a JSON response with an array of hashtags (without the # symbol).\n\n" .
            "Post: \"{$text}\"";

        $response = $this->generateText($prompt);

        if (!$response) {
            return [];
        }

        try {
            // Extract JSON from the response
            $jsonStr = trim($response);
            if (substr($jsonStr, 0, 3) === '```' && substr($jsonStr, -3) === '```') {
                $jsonStr = substr($jsonStr, 3, -3);
                if (substr($jsonStr, 0, 4) === 'json') {
                    $jsonStr = substr($jsonStr, 4);
                }
            }
            $jsonStr = trim($jsonStr);

            $data = json_decode($jsonStr, true);

            if (is_array($data)) {
                // Handle both array and object with hashtags key
                if (isset($data['hashtags']) && is_array($data['hashtags'])) {
                    return array_slice($data['hashtags'], 0, $count);
                } else {
                    // Assume the whole array is hashtags
                    return array_slice($data, 0, $count);
                }
            }

        } catch (\Exception $e) {
            $this->logger->error('Failed to parse hashtag recommendations: ' . $e->getMessage());
        }

        // Fallback: try to extract hashtags from text directly
        preg_match_all('/#(\w+)/', $response, $matches);
        if (!empty($matches[1])) {
            return array_slice($matches[1], 0, $count);
        }

        // If all else fails, extract words that might be hashtags
        $words = preg_split('/\s+/', $response);
        $hashtags = [];

        foreach ($words as $word) {
            $word = trim($word, ".,;:\"'[](){}#");
            if (!empty($word) && strlen($word) > 2) {
                $hashtags[] = $word;
                if (count($hashtags) >= $count) {
                    break;
                }
            }
        }

        return $hashtags;
    }

    /**
     * Analyze a social media profile based on recent posts
     *
     * @param array $posts Array of recent post texts
     * @param string $accountName Account name/handle
     * @return array Profile analysis
     */
    public function analyzeProfile($posts, $accountName)
    {
        $postsText = implode("\n\n", array_map(function($post, $index) {
            return "Post " . ($index + 1) . ": \"" . $post . "\"";
        }, $posts, array_keys($posts)));

        $prompt = "Analyze the social media profile based on these recent posts. " .
            "Provide a JSON response with: " .
            "content_themes (array of main themes), " .
            "tone (overall communication tone), " .
            "audience (likely target audience), " .
            "posting_strategy (observed strategy), " .
            "strengths (communication strengths), " .
            "improvement_areas (potential improvements), " .
            "and engagement_tips (tips to increase engagement).\n\n" .
            "Account: {$accountName}\n\n" .
            "{$postsText}";

        $this->setMaxTokens(2000);
        $response = $this->generateText($prompt);

        if (!$response) {
            return [
                'content_themes' => [],
                'tone' => 'unknown',
                'audience' => 'unknown',
                'posting_strategy' => 'unknown',
                'strengths' => [],
                'improvement_areas' => [],
                'engagement_tips' => [],
                'error' => true
            ];
        }

        try {
            // Extract JSON from the response
            $jsonStr = trim($response);
            if (substr($jsonStr, 0, 3) === '```' && substr($jsonStr, -3) === '```') {
                $jsonStr = substr($jsonStr, 3, -3);
                if (substr($jsonStr, 0, 4) === 'json') {
                    $jsonStr = substr($jsonStr, 4);
                }
            }
            $jsonStr = trim($jsonStr);

            $analysis = json_decode($jsonStr, true);

            if (!$analysis) {
                throw new \Exception("Failed to parse profile analysis JSON");
            }

            $analysis['error'] = false;
            return $analysis;

        } catch (\Exception $e) {
            $this->logger->error('Failed to parse profile analysis: ' . $e->getMessage());

            return [
                'content_themes' => [],
                'tone' => 'unknown',
                'audience' => 'unknown',
                'posting_strategy' => 'unknown',
                'strengths' => [],
                'improvement_areas' => [],
                'engagement_tips' => [],
                'raw_response' => $response,
                'error' => true
            ];
        }
    }

    /**
     * Save AI analysis results to the database
     *
     * @param int $contentId ID of the analyzed content (post, comment, etc.)
     * @param string $contentType Type of content (post, comment, profile, etc.)
     * @param array $analysis Analysis results
     * @return AiAnalysis New AiAnalysis model instance
     */
    public function saveAnalysis($contentId, $contentType, $analysis)
    {
        $aiAnalysis = new AiAnalysis();
        $aiAnalysis->content_id = $contentId;
        $aiAnalysis->content_type = $contentType;
        $aiAnalysis->model = $this->model;
        $aiAnalysis->analysis_data = json_encode($analysis);
        $aiAnalysis->created_at = date('Y-m-d H:i:s');

        // Save to DB
        $aiAnalysis->save();

        return $aiAnalysis;
    }

    /**
     * Generate a text completion using the OpenAI API
     *
     * @param string $prompt Text prompt
     * @return string|null Generated text or null on failure
     */
    private function generateText($prompt)
    {
        try {
            $params = [
                'model' => $this->model,
                'messages' => [
                    ['role' => 'system', 'content' => 'You are an AI assistant that helps analyze social media content and provides structured data about social media posts. Always respond with valid, well-formatted JSON when asked.'],
                    ['role' => 'user', 'content' => $prompt]
                ],
                'temperature' => $this->temperature,
                'max_tokens' => $this->maxTokens
            ];

            $response = $this->apiRequest(self::ENDPOINT_CHAT, $params);

            if (!$response || !isset($response['choices'][0]['message']['content'])) {
                throw new \Exception('No valid response content');
            }

            return $response['choices'][0]['message']['content'];

        } catch (\Exception $e) {
            $this->logger->error('Text generation error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Make an API request to the OpenAI API
     *
     * @param string $endpoint API endpoint
     * @param array $params Request parameters
     * @return array|null Response data or null on failure
     */
    private function apiRequest($endpoint, $params)
    {
        $url = self::API_BASE_URL . $endpoint;

        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey
        ];

        if ($this->orgId) {
            $headers[] = 'OpenAI-Organization: ' . $this->orgId;
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60); // Longer timeout for AI operations

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);

        curl_close($ch);

        if ($error) {
            $this->logger->error('OpenAI API request failed: ' . $error . ' (URL: ' . $url . ')');
            throw new \Exception('API request failed: ' . $error);
        }

        if ($httpCode >= 400) {
            $this->logger->error('OpenAI API request failed with HTTP code ' . $httpCode . ' (URL: ' . $url . ')');
            throw new \Exception('API request failed with HTTP code ' . $httpCode);
        }

        $data = json_decode($response, true);

        if (!$data) {
            $this->logger->error('Failed to parse OpenAI API response (URL: ' . $url . ')');
            throw new \Exception('Failed to parse API response');
        }

        if (isset($data['error'])) {
            $this->logger->error('OpenAI API error: ' . $data['error']['message'] . ' (URL: ' . $url . ')');
            throw new \Exception('API error: ' . $data['error']['message']);
        }

        return $data;
    }
}