<?php
/**
 * Payment Gateway Integration
 *
 * This file handles all payment processing for the Social Media Monitoring Platform
 * Supports multiple payment gateways including Stripe, PayPal, and more
 * Used for subscription billing and one-time payments
 *
 * @author Social Monitor Development Team
 * @version 1.3.0
 * @copyright Social Monitor Inc.
 */

namespace Api;

use Core\Helper;
use Core\Config;
use Core\Logger;
use Models\Payment;
use Models\Subscription;
use Models\User;
use Models\Invoice;

class PaymentGateway
{
    /**
     * Payment gateway types
     */
    const GATEWAY_STRIPE = 'stripe';
    const GATEWAY_PAYPAL = 'paypal';
    const GATEWAY_AUTHORIZE = 'authorize';
    const GATEWAY_ZARINPAL = 'zarinpal';

    /**
     * Payment statuses
     */
    const STATUS_PENDING = 'pending';
    const STATUS_COMPLETED = 'completed';
    const STATUS_FAILED = 'failed';
    const STATUS_REFUNDED = 'refunded';
    const STATUS_CANCELLED = 'cancelled';

    /**
     * Transaction types
     */
    const TYPE_SUBSCRIPTION = 'subscription';
    const TYPE_ONE_TIME = 'one_time';
    const TYPE_UPGRADE = 'upgrade';
    const TYPE_RENEWAL = 'renewal';

    /**
     * Current gateway type
     */
    private $gatewayType;

    /**
     * Gateway-specific configurations
     */
    private $config;

    /**
     * Logger instance
     */
    private $logger;

    /**
     * Gateway-specific API client
     */
    private $client;

    /**
     * Constructor
     *
     * @param string $gatewayType Payment gateway type
     */
    public function __construct($gatewayType = null)
    {
        $this->logger = Logger::getInstance();

        if ($gatewayType) {
            $this->gatewayType = $gatewayType;
        } else {
            $this->gatewayType = Config::get('payment.default_gateway', self::GATEWAY_STRIPE);
        }

        $this->loadConfig();
        $this->initializeClient();
    }

    /**
     * Load configuration for the current gateway
     */
    private function loadConfig()
    {
        $this->config = [
            'mode' => Config::get('payment.mode', 'sandbox'), // sandbox or live
            'currency' => Config::get('payment.currency', 'USD'),
            'tax_rate' => Config::get('payment.tax_rate', 0.0),
        ];

        switch ($this->gatewayType) {
            case self::GATEWAY_STRIPE:
                $this->config['api_key'] = Config::get('payment.stripe.api_key');
                $this->config['public_key'] = Config::get('payment.stripe.public_key');
                $this->config['webhook_secret'] = Config::get('payment.stripe.webhook_secret');
                break;

            case self::GATEWAY_PAYPAL:
                $this->config['client_id'] = Config::get('payment.paypal.client_id');
                $this->config['client_secret'] = Config::get('payment.paypal.client_secret');
                $this->config['return_url'] = Config::get('payment.paypal.return_url');
                $this->config['cancel_url'] = Config::get('payment.paypal.cancel_url');
                break;

            case self::GATEWAY_AUTHORIZE:
                $this->config['api_login_id'] = Config::get('payment.authorize.api_login_id');
                $this->config['transaction_key'] = Config::get('payment.authorize.transaction_key');
                $this->config['signature_key'] = Config::get('payment.authorize.signature_key');
                break;

            case self::GATEWAY_ZARINPAL:
                $this->config['merchant_id'] = Config::get('payment.zarinpal.merchant_id');
                $this->config['callback_url'] = Config::get('payment.zarinpal.callback_url');
                // در حالت آزمایشی از آدرس sandbox استفاده می‌شود
                $this->config['api_url'] = $this->config['mode'] === 'sandbox'
                    ? 'https://sandbox.zarinpal.com/pg/rest/WebGate/'
                    : 'https://www.zarinpal.com/pg/rest/WebGate/';
                $this->config['payment_url'] = $this->config['mode'] === 'sandbox'
                    ? 'https://sandbox.zarinpal.com/pg/StartPay/'
                    : 'https://www.zarinpal.com/pg/StartPay/';
                // تنظیم واحد پول به تومان برای زرین‌پال
                $this->config['zarinpal_currency'] = 'IRT'; // Iranian Toman
                break;

            default:
                throw new \Exception("Unsupported payment gateway: {$this->gatewayType}");
        }
    }

    /**
     * Initialize the payment gateway client
     */
    private function initializeClient()
    {
        switch ($this->gatewayType) {
            case self::GATEWAY_STRIPE:
                if (!class_exists('\Stripe\Stripe')) {
                    require_once(ROOT_DIR . '/vendor/stripe/stripe-php/init.php');
                }

                \Stripe\Stripe::setApiKey($this->config['api_key']);

                // Set API version explicitly
                \Stripe\Stripe::setApiVersion('2023-10-16');

                // Set app info
                \Stripe\Stripe::setAppInfo(
                    'Social Media Monitoring Platform',
                    Config::get('app.version', '1.0.0'),
                    Config::get('app.url')
                );

                $this->client = new \Stripe\StripeClient($this->config['api_key']);
                break;

            case self::GATEWAY_PAYPAL:
                if (!class_exists('\PayPalCheckoutSdk\Core\PayPalHttpClient')) {
                    require_once(ROOT_DIR . '/vendor/paypal/paypal-checkout-sdk/lib/PayPalCheckoutSdk/Core/PayPalHttpClient.php');
                    require_once(ROOT_DIR . '/vendor/paypal/paypal-checkout-sdk/lib/PayPalCheckoutSdk/Core/SandboxEnvironment.php');
                    require_once(ROOT_DIR . '/vendor/paypal/paypal-checkout-sdk/lib/PayPalCheckoutSdk/Core/ProductionEnvironment.php');
                }

                $environment = null;

                if ($this->config['mode'] === 'sandbox') {
                    $environment = new \PayPalCheckoutSdk\Core\SandboxEnvironment(
                        $this->config['client_id'],
                        $this->config['client_secret']
                    );
                } else {
                    $environment = new \PayPalCheckoutSdk\Core\ProductionEnvironment(
                        $this->config['client_id'],
                        $this->config['client_secret']
                    );
                }

                $this->client = new \PayPalCheckoutSdk\Core\PayPalHttpClient($environment);
                break;

            case self::GATEWAY_AUTHORIZE:
                if (!class_exists('\net\authorize\api\contract\v1\MerchantAuthenticationType')) {
                    require_once(ROOT_DIR . '/vendor/authorizenet/authorizenet/autoload.php');
                }

                $merchantAuthentication = new \net\authorize\api\contract\v1\MerchantAuthenticationType();
                $merchantAuthentication->setName($this->config['api_login_id']);
                $merchantAuthentication->setTransactionKey($this->config['transaction_key']);

                $this->client = $merchantAuthentication;
                break;

            case self::GATEWAY_ZARINPAL:
                // برای زرین‌پال نیاز به تنظیم کلاینت خاصی نیست
                // از تابع‌های cURL استفاده می‌کنیم
                $this->client = [
                    'merchant_id' => $this->config['merchant_id'],
                    'api_url' => $this->config['api_url'],
                    'payment_url' => $this->config['payment_url']
                ];
                break;
        }
    }

    /**
     * Process a subscription payment
     *
     * @param User $user User model
     * @param string $planId Subscription plan ID
     * @param array $paymentData Payment data (card details, etc.)
     * @param array $metadata Additional metadata
     * @return array Payment result
     */
    public function createSubscription($user, $planId, $paymentData, $metadata = [])
    {
        try {
            $this->logger->info("Creating subscription for user {$user->id}, plan {$planId}");

            switch ($this->gatewayType) {
                case self::GATEWAY_STRIPE:
                    return $this->createStripeSubscription($user, $planId, $paymentData, $metadata);

                case self::GATEWAY_PAYPAL:
                    return $this->createPayPalSubscription($user, $planId, $paymentData, $metadata);

                case self::GATEWAY_AUTHORIZE:
                    return $this->createAuthorizeNetSubscription($user, $planId, $paymentData, $metadata);

                case self::GATEWAY_ZARINPAL:
                    return $this->createZarinpalSubscription($user, $planId, $paymentData, $metadata);

                default:
                    throw new \Exception("Unsupported payment gateway for subscriptions");
            }
        } catch (\Exception $e) {
            $this->logger->error("Subscription creation failed: " . $e->getMessage());

            return [
                'success' => false,
                'message' => "Payment processing failed: " . $e->getMessage(),
                'error' => $e->getMessage(),
                'error_code' => $e->getCode(),
                'payment_id' => null,
                'transaction_id' => null
            ];
        }
    }

    /**
     * Process a one-time payment
     *
     * @param User $user User model
     * @param float $amount Payment amount
     * @param string $description Payment description
     * @param array $paymentData Payment data (card details, etc.)
     * @param array $metadata Additional metadata
     * @return array Payment result
     */
    public function processPayment($user, $amount, $description, $paymentData, $metadata = [])
    {
        try {
            $this->logger->info("Processing payment for user {$user->id}, amount {$amount}");

            // Apply tax if configured
            $taxAmount = $amount * $this->config['tax_rate'];
            $totalAmount = $amount + $taxAmount;

            switch ($this->gatewayType) {
                case self::GATEWAY_STRIPE:
                    return $this->processStripePayment($user, $totalAmount, $description, $paymentData, $metadata);

                case self::GATEWAY_PAYPAL:
                    return $this->processPayPalPayment($user, $totalAmount, $description, $paymentData, $metadata);

                case self::GATEWAY_AUTHORIZE:
                    return $this->processAuthorizeNetPayment($user, $totalAmount, $description, $paymentData, $metadata);

                case self::GATEWAY_ZARINPAL:
                    return $this->processZarinpalPayment($user, $totalAmount, $description, $paymentData, $metadata);

                default:
                    throw new \Exception("Unsupported payment gateway");
            }
        } catch (\Exception $e) {
            $this->logger->error("Payment processing failed: " . $e->getMessage());

            return [
                'success' => false,
                'message' => "Payment processing failed: " . $e->getMessage(),
                'error' => $e->getMessage(),
                'error_code' => $e->getCode(),
                'payment_id' => null,
                'transaction_id' => null
            ];
        }
    }

    /**
     * Cancel a subscription
     *
     * @param Subscription $subscription Subscription model
     * @param bool $atPeriodEnd Whether to cancel at period end or immediately
     * @return array Cancellation result
     */
    public function cancelSubscription($subscription, $atPeriodEnd = true)
    {
        try {
            $this->logger->info("Cancelling subscription {$subscription->id} (gateway subscription ID: {$subscription->gateway_subscription_id})");

            switch ($this->gatewayType) {
                case self::GATEWAY_STRIPE:
                    return $this->cancelStripeSubscription($subscription, $atPeriodEnd);

                case self::GATEWAY_PAYPAL:
                    return $this->cancelPayPalSubscription($subscription, $atPeriodEnd);

                case self::GATEWAY_AUTHORIZE:
                    return $this->cancelAuthorizeNetSubscription($subscription, $atPeriodEnd);

                case self::GATEWAY_ZARINPAL:
                    return $this->cancelZarinpalSubscription($subscription, $atPeriodEnd);

                default:
                    throw new \Exception("Unsupported payment gateway for subscription cancellation");
            }
        } catch (\Exception $e) {
            $this->logger->error("Subscription cancellation failed: " . $e->getMessage());

            return [
                'success' => false,
                'message' => "Subscription cancellation failed: " . $e->getMessage(),
                'error' => $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }

    /**
     * Process a refund
     *
     * @param Payment $payment Payment model
     * @param float $amount Amount to refund (null for full refund)
     * @param string $reason Reason for refund
     * @return array Refund result
     */
    public function processRefund($payment, $amount = null, $reason = '')
    {
        try {
            $this->logger->info("Processing refund for payment {$payment->id}, amount " . ($amount ?: 'full'));

            switch ($this->gatewayType) {
                case self::GATEWAY_STRIPE:
                    return $this->processStripeRefund($payment, $amount, $reason);

                case self::GATEWAY_PAYPAL:
                    return $this->processPayPalRefund($payment, $amount, $reason);

                case self::GATEWAY_AUTHORIZE:
                    return $this->processAuthorizeNetRefund($payment, $amount, $reason);

                case self::GATEWAY_ZARINPAL:
                    return $this->processZarinpalRefund($payment, $amount, $reason);

                default:
                    throw new \Exception("Unsupported payment gateway for refunds");
            }
        } catch (\Exception $e) {
            $this->logger->error("Refund processing failed: " . $e->getMessage());

            return [
                'success' => false,
                'message' => "Refund processing failed: " . $e->getMessage(),
                'error' => $e->getMessage(),
                'error_code' => $e->getCode(),
                'refund_id' => null
            ];
        }
    }

    /**
     * Process a webhook event from the payment gateway
     *
     * @param string $payload Webhook payload
     * @param array $headers Request headers
     * @return bool Success flag
     */
    public function processWebhook($payload, $headers)
    {
        try {
            $this->logger->info("Processing payment webhook");

            switch ($this->gatewayType) {
                case self::GATEWAY_STRIPE:
                    return $this->processStripeWebhook($payload, $headers);

                case self::GATEWAY_PAYPAL:
                    return $this->processPayPalWebhook($payload, $headers);

                case self::GATEWAY_AUTHORIZE:
                    return $this->processAuthorizeNetWebhook($payload, $headers);

                case self::GATEWAY_ZARINPAL:
                    return $this->processZarinpalWebhook($payload, $headers);

                default:
                    throw new \Exception("Unsupported payment gateway for webhooks");
            }
        } catch (\Exception $e) {
            $this->logger->error("Webhook processing failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Save payment information to the database
     *
     * @param User $user User model
     * @param array $paymentData Payment data
     * @return Payment New Payment model instance
     */
    public function savePayment($user, $paymentData)
    {
        $payment = new Payment();
        $payment->user_id = $user->id;
        $payment->gateway = $this->gatewayType;
        $payment->gateway_payment_id = $paymentData['payment_id'];
        $payment->gateway_transaction_id = $paymentData['transaction_id'] ?? null;
        $payment->amount = $paymentData['amount'];
        $payment->currency = $paymentData['currency'] ?? $this->config['currency'];
        $payment->status = $paymentData['status'] ?? self::STATUS_COMPLETED;
        $payment->payment_type = $paymentData['type'] ?? self::TYPE_ONE_TIME;
        $payment->description = $paymentData['description'] ?? '';
        $payment->metadata = json_encode($paymentData['metadata'] ?? []);
        $payment->created_at = date('Y-m-d H:i:s');

        // Save to DB
        $payment->save();

        // Create invoice if needed
        if ($payment->status === self::STATUS_COMPLETED) {
            $this->createInvoice($payment);
        }

        return $payment;
    }

    /**
     * Create an invoice for a completed payment
     *
     * @param Payment $payment Payment model
     * @return Invoice New Invoice model instance
     */
    private function createInvoice($payment)
    {
        $invoice = new Invoice();
        $invoice->user_id = $payment->user_id;
        $invoice->payment_id = $payment->id;
        $invoice->invoice_number = 'INV-' . date('Ymd') . '-' . $payment->id;
        $invoice->amount = $payment->amount;
        $invoice->tax_amount = $payment->amount * $this->config['tax_rate'];
        $invoice->total_amount = $invoice->amount + $invoice->tax_amount;
        $invoice->currency = $payment->currency;
        $invoice->status = 'paid';
        $invoice->issued_date = date('Y-m-d H:i:s');
        $invoice->due_date = date('Y-m-d H:i:s');
        $invoice->paid_date = date('Y-m-d H:i:s');

        // Save to DB
        $invoice->save();

        return $invoice;
    }

    /**
     * Create a Stripe subscription
     */
    private function createStripeSubscription($user, $planId, $paymentData, $metadata = [])
    {
        // Check if user already has a customer ID
        $stripeCustomerId = $user->stripe_customer_id ?? null;

        // Create customer if needed
        if (!$stripeCustomerId) {
            $customerData = [
                'email' => $user->email,
                'name' => $user->getFullName(),
                'metadata' => [
                    'user_id' => $user->id,
                    'platform' => 'Social Media Monitoring Platform'
                ]
            ];

            // Add payment method if provided
            if (isset($paymentData['payment_method_id'])) {
                $customerData['payment_method'] = $paymentData['payment_method_id'];
            }

            $customer = $this->client->customers->create($customerData);
            $stripeCustomerId = $customer->id;

            // Save Stripe customer ID to user
            $user->stripe_customer_id = $stripeCustomerId;
            $user->save();
        }

        // Create subscription
        $subscriptionData = [
            'customer' => $stripeCustomerId,
            'items' => [
                ['price' => $planId],
            ],
            'metadata' => array_merge([
                'user_id' => $user->id,
                'platform' => 'Social Media Monitoring Platform'
            ], $metadata),
            'expand' => ['latest_invoice.payment_intent']
        ];

        // Add trial if specified
        if (isset($paymentData['trial_days']) && $paymentData['trial_days'] > 0) {
            $subscriptionData['trial_period_days'] = $paymentData['trial_days'];
        }

        // Add payment method if provided
        if (isset($paymentData['payment_method_id'])) {
            $subscriptionData['default_payment_method'] = $paymentData['payment_method_id'];
        }

        $subscription = $this->client->subscriptions->create($subscriptionData);

        // Handle the result
        $result = [
            'success' => true,
            'gateway' => self::GATEWAY_STRIPE,
            'subscription_id' => $subscription->id,
            'customer_id' => $stripeCustomerId,
            'status' => $subscription->status
        ];

        // Get payment details if available
        if (isset($subscription->latest_invoice) && isset($subscription->latest_invoice->payment_intent)) {
            $paymentIntent = $subscription->latest_invoice->payment_intent;
            $result['payment_id'] = $paymentIntent->id;
            $result['client_secret'] = $paymentIntent->client_secret;
            $result['requires_action'] = $paymentIntent->status === 'requires_action';
        }

        // Save subscription in database
        $subscriptionModel = new Subscription();
        $subscriptionModel->user_id = $user->id;
        $subscriptionModel->gateway = self::GATEWAY_STRIPE;
        $subscriptionModel->gateway_subscription_id = $subscription->id;
        $subscriptionModel->gateway_customer_id = $stripeCustomerId;
        $subscriptionModel->plan_id = $planId;
        $subscriptionModel->status = $subscription->status;
        $subscriptionModel->current_period_start = date('Y-m-d H:i:s', $subscription->current_period_start);
        $subscriptionModel->current_period_end = date('Y-m-d H:i:s', $subscription->current_period_end);
        $subscriptionModel->created_at = date('Y-m-d H:i:s', $subscription->created);
        $subscriptionModel->save();

        return $result;
    }

    /**
     * Process a Stripe payment
     */
    private function processStripePayment($user, $amount, $description, $paymentData, $metadata = [])
    {
        // Check if user already has a customer ID
        $stripeCustomerId = $user->stripe_customer_id ?? null;

        // Create customer if needed
        if (!$stripeCustomerId) {
            $customerData = [
                'email' => $user->email,
                'name' => $user->getFullName(),
                'metadata' => [
                    'user_id' => $user->id,
                    'platform' => 'Social Media Monitoring Platform'
                ]
            ];

            $customer = $this->client->customers->create($customerData);
            $stripeCustomerId = $customer->id;

            // Save Stripe customer ID to user
            $user->stripe_customer_id = $stripeCustomerId;
            $user->save();
        }

        // Create payment intent
        $paymentIntentData = [
            'amount' => round($amount * 100), // Stripe uses cents
            'currency' => strtolower($this->config['currency']),
            'customer' => $stripeCustomerId,
            'description' => $description,
            'metadata' => array_merge([
                'user_id' => $user->id,
                'platform' => 'Social Media Monitoring Platform'
            ], $metadata)
        ];

        // Add payment method if provided
        if (isset($paymentData['payment_method_id'])) {
            $paymentIntentData['payment_method'] = $paymentData['payment_method_id'];
            $paymentIntentData['confirm'] = true;
        }

        $paymentIntent = $this->client->paymentIntents->create($paymentIntentData);

        // Handle the result
        $result = [
            'success' => true,
            'gateway' => self::GATEWAY_STRIPE,
            'payment_id' => $paymentIntent->id,
            'client_secret' => $paymentIntent->client_secret,
            'requires_action' => $paymentIntent->status === 'requires_action',
            'status' => $paymentIntent->status,
            'amount' => $amount,
            'currency' => $this->config['currency']
        ];

        // Save payment in database if it's completed
        if ($paymentIntent->status === 'succeeded') {
            $this->savePayment($user, [
                'payment_id' => $paymentIntent->id,
                'transaction_id' => $paymentIntent->charges->data[0]->id ?? null,
                'amount' => $amount,
                'currency' => $this->config['currency'],
                'status' => self::STATUS_COMPLETED,
                'type' => self::TYPE_ONE_TIME,
                'description' => $description,
                'metadata' => $metadata
            ]);
        }

        return $result;
    }

    /**
     * Cancel a Stripe subscription
     */
    private function cancelStripeSubscription($subscription, $atPeriodEnd = true)
    {
        $result = $this->client->subscriptions->cancel(
            $subscription->gateway_subscription_id,
            ['cancel_at_period_end' => $atPeriodEnd]
        );

        // Update subscription in database
        if ($atPeriodEnd) {
            $subscription->status = 'active';
            $subscription->cancel_at_period_end = true;
        } else {
            $subscription->status = 'cancelled';
            $subscription->ended_at = date('Y-m-d H:i:s');
        }

        $subscription->save();

        return [
            'success' => true,
            'message' => $atPeriodEnd ? 'Subscription will be cancelled at the end of the billing period' : 'Subscription cancelled successfully',
            'subscription_id' => $subscription->gateway_subscription_id
        ];
    }

    /**
     * Process a Stripe refund
     */
    private function processStripeRefund($payment, $amount = null, $reason = '')
    {
        $refundData = [
            'payment_intent' => $payment->gateway_payment_id
        ];

        if ($amount !== null) {
            $refundData['amount'] = round($amount * 100); // Stripe uses cents
        }

        if (!empty($reason)) {
            $refundData['reason'] = $reason;
        }

        $refund = $this->client->refunds->create($refundData);

        // Update payment in database
        $payment->status = self::STATUS_REFUNDED;
        $payment->refunded_amount = $amount ?: $payment->amount;
        $payment->refund_reason = $reason;
        $payment->refunded_at = date('Y-m-d H:i:s');
        $payment->save();

        return [
            'success' => true,
            'message' => 'Refund processed successfully',
            'refund_id' => $refund->id,
            'status' => $refund->status,
            'amount' => ($refund->amount / 100) // Convert cents back to dollars
        ];
    }

    /**
     * Process a Stripe webhook
     */
    private function processStripeWebhook($payload, $headers)
    {
        $signature = $headers['Stripe-Signature'] ?? '';

        try {
            // Verify webhook signature
            $event = \Stripe\Webhook::constructEvent(
                $payload,
                $signature,
                $this->config['webhook_secret']
            );

            // Handle different event types
            switch ($event->type) {
                case 'payment_intent.succeeded':
                    $paymentIntent = $event->data->object;
                    $this->handleSuccessfulPayment($paymentIntent);
                    break;

                case 'payment_intent.payment_failed':
                    $paymentIntent = $event->data->object;
                    $this->handleFailedPayment($paymentIntent);
                    break;

                case 'customer.subscription.created':
                case 'customer.subscription.updated':
                    $subscription = $event->data->object;
                    $this->handleSubscriptionUpdate($subscription);
                    break;

                case 'customer.subscription.deleted':
                    $subscription = $event->data->object;
                    $this->handleSubscriptionCancellation($subscription);
                    break;

                case 'invoice.payment_succeeded':
                    $invoice = $event->data->object;
                    $this->handleSuccessfulInvoicePayment($invoice);
                    break;

                case 'invoice.payment_failed':
                    $invoice = $event->data->object;
                    $this->handleFailedInvoicePayment($invoice);
                    break;
            }

            return true;

        } catch (\UnexpectedValueException $e) {
            // Invalid payload
            $this->logger->error('Invalid webhook payload: ' . $e->getMessage());
            return false;
        } catch (\Stripe\Exception\SignatureVerificationException $e) {
            // Invalid signature
            $this->logger->error('Invalid webhook signature: ' . $e->getMessage());
            return false;
        } catch (\Exception $e) {
            // General error
            $this->logger->error('Webhook processing error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Handle a successful payment from Stripe webhook
     */
    private function handleSuccessfulPayment($paymentIntent)
    {
        // Find user by customer ID
        $customerId = $paymentIntent->customer;

        if (!$customerId) {
            $this->logger->error('No customer ID in payment intent: ' . $paymentIntent->id);
            return;
        }

        $user = User::findByStripeCustomerId($customerId);

        if (!$user) {
            $this->logger->error('User not found for Stripe customer: ' . $customerId);
            return;
        }

        // Check if this payment is already recorded
        $existingPayment = Payment::findByGatewayPaymentId(self::GATEWAY_STRIPE, $paymentIntent->id);

        if ($existingPayment) {
            $this->logger->info('Payment already recorded: ' . $paymentIntent->id);
            return;
        }

        // Save payment
        $this->savePayment($user, [
            'payment_id' => $paymentIntent->id,
            'transaction_id' => $paymentIntent->charges->data[0]->id ?? null,
            'amount' => $paymentIntent->amount / 100, // Convert cents to dollars
            'currency' => $paymentIntent->currency,
            'status' => self::STATUS_COMPLETED,
            'type' => self::TYPE_ONE_TIME,
            'description' => $paymentIntent->description,
            'metadata' => $paymentIntent->metadata->toArray()
        ]);
    }

    /**
     * Handle a subscription update from Stripe webhook
     */
    private function handleSubscriptionUpdate($stripeSubscription)
    {
        // Find subscription in database
        $subscription = Subscription::findByGatewaySubscriptionId(self::GATEWAY_STRIPE, $stripeSubscription->id);

        if (!$subscription) {
            // This might be a new subscription
            $customerId = $stripeSubscription->customer;
            $user = User::findByStripeCustomerId($customerId);

            if (!$user) {
                $this->logger->error('User not found for Stripe customer: ' . $customerId);
                return;
            }

            // Create new subscription record
            $subscription = new Subscription();
            $subscription->user_id = $user->id;
            $subscription->gateway = self::GATEWAY_STRIPE;
            $subscription->gateway_subscription_id = $stripeSubscription->id;
            $subscription->gateway_customer_id = $customerId;
            $subscription->plan_id = $stripeSubscription->plan->id;
        }

        // Update subscription data
        $subscription->status = $stripeSubscription->status;
        $subscription->current_period_start = date('Y-m-d H:i:s', $stripeSubscription->current_period_start);
        $subscription->current_period_end = date('Y-m-d H:i:s', $stripeSubscription->current_period_end);

        if ($stripeSubscription->cancel_at_period_end) {
            $subscription->cancel_at_period_end = true;
        }

        if (isset($stripeSubscription->ended_at) && $stripeSubscription->ended_at) {
            $subscription->ended_at = date('Y-m-d H:i:s', $stripeSubscription->ended_at);
        }

        $subscription->save();
    }

    // PayPal and Authorize.Net integration methods would be implemented in a similar way
    // Below are placeholder method signatures that would be fully implemented in production

    private function createPayPalSubscription($user, $planId, $paymentData, $metadata = [])
    {
        // Implementation for PayPal subscription creation
    }

    private function processPayPalPayment($user, $amount, $description, $paymentData, $metadata = [])
    {
        // Implementation for PayPal payment processing
    }

    private function cancelPayPalSubscription($subscription, $atPeriodEnd = true)
    {
        // Implementation for PayPal subscription cancellation
    }

    private function processPayPalRefund($payment, $amount = null, $reason = '')
    {
        // Implementation for PayPal refund processing
    }

    private function processPayPalWebhook($payload, $headers)
    {
        // Implementation for PayPal webhook processing
    }

    private function createAuthorizeNetSubscription($user, $planId, $paymentData, $metadata = [])
    {
        // Implementation for Authorize.Net subscription creation
    }

    private function processAuthorizeNetPayment($user, $amount, $description, $paymentData, $metadata = [])
    {
        // Implementation for Authorize.Net payment processing
    }

    private function cancelAuthorizeNetSubscription($subscription, $atPeriodEnd = true)
    {
        // Implementation for Authorize.Net subscription cancellation
    }

    private function processAuthorizeNetRefund($payment, $amount = null, $reason = '')
    {
        // Implementation for Authorize.Net refund processing
    }

    private function processAuthorizeNetWebhook($payload, $headers)
    {
        // Implementation for Authorize.Net webhook processing
    }

    /**
     * Process a payment with ZarinPal
     *
     * @param User $user User model
     * @param float $amount Payment amount (in Tomans for ZarinPal)
     * @param string $description Payment description
     * @param array $paymentData Payment data
     * @param array $metadata Additional metadata
     * @return array Payment result
     */
    private function processZarinpalPayment($user, $amount, $description, $paymentData, $metadata = [])
    {
        // ایجاد درخواست پرداخت در زرین‌پال
        $data = [
            'MerchantID' => $this->config['merchant_id'],
            'Amount' => (int)$amount, // مبلغ به تومان
            'Description' => $description,
            'Email' => $user->email,
            'Mobile' => $user->phone ?? '',
            'CallbackURL' => $this->config['callback_url'] . '?user_id=' . $user->id
        ];

        // افزودن متادیتا به آدرس بازگشت
        if (!empty($metadata)) {
            $encodedMetadata = base64_encode(json_encode($metadata));
            $data['CallbackURL'] .= '&metadata=' . urlencode($encodedMetadata);
        }

        $jsonData = json_encode($data);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->config['api_url'] . 'PaymentRequest.json');
        curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest Api v1');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Content-Length: ' . strlen($jsonData)]);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $result = json_decode($result, true);

        if ($httpCode != 200 || $result['Status'] != 100) {
            $this->logger->error('ZarinPal payment request failed: ' . ($result['Status'] ?? 'Unknown error'));

            return [
                'success' => false,
                'message' => 'خطا در ایجاد درخواست پرداخت: ' . ($result['Status'] ?? 'خطای نامشخص'),
                'error' => $result['Status'] ?? 'Unknown error',
                'error_code' => $httpCode,
                'payment_id' => null,
                'transaction_id' => null
            ];
        }

        // ذخیره اطلاعات پرداخت در دیتابیس با وضعیت در انتظار
        $payment = $this->savePayment($user, [
            'payment_id' => $result['Authority'],
            'transaction_id' => null, // بعد از پرداخت تکمیل می‌شود
            'amount' => $amount,
            'currency' => $this->config['zarinpal_currency'],
            'status' => self::STATUS_PENDING,
            'type' => self::TYPE_ONE_TIME,
            'description' => $description,
            'metadata' => $metadata
        ]);

        return [
            'success' => true,
            'gateway' => self::GATEWAY_ZARINPAL,
            'payment_id' => $result['Authority'],
            'redirect_url' => $this->config['payment_url'] . $result['Authority'],
            'status' => 'pending',
            'amount' => $amount,
            'currency' => $this->config['zarinpal_currency'],
            'payment_local_id' => $payment->id
        ];
    }

    /**
     * Verify a ZarinPal payment after user returns from payment page
     *
     * @param string $authority Payment authority from ZarinPal
     * @param int $status Status code from ZarinPal
     * @param float $amount Original payment amount
     * @return array Verification result
     */
    public function verifyZarinpalPayment($authority, $status, $amount)
    {
        if ($status != 'OK') {
            $this->logger->info('ZarinPal payment cancelled by user: ' . $authority);

            // Update payment status in database
            $payment = Payment::findByGatewayPaymentId(self::GATEWAY_ZARINPAL, $authority);
            if ($payment) {
                $payment->status = self::STATUS_CANCELLED;
                $payment->save();
            }

            return [
                'success' => false,
                'message' => 'پرداخت توسط کاربر لغو شد',
                'error' => 'Payment cancelled',
                'error_code' => null
            ];
        }

        // Verify the payment with ZarinPal
        $data = [
            'MerchantID' => $this->config['merchant_id'],
            'Authority' => $authority,
            'Amount' => (int)$amount // مبلغ به تومان
        ];

        $jsonData = json_encode($data);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->config['api_url'] . 'PaymentVerification.json');
        curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest Api v1');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Content-Length: ' . strlen($jsonData)]);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $result = json_decode($result, true);

        if ($httpCode != 200 || $result['Status'] != 100) {
            $this->logger->error('ZarinPal payment verification failed: ' . ($result['Status'] ?? 'Unknown error'));

            // Update payment status in database
            $payment = Payment::findByGatewayPaymentId(self::GATEWAY_ZARINPAL, $authority);
            if ($payment) {
                $payment->status = self::STATUS_FAILED;
                $payment->save();
            }

            return [
                'success' => false,
                'message' => 'تایید پرداخت با خطا مواجه شد: ' . ($result['Status'] ?? 'خطای نامشخص'),
                'error' => $result['Status'] ?? 'Unknown error',
                'error_code' => $httpCode
            ];
        }

        // Payment is successful, update the payment record
        $payment = Payment::findByGatewayPaymentId(self::GATEWAY_ZARINPAL, $authority);

        if ($payment) {
            $payment->status = self::STATUS_COMPLETED;
            $payment->gateway_transaction_id = $result['RefID'];
            $payment->completed_at = date('Y-m-d H:i:s');
            $payment->save();

            // Create invoice
            $this->createInvoice($payment);
        }

        return [
            'success' => true,
            'message' => 'پرداخت با موفقیت انجام شد',
            'transaction_id' => $result['RefID'],
            'payment_id' => $authority,
            'payment_local_id' => $payment ? $payment->id : null
        ];
    }

    /**
     * Process a refund with ZarinPal
     * Note: ZarinPal does not have an automatic refund API, this is a manual process
     *
     * @param Payment $payment Payment model
     * @param float $amount Amount to refund (null for full refund)
     * @param string $reason Reason for refund
     * @return array Refund result
     */
    private function processZarinpalRefund($payment, $amount = null, $reason = '')
    {
        // ZarinPal does not have an automatic refund API
        // This is usually handled manually through the ZarinPal dashboard
        // We'll just update our database to reflect the refund

        if ($amount === null) {
            $amount = $payment->amount;
        }

        $payment->status = self::STATUS_REFUNDED;
        $payment->refunded_amount = $amount;
        $payment->refund_reason = $reason;
        $payment->refunded_at = date('Y-m-d H:i:s');
        $payment->save();

        $this->logger->info("Marked ZarinPal payment {$payment->id} as refunded. Manual refund required!");

        return [
            'success' => true,
            'message' => 'درخواست استرداد ثبت شد. نیاز به استرداد دستی از طریق پنل زرین‌پال.',
            'refund_id' => 'manual-' . time(),
            'status' => 'manual_refund_required',
            'amount' => $amount,
            'note' => 'ZarinPal requires manual refund process through their dashboard'
        ];
    }

    /**
     * Create a subscription with ZarinPal
     * Note: ZarinPal has limited subscription support, this is a simplified implementation
     *
     * @param User $user User model
     * @param string $planId Subscription plan ID
     * @param array $paymentData Payment data
     * @param array $metadata Additional metadata
     * @return array Subscription result
     */
    private function createZarinpalSubscription($user, $planId, $paymentData, $metadata = [])
    {
        // Get plan details
        $plan = $this->getPlanDetails($planId);

        if (!$plan) {
            return [
                'success' => false,
                'message' => 'طرح اشتراک یافت نشد',
                'error' => 'Plan not found',
                'error_code' => 404
            ];
        }

        // For ZarinPal, we'll create a regular payment first
        $metadata['is_subscription'] = true;
        $metadata['plan_id'] = $planId;
        $metadata['plan_name'] = $plan['name'];
        $metadata['plan_interval'] = $plan['interval'];
        $metadata['plan_duration'] = $plan['duration'];

        $paymentResult = $this->processZarinpalPayment(
            $user,
            $plan['price'],
            'اشتراک ' . $plan['name'],
            $paymentData,
            $metadata
        );

        // If payment initialized successfully, create a subscription record
        if ($paymentResult['success']) {
            // Create subscription record in pending state
            $subscription = new Subscription();
            $subscription->user_id = $user->id;
            $subscription->gateway = self::GATEWAY_ZARINPAL;
            $subscription->gateway_subscription_id = 'zp_sub_' . $paymentResult['payment_id'];
            $subscription->gateway_customer_id = null; // ZarinPal doesn't use customer IDs
            $subscription->plan_id = $planId;
            $subscription->status = 'pending';
            $subscription->amount = $plan['price'];
            $subscription->currency = $this->config['zarinpal_currency'];
            $subscription->interval = $plan['interval'];
            $subscription->created_at = date('Y-m-d H:i:s');

            // Calculate period end date based on interval
            $endDate = new \DateTime();
            switch ($plan['interval']) {
                case 'month':
                    $endDate->modify('+1 month');
                    break;
                case 'year':
                    $endDate->modify('+1 year');
                    break;
                default:
                    $endDate->modify('+30 days');
            }

            $subscription->current_period_start = date('Y-m-d H:i:s');
            $subscription->current_period_end = $endDate->format('Y-m-d H:i:s');
            $subscription->save();

            return [
                'success' => true,
                'gateway' => self::GATEWAY_ZARINPAL,
                'subscription_id' => $subscription->gateway_subscription_id,
                'redirect_url' => $paymentResult['redirect_url'],
                'status' => 'pending',
                'message' => 'لطفاً پرداخت را تکمیل کنید'
            ];
        }

        return $paymentResult;
    }

    /**
     * Process ZarinPal webhook
     * Note: ZarinPal doesn't have a webhook system, so this is a placeholder
     */
    private function processZarinpalWebhook($payload, $headers)
    {
        // ZarinPal doesn't have webhooks, so this is a placeholder
        $this->logger->info('ZarinPal webhook called, but ZarinPal does not support webhooks');
        return true;
    }

    /**
     * Cancel a ZarinPal subscription
     * Note: ZarinPal doesn't have built-in subscription management
     */
    private function cancelZarinpalSubscription($subscription, $atPeriodEnd = true)
    {
        // This is a simplified implementation since ZarinPal doesn't have built-in subscription management

        if ($atPeriodEnd) {
            $subscription->status = 'active';
            $subscription->cancel_at_period_end = true;
        } else {
            $subscription->status = 'cancelled';
            $subscription->ended_at = date('Y-m-d H:i:s');
        }

        $subscription->save();

        return [
            'success' => true,
            'message' => $atPeriodEnd ? 'اشتراک در پایان دوره لغو خواهد شد' : 'اشتراک با موفقیت لغو شد',
            'subscription_id' => $subscription->gateway_subscription_id
        ];
    }

    /**
     * Get details of a subscription plan
     *
     * @param string $planId Plan ID
     * @return array|null Plan details or null if not found
     */
    private function getPlanDetails($planId)
    {
        // In a real application, this would fetch from database or config
        $plans = [
            'basic_monthly' => [
                'id' => 'basic_monthly',
                'name' => 'اشتراک پایه ماهانه',
                'price' => 99000, // تومان
                'interval' => 'month',
                'duration' => 1
            ],
            'basic_yearly' => [
                'id' => 'basic_yearly',
                'name' => 'اشتراک پایه سالانه',
                'price' => 990000, // تومان
                'interval' => 'year',
                'duration' => 1
            ],
            'pro_monthly' => [
                'id' => 'pro_monthly',
                'name' => 'اشتراک حرفه‌ای ماهانه',
                'price' => 299000, // تومان
                'interval' => 'month',
                'duration' => 1
            ],
            'pro_yearly' => [
                'id' => 'pro_yearly',
                'name' => 'اشتراک حرفه‌ای سالانه',
                'price' => 2990000, // تومان
                'interval' => 'year',
                'duration' => 1
            ],
        ];

        return isset($plans[$planId]) ? $plans[$planId] : null;
    }

    private function handleFailedPayment($paymentIntent)
    {
        // Handle failed payment logic
    }

    private function handleSubscriptionCancellation($subscription)
    {
        // Handle subscription cancellation logic
    }

    private function handleSuccessfulInvoicePayment($invoice)
    {
        // Handle successful invoice payment logic
    }

    private function handleFailedInvoicePayment($invoice)
    {
        // Handle failed invoice payment logic
    }
}