<?php
/**
 * Instagram API Integration
 *
 * This file handles all communication with the Instagram Graph API
 * Supports data collection for posts, stories, comments, and metrics
 *
 * @author Social Monitor Development Team
 * @version 1.4.2
 * @copyright Social Monitor Inc.
 */

namespace Api;

use Core\Helper;
use Core\Config;
use Core\Logger;
use Models\SocialAccount;
use Models\Post;
use Models\Comment;
use Models\Insight;

class Instagram
{
    /**
     * Instagram Graph API base URL
     */
    const API_BASE_URL = 'https://graph.instagram.com/';

    /**
     * Instagram Graph API version
     */
    const API_VERSION = 'v17.0';

    /**
     * Default fields to fetch for a post
     */
    const DEFAULT_POST_FIELDS = 'id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username,children{id,media_type,media_url,thumbnail_url}';

    /**
     * Default fields to fetch for user data
     */
    const DEFAULT_USER_FIELDS = 'id,username,name,biography,profile_picture_url,website,is_verified,follows_count,followers_count,media_count';

    /**
     * Default fields to fetch for comment data
     */
    const DEFAULT_COMMENT_FIELDS = 'id,text,timestamp,username,like_count,replies';

    /**
     * Default metrics to track
     */
    const DEFAULT_METRICS = 'impressions,reach,engagement,saved,video_views';

    /**
     * Account access token
     */
    private $accessToken;

    /**
     * Instagram business account ID
     */
    private $accountId;

    /**
     * Logger instance
     */
    private $logger;

    /**
     * Constructor
     *
     * @param string $accessToken Instagram API access token
     * @param string $accountId Instagram business account ID
     */
    public function __construct($accessToken = null, $accountId = null)
    {
        $this->logger = Logger::getInstance();

        if ($accessToken) {
            $this->accessToken = $accessToken;
        } else {
            $this->accessToken = Config::get('instagram.default_access_token');
        }

        if ($accountId) {
            $this->accountId = $accountId;
        } else {
            $this->accountId = Config::get('instagram.default_account_id');
        }
    }

    /**
     * Set access token for API requests
     *
     * @param string $accessToken
     * @return $this
     */
    public function setAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;
        return $this;
    }

    /**
     * Set Instagram business account ID
     *
     * @param string $accountId
     * @return $this
     */
    public function setAccountId($accountId)
    {
        $this->accountId = $accountId;
        return $this;
    }

    /**
     * Get account profile information
     *
     * @param string $fields Fields to fetch
     * @return array|null Profile data or null on failure
     */
    public function getProfile($fields = null)
    {
        if (!$fields) {
            $fields = self::DEFAULT_USER_FIELDS;
        }

        $endpoint = $this->accountId;
        $params = [
            'fields' => $fields,
            'access_token' => $this->accessToken
        ];

        return $this->apiRequest($endpoint, $params);
    }

    /**
     * Get recent media posts from Instagram account
     *
     * @param int $limit Number of posts to retrieve
     * @param string $fields Fields to fetch for each post
     * @return array Posts data
     */
    public function getPosts($limit = 25, $fields = null)
    {
        if (!$fields) {
            $fields = self::DEFAULT_POST_FIELDS;
        }

        $endpoint = $this->accountId . '/media';
        $params = [
            'fields' => $fields,
            'limit' => $limit,
            'access_token' => $this->accessToken
        ];

        $response = $this->apiRequest($endpoint, $params);

        if (isset($response['data'])) {
            return $response['data'];
        }

        return [];
    }

    /**
     * Get detailed information about a specific post
     *
     * @param string $mediaId Instagram media ID
     * @param string $fields Fields to fetch
     * @return array|null Post data or null on failure
     */
    public function getPostDetails($mediaId, $fields = null)
    {
        if (!$fields) {
            $fields = self::DEFAULT_POST_FIELDS;
        }

        $endpoint = $mediaId;
        $params = [
            'fields' => $fields,
            'access_token' => $this->accessToken
        ];

        return $this->apiRequest($endpoint, $params);
    }

    /**
     * Get comments for a specific post
     *
     * @param string $mediaId Instagram media ID
     * @param int $limit Number of comments to retrieve
     * @param string $fields Fields to fetch for each comment
     * @return array Comments data
     */
    public function getComments($mediaId, $limit = 50, $fields = null)
    {
        if (!$fields) {
            $fields = self::DEFAULT_COMMENT_FIELDS;
        }

        $endpoint = $mediaId . '/comments';
        $params = [
            'fields' => $fields,
            'limit' => $limit,
            'access_token' => $this->accessToken
        ];

        $response = $this->apiRequest($endpoint, $params);

        if (isset($response['data'])) {
            return $response['data'];
        }

        return [];
    }

    /**
     * Get insights for a specific post
     *
     * @param string $mediaId Instagram media ID
     * @param string $metrics Comma-separated metrics to fetch
     * @return array Insights data
     */
    public function getPostInsights($mediaId, $metrics = null)
    {
        if (!$metrics) {
            $metrics = self::DEFAULT_METRICS;
        }

        $endpoint = $mediaId . '/insights';
        $params = [
            'metric' => $metrics,
            'access_token' => $this->accessToken
        ];

        $response = $this->apiRequest($endpoint, $params);

        if (isset($response['data'])) {
            return $response['data'];
        }

        return [];
    }

    /**
     * Get account-level insights over a specific time period
     *
     * @param string $period Time period (day, week, month)
     * @param string $metrics Metrics to fetch
     * @param int $days Number of days of data to fetch
     * @return array Insights data
     */
    public function getAccountInsights($period = 'day', $metrics = null, $days = 30)
    {
        if (!$metrics) {
            $metrics = 'impressions,reach,profile_views,follower_count';
        }

        $endpoint = $this->accountId . '/insights';
        $params = [
            'metric' => $metrics,
            'period' => $period,
            'access_token' => $this->accessToken
        ];

        $response = $this->apiRequest($endpoint, $params);

        if (isset($response['data'])) {
            return $response['data'];
        }

        return [];
    }

    /**
     * Search for media by hashtag
     *
     * @param string $hashtag Hashtag to search (without the # symbol)
     * @param int $limit Number of posts to retrieve
     * @return array Posts containing the hashtag
     */
    public function searchHashtag($hashtag, $limit = 25)
    {
        // First get the hashtag ID
        $hashtagIdEndpoint = 'ig_hashtag_search';
        $hashtagParams = [
            'q' => $hashtag,
            'access_token' => $this->accessToken
        ];

        $hashtagResponse = $this->apiRequest($hashtagIdEndpoint, $hashtagParams);

        if (!isset($hashtagResponse['data'][0]['id'])) {
            $this->logger->error('Failed to find hashtag ID for: ' . $hashtag);
            return [];
        }

        $hashtagId = $hashtagResponse['data'][0]['id'];

        // Now get recent media with this hashtag
        $mediaEndpoint = $hashtagId . '/recent_media';
        $mediaParams = [
            'fields' => self::DEFAULT_POST_FIELDS,
            'limit' => $limit,
            'access_token' => $this->accessToken
        ];

        $mediaResponse = $this->apiRequest($mediaEndpoint, $mediaParams);

        if (isset($mediaResponse['data'])) {
            return $mediaResponse['data'];
        }

        return [];
    }

    /**
     * Save post data to the database
     *
     * @param array $postData Raw post data from API
     * @return Post New Post model instance
     */
    public function savePost($postData)
    {
        $post = new Post();
        $post->platform = 'instagram';
        $post->platform_id = $postData['id'];
        $post->account_id = $this->accountId;
        $post->content = isset($postData['caption']) ? $postData['caption'] : '';
        $post->media_type = $postData['media_type'];
        $post->media_url = $postData['media_url'];
        $post->permalink = $postData['permalink'];
        $post->created_at = $postData['timestamp'];

        // Extract hashtags and mentions
        $post->hashtags = implode(',', Helper::extractHashtags($post->content));
        $post->mentions = implode(',', Helper::extractMentions($post->content));

        // Quick sentiment analysis
        $post->sentiment = Helper::quickSentimentAnalysis($post->content);

        // Save to DB
        $post->save();

        return $post;
    }

    /**
     * Refresh account data and update database
     *
     * @return SocialAccount Updated account model
     */
    public function refreshAccountData()
    {
        $profileData = $this->getProfile();

        if (!$profileData) {
            $this->logger->error('Failed to refresh Instagram account data for ID: ' . $this->accountId);
            return null;
        }

        // Find or create account in DB
        $account = SocialAccount::findByPlatformId('instagram', $this->accountId);

        if (!$account) {
            $account = new SocialAccount();
            $account->platform = 'instagram';
            $account->platform_id = $this->accountId;
        }

        // Update account data
        $account->username = $profileData['username'];
        $account->display_name = $profileData['name'];
        $account->bio = $profileData['biography'];
        $account->profile_image = $profileData['profile_picture_url'];
        $account->url = $profileData['website'];
        $account->is_verified = $profileData['is_verified'];
        $account->followers_count = $profileData['followers_count'];
        $account->following_count = $profileData['follows_count'];
        $account->posts_count = $profileData['media_count'];
        $account->last_updated = date('Y-m-d H:i:s');

        // Save to DB
        $account->save();

        return $account;
    }

    /**
     * Refresh all data for this account (profile, posts, comments, insights)
     *
     * @param int $postsLimit Number of posts to fetch
     * @return array Summary of updated data counts
     */
    public function refreshAllData($postsLimit = 50)
    {
        $summary = [
            'account_updated' => false,
            'posts_count' => 0,
            'comments_count' => 0,
            'insights_count' => 0
        ];

        // Refresh account data
        $account = $this->refreshAccountData();
        $summary['account_updated'] = ($account !== null);

        if (!$account) {
            return $summary;
        }

        // Fetch recent posts
        $posts = $this->getPosts($postsLimit);

        foreach ($posts as $postData) {
            // Save post
            $post = $this->savePost($postData);
            $summary['posts_count']++;

            // Get and save comments
            $comments = $this->getComments($postData['id']);
            foreach ($comments as $commentData) {
                $comment = new Comment();
                $comment->platform = 'instagram';
                $comment->platform_id = $commentData['id'];
                $comment->post_id = $post->id;
                $comment->content = $commentData['text'];
                $comment->author = $commentData['username'];
                $comment->created_at = $commentData['timestamp'];
                $comment->likes_count = $commentData['like_count'];
                $comment->save();

                $summary['comments_count']++;
            }

            // Get and save insights
            $insights = $this->getPostInsights($postData['id']);
            foreach ($insights as $insightData) {
                $insight = new Insight();
                $insight->platform = 'instagram';
                $insight->post_id = $post->id;
                $insight->metric = $insightData['name'];
                $insight->value = $insightData['values'][0]['value'];
                $insight->period = isset($insightData['period']) ? $insightData['period'] : 'lifetime';
                $insight->save();

                $summary['insights_count']++;
            }
        }

        return $summary;
    }

    /**
     * Make an API request to the Instagram Graph API
     *
     * @param string $endpoint API endpoint
     * @param array $params Query parameters
     * @param string $method HTTP method (GET, POST)
     * @return array|null Response data or null on failure
     */
    private function apiRequest($endpoint, $params = [], $method = 'GET')
    {
        $url = self::API_BASE_URL . self::API_VERSION . '/' . $endpoint;

        $ch = curl_init();

        if ($method === 'GET') {
            $url .= '?' . http_build_query($params);
        } else {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);

        curl_close($ch);

        if ($error) {
            $this->logger->error('Instagram API request failed: ' . $error . ' (URL: ' . $url . ')');
            return null;
        }

        if ($httpCode >= 400) {
            $this->logger->error('Instagram API request failed with HTTP code ' . $httpCode . ' (URL: ' . $url . ')');
            return null;
        }

        $data = json_decode($response, true);

        if (!$data) {
            $this->logger->error('Failed to parse Instagram API response (URL: ' . $url . ')');
            return null;
        }

        if (isset($data['error'])) {
            $this->logger->error('Instagram API error: ' . $data['error']['message'] . ' (URL: ' . $url . ')');
            return null;
        }

        return $data;
    }
}