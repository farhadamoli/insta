<?php
/**
 * Subscription Model
 *
 * Handles user subscription data and plan management
 *
 * @author Social Monitor Development Team
 * @version 1.2.0
 * @copyright Social Monitor Inc.
 */

namespace Models;

use Core\Model;
use Core\Database;
use Core\Config;

class Subscription extends Model
{
    /**
     * Table name
     */
    protected $table = 'subscriptions';

    /**
     * Primary key
     */
    protected $primaryKey = 'id';

    /**
     * Fillable fields
     */
    protected $fillable = [
        'user_id',
        'plan_id',
        'plan_name',
        'gateway',
        'gateway_subscription_id',
        'gateway_customer_id',
        'status',
        'amount',
        'currency',
        'interval',
        'interval_count',
        'trial_ends_at',
        'current_period_start',
        'current_period_end',
        'cancel_at_period_end',
        'canceled_at',
        'ended_at',
        'created_at',
        'updated_at'
    ];

    /**
     * Subscription statuses
     */
    const STATUS_ACTIVE = 'active';
    const STATUS_CANCELED = 'canceled';
    const STATUS_PAST_DUE = 'past_due';
    const STATUS_TRIALING = 'trialing';
    const STATUS_UNPAID = 'unpaid';
    const STATUS_INCOMPLETE = 'incomplete';
    const STATUS_INCOMPLETE_EXPIRED = 'incomplete_expired';

    /**
     * Plan IDs
     */
    const PLAN_FREE = 'free';
    const PLAN_STARTER = 'starter';
    const PLAN_PROFESSIONAL = 'professional';
    const PLAN_BUSINESS = 'business';

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Find subscription by user ID
     *
     * @param int $userId User ID
     * @return object|null Subscription or null if not found
     */
    public function findByUser($userId)
    {
        return $this->findOne(['user_id' => $userId]);
    }

    /**
     * Find active subscription by user ID
     *
     * @param int $userId User ID
     * @return object|null Subscription or null if not found
     */
    public function findActiveByUser($userId)
    {
        $activeStatuses = [
            self::STATUS_ACTIVE,
            self::STATUS_TRIALING,
            self::STATUS_PAST_DUE
        ];

        $sql = "SELECT * FROM {$this->table} 
                WHERE user_id = :user_id 
                AND status IN (" . implode(',', array_map(function($status) {
                return "'" . $status . "'";
            }, $activeStatuses)) . ")
                ORDER BY created_at DESC 
                LIMIT 1";

        $params = [':user_id' => $userId];

        return $this->db->fetchOne($sql, $params);
    }

    /**
     * Find subscription by gateway subscription ID
     *
     * @param string $gateway Payment gateway name
     * @param string $subscriptionId Gateway subscription ID
     * @return object|null Subscription or null if not found
     */
    public function findByGatewaySubscriptionId($gateway, $subscriptionId)
    {
        return $this->findOne([
            'gateway' => $gateway,
            'gateway_subscription_id' => $subscriptionId
        ]);
    }

    /**
     * Find subscriptions by plan ID
     *
     * @param string $planId Plan ID
     * @param array $conditions Additional conditions
     * @param string $orderBy Order by clause
     * @return array Subscriptions
     */
    public function findByPlan($planId, $conditions = [], $orderBy = 'created_at DESC')
    {
        $conditions['plan_id'] = $planId;
        return $this->findAll($conditions, $orderBy);
    }

    /**
     * Count subscriptions by plan ID
     *
     * @param string $planId Plan ID
     * @param array $conditions Additional conditions
     * @return int Count
     */
    public function countByPlan($planId, $conditions = [])
    {
        $conditions['plan_id'] = $planId;
        return $this->count($conditions);
    }

    /**
     * Create a new subscription
     *
     * @param array $data Subscription data
     * @return int|false Subscription ID or false on failure
     */
    public function create($data)
    {
        // Validate required fields
        if (empty($data['user_id']) || empty($data['plan_id'])) {
            return false;
        }

        // Set plan name if not provided
        if (empty($data['plan_name']) && !empty($data['plan_id'])) {
            $plans = $this->getAvailablePlans();
            $data['plan_name'] = isset($plans[$data['plan_id']]['name']) ? $plans[$data['plan_id']]['name'] : $data['plan_id'];
        }

        // Set default status if not specified
        if (!isset($data['status'])) {
            $data['status'] = self::STATUS_ACTIVE;
        }

        // Set timestamps
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');

        // Check for existing active subscription
        $existingSubscription = $this->findActiveByUser($data['user_id']);

        if ($existingSubscription) {
            // Cancel existing subscription
            $this->cancel($existingSubscription->id);
        }

        // Create subscription
        return $this->insert($data);
    }

    /**
     * Update subscription
     *
     * @param int $id Subscription ID
     * @param array $data Subscription data
     * @return bool Success flag
     */
    public function update($id, $data)
    {
        // Set updated timestamp
        $data['updated_at'] = date('Y-m-d H:i:s');

        // Update subscription
        return $this->updateById($id, $data);
    }

    /**
     * Cancel subscription
     *
     * @param int $id Subscription ID
     * @param bool $immediate Cancel immediately or at end of period
     * @return bool Success flag
     */
    public function cancel($id, $immediate = false)
    {
        $subscription = $this->findById($id);

        if (!$subscription) {
            return false;
        }

        $data = [
            'canceled_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($immediate) {
            $data['status'] = self::STATUS_CANCELED;
            $data['ended_at'] = date('Y-m-d H:i:s');
        } else {
            $data['cancel_at_period_end'] = 1;
        }

        return $this->updateById($id, $data);
    }

    /**
     * Reactivate canceled subscription
     *
     * @param int $id Subscription ID
     * @return bool Success flag
     */
    public function reactivate($id)
    {
        $subscription = $this->findById($id);

        if (!$subscription || $subscription->ended_at !== null) {
            return false;
        }

        $data = [
            'status' => self::STATUS_ACTIVE,
            'cancel_at_period_end' => 0,
            'canceled_at' => null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->updateById($id, $data);
    }

    /**
     * Change subscription plan
     *
     * @param int $id Subscription ID
     * @param string $planId New plan ID
     * @param array $additionalData Additional data to update
     * @return bool Success flag
     */
    public function changePlan($id, $planId, $additionalData = [])
    {
        $subscription = $this->findById($id);

        if (!$subscription) {
            return false;
        }

        // Get plan details
        $plans = $this->getAvailablePlans();
        $planName = isset($plans[$planId]['name']) ? $plans[$planId]['name'] : $planId;

        $data = array_merge([
            'plan_id' => $planId,
            'plan_name' => $planName,
            'updated_at' => date('Y-m-d H:i:s')
        ], $additionalData);

        return $this->updateById($id, $data);
    }

    /**
     * Check if subscription is active
     *
     * @param object $subscription Subscription object
     * @return bool Is active flag
     */
    public function isActive($subscription)
    {
        if (!$subscription) {
            return false;
        }

        $activeStatuses = [
            self::STATUS_ACTIVE,
            self::STATUS_TRIALING,
            self::STATUS_PAST_DUE
        ];

        return in_array($subscription->status, $activeStatuses);
    }

    /**
     * Check if subscription is canceled
     *
     * @param object $subscription Subscription object
     * @return bool Is canceled flag
     */
    public function isCanceled($subscription)
    {
        if (!$subscription) {
            return false;
        }

        return $subscription->status === self::STATUS_CANCELED || $subscription->cancel_at_period_end == 1;
    }

    /**
     * Check if subscription is on trial
     *
     * @param object $subscription Subscription object
     * @return bool Is on trial flag
     */
    public function isOnTrial($subscription)
    {
        if (!$subscription) {
            return false;
        }

        return $subscription->status === self::STATUS_TRIALING ||
            ($subscription->trial_ends_at !== null && strtotime($subscription->trial_ends_at) > time());
    }

    /**
     * Get available subscription plans
     *
     * @return array Plans
     */
    public function getAvailablePlans()
    {
        // In a real implementation, this might come from a database or API
        // Here we're using a static array for demonstration

        return [
            self::PLAN_FREE => [
                'id' => self::PLAN_FREE,
                'name' => 'Free',
                'description' => 'Basic features for individuals getting started',
                'price_monthly' => 0,
                'price_yearly' => 0,
                'currency' => 'USD',
                'interval' => 'month',
                'features' => [
                    'accounts_limit' => 2,
                    'posts_per_month' => 50,
                    'scheduled_posts' => 10,
                    'analytics_basic' => true,
                    'content_basic' => true,
                    'scheduling_basic' => true
                ]
            ],
            self::PLAN_STARTER => [
                'id' => self::PLAN_STARTER,
                'name' => 'Starter',
                'description' => 'Essential features for growing your social presence',
                'price_monthly' => 29,
                'price_yearly' => 290, // ~$24/month with annual billing
                'currency' => 'USD',
                'interval' => 'month',
                'features' => [
                    'accounts_limit' => 5,
                    'posts_per_month' => 200,
                    'scheduled_posts' => 100,
                    'analytics_basic' => true,
                    'analytics_advanced' => false,
                    'content_basic' => true,
                    'scheduling_basic' => true,
                    'ai_content' => true,
                    'ai_credits' => 50
                ]
            ],
            self::PLAN_PROFESSIONAL => [
                'id' => self::PLAN_PROFESSIONAL,
                'name' => 'Professional',
                'description' => 'Advanced features for social media professionals',
                'price_monthly' => 79,
                'price_yearly' => 790, // ~$66/month with annual billing
                'currency' => 'USD',
                'interval' => 'month',
                'features' => [
                    'accounts_limit' => 15,
                    'posts_per_month' => 500,
                    'scheduled_posts' => 250,
                    'analytics_basic' => true,
                    'analytics_advanced' => true,
                    'content_basic' => true,
                    'scheduling_basic' => true,
                    'scheduling_advanced' => true,
                    'ai_content' => true,
                    'ai_credits' => 200,
                    'campaigns' => true,
                    'seo_tools' => true,
                    'website_builder' => true,
                    'team_members' => 3
                ]
            ],
            self::PLAN_BUSINESS => [
                'id' => self::PLAN_BUSINESS,
                'name' => 'Business',
                'description' => 'Complete solution for agencies and businesses',
                'price_monthly' => 199,
                'price_yearly' => 1990, // ~$166/month with annual billing
                'currency' => 'USD',
                'interval' => 'month',
                'features' => [
                    'accounts_limit' => 'unlimited',
                    'posts_per_month' => 'unlimited',
                    'scheduled_posts' => 'unlimited',
                    'analytics_basic' => true,
                    'analytics_advanced' => true,
                    'analytics_custom' => true,
                    'content_basic' => true,
                    'scheduling_basic' => true,
                    'scheduling_advanced' => true,
                    'ai_content' => true,
                    'ai_credits' => 'unlimited',
                    'campaigns' => true,
                    'seo_tools' => true,
                    'website_builder' => true,
                    'crm' => true,
                    'team_members' => 10,
                    'white_label' => true,
                    'priority_support' => true
                ]
            ]
        ];
    }

    /**
     * Get subscription plan details
     *
     * @param string $planId Plan ID
     * @return array|null Plan details or null if not found
     */
    public function getPlanDetails($planId)
    {
        $plans = $this->getAvailablePlans();

        return isset($plans[$planId]) ? $plans[$planId] : null;
    }

    /**
     * Get plan features
     *
     * @param string $planId Plan ID
     * @return array Features
     */
    public function getPlanFeatures($planId)
    {
        $plan = $this->getPlanDetails($planId);

        if (!$plan) {
            return [];
        }

        // Convert features array to feature keys
        $features = [];

        foreach ($plan['features'] as $key => $value) {
            if ($value === true) {
                $features[] = $key;
            } elseif ($value !== false && $value !== 0) {
                $features[] = $key;
            }
        }

        return $features;
    }

    /**
     * Get feature limit for a plan
     *
     * @param string $planId Plan ID
     * @param string $feature Feature key
     * @return mixed Feature limit or null if not found
     */
    public function getFeatureLimit($planId, $feature)
    {
        $plan = $this->getPlanDetails($planId);

        if (!$plan || !isset($plan['features'][$feature])) {
            return null;
        }

        return $plan['features'][$feature];
    }

    /**
     * Get remaining trial days
     *
     * @param object $subscription Subscription object
     * @return int Remaining days (0 if not on trial)
     */
    public function getRemainingTrialDays($subscription)
    {
        if (!$this->isOnTrial($subscription)) {
            return 0;
        }

        $trialEnd = strtotime($subscription->trial_ends_at);
        $now = time();

        if ($trialEnd <= $now) {
            return 0;
        }

        return ceil(($trialEnd - $now) / 86400); // 86400 seconds in a day
    }

    /**
     * Get subscription expiration date
     *
     * @param object $subscription Subscription object
     * @return string|null Expiration date (Y-m-d H:i:s) or null if not applicable
     */
    public function getExpirationDate($subscription)
    {
        if (!$subscription) {
            return null;
        }

        if ($subscription->status === self::STATUS_CANCELED && $subscription->ended_at) {
            return $subscription->ended_at;
        }

        if ($subscription->cancel_at_period_end) {
            return $subscription->current_period_end;
        }

        return null;
    }

    /**
     * Get subscription renewal date
     *
     * @param object $subscription Subscription object
     * @return string|null Renewal date (Y-m-d H:i:s) or null if not applicable
     */
    public function getRenewalDate($subscription)
    {
        if (!$subscription || !$this->isActive($subscription) || $subscription->cancel_at_period_end) {
            return null;
        }

        return $subscription->current_period_end;
    }

    /**
     * Get subscription status text
     *
     * @param object $subscription Subscription object
     * @return string Status text
     */
    public function getStatusText($subscription)
    {
        if (!$subscription) {
            return 'No subscription';
        }

        $statusMap = [
            self::STATUS_ACTIVE => 'Active',
            self::STATUS_CANCELED => 'Canceled',
            self::STATUS_PAST_DUE => 'Past Due',
            self::STATUS_TRIALING => 'Trial',
            self::STATUS_UNPAID => 'Unpaid',
            self::STATUS_INCOMPLETE => 'Incomplete',
            self::STATUS_INCOMPLETE_EXPIRED => 'Expired'
        ];

        $status = isset($statusMap[$subscription->status]) ? $statusMap[$subscription->status] : $subscription->status;

        if ($subscription->cancel_at_period_end) {
            $status .= ' (Cancels on ' . date('M j, Y', strtotime($subscription->current_period_end)) . ')';
        }

        return $status;
    }

    /**
     * Check if user exceeds plan limits
     *
     * @param int $userId User ID
     * @param string $feature Feature to check
     * @param int $additionalCount Additional count to add
     * @return bool Exceeds limit flag
     */
    public function exceedsPlanLimits($userId, $feature, $additionalCount = 1)
    {
        $subscription = $this->findActiveByUser($userId);

        if (!$subscription) {
            // Use free plan limits
            $planId = self::PLAN_FREE;
        } else {
            $planId = $subscription->plan_id;
        }

        $limit = $this->getFeatureLimit($planId, $feature);

        // Unlimited
        if ($limit === 'unlimited' || $limit === null) {
            return false;
        }

        // Get current usage
        $currentUsage = $this->getFeatureUsage($userId, $feature);

        // Check if adding additional count exceeds limit
        return ($currentUsage + $additionalCount) > $limit;
    }

    /**
     * Get feature usage
     *
     * @param int $userId User ID
     * @param string $feature Feature to check
     * @return int Current usage
     */
    private function getFeatureUsage($userId, $feature)
    {
        // In a real implementation, this would query the relevant tables
        // Here we're using placeholder logic for demonstration

        switch ($feature) {
            case 'accounts_limit':
                // Count user's social accounts
                $accountModel = new \Models\SocialAccount();
                return $accountModel->countByUser($userId);

            case 'posts_per_month':
                // Count posts created this month
                $postModel = new \Models\Post();
                $startDate = date('Y-m-01 00:00:00'); // First day of current month
                $endDate = date('Y-m-t 23:59:59'); // Last day of current month
                return $postModel->countByUserAndDateRange($userId, $startDate, $endDate);

            case 'scheduled_posts':
                // Count currently scheduled posts
                $scheduledPostModel = new \Models\ScheduledPost();
                return $scheduledPostModel->countPendingByUser($userId);

            case 'team_members':
                // Count team members
                $teamMemberModel = new \Models\TeamMember();
                return $teamMemberModel->countByTeamOwner($userId);

            case 'ai_credits':
                // Get AI credits used this month
                $aiCreditModel = new \Models\AiCredit();
                $startDate = date('Y-m-01 00:00:00'); // First day of current month
                $endDate = date('Y-m-t 23:59:59'); // Last day of current month
                return $aiCreditModel->getUsedCredits($userId, $startDate, $endDate);

            default:
                return 0;
        }
    }

    /**
     * Get subscription usage percentages
     *
     * @param int $userId User ID
     * @return array Usage percentages
     */
    public function getUsagePercentages($userId)
    {
        $subscription = $this->findActiveByUser($userId);

        if (!$subscription) {
            // Use free plan limits
            $planId = self::PLAN_FREE;
        } else {
            $planId = $subscription->plan_id;
        }

        $features = [
            'accounts_limit',
            'posts_per_month',
            'scheduled_posts',
            'ai_credits'
        ];

        $usage = [];

        foreach ($features as $feature) {
            $limit = $this->getFeatureLimit($planId, $feature);
            $currentUsage = $this->getFeatureUsage($userId, $feature);

            // Calculate percentage
            if ($limit === 'unlimited' || $limit === null) {
                $percentage = 0;
            } elseif ($limit == 0) {
                $percentage = 100;
            } else {
                $percentage = min(100, round(($currentUsage / $limit) * 100));
            }

            $usage[$feature] = [
                'limit' => $limit,
                'used' => $currentUsage,
                'percentage' => $percentage
            ];
        }

        return $usage;
    }
}