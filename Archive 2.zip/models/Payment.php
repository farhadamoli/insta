<?php

/**
 * Payment Model
 *
 * این کلاس برای مدیریت پرداخت‌ها و تراکنش‌های مالی در سیستم استفاده می‌شود
 * به طور پیش‌فرض از درگاه پرداخت زرین‌پال استفاده می‌کند
 */

namespace App\Models;

use PDO;
use App\Core\Database;
use App\Models\User;
use App\Models\Subscription;
use Exception;

class Payment {
    private $db;
    private $table = 'payments';

    // تنظیمات زرین‌پال
    private $zarinpalMerchantID = 'YOUR_ZARINPAL_MERCHANT_ID';
    private $zarinpalCallbackURL = 'https://edameye.com/api/payment/verify';
    private $zarinpalApiUrl = 'https://api.zarinpal.com/pg/v4/payment/request.json';
    private $zarinpalVerifyUrl = 'https://api.zarinpal.com/pg/v4/payment/verify.json';

    // وضعیت‌های پرداخت
    const STATUS_PENDING = 'pending';
    const STATUS_COMPLETED = 'completed';
    const STATUS_FAILED = 'failed';
    const STATUS_REFUNDED = 'refunded';

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * ایجاد تراکنش جدید
     *
     * @param int $user_id شناسه کاربر
     * @param int $subscription_id شناسه اشتراک (اختیاری)
     * @param float $amount مبلغ پرداخت (به تومان)
     * @param string $description توضیحات پرداخت
     * @return int|false شناسه پرداخت یا false در صورت خطا
     */
    public function createPayment($user_id, $subscription_id = null, $amount, $description) {
        try {
            $sql = "INSERT INTO {$this->table} (user_id, subscription_id, amount, description, status, created_at) 
                    VALUES (:user_id, :subscription_id, :amount, :description, :status, NOW())";

            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':subscription_id', $subscription_id, PDO::PARAM_INT);
            $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
            $stmt->bindParam(':description', $description, PDO::PARAM_STR);
            $status = self::STATUS_PENDING;
            $stmt->bindParam(':status', $status, PDO::PARAM_STR);

            $stmt->execute();

            return $this->db->lastInsertId();
        } catch (Exception $e) {
            error_log("Error creating payment: " . $e->getMessage());
            return false;
        }
    }

    /**
     * دریافت اطلاعات پرداخت با شناسه
     *
     * @param int $payment_id شناسه پرداخت
     * @return array|false اطلاعات پرداخت یا false در صورت خطا
     */
    public function getPaymentById($payment_id) {
        try {
            $sql = "SELECT * FROM {$this->table} WHERE id = :payment_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':payment_id', $payment_id, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting payment: " . $e->getMessage());
            return false;
        }
    }

    /**
     * به‌روزرسانی وضعیت پرداخت
     *
     * @param int $payment_id شناسه پرداخت
     * @param string $status وضعیت جدید
     * @param string $transaction_id شناسه تراکنش دریافتی از درگاه پرداخت
     * @return bool موفقیت یا عدم موفقیت به‌روزرسانی
     */
    public function updatePaymentStatus($payment_id, $status, $transaction_id = null) {
        try {
            $sql = "UPDATE {$this->table} SET status = :status, transaction_id = :transaction_id, updated_at = NOW() 
                    WHERE id = :payment_id";

            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':payment_id', $payment_id, PDO::PARAM_INT);
            $stmt->bindParam(':status', $status, PDO::PARAM_STR);
            $stmt->bindParam(':transaction_id', $transaction_id, PDO::PARAM_STR);

            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error updating payment status: " . $e->getMessage());
            return false;
        }
    }

    /**
     * لیست پرداخت‌های کاربر
     *
     * @param int $user_id شناسه کاربر
     * @param int $limit محدودیت تعداد نتایج
     * @param int $offset شروع از
     * @return array لیست پرداخت‌ها
     */
    public function getUserPayments($user_id, $limit = 20, $offset = 0) {
        try {
            $sql = "SELECT * FROM {$this->table} WHERE user_id = :user_id ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting user payments: " . $e->getMessage());
            return [];
        }
    }

    /**
     * شروع فرآیند پرداخت با زرین‌پال
     *
     * @param int $payment_id شناسه پرداخت در سیستم
     * @return array|false نتیجه درخواست یا false در صورت خطا
     */
    public function startZarinpalPayment($payment_id) {
        $payment = $this->getPaymentById($payment_id);

        if (!$payment) {
            return false;
        }

        // تبدیل تومان به ریال برای زرین‌پال
        $amount = $payment['amount'] * 10;

        $data = array(
            'merchant_id' => $this->zarinpalMerchantID,
            'amount' => $amount,
            'callback_url' => $this->zarinpalCallbackURL . '?payment_id=' . $payment_id,
            'description' => $payment['description'],
            'metadata' => [
                'payment_id' => $payment_id,
                'user_id' => $payment['user_id']
            ]
        );

        $jsonData = json_encode($data);

        $ch = curl_init($this->zarinpalApiUrl);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Edameye Payment System');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ));

        $result = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($result, true);

        if (isset($result['data']['code']) && $result['data']['code'] == 100) {
            // ذخیره‌سازی شناسه‌ی درخواست برای استفاده در مرحله‌ی تأیید
            $this->updatePaymentStatus($payment_id, self::STATUS_PENDING, $result['data']['authority']);

            return [
                'success' => true,
                'authority' => $result['data']['authority'],
                'payment_url' => 'https://www.zarinpal.com/pg/StartPay/' . $result['data']['authority']
            ];
        } else {
            // ثبت خطا
            $error_code = isset($result['errors']['code']) ? $result['errors']['code'] : 'unknown';
            $error_message = isset($result['errors']['message']) ? $result['errors']['message'] : 'Unknown error';
            error_log("Zarinpal payment initiation failed - Code: {$error_code}, Message: {$error_message}");

            return [
                'success' => false,
                'error_code' => $error_code,
                'error_message' => $error_message
            ];
        }
    }

    /**
     * تأیید پرداخت زرین‌پال
     *
     * @param int $payment_id شناسه پرداخت در سیستم
     * @param string $authority کد اختصاصی پرداخت از زرین‌پال
     * @param int $status کد وضعیت از زرین‌پال
     * @return array نتیجه تأیید
     */
    public function verifyZarinpalPayment($payment_id, $authority, $status) {
        $payment = $this->getPaymentById($payment_id);

        if (!$payment) {
            return [
                'success' => false,
                'message' => 'پرداخت یافت نشد'
            ];
        }

        // اگر وضعیت OK (کد 1) نباشد، پرداخت ناموفق بوده است
        if ($status != 'OK') {
            $this->updatePaymentStatus($payment_id, self::STATUS_FAILED);
            return [
                'success' => false,
                'message' => 'پرداخت توسط کاربر لغو شد'
            ];
        }

        // تبدیل تومان به ریال برای زرین‌پال
        $amount = $payment['amount'] * 10;

        $data = array(
            'merchant_id' => $this->zarinpalMerchantID,
            'authority' => $authority,
            'amount' => $amount
        );

        $jsonData = json_encode($data);

        $ch = curl_init($this->zarinpalVerifyUrl);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Edameye Payment System');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ));

        $result = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($result, true);

        if (isset($result['data']['code']) && $result['data']['code'] == 100) {
            // پرداخت موفق بوده است
            $reference_id = $result['data']['ref_id'];
            $this->updatePaymentStatus($payment_id, self::STATUS_COMPLETED, $reference_id);

            // اگر این پرداخت مربوط به اشتراک باشد، اشتراک کاربر را فعال می‌کنیم
            if ($payment['subscription_id']) {
                $subscription = new Subscription();
                $subscription->activateUserSubscription($payment['user_id'], $payment['subscription_id']);
            }

            return [
                'success' => true,
                'ref_id' => $reference_id,
                'message' => 'پرداخت با موفقیت انجام شد'
            ];
        } else {
            // پرداخت ناموفق بوده است
            $error_code = isset($result['errors']['code']) ? $result['errors']['code'] : 'unknown';
            $error_message = isset($result['errors']['message']) ? $result['errors']['message'] : 'خطای نامشخص';

            $this->updatePaymentStatus($payment_id, self::STATUS_FAILED);

            error_log("Zarinpal payment verification failed - Code: {$error_code}, Message: {$error_message}");

            return [
                'success' => false,
                'error_code' => $error_code,
                'error_message' => $error_message,
                'message' => 'خطا در تایید پرداخت'
            ];
        }
    }

    /**
     * استرداد وجه پرداخت
     *
     * @param int $payment_id شناسه پرداخت
     * @param string $reason دلیل استرداد
     * @return bool موفقیت یا عدم موفقیت استرداد
     */
    public function refundPayment($payment_id, $reason = '') {
        $payment = $this->getPaymentById($payment_id);

        if (!$payment || $payment['status'] != self::STATUS_COMPLETED) {
            return false;
        }

        // اینجا کد مربوط به استرداد وجه از طریق API زرین‌پال قرار می‌گیرد
        // در حال حاضر زرین‌پال API رسمی برای استرداد وجه ندارد و باید از پنل مدیریتی استفاده کرد

        try {
            $sql = "UPDATE {$this->table} SET status = :status, refund_reason = :reason, refunded_at = NOW() 
                    WHERE id = :payment_id";

            $stmt = $this->db->prepare($sql);
            $status = self::STATUS_REFUNDED;
            $stmt->bindParam(':status', $status, PDO::PARAM_STR);
            $stmt->bindParam(':reason', $reason, PDO::PARAM_STR);
            $stmt->bindParam(':payment_id', $payment_id, PDO::PARAM_INT);

            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error refunding payment: " . $e->getMessage());
            return false;
        }
    }

    /**
     * دریافت آمار پرداخت‌ها
     *
     * @param string $period دوره زمانی (daily, weekly, monthly, yearly)
     * @return array آمار پرداخت‌ها
     */
    public function getPaymentStats($period = 'monthly') {
        try {
            $sql = "";

            switch ($period) {
                case 'daily':
                    $sql = "SELECT 
                            DATE(created_at) as date,
                            COUNT(*) as total_count,
                            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                            SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_amount
                        FROM {$this->table}
                        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                        GROUP BY DATE(created_at)
                        ORDER BY date DESC";
                    break;

                case 'weekly':
                    $sql = "SELECT 
                            YEARWEEK(created_at) as yearweek,
                            COUNT(*) as total_count,
                            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                            SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_amount
                        FROM {$this->table}
                        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 26 WEEK)
                        GROUP BY YEARWEEK(created_at)
                        ORDER BY yearweek DESC";
                    break;

                case 'monthly':
                default:
                    $sql = "SELECT 
                            DATE_FORMAT(created_at, '%Y-%m') as month,
                            COUNT(*) as total_count,
                            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                            SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_amount
                        FROM {$this->table}
                        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                        ORDER BY month DESC";
                    break;

                case 'yearly':
                    $sql = "SELECT 
                            YEAR(created_at) as year,
                            COUNT(*) as total_count,
                            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                            SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_amount
                        FROM {$this->table}
                        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 5 YEAR)
                        GROUP BY YEAR(created_at)
                        ORDER BY year DESC";
                    break;
            }

            $stmt = $this->db->prepare($sql);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting payment stats: " . $e->getMessage());
            return [];
        }
    }

    /**
     * SQL برای ایجاد جدول در دیتابیس
     *
     * @return string دستور SQL
     */
    public static function getTableSchema() {
        return "CREATE TABLE IF NOT EXISTS payments (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT(11) UNSIGNED NOT NULL,
            subscription_id INT(11) UNSIGNED DEFAULT NULL,
            amount DECIMAL(10,2) NOT NULL,
            description VARCHAR(255) NOT NULL,
            status ENUM('pending', 'completed', 'failed', 'refunded') NOT NULL DEFAULT 'pending',
            transaction_id VARCHAR(100) DEFAULT NULL,
            refund_reason TEXT DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME DEFAULT NULL,
            refunded_at DATETIME DEFAULT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE SET NULL,
            INDEX (user_id),
            INDEX (subscription_id),
            INDEX (status),
            INDEX (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;";
    }
}