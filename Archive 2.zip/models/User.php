<?php
/**
 * User Model
 *
 * Handles user data management and authentication
 *
 * @author Social Monitor Development Team
 * @version 1.3.1
 * @copyright Social Monitor Inc.
 */

namespace Models;

use Core\Model;
use Core\Database;
use Core\Config;
use Core\Helper;
use Core\Auth;

class User extends Model
{
    /**
     * Table name
     */
    protected $table = 'users';

    /**
     * Primary key
     */
    protected $primaryKey = 'id';

    /**
     * Fillable fields
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'role_id',
        'status',
        'email_verified',
        'email_verification_token',
        'password_reset_token',
        'password_reset_expires',
        'profile_image',
        'phone',
        'country',
        'timezone',
        'language',
        'company',
        'job_title',
        'bio',
        'website',
        'social_profiles',
        'preferences',
        'last_login',
        'last_ip',
        'login_count',
        'referral_code',
        'referred_by',
        'stripe_customer_id',
        'created_at',
        'updated_at'
    ];

    /**
     * User statuses
     */
    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_PENDING = 'pending';
    const STATUS_SUSPENDED = 'suspended';

    /**
     * User roles
     */
    const ROLE_ADMIN = 1;
    const ROLE_MANAGER = 2;
    const ROLE_USER = 3;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Find user by email
     *
     * @param string $email Email address
     * @return object|null User or null if not found
     */
    public function findByEmail($email)
    {
        return $this->findOne(['email' => $email]);
    }

    /**
     * Find user by verification token
     *
     * @param string $token Verification token
     * @return object|null User or null if not found
     */
    public function findByVerificationToken($token)
    {
        return $this->findOne(['email_verification_token' => $token]);
    }

    /**
     * Find user by password reset token
     *
     * @param string $token Password reset token
     * @return object|null User or null if not found
     */
    public function findByPasswordResetToken($token)
    {
        return $this->findOne([
            'password_reset_token' => $token,
            'password_reset_expires > ' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Find user by Stripe customer ID
     *
     * @param string $customerId Stripe customer ID
     * @return object|null User or null if not found
     */
    public function findByStripeCustomerId($customerId)
    {
        return $this->findOne(['stripe_customer_id' => $customerId]);
    }

    /**
     * Find user by referral code
     *
     * @param string $referralCode Referral code
     * @return object|null User or null if not found
     */
    public function findByReferralCode($referralCode)
    {
        return $this->findOne(['referral_code' => $referralCode]);
    }

    /**
     * Create a new user
     *
     * @param array $data User data
     * @return int|false User ID or false on failure
     */
    public function create($data)
    {
        // Validate required fields
        if (empty($data['email']) || empty($data['password'])) {
            return false;
        }

        // Check if email already exists
        if ($this->findByEmail($data['email'])) {
            return false;
        }

        // Set default role if not specified
        if (!isset($data['role_id'])) {
            $data['role_id'] = self::ROLE_USER;
        }

        // Set default status if not specified
        if (!isset($data['status'])) {
            $requireVerification = Config::get('auth.require_email_verification', true);
            $data['status'] = $requireVerification ? self::STATUS_PENDING : self::STATUS_ACTIVE;
        }

        // Set email verification status
        if (!isset($data['email_verified'])) {
            $data['email_verified'] = 0;
        }

        // Generate email verification token if needed
        if (!$data['email_verified']) {
            $data['email_verification_token'] = Helper::generateToken();
        }

        // Generate referral code
        if (!isset($data['referral_code'])) {
            $data['referral_code'] = $this->generateReferralCode();
        }

        // Hash password
        $data['password'] = Auth::hashPassword($data['password']);

        // Set timestamps
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');

        // Create user
        return $this->insert($data);
    }

    /**
     * Update user
     *
     * @param int $id User ID
     * @param array $data User data
     * @return bool Success flag
     */
    public function update($id, $data)
    {
        // Don't allow updating email to an existing email
        if (isset($data['email'])) {
            $existingUser = $this->findByEmail($data['email']);
            if ($existingUser && $existingUser->id != $id) {
                return false;
            }
        }

        // Hash password if provided
        if (isset($data['password']) && !empty($data['password'])) {
            $data['password'] = Auth::hashPassword($data['password']);
        } elseif (isset($data['password']) && empty($data['password'])) {
            // Don't update empty password
            unset($data['password']);
        }

        // Set updated timestamp
        $data['updated_at'] = date('Y-m-d H:i:s');

        // Update user
        return $this->updateById($id, $data);
    }

    /**
     * Verify user email
     *
     * @param string $token Verification token
     * @return bool Success flag
     */
    public function verifyEmail($token)
    {
        $user = $this->findByVerificationToken($token);

        if (!$user) {
            return false;
        }

        $data = [
            'email_verified' => 1,
            'email_verification_token' => null,
            'status' => self::STATUS_ACTIVE,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->updateById($user->id, $data);
    }

    /**
     * Request password reset
     *
     * @param string $email User email
     * @return string|false Reset token or false on failure
     */
    public function requestPasswordReset($email)
    {
        $user = $this->findByEmail($email);

        if (!$user) {
            return false;
        }

        $token = Helper::generateToken();
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $data = [
            'password_reset_token' => $token,
            'password_reset_expires' => $expires,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $success = $this->updateById($user->id, $data);

        return $success ? $token : false;
    }

    /**
     * Reset password using token
     *
     * @param string $token Reset token
     * @param string $password New password
     * @return bool Success flag
     */
    public function resetPassword($token, $password)
    {
        $user = $this->findByPasswordResetToken($token);

        if (!$user) {
            return false;
        }

        $data = [
            'password' => Auth::hashPassword($password),
            'password_reset_token' => null,
            'password_reset_expires' => null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->updateById($user->id, $data);
    }

    /**
     * Update login information
     *
     * @param int $userId User ID
     * @param string $ip IP address
     * @return bool Success flag
     */
    public function updateLoginInfo($userId, $ip)
    {
        $user = $this->findById($userId);

        if (!$user) {
            return false;
        }

        $data = [
            'last_login' => date('Y-m-d H:i:s'),
            'last_ip' => $ip,
            'login_count' => $user->login_count + 1,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->updateById($userId, $data);
    }

    /**
     * Update user preferences
     *
     * @param int $userId User ID
     * @param array $preferences Preferences array
     * @return bool Success flag
     */
    public function updatePreferences($userId, $preferences)
    {
        $user = $this->findById($userId);

        if (!$user) {
            return false;
        }

        $existingPreferences = [];

        if (!empty($user->preferences)) {
            $existingPreferences = json_decode($user->preferences, true);

            if (!is_array($existingPreferences)) {
                $existingPreferences = [];
            }
        }

        $updatedPreferences = array_merge($existingPreferences, $preferences);

        $data = [
            'preferences' => json_encode($updatedPreferences),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->updateById($userId, $data);
    }

    /**
     * Get user preferences
     *
     * @param int $userId User ID
     * @param string|null $key Specific preference key (optional)
     * @param mixed $default Default value if preference not found
     * @return mixed Preferences array or specific preference value
     */
    public function getPreferences($userId, $key = null, $default = null)
    {
        $user = $this->findById($userId);

        if (!$user || empty($user->preferences)) {
            return $key ? $default : [];
        }

        $preferences = json_decode($user->preferences, true);

        if (!is_array($preferences)) {
            return $key ? $default : [];
        }

        if ($key) {
            return isset($preferences[$key]) ? $preferences[$key] : $default;
        }

        return $preferences;
    }

    /**
     * Update social profiles
     *
     * @param int $userId User ID
     * @param array $profiles Social profiles data
     * @return bool Success flag
     */
    public function updateSocialProfiles($userId, $profiles)
    {
        $user = $this->findById($userId);

        if (!$user) {
            return false;
        }

        $existingProfiles = [];

        if (!empty($user->social_profiles)) {
            $existingProfiles = json_decode($user->social_profiles, true);

            if (!is_array($existingProfiles)) {
                $existingProfiles = [];
            }
        }

        $updatedProfiles = array_merge($existingProfiles, $profiles);

        $data = [
            'social_profiles' => json_encode($updatedProfiles),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->updateById($userId, $data);
    }

    /**
     * Get user social profiles
     *
     * @param int $userId User ID
     * @return array Social profiles
     */
    public function getSocialProfiles($userId)
    {
        $user = $this->findById($userId);

        if (!$user || empty($user->social_profiles)) {
            return [];
        }

        $profiles = json_decode($user->social_profiles, true);

        if (!is_array($profiles)) {
            return [];
        }

        return $profiles;
    }

    /**
     * Change user status
     *
     * @param int $userId User ID
     * @param string $status New status
     * @return bool Success flag
     */
    public function changeStatus($userId, $status)
    {
        $validStatuses = [
            self::STATUS_ACTIVE,
            self::STATUS_INACTIVE,
            self::STATUS_PENDING,
            self::STATUS_SUSPENDED
        ];

        if (!in_array($status, $validStatuses)) {
            return false;
        }

        $data = [
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        return $this->updateById($userId, $data);
    }

    /**
     * Check if user has permission
     *
     * @param int $userId User ID
     * @param string $permission Permission to check
     * @return bool Has permission flag
     */
    public function hasPermission($userId, $permission)
    {
        $user = $this->findById($userId);

        if (!$user) {
            return false;
        }

        // Admin has all permissions
        if ($user->role_id == self::ROLE_ADMIN) {
            return true;
        }

        // Get permissions for user's role
        $rolePermissions = $this->getRolePermissions($user->role_id);

        // Check if permission exists in role permissions
        return in_array($permission, $rolePermissions);
    }

    /**
     * Check if user has feature access
     *
     * @param int $userId User ID
     * @param string $feature Feature to check
     * @return bool Has access flag
     */
    public function hasFeature($userId, $feature)
    {
        $user = $this->findById($userId);

        if (!$user) {
            return false;
        }

        // Admin has all features
        if ($user->role_id == self::ROLE_ADMIN) {
            return true;
        }

        // Get user's subscription
        $subscriptionModel = new Subscription();
        $subscription = $subscriptionModel->findActiveByUser($userId);

        if (!$subscription) {
            // Check if feature is available on free plan
            return $this->isFeatureAvailableOnFree($feature);
        }

        // Get features for this subscription plan
        $planFeatures = $subscriptionModel->getPlanFeatures($subscription->plan_id);

        // Check if feature exists in plan features
        return in_array($feature, $planFeatures);
    }

    /**
     * Get full name
     *
     * @param object $user User object
     * @return string Full name
     */
    public function getFullName($user)
    {
        return trim($user->first_name . ' ' . $user->last_name);
    }

    /**
     * Get user's display name
     *
     * @param object $user User object
     * @return string Display name
     */
    public function getDisplayName($user)
    {
        if (!empty($user->first_name)) {
            return $user->first_name;
        }

        return explode('@', $user->email)[0];
    }

    /**
     * Check if user is admin
     *
     * @param int $userId User ID
     * @return bool Is admin flag
     */
    public function isAdmin($userId)
    {
        $user = $this->findById($userId);

        if (!$user) {
            return false;
        }

        return $user->role_id == self::ROLE_ADMIN;
    }

    /**
     * Get role name
     *
     * @param int $roleId Role ID
     * @return string Role name
     */
    public function getRoleName($roleId)
    {
        $roles = [
            self::ROLE_ADMIN => 'Administrator',
            self::ROLE_MANAGER => 'Manager',
            self::ROLE_USER => 'User'
        ];

        return isset($roles[$roleId]) ? $roles[$roleId] : 'Unknown';
    }

    /**
     * Get all roles
     *
     * @return array Roles
     */
    public function getRoles()
    {
        return [
            self::ROLE_ADMIN => 'Administrator',
            self::ROLE_MANAGER => 'Manager',
            self::ROLE_USER => 'User'
        ];
    }

    /**
     * Get role permissions
     *
     * @param int $roleId Role ID
     * @return array Permissions
     */
    private function getRolePermissions($roleId)
    {
        // In a real implementation, this would come from a database
        // Here we're using a simple array-based approach for demonstration

        $permissions = [
            self::ROLE_ADMIN => [
                // Admin has all permissions
                '*'
            ],
            self::ROLE_MANAGER => [
                // Content permissions
                'content.create',
                'content.edit',
                'content.delete',
                'content.publish',
                'content.schedule',

                // Analytics permissions
                'analytics.view',
                'analytics.export',

                // Account permissions
                'accounts.view',
                'accounts.add',
                'accounts.edit',
                'accounts.remove',

                // User management (limited)
                'users.view',
                'users.invite',

                // Team permissions
                'team.manage',

                // Limited access to other features
                'contentgen.access',
                'marketing.access',
                'seo.access',
                'web.access',
                'crm.access'
            ],
            self::ROLE_USER => [
                // Basic content permissions
                'content.create',
                'content.edit',
                'content.schedule',

                // Basic analytics
                'analytics.view',

                // Account permissions
                'accounts.view',
                'accounts.add',
                'accounts.edit',

                // Limited feature access
                'contentgen.access',
                'marketing.access'
            ]
        ];

        return isset($permissions[$roleId]) ? $permissions[$roleId] : [];
    }

    /**
     * Check if feature is available on free plan
     *
     * @param string $feature Feature to check
     * @return bool Available flag
     */
    private function isFeatureAvailableOnFree($feature)
    {
        // Basic features available on free plan
        $freeFeatures = [
            'analytics_basic',
            'content_basic',
            'scheduling_basic',
            'accounts_limited'
        ];

        return in_array($feature, $freeFeatures);
    }

    /**
     * Generate a unique referral code
     *
     * @return string Referral code
     */
    private function generateReferralCode()
    {
        $code = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));

        // Check if code already exists
        $existingUser = $this->findByReferralCode($code);

        if ($existingUser) {
            // Recursively generate a new code
            return $this->generateReferralCode();
        }

        return $code;
    }

    /**
     * Get user's usage statistics
     *
     * @param int $userId User ID
     * @return array Usage statistics
     */
    public function getUsageStats($userId)
    {
        // In a real implementation, this would calculate usage from various tables
        // Here we're using placeholder data for demonstration

        return [
            'posts_used' => 45,
            'posts_limit' => 100,
            'posts_percent' => 45,

            'scheduled_used' => 15,
            'scheduled_limit' => 50,
            'scheduled_percent' => 30,

            'ai_credits_used' => 120,
            'ai_credits_limit' => 200,
            'ai_credits_percent' => 60,

            'accounts_used' => 3,
            'accounts_limit' => 5,
            'accounts_percent' => 60,

            'storage_used' => 25,  // MB
            'storage_limit' => 100, // MB
            'storage_percent' => 25
        ];
    }
}