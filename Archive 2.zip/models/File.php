<?php

/**
 * File.php
 *
 * مدل مدیریت فایل‌ها برای پروژه ادامه‌ای
 */

namespace App\Models;

use PDO;
use App\Core\Database;
use Exception;

class File {
    private $db;
    private $table = 'files';

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * ذخیره اطلاعات فایل در دیتابیس
     *
     * @param array $data اطلاعات فایل
     * @return int|false شناسه فایل یا false در صورت خطا
     */
    public function saveFileInfo(array $data) {
        try {
            $sql = "INSERT INTO {$this->table} (user_id, file_path, file_url, file_type, file_size, file_name, thumbnail, category, created_at) 
                    VALUES (:user_id, :file_path, :file_url, :file_type, :file_size, :file_name, :thumbnail, :category, :created_at)";

            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $data['user_id'], PDO::PARAM_INT);
            $stmt->bindParam(':file_path', $data['file_path'], PDO::PARAM_STR);
            $stmt->bindParam(':file_url', $data['file_url'], PDO::PARAM_STR);
            $stmt->bindParam(':file_type', $data['file_type'], PDO::PARAM_STR);
            $stmt->bindParam(':file_size', $data['file_size'], PDO::PARAM_INT);
            $stmt->bindParam(':file_name', $data['file_name'], PDO::PARAM_STR);
            $stmt->bindParam(':thumbnail', $data['thumbnail'], PDO::PARAM_STR);
            $stmt->bindParam(':category', $data['category'], PDO::PARAM_STR);
            $stmt->bindParam(':created_at', $data['created_at'], PDO::PARAM_STR);

            $stmt->execute();

            return $this->db->lastInsertId();
        } catch (Exception $e) {
            error_log("Error saving file info: " . $e->getMessage());
            return false;
        }
    }

    /**
     * دریافت اطلاعات فایل با شناسه
     *
     * @param int $file_id شناسه فایل
     * @return array|false اطلاعات فایل یا false در صورت خطا
     */
    public function getFileById($file_id) {
        try {
            $sql = "SELECT * FROM {$this->table} WHERE id = :file_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':file_id', $file_id, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting file: " . $e->getMessage());
            return false;
        }
    }

    /**
     * حذف فایل از دیتابیس
     *
     * @param int $file_id شناسه فایل
     * @return bool موفقیت یا عدم موفقیت حذف
     */
    public function deleteFile($file_id) {
        try {
            $sql = "DELETE FROM {$this->table} WHERE id = :file_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':file_id', $file_id, PDO::PARAM_INT);

            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error deleting file: " . $e->getMessage());
            return false;
        }
    }

    /**
     * دریافت لیست فایل‌های کاربر
     *
     * @param int $user_id شناسه کاربر
     * @param string $category دسته‌بندی فایل (اختیاری)
     * @param int $limit محدودیت تعداد نتایج
     * @param int $offset شروع از
     * @return array لیست فایل‌ها
     */
    public function getUserFiles($user_id, $category = '', $limit = 20, $offset = 0) {
        try {
            $params = [':user_id' => $user_id];
            $sql = "SELECT * FROM {$this->table} WHERE user_id = :user_id";

            if (!empty($category)) {
                $sql .= " AND category = :category";
                $params[':category'] = $category;
            }

            $sql .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";

            $stmt = $this->db->prepare($sql);

            foreach ($params as $key => $value) {
                if ($key === ':user_id') {
                    $stmt->bindValue($key, $value, PDO::PARAM_INT);
                } else {
                    $stmt->bindValue($key, $value, PDO::PARAM_STR);
                }
            }

            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting user files: " . $e->getMessage());
            return [];
        }
    }

    /**
     * شمارش تعداد فایل‌های کاربر
     *
     * @param int $user_id شناسه کاربر
     * @param string $category دسته‌بندی فایل (اختیاری)
     * @return int تعداد فایل‌ها
     */
    public function getUserFilesCount($user_id, $category = '') {
        try {
            $params = [':user_id' => $user_id];
            $sql = "SELECT COUNT(*) FROM {$this->table} WHERE user_id = :user_id";

            if (!empty($category)) {
                $sql .= " AND category = :category";
                $params[':category'] = $category;
            }

            $stmt = $this->db->prepare($sql);

            foreach ($params as $key => $value) {
                if ($key === ':user_id') {
                    $stmt->bindValue($key, $value, PDO::PARAM_INT);
                } else {
                    $stmt->bindValue($key, $value, PDO::PARAM_STR);
                }
            }

            $stmt->execute();

            return (int) $stmt->fetchColumn();
        } catch (Exception $e) {
            error_log("Error counting user files: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * دریافت لیست فایل‌های سیستم (برای ادمین)
     *
     * @param string $category دسته‌بندی فایل (اختیاری)
     * @param int $limit محدودیت تعداد نتایج
     * @param int $offset شروع از
     * @return array لیست فایل‌ها
     */
    public function getAllFiles($category = '', $limit = 20, $offset = 0) {
        try {
            $params = [];
            $sql = "SELECT f.*, u.username, u.email FROM {$this->table} f JOIN users u ON f.user_id = u.id";

            if (!empty($category)) {
                $sql .= " WHERE f.category = :category";
                $params[':category'] = $category;
            }

            $sql .= " ORDER BY f.created_at DESC LIMIT :limit OFFSET :offset";

            $stmt = $this->db->prepare($sql);

            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, PDO::PARAM_STR);
            }

            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting all files: " . $e->getMessage());
            return [];
        }
    }

    /**
     * شمارش تعداد کل فایل‌های سیستم (برای ادمین)
     *
     * @param string $category دسته‌بندی فایل (اختیاری)
     * @return int تعداد فایل‌ها
     */
    public function getAllFilesCount($category = '') {
        try {
            $params = [];
            $sql = "SELECT COUNT(*) FROM {$this->table}";

            if (!empty($category)) {
                $sql .= " WHERE category = :category";
                $params[':category'] = $category;
            }

            $stmt = $this->db->prepare($sql);

            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, PDO::PARAM_STR);
            }

            $stmt->execute();

            return (int) $stmt->fetchColumn();
        } catch (Exception $e) {
            error_log("Error counting all files: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * به‌روزرسانی اطلاعات فایل
     *
     * @param int $file_id شناسه فایل
     * @param array $data اطلاعات جدید
     * @return bool موفقیت یا عدم موفقیت به‌روزرسانی
     */
    public function updateFile($file_id, array $data) {
        try {
            $updates = [];
            $params = [':id' => $file_id];

            foreach ($data as $key => $value) {
                if (in_array($key, ['file_path', 'file_url', 'file_name', 'category', 'thumbnail'])) {
                    $updates[] = "{$key} = :{$key}";
                    $params[":{$key}"] = $value;
                }
            }

            if (empty($updates)) {
                return false;
            }

            $sql = "UPDATE {$this->table} SET " . implode(', ', $updates) . " WHERE id = :id";

            $stmt = $this->db->prepare($sql);

            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }

            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error updating file: " . $e->getMessage());
            return false;
        }
    }

    /**
     * حذف فایل‌های قدیمی براساس تاریخ
     *
     * @param string $date تاریخ (فایل‌های قبل از این تاریخ حذف می‌شوند)
     * @param string $category دسته‌بندی فایل (اختیاری)
     * @return int تعداد فایل‌های حذف شده
     */
    public function deleteOldFiles($date, $category = '') {
        try {
            $params = [':date' => $date];
            $sql = "DELETE FROM {$this->table} WHERE created_at < :date";

            if (!empty($category)) {
                $sql .= " AND category = :category";
                $params[':category'] = $category;
            }

            $stmt = $this->db->prepare($sql);

            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }

            $stmt->execute();

            return $stmt->rowCount();
        } catch (Exception $e) {
            error_log("Error deleting old files: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * SQL برای ایجاد جدول در دیتابیس
     *
     * @return string دستور SQL
     */
    public static function getTableSchema() {
        return "CREATE TABLE IF NOT EXISTS files (
            id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT(11) UNSIGNED NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            file_url VARCHAR(255) NOT NULL,
            file_type VARCHAR(100) NOT NULL,
            file_size INT(11) UNSIGNED NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            thumbnail VARCHAR(255) DEFAULT NULL,
            category VARCHAR(50) NOT NULL DEFAULT 'general',
            created_at DATETIME NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX (user_id),
            INDEX (category),
            INDEX (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;";
    }
}