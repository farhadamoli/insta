<?php

/**
 * lang/fa/general.php
 *
 * فایل ترجمه عمومی فارسی برای پروژه ادامه‌ای
 */

return [
    // عناوین اصلی
    'app_name' => 'ادامه‌ای',
    'app_tagline' => 'پلتفرم جامع نظارت بر رسانه‌های اجتماعی',
    'app_description' => 'ادامه‌ای یک پلتفرم پیشرفته برای نظارت، تحلیل و مدیریت حضور شما در رسانه‌های اجتماعی است.',

    // منوی اصلی
    'menu_home' => 'خانه',
    'menu_dashboard' => 'پیشخوان',
    'menu_monitoring' => 'نظارت',
    'menu_analytics' => 'تحلیل‌ها',
    'menu_reports' => 'گزارش‌ها',
    'menu_subscription' => 'اشتراک',
    'menu_support' => 'پشتیبانی',
    'menu_settings' => 'تنظیمات',

    // عنوان‌های بخش
    'section_title_dashboard' => 'پیشخوان',
    'section_title_monitoring' => 'نظارت بر رسانه‌های اجتماعی',
    'section_title_analytics' => 'تحلیل داده‌ها',
    'section_title_reports' => 'گزارش‌ها',
    'section_title_subscription' => 'مدیریت اشتراک',
    'section_title_support' => 'پشتیبانی',
    'section_title_settings' => 'تنظیمات حساب کاربری',

    // عناوین عمومی
    'title_login' => 'ورود به حساب کاربری',
    'title_register' => 'ثبت‌نام در ادامه‌ای',
    'title_forgot_password' => 'بازیابی رمز عبور',
    'title_reset_password' => 'تغییر رمز عبور',
    'title_profile' => 'پروفایل کاربری',
    'title_edit_profile' => 'ویرایش پروفایل',
    'title_contact_us' => 'تماس با ما',
    'title_about_us' => 'درباره ما',
    'title_privacy_policy' => 'سیاست حفظ حریم خصوصی',
    'title_terms_of_service' => 'شرایط استفاده از خدمات',

    // دکمه‌ها
    'btn_login' => 'ورود',
    'btn_register' => 'ثبت‌نام',
    'btn_logout' => 'خروج',
    'btn_save' => 'ذخیره',
    'btn_cancel' => 'انصراف',
    'btn_delete' => 'حذف',
    'btn_edit' => 'ویرایش',
    'btn_add' => 'افزودن',
    'btn_search' => 'جستجو',
    'btn_submit' => 'ثبت',
    'btn_back' => 'بازگشت',
    'btn_next' => 'بعدی',
    'btn_previous' => 'قبلی',
    'btn_view' => 'مشاهده',
    'btn_download' => 'دانلود',
    'btn_upload' => 'آپلود',
    'btn_send' => 'ارسال',

    // فرم‌ها
    'form_username' => 'نام کاربری',
    'form_password' => 'رمز عبور',
    'form_confirm_password' => 'تکرار رمز عبور',
    'form_email' => 'ایمیل',
    'form_first_name' => 'نام',
    'form_last_name' => 'نام خانوادگی',
    'form_phone' => 'شماره تلفن',
    'form_address' => 'آدرس',
    'form_city' => 'شهر',
    'form_state' => 'استان',
    'form_country' => 'کشور',
    'form_zip' => 'کد پستی',
    'form_company' => 'شرکت/سازمان',
    'form_subject' => 'موضوع',
    'form_message' => 'پیام',
    'form_current_password' => 'رمز عبور فعلی',
    'form_new_password' => 'رمز عبور جدید',
    'form_confirm_new_password' => 'تکرار رمز عبور جدید',

    // پیام‌های خطا
    'error_general' => 'خطایی رخ داده است. لطفا مجددا تلاش کنید.',
    'error_404' => 'صفحه مورد نظر یافت نشد.',
    'error_403' => 'شما اجازه دسترسی به این صفحه را ندارید.',
    'error_500' => 'خطای داخلی سرور رخ داده است.',
    'error_login_failed' => 'نام کاربری یا رمز عبور اشتباه است.',
    'error_registration_failed' => 'ثبت‌نام با خطا مواجه شد.',
    'error_email_exists' => 'این ایمیل قبلا ثبت شده است.',
    'error_username_exists' => 'این نام کاربری قبلا ثبت شده است.',
    'error_password_mismatch' => 'رمز عبور و تکرار آن مطابقت ندارند.',
    'error_password_weak' => 'رمز عبور ضعیف است. لطفا از ترکیبی از حروف، اعداد و نمادها استفاده کنید.',
    'error_invalid_email' => 'فرمت ایمیل نامعتبر است.',
    'error_required_field' => 'این فیلد الزامی است.',
    'error_file_upload' => 'خطا در آپلود فایل.',
    'error_invalid_file_type' => 'نوع فایل نامعتبر است.',
    'error_file_too_large' => 'حجم فایل بیش از حد مجاز است.',

    // پیام‌های موفقیت
    'success_login' => 'ورود موفقیت‌آمیز بود.',
    'success_registration' => 'ثبت‌نام با موفقیت انجام شد.',
    'success_password_reset' => 'رمز عبور با موفقیت تغییر یافت.',
    'success_profile_update' => 'پروفایل با موفقیت به‌روزرسانی شد.',
    'success_email_sent' => 'ایمیل با موفقیت ارسال شد.',
    'success_contact_sent' => 'پیام شما با موفقیت ارسال شد.',
    'success_file_upload' => 'فایل با موفقیت آپلود شد.',
    'success_subscription' => 'اشتراک با موفقیت فعال شد.',

    // زمان و تاریخ
    'date_format' => 'Y/m/d',
    'time_format' => 'H:i',
    'datetime_format' => 'Y/m/d H:i',
    'date_today' => 'امروز',
    'date_yesterday' => 'دیروز',
    'date_tomorrow' => 'فردا',
    'date_days_ago' => ':days روز پیش',
    'date_months_ago' => ':months ماه پیش',
    'date_years_ago' => ':years سال پیش',

    // پاورقی
    'footer_copyright' => 'تمامی حقوق محفوظ است © :year ادامه‌ای',
    'footer_about' => 'درباره ما',
    'footer_privacy' => 'حریم خصوصی',
    'footer_terms' => 'شرایط استفاده',
    'footer_contact' => 'تماس با ما',
    'footer_support' => 'پشتیبانی',
    'footer_follow_us' => 'ما را دنبال کنید',

    // عمومی
    'yes' => 'بله',
    'no' => 'خیر',
    'or' => 'یا',
    'and' => 'و',
    'all' => 'همه',
    'none' => 'هیچ‌کدام',
    'more' => 'بیشتر',
    'less' => 'کمتر',
    'loading' => 'در حال بارگذاری...',
    'show_more' => 'نمایش بیشتر',
    'show_less' => 'نمایش کمتر',
    'search_placeholder' => 'جستجو...',
    'no_results' => 'نتیجه‌ای یافت نشد.',
    'language' => 'زبان',
    'select_language' => 'انتخاب زبان',
    'search_results' => 'نتایج جستجو',
    'confirm_delete' => 'آیا از حذف این مورد اطمینان دارید؟',
    'confirm_action' => 'آیا از انجام این عملیات اطمینان دارید؟',
];