<?php

/**
 * lang/en/general.php
 *
 * English general translation file for Edameye project
 */

return [
    // Main titles
    'app_name' => 'Edameye',
    'app_tagline' => 'Comprehensive Social Media Monitoring Platform',
    'app_description' => 'Edameye is an advanced platform for monitoring, analyzing, and managing your presence on social media.',

    // Main menu
    'menu_home' => 'Home',
    'menu_dashboard' => 'Dashboard',
    'menu_monitoring' => 'Monitoring',
    'menu_analytics' => 'Analytics',
    'menu_reports' => 'Reports',
    'menu_subscription' => 'Subscription',
    'menu_support' => 'Support',
    'menu_settings' => 'Settings',

    // Section titles
    'section_title_dashboard' => 'Dashboard',
    'section_title_monitoring' => 'Social Media Monitoring',
    'section_title_analytics' => 'Data Analytics',
    'section_title_reports' => 'Reports',
    'section_title_subscription' => 'Subscription Management',
    'section_title_support' => 'Support',
    'section_title_settings' => 'Account Settings',

    // Common titles
    'title_login' => 'Login to Your Account',
    'title_register' => 'Register on Edameye',
    'title_forgot_password' => 'Recover Password',
    'title_reset_password' => 'Reset Password',
    'title_profile' => 'User Profile',
    'title_edit_profile' => 'Edit Profile',
    'title_contact_us' => 'Contact Us',
    'title_about_us' => 'About Us',
    'title_privacy_policy' => 'Privacy Policy',
    'title_terms_of_service' => 'Terms of Service',

    // Buttons
    'btn_login' => 'Login',
    'btn_register' => 'Register',
    'btn_logout' => 'Logout',
    'btn_save' => 'Save',
    'btn_cancel' => 'Cancel',
    'btn_delete' => 'Delete',
    'btn_edit' => 'Edit',
    'btn_add' => 'Add',
    'btn_search' => 'Search',
    'btn_submit' => 'Submit',
    'btn_back' => 'Back',
    'btn_next' => 'Next',
    'btn_previous' => 'Previous',
    'btn_view' => 'View',
    'btn_download' => 'Download',
    'btn_upload' => 'Upload',
    'btn_send' => 'Send',

    // Forms
    'form_username' => 'Username',
    'form_password' => 'Password',
    'form_confirm_password' => 'Confirm Password',
    'form_email' => 'Email',
    'form_first_name' => 'First Name',
    'form_last_name' => 'Last Name',
    'form_phone' => 'Phone Number',
    'form_address' => 'Address',
    'form_city' => 'City',
    'form_state' => 'State/Province',
    'form_country' => 'Country',
    'form_zip' => 'Zip/Postal Code',
    'form_company' => 'Company/Organization',
    'form_subject' => 'Subject',
    'form_message' => 'Message',
    'form_current_password' => 'Current Password',
    'form_new_password' => 'New Password',
    'form_confirm_new_password' => 'Confirm New Password',

    // Error messages
    'error_general' => 'An error has occurred. Please try again.',
    'error_404' => 'Page not found.',
    'error_403' => 'You do not have permission to access this page.',
    'error_500' => 'Internal server error has occurred.',
    'error_login_failed' => 'Username or password is incorrect.',
    'error_registration_failed' => 'Registration failed.',
    'error_email_exists' => 'This email is already registered.',
    'error_username_exists' => 'This username is already taken.',
    'error_password_mismatch' => 'Password and confirmation do not match.',
    'error_password_weak' => 'Password is too weak. Please use a combination of letters, numbers, and symbols.',
    'error_invalid_email' => 'Invalid email format.',
    'error_required_field' => 'This field is required.',
    'error_file_upload' => 'Error uploading file.',
    'error_invalid_file_type' => 'Invalid file type.',
    'error_file_too_large' => 'File is too large.',

    // Success messages
    'success_login' => 'Login successful.',
    'success_registration' => 'Registration successful.',
    'success_password_reset' => 'Password has been reset successfully.',
    'success_profile_update' => 'Profile updated successfully.',
    'success_email_sent' => 'Email sent successfully.',
    'success_contact_sent' => 'Your message has been sent successfully.',
    'success_file_upload' => 'File uploaded successfully.',
    'success_subscription' => 'Subscription activated successfully.',

    // Time and date
    'date_format' => 'm/d/Y',
    'time_format' => 'h:i A',
    'datetime_format' => 'm/d/Y h:i A',
    'date_today' => 'Today',
    'date_yesterday' => 'Yesterday',
    'date_tomorrow' => 'Tomorrow',
    'date_days_ago' => ':days days ago',
    'date_months_ago' => ':months months ago',
    'date_years_ago' => ':years years ago',

    // Footer
    'footer_copyright' => 'All rights reserved © :year Edameye',
    'footer_about' => 'About Us',
    'footer_privacy' => 'Privacy Policy',
    'footer_terms' => 'Terms of Service',
    'footer_contact' => 'Contact Us',
    'footer_support' => 'Support',
    'footer_follow_us' => 'Follow Us',

    // General
    'yes' => 'Yes',
    'no' => 'No',
    'or' => 'or',
    'and' => 'and',
    'all' => 'All',
    'none' => 'None',
    'more' => 'More',
    'less' => 'Less',
    'loading' => 'Loading...',
    'show_more' => 'Show More',
    'show_less' => 'Show Less',
    'search_placeholder' => 'Search...',
    'no_results' => 'No results found.',
    'language' => 'Language',
    'select_language' => 'Select Language',
    'search_results' => 'Search Results',
    'confirm_delete' => 'Are you sure you want to delete this item?',
    'confirm_action' => 'Are you sure you want to perform this action?',
];